#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_KeyPlayVideo_type.BP_STRUCT_KeyPlayVideo_type
// Size: 0x18 // Inherited bytes: 0x00
struct FBP_STRUCT_KeyPlayVideo_type {
	// Fields
	int id_0_24DFE6403463542B32EB0F3509F517F4; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString path_1_4F4D7E40361FBD2B6DD1C67D05166158; // Offset: 0x08 // Size: 0x10
};

