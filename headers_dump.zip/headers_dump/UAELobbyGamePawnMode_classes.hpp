#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass UAELobbyGamePawnMode.UAELobbyGamePawnMode_C
// Size: 0x4b0 // Inherited bytes: 0x4a8
struct AUAELobbyGamePawnMode_C : AUAELobbyGameMode {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x4a8 // Size: 0x08

	// Functions

	// Object Name: Function UAELobbyGamePawnMode.UAELobbyGamePawnMode_C.UserConstructionScript
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void UserConstructionScript(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)
};

