#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Reconnect_UIBP.Reconnect_UIBP_C
// Size: 0x278 // Inherited bytes: 0x260
struct UReconnect_UIBP_C : UUserWidget {
	// Fields
	struct UButton* Button_Bg; // Offset: 0x260 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_2; // Offset: 0x268 // Size: 0x08
	struct UTextBlock* TextBlock_Tips; // Offset: 0x270 // Size: 0x08
};

