#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_AchievementCondCfg_type.BP_STRUCT_AchievementCondCfg_type
// Size: 0x48 // Inherited bytes: 0x00
struct FBP_STRUCT_AchievementCondCfg_type {
	// Fields
	struct FString Param1_0_47050D40128D80B525DFCB3D014FCDF1; // Offset: 0x00 // Size: 0x10
	struct FString Param2_1_47060D80128D80B625DFCB3C014FCDF2; // Offset: 0x10 // Size: 0x10
	struct FString Desc_3_2170A480766826080289B3240BF08BD3; // Offset: 0x20 // Size: 0x10
	int ID_4_370328007EDF2F127BDAF901074BF0F4; // Offset: 0x30 // Size: 0x04
	int Param2ID_5_60B090C07F739D252D5348890FCDF794; // Offset: 0x34 // Size: 0x04
	struct FString ProgressDesc_6_64DA39C054D641632DC47F8F0DC7B9E3; // Offset: 0x38 // Size: 0x10
};

