#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct Gameplay.ItemOperationInfo
// Size: 0x20 // Inherited bytes: 0x00
struct FItemOperationInfo {
	// Fields
	struct FItemDefineID DefineID; // Offset: 0x00 // Size: 0x18
	enum class EBattleItemOperationType BattleItemOperationType; // Offset: 0x18 // Size: 0x01
	char Reason; // Offset: 0x19 // Size: 0x01
	char pad_0x1A[0x2]; // Offset: 0x1a // Size: 0x02
	int Count; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.GameModeStateChangedParams
// Size: 0x10 // Inherited bytes: 0x00
struct FGameModeStateChangedParams {
	// Fields
	struct FName GameModeState; // Offset: 0x00 // Size: 0x08
	bool bAliveOnNonePlayer; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x7]; // Offset: 0x09 // Size: 0x07
};

// Object Name: ScriptStruct Gameplay.CollectedEventData
// Size: 0x50 // Inherited bytes: 0x00
struct FCollectedEventData {
	// Fields
	struct TMap<struct FString, struct FString> KeyValueMap; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct Gameplay.HeartBeatData
// Size: 0x18 // Inherited bytes: 0x00
struct FHeartBeatData {
	// Fields
	int AlivePlayerNum; // Offset: 0x00 // Size: 0x04
	int AINum; // Offset: 0x04 // Size: 0x04
	int MonsterNum; // Offset: 0x08 // Size: 0x04
	int ConnectionNum; // Offset: 0x0c // Size: 0x04
	int OnlineNum; // Offset: 0x10 // Size: 0x04
	int HighPingNum; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.VehicleReportEntry
// Size: 0x18 // Inherited bytes: 0x00
struct FVehicleReportEntry {
	// Fields
	uint32_t VehicleID; // Offset: 0x00 // Size: 0x04
	int VehicleShapeType; // Offset: 0x04 // Size: 0x04
	bool IsDestroyed; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
	float FirstAttackedTime; // Offset: 0x0c // Size: 0x04
	float LastAttackedTime; // Offset: 0x10 // Size: 0x04
	bool Drived; // Offset: 0x14 // Size: 0x01
	char pad_0x15[0x3]; // Offset: 0x15 // Size: 0x03
};

// Object Name: ScriptStruct Gameplay.DSAIDropInfo
// Size: 0x20 // Inherited bytes: 0x00
struct FDSAIDropInfo {
	// Fields
	uint64 BattleID; // Offset: 0x00 // Size: 0x08
	int nts; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct TArray<struct FDSAIDropItem> ais; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.DSAIDropItem
// Size: 0x10 // Inherited bytes: 0x00
struct FDSAIDropItem {
	// Fields
	uint64 UId; // Offset: 0x00 // Size: 0x08
	int Time; // Offset: 0x08 // Size: 0x04
	uint8_t hlv; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
};

// Object Name: ScriptStruct Gameplay.GameModeParams
// Size: 0x10 // Inherited bytes: 0x00
struct FGameModeParams {
	// Fields
	struct FName CurrentGameModeState; // Offset: 0x00 // Size: 0x08
	int MaxKillTime; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.BattleData
// Size: 0x08 // Inherited bytes: 0x00
struct FBattleData {
	// Fields
	int WatcherNum; // Offset: 0x00 // Size: 0x04
	int CircleNum; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.GameModeTeamBattleResultData
// Size: 0x88 // Inherited bytes: 0x00
struct FGameModeTeamBattleResultData {
	// Fields
	struct FString Reason; // Offset: 0x00 // Size: 0x10
	int RemainTeamCount; // Offset: 0x10 // Size: 0x04
	int RemainAlivePlayerCount; // Offset: 0x14 // Size: 0x04
	float PlaneDirectionX; // Offset: 0x18 // Size: 0x04
	float PlaneDirectionY; // Offset: 0x1c // Size: 0x04
	struct TMap<struct FString, struct FString> PlayersLogoutTime; // Offset: 0x20 // Size: 0x50
	struct TArray<struct FGameModeCorpsDetailData> RealTimeCorpsRank; // Offset: 0x70 // Size: 0x10
	bool bIsGameTerminator; // Offset: 0x80 // Size: 0x01
	char pad_0x81[0x7]; // Offset: 0x81 // Size: 0x07
};

// Object Name: ScriptStruct Gameplay.GameModeCorpsDetailData
// Size: 0x30 // Inherited bytes: 0x00
struct FGameModeCorpsDetailData {
	// Fields
	struct FString Name; // Offset: 0x00 // Size: 0x10
	int CorpsHeadIcon; // Offset: 0x10 // Size: 0x04
	int KilledNum; // Offset: 0x14 // Size: 0x04
	int SegmentLevel; // Offset: 0x18 // Size: 0x04
	int RealtimeRank; // Offset: 0x1c // Size: 0x04
	int DefeatPlayerNum; // Offset: 0x20 // Size: 0x04
	float TotalDamage; // Offset: 0x24 // Size: 0x04
	float SurvivalTime; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.DSCorpsInfo
// Size: 0x20 // Inherited bytes: 0x00
struct FDSCorpsInfo {
	// Fields
	uint64 CorpsID; // Offset: 0x00 // Size: 0x08
	struct FString CorpsName; // Offset: 0x08 // Size: 0x10
	int Icon; // Offset: 0x18 // Size: 0x04
	int SegmentLevel; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.CharacterOverrideAttrData
// Size: 0x18 // Inherited bytes: 0x00
struct FCharacterOverrideAttrData {
	// Fields
	struct FString AttrName; // Offset: 0x00 // Size: 0x10
	float AttrValue; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.StatueBaseData
// Size: 0x68 // Inherited bytes: 0x00
struct FStatueBaseData {
	// Fields
	struct FString ClassPath; // Offset: 0x00 // Size: 0x10
	struct FString MatPath; // Offset: 0x10 // Size: 0x10
	struct FString TeamFlag; // Offset: 0x20 // Size: 0x10
	struct FString TeamName; // Offset: 0x30 // Size: 0x10
	struct FVector Loc; // Offset: 0x40 // Size: 0x0c
	struct FRotator Rot; // Offset: 0x4c // Size: 0x0c
	struct FVector Scale; // Offset: 0x58 // Size: 0x0c
	char pad_0x64[0x4]; // Offset: 0x64 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.SeasonStatueData
// Size: 0x78 // Inherited bytes: 0x00
struct FSeasonStatueData {
	// Fields
	struct FString Name; // Offset: 0x00 // Size: 0x10
	struct FVector Loc; // Offset: 0x10 // Size: 0x0c
	struct FRotator Rot; // Offset: 0x1c // Size: 0x0c
	struct FVector Scale; // Offset: 0x28 // Size: 0x0c
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
	struct FString Nation; // Offset: 0x38 // Size: 0x10
	int AGender; // Offset: 0x48 // Size: 0x04
	int Head; // Offset: 0x4c // Size: 0x04
	int Hair; // Offset: 0x50 // Size: 0x04
	int WeaponID; // Offset: 0x54 // Size: 0x04
	struct TArray<int> AvatarList; // Offset: 0x58 // Size: 0x10
	struct TArray<struct FGameModePlayerItem> AvatarWithAdditionList; // Offset: 0x68 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.GameModePlayerItem
// Size: 0x18 // Inherited bytes: 0x00
struct FGameModePlayerItem {
	// Fields
	int ItemTableID; // Offset: 0x00 // Size: 0x04
	int Count; // Offset: 0x04 // Size: 0x04
	struct TArray<int> AdditionIntData; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.MissionBoardConfig
// Size: 0x50 // Inherited bytes: 0x00
struct FMissionBoardConfig {
	// Fields
	struct FString ResPath; // Offset: 0x00 // Size: 0x10
	struct FVector Loc; // Offset: 0x10 // Size: 0x0c
	struct FRotator Rot; // Offset: 0x1c // Size: 0x0c
	struct FVector Scale; // Offset: 0x28 // Size: 0x0c
	float Progress; // Offset: 0x34 // Size: 0x04
	struct FString CountOrTime; // Offset: 0x38 // Size: 0x10
	int TipId; // Offset: 0x48 // Size: 0x04
	char pad_0x4C[0x4]; // Offset: 0x4c // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.AdvertisementActorConfig
// Size: 0x50 // Inherited bytes: 0x00
struct FAdvertisementActorConfig {
	// Fields
	struct FString ResPath; // Offset: 0x00 // Size: 0x10
	struct FString HttpImgPath; // Offset: 0x10 // Size: 0x10
	struct FVector Loc; // Offset: 0x20 // Size: 0x0c
	struct FRotator Rot; // Offset: 0x2c // Size: 0x0c
	struct FVector Scale; // Offset: 0x38 // Size: 0x0c
	int ID; // Offset: 0x44 // Size: 0x04
	int CulDistance; // Offset: 0x48 // Size: 0x04
	char pad_0x4C[0x4]; // Offset: 0x4c // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.AirDropBoxInOb
// Size: 0x14 // Inherited bytes: 0x00
struct FAirDropBoxInOb {
	// Fields
	int boxId; // Offset: 0x00 // Size: 0x04
	bool Flying; // Offset: 0x04 // Size: 0x01
	bool IsEmpty; // Offset: 0x05 // Size: 0x01
	char pad_0x6[0x2]; // Offset: 0x06 // Size: 0x02
	struct FVector pos; // Offset: 0x08 // Size: 0x0c
};

// Object Name: ScriptStruct Gameplay.VehicleAvatarReplaceCfg
// Size: 0x30 // Inherited bytes: 0x00
struct FVehicleAvatarReplaceCfg {
	// Fields
	int OriginID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<int> SkinIDList; // Offset: 0x08 // Size: 0x10
	struct TArray<float> ProbabilityDistribute; // Offset: 0x18 // Size: 0x10
	int MaxNum; // Offset: 0x28 // Size: 0x04
	int CurrentNum; // Offset: 0x2c // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.DynamicLoadItem
// Size: 0x40 // Inherited bytes: 0x00
struct FDynamicLoadItem {
	// Fields
	struct TArray<struct FDynamicBuildingGroupTransform> TransArray; // Offset: 0x00 // Size: 0x10
	int ActID; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct FString Path; // Offset: 0x18 // Size: 0x10
	bool IsClearAfterStart; // Offset: 0x28 // Size: 0x01
	bool IsPlayerStartPot; // Offset: 0x29 // Size: 0x01
	char pad_0x2A[0x6]; // Offset: 0x2a // Size: 0x06
	struct TArray<int> PosIdxList; // Offset: 0x30 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.DynamicBuildingGroupTransform
// Size: 0x18 // Inherited bytes: 0x00
struct FDynamicBuildingGroupTransform {
	// Fields
	float LocX; // Offset: 0x00 // Size: 0x04
	float LocY; // Offset: 0x04 // Size: 0x04
	float LocZ; // Offset: 0x08 // Size: 0x04
	float RotX; // Offset: 0x0c // Size: 0x04
	float RotY; // Offset: 0x10 // Size: 0x04
	float RotZ; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.DynamicLoadActors
// Size: 0x10 // Inherited bytes: 0x00
struct FDynamicLoadActors {
	// Fields
	struct TArray<struct AActor*> ActorArray; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.DynamicTriggerConfig
// Size: 0x20 // Inherited bytes: 0x00
struct FDynamicTriggerConfig {
	// Fields
	struct TArray<struct FDynamicTriggerTransform> Transforms; // Offset: 0x00 // Size: 0x10
	struct FString TriggerClassPath; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.DynamicTriggerTransform
// Size: 0x18 // Inherited bytes: 0x00
struct FDynamicTriggerTransform {
	// Fields
	struct FVector Loc; // Offset: 0x00 // Size: 0x0c
	struct FRotator Rot; // Offset: 0x0c // Size: 0x0c
};

// Object Name: ScriptStruct Gameplay.CharacterShootVerifyData
// Size: 0x50 // Inherited bytes: 0x00
struct FCharacterShootVerifyData {
	// Fields
	struct TMap<char, int> ShootVerifyFailed; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct Gameplay.VehicleMoveDragData
// Size: 0x20 // Inherited bytes: 0x00
struct FVehicleMoveDragData {
	// Fields
	struct TArray<struct FVehicleMoveDrag> MoveDrag; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FVehicleMoveDrag> SimulatedMoveDrag; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.VehicleMoveDrag
// Size: 0x28 // Inherited bytes: 0x00
struct FVehicleMoveDrag {
	// Fields
	int Minute; // Offset: 0x00 // Size: 0x04
	char VehicleType; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
	struct TArray<char> Reasons; // Offset: 0x08 // Size: 0x10
	struct TArray<int> Counters; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.ParachuteDragData
// Size: 0x08 // Inherited bytes: 0x00
struct FParachuteDragData {
	// Fields
	uint32_t MyDrag; // Offset: 0x00 // Size: 0x04
	uint32_t OtherDrag; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.CharacterMoveDragData
// Size: 0x20 // Inherited bytes: 0x00
struct FCharacterMoveDragData {
	// Fields
	struct TArray<struct FCharacterMoveDrag> Drag; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FCharacterSimulateMoveDrag> SimulateDrag; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.CharacterSimulateMoveDrag
// Size: 0x10 // Inherited bytes: 0x00
struct FCharacterSimulateMoveDrag {
	// Fields
	int Minute; // Offset: 0x00 // Size: 0x04
	int Count; // Offset: 0x04 // Size: 0x04
	int DragCount; // Offset: 0x08 // Size: 0x04
	int ShakeCount; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.CharacterMoveDrag
// Size: 0x68 // Inherited bytes: 0x00
struct FCharacterMoveDrag {
	// Fields
	int Minute; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TMap<char, int> ReasonCount; // Offset: 0x08 // Size: 0x50
	struct TArray<struct FDistanceDragData> ExceedsDistances; // Offset: 0x58 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.DistanceDragData
// Size: 0x18 // Inherited bytes: 0x00
struct FDistanceDragData {
	// Fields
	float CX; // Offset: 0x00 // Size: 0x04
	float CY; // Offset: 0x04 // Size: 0x04
	float CZ; // Offset: 0x08 // Size: 0x04
	float SX; // Offset: 0x0c // Size: 0x04
	float SY; // Offset: 0x10 // Size: 0x04
	float SZ; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.DSSwitchInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FDSSwitchInfo {
	// Fields
	int KeyNum; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString SValue; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.WeatherInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FWeatherInfo {
	// Fields
	struct FString WeatherLevelName; // Offset: 0x00 // Size: 0x10
	int WeatherID; // Offset: 0x10 // Size: 0x04
	float WeatherTime; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.GameModePlayerTaskData
// Size: 0x18 // Inherited bytes: 0x00
struct FGameModePlayerTaskData {
	// Fields
	int task_id; // Offset: 0x00 // Size: 0x04
	int process; // Offset: 0x04 // Size: 0x04
	struct FString ext_info; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.GameModePlayerPetInfo
// Size: 0x20 // Inherited bytes: 0x00
struct FGameModePlayerPetInfo {
	// Fields
	int PetId; // Offset: 0x00 // Size: 0x04
	int PetLevel; // Offset: 0x04 // Size: 0x04
	int PetCfgId; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct TArray<int> PetAvatarList; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.GameModePlayerUpassInfo
// Size: 0x30 // Inherited bytes: 0x00
struct FGameModePlayerUpassInfo {
	// Fields
	int updateTime; // Offset: 0x00 // Size: 0x04
	int upassLevel; // Offset: 0x04 // Size: 0x04
	int upassScore; // Offset: 0x08 // Size: 0x04
	bool isBattleTitle; // Offset: 0x0c // Size: 0x01
	bool isUI; // Offset: 0x0d // Size: 0x01
	bool battleShow; // Offset: 0x0e // Size: 0x01
	bool isBuy; // Offset: 0x0f // Size: 0x01
	struct FString iconUrl; // Offset: 0x10 // Size: 0x10
	bool mainSwitch; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x3]; // Offset: 0x21 // Size: 0x03
	int upassKeepBuy; // Offset: 0x24 // Size: 0x04
	int upassCurValue; // Offset: 0x28 // Size: 0x04
	int nUpassPrimePlusCard; // Offset: 0x2c // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.DIYMergedTexData
// Size: 0x48 // Inherited bytes: 0x00
struct FDIYMergedTexData {
	// Fields
	struct TArray<struct FDIYOneTexData> TextureList; // Offset: 0x00 // Size: 0x10
	int TexPathID; // Offset: 0x10 // Size: 0x04
	struct FDIYParamData DIYParam; // Offset: 0x14 // Size: 0x30
	int SlotID; // Offset: 0x44 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.DIYParamData
// Size: 0x30 // Inherited bytes: 0x00
struct FDIYParamData {
	// Fields
	int Direction; // Offset: 0x00 // Size: 0x04
	int ColorID; // Offset: 0x04 // Size: 0x04
	float Opacity; // Offset: 0x08 // Size: 0x04
	float Rotation; // Offset: 0x0c // Size: 0x04
	float ScaleX; // Offset: 0x10 // Size: 0x04
	float ScaleY; // Offset: 0x14 // Size: 0x04
	float OffSetX; // Offset: 0x18 // Size: 0x04
	float OffSetY; // Offset: 0x1c // Size: 0x04
	float UClipX; // Offset: 0x20 // Size: 0x04
	float UClipY; // Offset: 0x24 // Size: 0x04
	float VClipX; // Offset: 0x28 // Size: 0x04
	float VClipY; // Offset: 0x2c // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.DIYOneTexData
// Size: 0x34 // Inherited bytes: 0x00
struct FDIYOneTexData {
	// Fields
	int TexPathID; // Offset: 0x00 // Size: 0x04
	struct FDIYParamData DIYParam; // Offset: 0x04 // Size: 0x30
};

// Object Name: ScriptStruct Gameplay.ResponResult
// Size: 0x01 // Inherited bytes: 0x00
struct FResponResult {
	// Fields
	bool bResponed; // Offset: 0x00 // Size: 0x01
};

// Object Name: ScriptStruct Gameplay.WeaponDIYData
// Size: 0x50 // Inherited bytes: 0x01
struct FWeaponDIYData : FResponResult {
	// Fields
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int WeaponID; // Offset: 0x04 // Size: 0x04
	int PlanID; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct TArray<struct FDIYMergedTexData> DIYData; // Offset: 0x10 // Size: 0x10
	struct TArray<int> MatParam; // Offset: 0x20 // Size: 0x10
	struct TArray<int> MirroParam; // Offset: 0x30 // Size: 0x10
	struct TArray<int> SlotMatParam; // Offset: 0x40 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.TLog_ActivityEventType
// Size: 0x10 // Inherited bytes: 0x00
struct FTLog_ActivityEventType {
	// Fields
	char ActivityEventID; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	struct FVector ActivityEventLoc; // Offset: 0x04 // Size: 0x0c
};

// Object Name: ScriptStruct Gameplay.PlayerAnimData
// Size: 0x10 // Inherited bytes: 0x00
struct FPlayerAnimData {
	// Fields
	struct UAnimationAsset* Animation; // Offset: 0x00 // Size: 0x08
	float Rate; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.PlayerVehAnimList
// Size: 0xf8 // Inherited bytes: 0x00
struct FPlayerVehAnimList {
	// Fields
	char pad_0x0[0x4]; // Offset: 0x00 // Size: 0x04
	int FrameCounter; // Offset: 0x04 // Size: 0x04
	struct UAnimationAsset* IdleAnim; // Offset: 0x08 // Size: 0x08
	struct UAnimationAsset* IdleMotorbikeAnim; // Offset: 0x10 // Size: 0x08
	struct UAnimationAsset* VacateMotorbikeAnim; // Offset: 0x18 // Size: 0x08
	struct UAnimationAsset* LeanOutAnim; // Offset: 0x20 // Size: 0x08
	struct UAnimationAsset* LeanInAnim; // Offset: 0x28 // Size: 0x08
	struct UAnimationAsset* AimAnim; // Offset: 0x30 // Size: 0x08
	struct UAnimationAsset* WeaponIdleAddition; // Offset: 0x38 // Size: 0x08
	struct UAnimationAsset* WeaponAimAddition; // Offset: 0x40 // Size: 0x08
	struct UAnimationAsset* WeaponReloadAddition; // Offset: 0x48 // Size: 0x08
	struct UAnimationAsset* SurfBoard_IdleAnim; // Offset: 0x50 // Size: 0x08
	struct UAnimationAsset* SurfBoard_MoveAnim; // Offset: 0x58 // Size: 0x08
	struct UAnimationAsset* SurfBoard_JumpAnim; // Offset: 0x60 // Size: 0x08
	struct UAnimationAsset* SurfBoard_LandAnim; // Offset: 0x68 // Size: 0x08
	struct UAnimationAsset* SurfBoard_JumpLeftTurnAnim; // Offset: 0x70 // Size: 0x08
	struct UAnimationAsset* SurfBoard_JumpRightTurnAnim; // Offset: 0x78 // Size: 0x08
	struct UAnimationAsset* Ski_JumpStationary; // Offset: 0x80 // Size: 0x08
	struct UAnimationAsset* Ski_DownTurnLR; // Offset: 0x88 // Size: 0x08
	struct UAnimationAsset* Ski_DownTurnRL; // Offset: 0x90 // Size: 0x08
	struct UAnimationAsset* Ski_DownTurnFD; // Offset: 0x98 // Size: 0x08
	struct UAnimationAsset* Ski_Falling; // Offset: 0xa0 // Size: 0x08
	struct UAnimationAsset* Ski_DownFallLandingAdditive; // Offset: 0xa8 // Size: 0x08
	struct UAnimationAsset* Ski_DownFallLandingHard; // Offset: 0xb0 // Size: 0x08
	struct UAnimationAsset* VehicleWeaponIdleAnim; // Offset: 0xb8 // Size: 0x08
	struct UAnimationAsset* VehicleWeaponEquipAnim; // Offset: 0xc0 // Size: 0x08
	struct UAnimationAsset* VehicleWeaponUnEquipAnim; // Offset: 0xc8 // Size: 0x08
	struct UAnimationAsset* VehicleWeaponReloadAnim; // Offset: 0xd0 // Size: 0x08
	struct UAnimationAsset* VehicleWeaponAimOffsetAnim; // Offset: 0xd8 // Size: 0x08
	struct UAnimationAsset* MotorgliderSteerAnim; // Offset: 0xe0 // Size: 0x08
	struct UAnimationAsset* MotorgliderIdleAnim; // Offset: 0xe8 // Size: 0x08
	struct UAnimationAsset* VehicleDriverForwardAnim; // Offset: 0xf0 // Size: 0x08
};

// Object Name: ScriptStruct Gameplay.AnchorPlatData
// Size: 0x08 // Inherited bytes: 0x00
struct FAnchorPlatData {
	// Fields
	int AnchorPlatResID; // Offset: 0x00 // Size: 0x04
	int AnchorPlatColorID; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.GameModePlayerParams
// Size: 0x398 // Inherited bytes: 0x00
struct FGameModePlayerParams {
	// Fields
	bool bEnablePlaneBanner; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FString PlanetailResLink; // Offset: 0x08 // Size: 0x10
	uint64 UId; // Offset: 0x18 // Size: 0x08
	struct FString OpenID; // Offset: 0x20 // Size: 0x10
	uint8_t PlatID; // Offset: 0x30 // Size: 0x01
	char pad_0x31[0x7]; // Offset: 0x31 // Size: 0x07
	struct FName PlayerType; // Offset: 0x38 // Size: 0x08
	struct FString PlayerName; // Offset: 0x40 // Size: 0x10
	uint32_t PlayerKey; // Offset: 0x50 // Size: 0x04
	int TeamID; // Offset: 0x54 // Size: 0x04
	int64_t IdxInTeam; // Offset: 0x58 // Size: 0x08
	int PlayerBornPointID; // Offset: 0x60 // Size: 0x04
	bool bTeamLeader; // Offset: 0x64 // Size: 0x01
	bool bIsGM; // Offset: 0x65 // Size: 0x01
	char gender; // Offset: 0x66 // Size: 0x01
	char pad_0x67[0x1]; // Offset: 0x67 // Size: 0x01
	struct FString PIC_URL; // Offset: 0x68 // Size: 0x10
	int Level; // Offset: 0x78 // Size: 0x04
	int Segment_Level; // Offset: 0x7c // Size: 0x04
	int AceImprintShowId; // Offset: 0x80 // Size: 0x04
	int AceImprintBaseId; // Offset: 0x84 // Size: 0x04
	int AvatarBoxId; // Offset: 0x88 // Size: 0x04
	bool bAIPlayer; // Offset: 0x8c // Size: 0x01
	char pad_0x8D[0x3]; // Offset: 0x8d // Size: 0x03
	uint64 MLAIDisplayUID; // Offset: 0x90 // Size: 0x08
	struct TArray<struct FGameModePlayerItem> ItemList; // Offset: 0x98 // Size: 0x10
	struct TArray<struct FGameModePlayerItem> fireworksInfo; // Offset: 0xa8 // Size: 0x10
	struct TArray<int> equip_plating_list; // Offset: 0xb8 // Size: 0x10
	struct TArray<struct FGameModePlayerRolewearInfo> AllWear; // Offset: 0xc8 // Size: 0x10
	int RolewearIndex; // Offset: 0xd8 // Size: 0x04
	char pad_0xDC[0x4]; // Offset: 0xdc // Size: 0x04
	struct TArray<struct FGameModePlayerExpressionItem> ExpressionItemList; // Offset: 0xe0 // Size: 0x10
	struct TArray<struct FGameModePlayerTaskData> TaskDataList; // Offset: 0xf0 // Size: 0x10
	struct TArray<struct FGameModePlayerItem> WeaponAvatarList; // Offset: 0x100 // Size: 0x10
	struct TArray<struct FGameModePlayerItem> VehicleAvatarList; // Offset: 0x110 // Size: 0x10
	struct TArray<struct FVehicleAvatarData> VehicleAdvanceAvatarList; // Offset: 0x120 // Size: 0x10
	struct FGameModePlayerEquipmentAvatar EquipmentAvatar; // Offset: 0x130 // Size: 0x0c
	char pad_0x13C[0x4]; // Offset: 0x13c // Size: 0x04
	struct TArray<struct FGameModeWeaponDIYPlanData> WeaponDIYPlanData; // Offset: 0x140 // Size: 0x10
	int VehicleSkinInReady; // Offset: 0x150 // Size: 0x04
	char pad_0x154[0x4]; // Offset: 0x154 // Size: 0x04
	struct FGameModePlayerAliasInfo AliasInfo; // Offset: 0x158 // Size: 0x48
	struct FGameModePlayerUpassInfo UpassInfo; // Offset: 0x1a0 // Size: 0x30
	struct FGameModePlayerPetInfo PetInfo; // Offset: 0x1d0 // Size: 0x20
	struct TArray<struct FGameModePlayerKnapsackExtInfo> KnapsackExtInfoList; // Offset: 0x1f0 // Size: 0x10
	struct TArray<struct FGameModePlayeWeaponSchemeInfo> WeaponSchemeInfoList; // Offset: 0x200 // Size: 0x10
	int CurWeaponSchemeIndex; // Offset: 0x210 // Size: 0x04
	int PveLevel; // Offset: 0x214 // Size: 0x04
	struct TArray<int> CharSkillList; // Offset: 0x218 // Size: 0x10
	struct FGameModePlayerBanChat banChat; // Offset: 0x228 // Size: 0x18
	struct FGameModePlayerBanChat banTarget; // Offset: 0x240 // Size: 0x18
	struct TArray<struct FSpecialPickItem> SpecialPickItem; // Offset: 0x258 // Size: 0x10
	struct FAchievementPrize EquippedAchievementPrize; // Offset: 0x268 // Size: 0x0c
	char pad_0x274[0x4]; // Offset: 0x274 // Size: 0x04
	struct TArray<int> audioChat; // Offset: 0x278 // Size: 0x10
	struct FName CurrentPlayerState; // Offset: 0x288 // Size: 0x08
	struct FName CurrentCharacterState; // Offset: 0x290 // Size: 0x08
	float SyncedTimestamp; // Offset: 0x298 // Size: 0x04
	float DestinyValue; // Offset: 0x29c // Size: 0x04
	float WarmScore; // Offset: 0x2a0 // Size: 0x04
	float AIAllocMarkValue; // Offset: 0x2a4 // Size: 0x04
	int LeaderCount; // Offset: 0x2a8 // Size: 0x04
	char pad_0x2AC[0x4]; // Offset: 0x2ac // Size: 0x04
	uint64 LastGameLeaderUID; // Offset: 0x2b0 // Size: 0x08
	struct TArray<uint64> LastGameTeammatesUID; // Offset: 0x2b8 // Size: 0x10
	uint64 LastGameBattleID; // Offset: 0x2c8 // Size: 0x08
	float RatingScore; // Offset: 0x2d0 // Size: 0x04
	bool bDoPlayerUseAutoFollow; // Offset: 0x2d4 // Size: 0x01
	char pad_0x2D5[0x3]; // Offset: 0x2d5 // Size: 0x03
	float MaxRankingScore; // Offset: 0x2d8 // Size: 0x04
	bool bIsObserver; // Offset: 0x2dc // Size: 0x01
	char pad_0x2DD[0x3]; // Offset: 0x2dd // Size: 0x03
	uint64 WatchPlayerKey; // Offset: 0x2e0 // Size: 0x08
	bool bIsHawkEyeSpectator; // Offset: 0x2e8 // Size: 0x01
	char pad_0x2E9[0x3]; // Offset: 0x2e9 // Size: 0x03
	int HawkEyeSpectateMaxMatchCount; // Offset: 0x2ec // Size: 0x04
	int HawkEyeSpectateUsedMatchCount; // Offset: 0x2f0 // Size: 0x04
	char PlatformGender; // Offset: 0x2f4 // Size: 0x01
	char pad_0x2F5[0x3]; // Offset: 0x2f5 // Size: 0x03
	int planeAvatarId; // Offset: 0x2f8 // Size: 0x04
	int DyeDebugFlag; // Offset: 0x2fc // Size: 0x04
	struct FString Nation; // Offset: 0x300 // Size: 0x10
	int MatchLabel; // Offset: 0x310 // Size: 0x04
	int AnchorPlatColorID; // Offset: 0x314 // Size: 0x04
	int AnchorPlatResID; // Offset: 0x318 // Size: 0x04
	bool OnlyTeammateSeeAvatar; // Offset: 0x31c // Size: 0x01
	char pad_0x31D[0x3]; // Offset: 0x31d // Size: 0x03
	int64_t LastGameResultTime; // Offset: 0x320 // Size: 0x08
	int64_t CorpsID; // Offset: 0x328 // Size: 0x08
	int64_t CampID; // Offset: 0x330 // Size: 0x08
	bool bUsedSimulation; // Offset: 0x338 // Size: 0x01
	bool bRoomCanKickPlayer; // Offset: 0x339 // Size: 0x01
	bool bCanDownloadInBattle; // Offset: 0x33a // Size: 0x01
	char pad_0x33B[0x5]; // Offset: 0x33b // Size: 0x05
	struct FString IpCountryStr; // Offset: 0x340 // Size: 0x10
	bool bRoomOwner; // Offset: 0x350 // Size: 0x01
	char pad_0x351[0x3]; // Offset: 0x351 // Size: 0x03
	int VeteranRecruitIndex; // Offset: 0x354 // Size: 0x04
	int MatchStrategyLabel; // Offset: 0x358 // Size: 0x04
	char pad_0x35C[0x4]; // Offset: 0x35c // Size: 0x04
	struct TArray<struct FDailyTaskStoreInfo> DailyTaskStoreList; // Offset: 0x360 // Size: 0x10
	int LandId; // Offset: 0x370 // Size: 0x04
	int FollowType; // Offset: 0x374 // Size: 0x04
	uint64 FollowUID; // Offset: 0x378 // Size: 0x08
	uint32_t TaskSyncToDsTs; // Offset: 0x380 // Size: 0x04
	char pad_0x384[0x4]; // Offset: 0x384 // Size: 0x04
	uint64 LuckmateUID; // Offset: 0x388 // Size: 0x08
	int CollectedEventType; // Offset: 0x390 // Size: 0x04
	char pad_0x394[0x4]; // Offset: 0x394 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.DailyTaskStoreInfo
// Size: 0x0c // Inherited bytes: 0x00
struct FDailyTaskStoreInfo {
	// Fields
	int TaskId; // Offset: 0x00 // Size: 0x04
	int State; // Offset: 0x04 // Size: 0x04
	int Progress; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.AchievementPrize
// Size: 0x0c // Inherited bytes: 0x00
struct FAchievementPrize {
	// Fields
	int MedalAvatarID; // Offset: 0x00 // Size: 0x04
	int NotifyTitleAvatarID; // Offset: 0x04 // Size: 0x04
	int ScoreBoardAvatarID; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.SpecialPickItem
// Size: 0x0c // Inherited bytes: 0x00
struct FSpecialPickItem {
	// Fields
	int item_id; // Offset: 0x00 // Size: 0x04
	int cur_count; // Offset: 0x04 // Size: 0x04
	int total_count; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.GameModePlayerBanChat
// Size: 0x18 // Inherited bytes: 0x00
struct FGameModePlayerBanChat {
	// Fields
	int end_time; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString Reason; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.GameModePlayeWeaponSchemeInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FGameModePlayeWeaponSchemeInfo {
	// Fields
	int SchemeIndex; // Offset: 0x00 // Size: 0x04
	bool IsLocked; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
	struct TArray<struct FGameModePlayeWeaponSchemeSlotInfo> SlotList; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.GameModePlayeWeaponSchemeSlotInfo
// Size: 0x20 // Inherited bytes: 0x00
struct FGameModePlayeWeaponSchemeSlotInfo {
	// Fields
	int SlotIndex; // Offset: 0x00 // Size: 0x04
	int ItemID; // Offset: 0x04 // Size: 0x04
	int Count; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct TArray<int> AttachList; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.GameModePlayerKnapsackExtInfo
// Size: 0x68 // Inherited bytes: 0x00
struct FGameModePlayerKnapsackExtInfo {
	// Fields
	struct FGameModePlayerKnapsackSingleInfo KnapsackExtInfo; // Offset: 0x00 // Size: 0x60
	bool IsLocked; // Offset: 0x60 // Size: 0x01
	char pad_0x61[0x3]; // Offset: 0x61 // Size: 0x03
	int WearIndex; // Offset: 0x64 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.GameModePlayerKnapsackSingleInfo
// Size: 0x60 // Inherited bytes: 0x00
struct FGameModePlayerKnapsackSingleInfo {
	// Fields
	int Parachute; // Offset: 0x00 // Size: 0x04
	int BagSkin; // Offset: 0x04 // Size: 0x04
	int HelmetSkin; // Offset: 0x08 // Size: 0x04
	int FlySkin; // Offset: 0x0c // Size: 0x04
	int GrenadeSkin; // Offset: 0x10 // Size: 0x04
	struct FGameModePlayerConsumableAvatar ConsumableAvatarList; // Offset: 0x14 // Size: 0x10
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
	struct TArray<struct FGameModePlayerItem> WeaponList; // Offset: 0x28 // Size: 0x10
	struct TArray<struct FGameModePlayerItem> VehicleSkinList; // Offset: 0x38 // Size: 0x10
	struct TArray<struct FGameModePlayerItem> BackPackPendantList; // Offset: 0x48 // Size: 0x10
	int ShowVehicleSkin; // Offset: 0x58 // Size: 0x04
	int WingmanSkin; // Offset: 0x5c // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.GameModePlayerConsumableAvatar
// Size: 0x10 // Inherited bytes: 0x00
struct FGameModePlayerConsumableAvatar {
	// Fields
	int GrenadeAvatarShoulei; // Offset: 0x00 // Size: 0x04
	int GrenadeAvatarSmoke; // Offset: 0x04 // Size: 0x04
	int GrenadeAvatarStun; // Offset: 0x08 // Size: 0x04
	int GrenadeAvatarBurn; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.GameModePlayerAliasInfo
// Size: 0x48 // Inherited bytes: 0x00
struct FGameModePlayerAliasInfo {
	// Fields
	int AliasID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString AliasTitle; // Offset: 0x08 // Size: 0x10
	struct FString AliasNation; // Offset: 0x18 // Size: 0x10
	int AliasRank; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct FString AliasPartnerName; // Offset: 0x30 // Size: 0x10
	int AliasPartnerRelation; // Offset: 0x40 // Size: 0x04
	int AliasRankID; // Offset: 0x44 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.GameModeWeaponDIYPlanData
// Size: 0x08 // Inherited bytes: 0x00
struct FGameModeWeaponDIYPlanData {
	// Fields
	int WeaponAvatarID; // Offset: 0x00 // Size: 0x04
	int PlanID; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.GameModePlayerEquipmentAvatar
// Size: 0x0c // Inherited bytes: 0x00
struct FGameModePlayerEquipmentAvatar {
	// Fields
	int BagAvatar; // Offset: 0x00 // Size: 0x04
	int HelmetAvatar; // Offset: 0x04 // Size: 0x04
	int ArmorAvatar; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.VehicleAvatarData
// Size: 0x28 // Inherited bytes: 0x00
struct FVehicleAvatarData {
	// Fields
	int VehicleSkinID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<int> VehicleStyleIDList; // Offset: 0x08 // Size: 0x10
	struct TArray<struct FVehicleAvatarStyle> VehicleAvatarStyle; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.VehicleAvatarStyle
// Size: 0x10 // Inherited bytes: 0x00
struct FVehicleAvatarStyle {
	// Fields
	int ModelID; // Offset: 0x00 // Size: 0x04
	int ColorID; // Offset: 0x04 // Size: 0x04
	int PatternID; // Offset: 0x08 // Size: 0x04
	int ParticleID; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.GameModePlayerExpressionItem
// Size: 0x18 // Inherited bytes: 0x18
struct FGameModePlayerExpressionItem : FGameModePlayerItem {
};

// Object Name: ScriptStruct Gameplay.GameModePlayerRolewearInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FGameModePlayerRolewearInfo {
	// Fields
	struct TArray<struct FGameModePlayerItem> RolewearInfo; // Offset: 0x00 // Size: 0x10
	bool IsLocked; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x7]; // Offset: 0x11 // Size: 0x07
};

// Object Name: ScriptStruct Gameplay.GameModeAIPlayerParams
// Size: 0x3a8 // Inherited bytes: 0x398
struct FGameModeAIPlayerParams : FGameModePlayerParams {
	// Fields
	uint8_t AIType; // Offset: 0x394 // Size: 0x01
	uint32_t AILevel; // Offset: 0x398 // Size: 0x04
	bool bMLAIPlayer; // Offset: 0x39c // Size: 0x01
	bool bMLDelivery; // Offset: 0x39d // Size: 0x01
	char pad_0x39F[0x1]; // Offset: 0x39f // Size: 0x01
	uint32_t MLBotType; // Offset: 0x3a0 // Size: 0x04
	char pad_0x3A4[0x4]; // Offset: 0x3a4 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.GameModePlayerBattleResultData
// Size: 0x600 // Inherited bytes: 0x00
struct FGameModePlayerBattleResultData {
	// Fields
	struct FString Reason; // Offset: 0x00 // Size: 0x10
	int RemainingPlayerCount; // Offset: 0x10 // Size: 0x04
	int TotalPlayerCount; // Offset: 0x14 // Size: 0x04
	int RemainingTeamCount; // Offset: 0x18 // Size: 0x04
	int TotalTeamCount; // Offset: 0x1c // Size: 0x04
	bool IsSolo; // Offset: 0x20 // Size: 0x01
	bool IsSafeExit; // Offset: 0x21 // Size: 0x01
	char pad_0x22[0x6]; // Offset: 0x22 // Size: 0x06
	uint64 Killer; // Offset: 0x28 // Size: 0x08
	uint64 killer_ig_uid; // Offset: 0x30 // Size: 0x08
	uint64 KillerAIDisplayUID; // Offset: 0x38 // Size: 0x08
	struct FString KillerName; // Offset: 0x40 // Size: 0x10
	struct FString BeKilledOpenID; // Offset: 0x50 // Size: 0x10
	uint32_t KillerType; // Offset: 0x60 // Size: 0x04
	uint32_t KillerDeliveryType; // Offset: 0x64 // Size: 0x04
	uint32_t DeadCircleIndex; // Offset: 0x68 // Size: 0x04
	int ShootWeaponShotNum; // Offset: 0x6c // Size: 0x04
	int ShootWeaponShotAndHitPlayerNum; // Offset: 0x70 // Size: 0x04
	int ShootWeaponShotAndHitPlayerNumNoAI; // Offset: 0x74 // Size: 0x04
	int ShootWeaponShotHeadNum; // Offset: 0x78 // Size: 0x04
	int ShootWeaponShotHeadNumNoAI; // Offset: 0x7c // Size: 0x04
	int HealTimes; // Offset: 0x80 // Size: 0x04
	char pad_0x84[0x4]; // Offset: 0x84 // Size: 0x04
	struct TArray<struct FString> KillFlow; // Offset: 0x88 // Size: 0x10
	struct TArray<struct FString> KnockOutFlow; // Offset: 0x98 // Size: 0x10
	struct TArray<struct FTLog_PickUpItemFlow> TLog_PickUpItemFlowData; // Offset: 0xa8 // Size: 0x10
	struct TMap<int, struct FTLog_BornLandGrenadeData> TLog_BornLandGrenadeData; // Offset: 0xb8 // Size: 0x50
	int PickUpItemTimes; // Offset: 0x108 // Size: 0x04
	char pad_0x10C[0x4]; // Offset: 0x10c // Size: 0x04
	struct TMap<int, int> TLog_BulletCount; // Offset: 0x110 // Size: 0x50
	uint64 parachute_leader_uid; // Offset: 0x160 // Size: 0x08
	struct TArray<struct FUseItemFlow> UseItemFlow; // Offset: 0x168 // Size: 0x10
	struct TArray<struct FUseBuffFlow> UseBuffFlow; // Offset: 0x178 // Size: 0x10
	struct TArray<struct FBuildingEnterFlow> BuildingEnterFlow; // Offset: 0x188 // Size: 0x10
	struct TArray<struct FDestroyVehicleWheelFlow> DestroyVehicleWheelFlow; // Offset: 0x198 // Size: 0x10
	int destroyVehicleNum; // Offset: 0x1a8 // Size: 0x04
	int is_escape; // Offset: 0x1ac // Size: 0x04
	struct TArray<struct FTLog_KillInfo> PlayerKillAIInfo; // Offset: 0x1b0 // Size: 0x10
	struct TArray<struct FTLog_KillInfo> PlayerNearDeathDuoToAI; // Offset: 0x1c0 // Size: 0x10
	struct FTLog_KillInfo AIKillPlayerInfo; // Offset: 0x1d0 // Size: 0x28
	struct TArray<struct FGameModeTeammateBattleResultData> TeammateList; // Offset: 0x1f8 // Size: 0x10
	struct TArray<struct FGameModeLikeResultData> Like; // Offset: 0x208 // Size: 0x10
	struct TArray<uint64> BeLiked; // Offset: 0x218 // Size: 0x10
	uint32_t Switch; // Offset: 0x228 // Size: 0x04
	char pad_0x22C[0x4]; // Offset: 0x22c // Size: 0x04
	struct TArray<uint32_t> Self; // Offset: 0x230 // Size: 0x10
	struct TArray<struct FGameModeTeammateLableCheckData> LabelCheck; // Offset: 0x240 // Size: 0x10
	struct FVector LandLocation; // Offset: 0x250 // Size: 0x0c
	int LandTime; // Offset: 0x25c // Size: 0x04
	struct FVector ParachuteLocation; // Offset: 0x260 // Size: 0x0c
	struct FVector DeadLocation; // Offset: 0x26c // Size: 0x0c
	struct FString DeadDamangeType; // Offset: 0x278 // Size: 0x10
	int PveDeadAttacker; // Offset: 0x288 // Size: 0x04
	int PveStageId; // Offset: 0x28c // Size: 0x04
	struct FString DeadTimeStr; // Offset: 0x290 // Size: 0x10
	struct FString logoutime; // Offset: 0x2a0 // Size: 0x10
	float Pronetime; // Offset: 0x2b0 // Size: 0x04
	float BeInWaterTime; // Offset: 0x2b4 // Size: 0x04
	float SwimmingDistance; // Offset: 0x2b8 // Size: 0x04
	int BeDownTimes; // Offset: 0x2bc // Size: 0x04
	int BeSavedTimes; // Offset: 0x2c0 // Size: 0x04
	int PickUpAirDrops; // Offset: 0x2c4 // Size: 0x04
	struct FEquipmentData EquipmentData; // Offset: 0x2c8 // Size: 0x70
	int Rank; // Offset: 0x338 // Size: 0x04
	int TotalScore; // Offset: 0x33c // Size: 0x04
	int ProneTimes; // Offset: 0x340 // Size: 0x04
	int CrouchTimes; // Offset: 0x344 // Size: 0x04
	int JumpTimes; // Offset: 0x348 // Size: 0x04
	int TouchDownAreaID; // Offset: 0x34c // Size: 0x04
	int TouchDownLocTypeID; // Offset: 0x350 // Size: 0x04
	char pad_0x354[0x4]; // Offset: 0x354 // Size: 0x04
	struct TArray<int> TouchDownAreaList; // Offset: 0x358 // Size: 0x10
	struct TArray<struct FGameModePlayerTaskData> CompletedTaskList; // Offset: 0x368 // Size: 0x10
	struct TArray<struct FReportCollection> SpecialCollectionList; // Offset: 0x378 // Size: 0x10
	struct TArray<struct FWeaponDamageRecord> WeaponDamageRecordList; // Offset: 0x388 // Size: 0x10
	struct FGrenadeDamageRecord GrenadeDamageRecord; // Offset: 0x398 // Size: 0x28
	struct FKniveDamageRecord KniveDamageRecord; // Offset: 0x3c0 // Size: 0x28
	struct TArray<int> SecretAreaIDList; // Offset: 0x3e8 // Size: 0x10
	int KillNumInVehicle; // Offset: 0x3f8 // Size: 0x04
	float TotalSprintDistance; // Offset: 0x3fc // Size: 0x04
	float TotalBeenDamageAmount; // Offset: 0x400 // Size: 0x04
	float DestroyVehicleWheelNum; // Offset: 0x404 // Size: 0x04
	struct TArray<int> BuildFlow; // Offset: 0x408 // Size: 0x10
	struct TArray<int> DestroyShelterFlow; // Offset: 0x418 // Size: 0x10
	float ShelterTakeDamage; // Offset: 0x428 // Size: 0x04
	float HitShelterDamage; // Offset: 0x42c // Size: 0x04
	struct TArray<struct FVehicleDriveDisData> VehicleDriveDisDataArray; // Offset: 0x430 // Size: 0x10
	struct TArray<struct FKnockOutData> KnockOutList; // Offset: 0x440 // Size: 0x10
	bool IsKickedFromGame; // Offset: 0x450 // Size: 0x01
	char pad_0x451[0x3]; // Offset: 0x451 // Size: 0x03
	int KillMonsterNum; // Offset: 0x454 // Size: 0x04
	int LightCandleNum; // Offset: 0x458 // Size: 0x04
	int KillMagicWalkAI; // Offset: 0x45c // Size: 0x04
	int SendMagicWalkAI; // Offset: 0x460 // Size: 0x04
	float BattleStateTime; // Offset: 0x464 // Size: 0x04
	bool bIsGameTerminator; // Offset: 0x468 // Size: 0x01
	char pad_0x469[0x7]; // Offset: 0x469 // Size: 0x07
	struct TMap<int, int> ActivityButtonCount; // Offset: 0x470 // Size: 0x50
	struct FTLog_SpecialStats TLog_SpecialStats; // Offset: 0x4c0 // Size: 0x08
	float TotalDamage; // Offset: 0x4c8 // Size: 0x04
	int MeleeKillTimes; // Offset: 0x4cc // Size: 0x04
	float MeleeDamageAmount; // Offset: 0x4d0 // Size: 0x04
	float RangedDamagedAmount; // Offset: 0x4d4 // Size: 0x04
	float VehicleDamageAmount; // Offset: 0x4d8 // Size: 0x04
	int OpenAirDropBoxesNum; // Offset: 0x4dc // Size: 0x04
	int FollowState; // Offset: 0x4e0 // Size: 0x04
	char pad_0x4E4[0x4]; // Offset: 0x4e4 // Size: 0x04
	struct TArray<struct FString> DestroyVehicleFlow; // Offset: 0x4e8 // Size: 0x10
	int UseHelicoperNum; // Offset: 0x4f8 // Size: 0x04
	float UseHelicoperDistance; // Offset: 0x4fc // Size: 0x04
	int RevivalNum; // Offset: 0x500 // Size: 0x04
	int BeRevivedNum; // Offset: 0x504 // Size: 0x04
	int DrivingHelicopterTime; // Offset: 0x508 // Size: 0x04
	int InHelicopterTime; // Offset: 0x50c // Size: 0x04
	int SnowBoardJumpActionCount; // Offset: 0x510 // Size: 0x04
	int EmoteOnTelpherCount; // Offset: 0x514 // Size: 0x04
	struct TArray<int> FindBlackMonsterIDs; // Offset: 0x518 // Size: 0x10
	int KillSnowManCount; // Offset: 0x528 // Size: 0x04
	char pad_0x52C[0x4]; // Offset: 0x52c // Size: 0x04
	struct TMap<enum class EEventCounterDefine, int> EventCounterMap; // Offset: 0x530 // Size: 0x50
	struct TMap<int, int> GeneralCounterMap; // Offset: 0x580 // Size: 0x50
	struct FTLog_Micphone MicphoneTlog; // Offset: 0x5d0 // Size: 0x18
	int NormalItemNum; // Offset: 0x5e8 // Size: 0x04
	int SeniorItemNum; // Offset: 0x5ec // Size: 0x04
	struct TArray<struct FSpecialWeaponRecord> SpecicalWeaponRecordList; // Offset: 0x5f0 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.SpecialWeaponRecord
// Size: 0x08 // Inherited bytes: 0x00
struct FSpecialWeaponRecord {
	// Fields
	int WeaponID; // Offset: 0x00 // Size: 0x04
	int FireCount; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.TLog_Micphone
// Size: 0x18 // Inherited bytes: 0x00
struct FTLog_Micphone {
	// Fields
	float TeammateMicrophoneTime; // Offset: 0x00 // Size: 0x04
	float TeammateSpeakerTime; // Offset: 0x04 // Size: 0x04
	float EnemyMicrophoneTime; // Offset: 0x08 // Size: 0x04
	float EnemySpeakerTime; // Offset: 0x0c // Size: 0x04
	float TeammateInterphoneTime; // Offset: 0x10 // Size: 0x04
	float EnemyInterphoneTime; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.TLog_SpecialStats
// Size: 0x08 // Inherited bytes: 0x00
struct FTLog_SpecialStats {
	// Fields
	float MonsterDamageInNight1; // Offset: 0x00 // Size: 0x04
	float MonsterDamageInNight2; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.KnockOutData
// Size: 0x10 // Inherited bytes: 0x00
struct FKnockOutData {
	// Fields
	uint64 AttackerID; // Offset: 0x00 // Size: 0x08
	int Times; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.VehicleDriveDisData
// Size: 0x30 // Inherited bytes: 0x00
struct FVehicleDriveDisData {
	// Fields
	uint64 DriverID; // Offset: 0x00 // Size: 0x08
	int VehicleType; // Offset: 0x08 // Size: 0x04
	int AvatarID; // Offset: 0x0c // Size: 0x04
	float DriveDistance; // Offset: 0x10 // Size: 0x04
	float DriveTime; // Offset: 0x14 // Size: 0x04
	float VehicleJumpDistanceMax; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct TArray<uint64> PeopleInCar; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.KniveDamageRecord
// Size: 0x28 // Inherited bytes: 0x00
struct FKniveDamageRecord {
	// Fields
	int HeadShootCount; // Offset: 0x00 // Size: 0x04
	int LimbsShootCount; // Offset: 0x04 // Size: 0x04
	int BodyShootCount; // Offset: 0x08 // Size: 0x04
	int HandShootCount; // Offset: 0x0c // Size: 0x04
	int FootShootCount; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct TArray<struct FKniveDamageRecordItem> Knives; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.KniveDamageRecordItem
// Size: 0x1c // Inherited bytes: 0x00
struct FKniveDamageRecordItem {
	// Fields
	int WeaponID; // Offset: 0x00 // Size: 0x04
	float TotalDamage; // Offset: 0x04 // Size: 0x04
	int KillCount; // Offset: 0x08 // Size: 0x04
	int KnockNumber; // Offset: 0x0c // Size: 0x04
	int AvatarID; // Offset: 0x10 // Size: 0x04
	int TotalUseTime; // Offset: 0x14 // Size: 0x04
	int TotalOwnTime; // Offset: 0x18 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.GrenadeDamageRecord
// Size: 0x28 // Inherited bytes: 0x00
struct FGrenadeDamageRecord {
	// Fields
	int HitCount; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<int> HitDistanceArray; // Offset: 0x08 // Size: 0x10
	struct TArray<struct FGrenadeDamageRecordItem> Grenades; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.GrenadeDamageRecordItem
// Size: 0x18 // Inherited bytes: 0x00
struct FGrenadeDamageRecordItem {
	// Fields
	int WeaponID; // Offset: 0x00 // Size: 0x04
	float TotalDamage; // Offset: 0x04 // Size: 0x04
	int FireCount; // Offset: 0x08 // Size: 0x04
	int KillCount; // Offset: 0x0c // Size: 0x04
	int KnockNumber; // Offset: 0x10 // Size: 0x04
	int AvatarID; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.WeaponDamageRecord
// Size: 0x60 // Inherited bytes: 0x00
struct FWeaponDamageRecord {
	// Fields
	int WeaponID; // Offset: 0x00 // Size: 0x04
	float TotalDamage; // Offset: 0x04 // Size: 0x04
	int FireCount; // Offset: 0x08 // Size: 0x04
	int HeadShootCount; // Offset: 0x0c // Size: 0x04
	int LimbsShootCount; // Offset: 0x10 // Size: 0x04
	int BodyShootCount; // Offset: 0x14 // Size: 0x04
	int HandShootCount; // Offset: 0x18 // Size: 0x04
	int FootShootCount; // Offset: 0x1c // Size: 0x04
	int UniqueHitCount; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
	struct TArray<int> HitDistanceArray; // Offset: 0x28 // Size: 0x10
	int TotalUseTime; // Offset: 0x38 // Size: 0x04
	int TotalOwnTime; // Offset: 0x3c // Size: 0x04
	int KillCount; // Offset: 0x40 // Size: 0x04
	int KnockNumber; // Offset: 0x44 // Size: 0x04
	struct TArray<int> Associations; // Offset: 0x48 // Size: 0x10
	int AvatarID; // Offset: 0x58 // Size: 0x04
	int DIYPlanID; // Offset: 0x5c // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.ReportCollection
// Size: 0x08 // Inherited bytes: 0x00
struct FReportCollection {
	// Fields
	int item_id; // Offset: 0x00 // Size: 0x04
	int Count; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.EquipmentData
// Size: 0x70 // Inherited bytes: 0x00
struct FEquipmentData {
	// Fields
	int HelmetID; // Offset: 0x00 // Size: 0x04
	int ArmorID; // Offset: 0x04 // Size: 0x04
	int BackPackID; // Offset: 0x08 // Size: 0x04
	int MainWeapon1ID; // Offset: 0x0c // Size: 0x04
	struct TArray<int> MainWeapon1AttachmentsID; // Offset: 0x10 // Size: 0x10
	int MainWeapon2ID; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
	struct TArray<int> MainWeapon2AttachmentsID; // Offset: 0x28 // Size: 0x10
	int ViceWeaponID; // Offset: 0x38 // Size: 0x04
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
	struct TArray<int> ViceWeaponAttachmentsID; // Offset: 0x40 // Size: 0x10
	int CloseWeaponID; // Offset: 0x50 // Size: 0x04
	char pad_0x54[0x4]; // Offset: 0x54 // Size: 0x04
	struct TArray<int> ThrowWeaponsID; // Offset: 0x58 // Size: 0x10
	uint8_t IsLuckyClothing; // Offset: 0x68 // Size: 0x01
	char pad_0x69[0x7]; // Offset: 0x69 // Size: 0x07
};

// Object Name: ScriptStruct Gameplay.GameModeTeammateLableCheckData
// Size: 0x10 // Inherited bytes: 0x00
struct FGameModeTeammateLableCheckData {
	// Fields
	uint32_t Mask; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	uint64 UId; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct Gameplay.GameModeLikeResultData
// Size: 0x18 // Inherited bytes: 0x00
struct FGameModeLikeResultData {
	// Fields
	struct TArray<uint32_t> Like; // Offset: 0x00 // Size: 0x10
	uint64 UId; // Offset: 0x10 // Size: 0x08
};

// Object Name: ScriptStruct Gameplay.GameModeTeammateBattleResultData
// Size: 0x1c0 // Inherited bytes: 0x00
struct FGameModeTeammateBattleResultData {
	// Fields
	struct FString Name; // Offset: 0x00 // Size: 0x10
	uint64 UId; // Offset: 0x10 // Size: 0x08
	int Kill; // Offset: 0x18 // Size: 0x04
	int AIKills; // Offset: 0x1c // Size: 0x04
	struct FString State; // Offset: 0x20 // Size: 0x10
	float travelDistance; // Offset: 0x30 // Size: 0x04
	float marchDistance; // Offset: 0x34 // Size: 0x04
	float DriveDistance; // Offset: 0x38 // Size: 0x04
	float MonsterCatchupDistance; // Offset: 0x3c // Size: 0x04
	float DamageAmount; // Offset: 0x40 // Size: 0x04
	float HealAmount; // Offset: 0x44 // Size: 0x04
	int AssistNum; // Offset: 0x48 // Size: 0x04
	char pad_0x4C[0x4]; // Offset: 0x4c // Size: 0x04
	struct TArray<uint64> AssistTeammatesList; // Offset: 0x50 // Size: 0x10
	int HeadShotNum; // Offset: 0x60 // Size: 0x04
	int HeadShotNumNoAI; // Offset: 0x64 // Size: 0x04
	float surviveTime; // Offset: 0x68 // Size: 0x04
	int rescueTimes; // Offset: 0x6c // Size: 0x04
	struct TArray<uint64> RescueTeammatesList; // Offset: 0x70 // Size: 0x10
	int DestroyVehicles; // Offset: 0x80 // Size: 0x04
	char pad_0x84[0x4]; // Offset: 0x84 // Size: 0x04
	struct TArray<struct FString> KillFlow; // Offset: 0x88 // Size: 0x10
	struct TArray<struct FString> KnockOutFlow; // Offset: 0x98 // Size: 0x10
	float OutsideBlueCircleTime; // Offset: 0xa8 // Size: 0x04
	char pad_0xAC[0x4]; // Offset: 0xac // Size: 0x04
	struct TArray<struct FVehicleDriveDisData> VehicleDriveDisDataArray; // Offset: 0xb0 // Size: 0x10
	int FirstOpenedAirDropBoxNum; // Offset: 0xc0 // Size: 0x04
	float HitEnemyHeadAmount; // Offset: 0xc4 // Size: 0x04
	float TotalBeenDamageAmount; // Offset: 0xc8 // Size: 0x04
	char pad_0xCC[0x4]; // Offset: 0xcc // Size: 0x04
	struct TArray<struct FPlayEmoteData> FPlayEmoteDataArray; // Offset: 0xd0 // Size: 0x10
	int FirstOpenedPlayerTombBoxNum; // Offset: 0xe0 // Size: 0x04
	float InDamageAmount; // Offset: 0xe4 // Size: 0x04
	int ProneTimes; // Offset: 0xe8 // Size: 0x04
	int CrouchTimes; // Offset: 0xec // Size: 0x04
	int JumpTimes; // Offset: 0xf0 // Size: 0x04
	int KillMonsterNum; // Offset: 0xf4 // Size: 0x04
	struct TMap<int, int> MonsterID2KillNum; // Offset: 0xf8 // Size: 0x50
	int LightCandleNum; // Offset: 0x148 // Size: 0x04
	char pad_0x14C[0x4]; // Offset: 0x14c // Size: 0x04
	struct TMap<int, int> ActivityButtonCount; // Offset: 0x150 // Size: 0x50
	float TotalDamageAmountToMonsters; // Offset: 0x1a0 // Size: 0x04
	float TotalDamageAmountFromMonsters; // Offset: 0x1a4 // Size: 0x04
	int MonsterHeadShotKilledTimes; // Offset: 0x1a8 // Size: 0x04
	int BeMonsterDownTimes; // Offset: 0x1ac // Size: 0x04
	bool bIsGameTerminator; // Offset: 0x1b0 // Size: 0x01
	char pad_0x1B1[0x3]; // Offset: 0x1b1 // Size: 0x03
	int mainWeaponID; // Offset: 0x1b4 // Size: 0x04
	float MaxWeaponAccurate; // Offset: 0x1b8 // Size: 0x04
	float MaxWeaponHeadShotRate; // Offset: 0x1bc // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.PlayEmoteData
// Size: 0x08 // Inherited bytes: 0x00
struct FPlayEmoteData {
	// Fields
	int EmoteIndex; // Offset: 0x00 // Size: 0x04
	int AreaID; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.TLog_KillInfo
// Size: 0x28 // Inherited bytes: 0x00
struct FTLog_KillInfo {
	// Fields
	int FakePlayerID; // Offset: 0x00 // Size: 0x04
	int DeadTime; // Offset: 0x04 // Size: 0x04
	int AILastFightTime; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct TArray<int> PlayerAreas; // Offset: 0x10 // Size: 0x10
	int ArmorID; // Offset: 0x20 // Size: 0x04
	int HelmetID; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.DestroyVehicleWheelFlow
// Size: 0x08 // Inherited bytes: 0x00
struct FDestroyVehicleWheelFlow {
	// Fields
	int AreaID; // Offset: 0x00 // Size: 0x04
	int UseCount; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.BuildingEnterFlow
// Size: 0x58 // Inherited bytes: 0x00
struct FBuildingEnterFlow {
	// Fields
	int BuildingID; // Offset: 0x00 // Size: 0x04
	int EnterCount; // Offset: 0x04 // Size: 0x04
	struct TMap<int, int> AreaCountMap; // Offset: 0x08 // Size: 0x50
};

// Object Name: ScriptStruct Gameplay.UseBuffFlow
// Size: 0x58 // Inherited bytes: 0x00
struct FUseBuffFlow {
	// Fields
	int BuffID; // Offset: 0x00 // Size: 0x04
	int UseCount; // Offset: 0x04 // Size: 0x04
	struct TMap<int, int> AreaCountMap; // Offset: 0x08 // Size: 0x50
};

// Object Name: ScriptStruct Gameplay.UseItemFlow
// Size: 0x58 // Inherited bytes: 0x00
struct FUseItemFlow {
	// Fields
	int ItemSpesificID; // Offset: 0x00 // Size: 0x04
	int UseCount; // Offset: 0x04 // Size: 0x04
	struct TMap<int, int> AreaCountMap; // Offset: 0x08 // Size: 0x50
};

// Object Name: ScriptStruct Gameplay.TLog_BornLandGrenadeData
// Size: 0x10 // Inherited bytes: 0x00
struct FTLog_BornLandGrenadeData {
	// Fields
	int PickupCount; // Offset: 0x00 // Size: 0x04
	int ThrowCount; // Offset: 0x04 // Size: 0x04
	int HitOthersCount; // Offset: 0x08 // Size: 0x04
	int HitedByOthersCount; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.TLog_PickUpItemFlow
// Size: 0x38 // Inherited bytes: 0x00
struct FTLog_PickUpItemFlow {
	// Fields
	int ItemSpesificID; // Offset: 0x00 // Size: 0x04
	int Count; // Offset: 0x04 // Size: 0x04
	struct FVector Location; // Offset: 0x08 // Size: 0x0c
	int SourceType; // Offset: 0x14 // Size: 0x04
	int AdditionalParam; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct FString TimeStr; // Offset: 0x20 // Size: 0x10
	uint64 InstanceID; // Offset: 0x30 // Size: 0x08
};

// Object Name: ScriptStruct Gameplay.GameModePlayerBattleResultData_SuperCold
// Size: 0x38 // Inherited bytes: 0x00
struct FGameModePlayerBattleResultData_SuperCold {
	// Fields
	int MakeFiresNum; // Offset: 0x00 // Size: 0x04
	int DeerBBQNum; // Offset: 0x04 // Size: 0x04
	int ChichenBBQNum; // Offset: 0x08 // Size: 0x04
	int UseKFNum; // Offset: 0x0c // Size: 0x04
	int UseUAVNum; // Offset: 0x10 // Size: 0x04
	int KFUsingTime; // Offset: 0x14 // Size: 0x04
	int UAVUsingTime; // Offset: 0x18 // Size: 0x04
	int SkateboardUsingCount; // Offset: 0x1c // Size: 0x04
	int SkateboardUsingTime; // Offset: 0x20 // Size: 0x04
	int SkateboardUsingDistance; // Offset: 0x24 // Size: 0x04
	struct TArray<struct FKillAnimalData> AnimalKillFlow; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.KillAnimalData
// Size: 0x08 // Inherited bytes: 0x00
struct FKillAnimalData {
	// Fields
	char AnimalType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int KillNum; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.OnePlayerWeapon
// Size: 0x20 // Inherited bytes: 0x00
struct FOnePlayerWeapon {
	// Fields
	struct FString PlayerID; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FWeaponReport> Weapons; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.WeaponReport
// Size: 0x68 // Inherited bytes: 0x00
struct FWeaponReport {
	// Fields
	int WeaponID; // Offset: 0x00 // Size: 0x04
	int FireCount; // Offset: 0x04 // Size: 0x04
	int AdsFireCount; // Offset: 0x08 // Size: 0x04
	int HitCount; // Offset: 0x0c // Size: 0x04
	int UniqueHitCount; // Offset: 0x10 // Size: 0x04
	int KillCount; // Offset: 0x14 // Size: 0x04
	float TotalDamage; // Offset: 0x18 // Size: 0x04
	float TotalMonsterDamage; // Offset: 0x1c // Size: 0x04
	float TotalRealPlayerDamage; // Offset: 0x20 // Size: 0x04
	float TotalNormalAIDamage; // Offset: 0x24 // Size: 0x04
	float TotalMLAIDamage; // Offset: 0x28 // Size: 0x04
	int TotalOwnTime; // Offset: 0x2c // Size: 0x04
	int TotalUseTime; // Offset: 0x30 // Size: 0x04
	int KnockDownCount; // Offset: 0x34 // Size: 0x04
	int HeadShootCount; // Offset: 0x38 // Size: 0x04
	int KillAICount; // Offset: 0x3c // Size: 0x04
	int KnockDownAICount; // Offset: 0x40 // Size: 0x04
	int HeadShootAICount; // Offset: 0x44 // Size: 0x04
	int HitAICount; // Offset: 0x48 // Size: 0x04
	int UniqueHitAICount; // Offset: 0x4c // Size: 0x04
	int UseCount; // Offset: 0x50 // Size: 0x04
	char pad_0x54[0x4]; // Offset: 0x54 // Size: 0x04
	struct TArray<struct FHitFlow> HitFlow; // Offset: 0x58 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.HitFlow
// Size: 0x38 // Inherited bytes: 0x00
struct FHitFlow {
	// Fields
	int AimType; // Offset: 0x00 // Size: 0x04
	int Distance; // Offset: 0x04 // Size: 0x04
	int IsKill; // Offset: 0x08 // Size: 0x04
	float Damage; // Offset: 0x0c // Size: 0x04
	bool bFallOnGround; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x7]; // Offset: 0x11 // Size: 0x07
	struct TArray<char> PlayerStates; // Offset: 0x18 // Size: 0x10
	char HitPos; // Offset: 0x28 // Size: 0x01
	bool IsAI; // Offset: 0x29 // Size: 0x01
	char pad_0x2A[0xe]; // Offset: 0x2a // Size: 0x0e
};

// Object Name: ScriptStruct Gameplay.GameBaseInfo
// Size: 0x80 // Inherited bytes: 0x00
struct FGameBaseInfo {
	// Fields
	struct FString GameSvrId; // Offset: 0x00 // Size: 0x10
	struct FString GameAppID; // Offset: 0x10 // Size: 0x10
	struct FString OpenID; // Offset: 0x20 // Size: 0x10
	uint16_t AreaID; // Offset: 0x30 // Size: 0x02
	uint8_t PlatID; // Offset: 0x32 // Size: 0x01
	char pad_0x33[0x5]; // Offset: 0x33 // Size: 0x05
	struct FString ZoneID; // Offset: 0x38 // Size: 0x10
	uint64 BattleID; // Offset: 0x48 // Size: 0x08
	struct FString UserName; // Offset: 0x50 // Size: 0x10
	uint64 RoleID; // Offset: 0x60 // Size: 0x08
	uint8_t RoleType; // Offset: 0x68 // Size: 0x01
	char pad_0x69[0x7]; // Offset: 0x69 // Size: 0x07
	struct FString PicUrl; // Offset: 0x70 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.DamageInfo
// Size: 0x90 // Inherited bytes: 0x00
struct FDamageInfo {
	// Fields
	uint32_t DamageType; // Offset: 0x00 // Size: 0x04
	bool bIsHeadshot; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
	float Distance; // Offset: 0x08 // Size: 0x04
	uint32_t Time; // Offset: 0x0c // Size: 0x04
	uint32_t DamageValue; // Offset: 0x10 // Size: 0x04
	uint32_t AttackerID; // Offset: 0x14 // Size: 0x04
	struct FVector AttackerLoc; // Offset: 0x18 // Size: 0x0c
	uint32_t AttackerBulletNumInClip; // Offset: 0x24 // Size: 0x04
	uint32_t AttackerSightType; // Offset: 0x28 // Size: 0x04
	uint32_t AttackerWeaponType; // Offset: 0x2c // Size: 0x04
	uint32_t AttackerShotTimes; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
	uint64 AttackerState; // Offset: 0x38 // Size: 0x08
	bool bAttackerMoving; // Offset: 0x40 // Size: 0x01
	char pad_0x41[0x7]; // Offset: 0x41 // Size: 0x07
	uint64 VictimID; // Offset: 0x48 // Size: 0x08
	uint32_t VictimType; // Offset: 0x50 // Size: 0x04
	uint32_t VictimDeliveryType; // Offset: 0x54 // Size: 0x04
	uint32_t CircleIndex; // Offset: 0x58 // Size: 0x04
	struct FVector VictimLoc; // Offset: 0x5c // Size: 0x0c
	uint32_t VictimState; // Offset: 0x68 // Size: 0x04
	bool bVictimInWater; // Offset: 0x6c // Size: 0x01
	char pad_0x6D[0x3]; // Offset: 0x6d // Size: 0x03
	int VictimVehicleType; // Offset: 0x70 // Size: 0x04
	float VictimVelocity; // Offset: 0x74 // Size: 0x04
	uint32_t AttackerAreaID; // Offset: 0x78 // Size: 0x04
	uint32_t AlivePlayerNum; // Offset: 0x7c // Size: 0x04
	uint32_t VictimTeamID; // Offset: 0x80 // Size: 0x04
	int FloorType; // Offset: 0x84 // Size: 0x04
	uint32_t AttackerWeaponAvatarID; // Offset: 0x88 // Size: 0x04
	uint32_t AttackerVehicleShapeType; // Offset: 0x8c // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.ActivityEventReportData
// Size: 0x14 // Inherited bytes: 0x00
struct FActivityEventReportData {
	// Fields
	char EventId; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int Count; // Offset: 0x04 // Size: 0x04
	struct FVector Location; // Offset: 0x08 // Size: 0x0c
};

// Object Name: ScriptStruct Gameplay.SpecialPickItemState
// Size: 0x08 // Inherited bytes: 0x00
struct FSpecialPickItemState {
	// Fields
	int item_id; // Offset: 0x00 // Size: 0x04
	bool bIsCollectionCompleted; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
};

// Object Name: ScriptStruct Gameplay.TLog_PropEquipUnequipFlow
// Size: 0x18 // Inherited bytes: 0x00
struct FTLog_PropEquipUnequipFlow {
	// Fields
	int ItemSpesificID; // Offset: 0x00 // Size: 0x04
	enum class ETLog_BackpackEquipmentSlotType SlotType; // Offset: 0x04 // Size: 0x01
	bool bEquip; // Offset: 0x05 // Size: 0x01
	char pad_0x6[0x2]; // Offset: 0x06 // Size: 0x02
	struct FString TimeStr; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.AIDeliveryTlogData
// Size: 0x58 // Inherited bytes: 0x00
struct FAIDeliveryTlogData {
	// Fields
	uint64 UId; // Offset: 0x00 // Size: 0x08
	struct TMap<uint32_t, struct FAIDeliveryInfo> DeliveryMap; // Offset: 0x08 // Size: 0x50
};

// Object Name: ScriptStruct Gameplay.AIDeliveryInfo
// Size: 0x10 // Inherited bytes: 0x00
struct FAIDeliveryInfo {
	// Fields
	int DeliveryStartTime; // Offset: 0x00 // Size: 0x04
	bool bSuccess; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
	int DeliveryArrivalTime; // Offset: 0x08 // Size: 0x04
	int EventTypeId; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.BuildMaterialData
// Size: 0x08 // Inherited bytes: 0x00
struct FBuildMaterialData {
	// Fields
	int MatID; // Offset: 0x00 // Size: 0x04
	int MatCount; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.MonsterTreasureBoxData
// Size: 0x18 // Inherited bytes: 0x00
struct FMonsterTreasureBoxData {
	// Fields
	float BoxStartTime; // Offset: 0x00 // Size: 0x04
	struct FVector BoxLocation; // Offset: 0x04 // Size: 0x0c
	uint64 BoxStartPlayer; // Offset: 0x10 // Size: 0x08
};

// Object Name: ScriptStruct Gameplay.UAEWindowRepData
// Size: 0x50 // Inherited bytes: 0x00
struct FUAEWindowRepData {
	// Fields
	struct FTransform Transform; // Offset: 0x00 // Size: 0x30
	struct FString PathToLoad; // Offset: 0x30 // Size: 0x10
	int ID; // Offset: 0x40 // Size: 0x04
	bool bBroken; // Offset: 0x44 // Size: 0x01
	char pad_0x45[0x3]; // Offset: 0x45 // Size: 0x03
	struct APawn* LastInstigatorPawn; // Offset: 0x48 // Size: 0x08
};

// Object Name: ScriptStruct Gameplay.WeaponAttrReloadTableStruct
// Size: 0x3e0 // Inherited bytes: 0x00
struct FWeaponAttrReloadTableStruct {
	// Fields
	int KeyID; // Offset: 0x00 // Size: 0x04
	float AutoAimingConfig_InnerRange_Speed; // Offset: 0x04 // Size: 0x04
	float AutoAimingConfig_InnerRange_CenterSpeedRate; // Offset: 0x08 // Size: 0x04
	float AutoAimingConfig_InnerRange_RangeRate; // Offset: 0x0c // Size: 0x04
	float AutoAimingConfig_InnerRange_SpeedRate; // Offset: 0x10 // Size: 0x04
	float AutoAimingConfig_InnerRange_RangeRateSight; // Offset: 0x14 // Size: 0x04
	float AutoAimingConfig_InnerRange_SpeedRateSight; // Offset: 0x18 // Size: 0x04
	float AutoAimingConfig_InnerRange_CrouchRate; // Offset: 0x1c // Size: 0x04
	float AutoAimingConfig_InnerRange_ProneRate; // Offset: 0x20 // Size: 0x04
	float AutoAimingConfig_InnerRange_DyingRate; // Offset: 0x24 // Size: 0x04
	float AutoAimingConfig_InnerRange_DriveVehicleRate; // Offset: 0x28 // Size: 0x04
	float AutoAimingConfig_InnerRange_InVehicleRate; // Offset: 0x2c // Size: 0x04
	float AutoAimingConfig_InnerRange_FreeFallRate; // Offset: 0x30 // Size: 0x04
	float AutoAimingConfig_InnerRange_OpeningRate; // Offset: 0x34 // Size: 0x04
	float AutoAimingConfig_InnerRange_LandingRate; // Offset: 0x38 // Size: 0x04
	float AutoAimingConfig_InnerRange_AdsorbMaxRange; // Offset: 0x3c // Size: 0x04
	float AutoAimingConfig_InnerRange_AdsorbMinRange; // Offset: 0x40 // Size: 0x04
	float AutoAimingConfig_InnerRange_AdsorbMinAttenuationDis; // Offset: 0x44 // Size: 0x04
	float AutoAimingConfig_InnerRange_AdsorbMaxAttenuationDis; // Offset: 0x48 // Size: 0x04
	float AutoAimingConfig_InnerRange_AdsorbActiveMinRange; // Offset: 0x4c // Size: 0x04
	float AutoAimingConfig_OuterRange_Speed; // Offset: 0x50 // Size: 0x04
	float AutoAimingConfig_OuterRange_CenterSpeedRate; // Offset: 0x54 // Size: 0x04
	float AutoAimingConfig_OuterRange_RangeRate; // Offset: 0x58 // Size: 0x04
	float AutoAimingConfig_OuterRange_SpeedRate; // Offset: 0x5c // Size: 0x04
	float AutoAimingConfig_OuterRange_RangeRateSight; // Offset: 0x60 // Size: 0x04
	float AutoAimingConfig_OuterRange_SpeedRateSight; // Offset: 0x64 // Size: 0x04
	float AutoAimingConfig_OuterRange_CrouchRate; // Offset: 0x68 // Size: 0x04
	float AutoAimingConfig_OuterRange_ProneRate; // Offset: 0x6c // Size: 0x04
	float AutoAimingConfig_OuterRange_DyingRate; // Offset: 0x70 // Size: 0x04
	float AutoAimingConfig_OuterRange_DriveVehicleRate; // Offset: 0x74 // Size: 0x04
	float AutoAimingConfig_OuterRange_InVehicleRate; // Offset: 0x78 // Size: 0x04
	float AutoAimingConfig_OuterRange_FreeFallRate; // Offset: 0x7c // Size: 0x04
	float AutoAimingConfig_OuterRange_OpeningRate; // Offset: 0x80 // Size: 0x04
	float AutoAimingConfig_OuterRange_LandingRate; // Offset: 0x84 // Size: 0x04
	float AutoAimingConfig_OuterRange_AdsorbMaxRange; // Offset: 0x88 // Size: 0x04
	float AutoAimingConfig_OuterRange_AdsorbMinRange; // Offset: 0x8c // Size: 0x04
	float AutoAimingConfig_OuterRange_AdsorbMinAttenuationDis; // Offset: 0x90 // Size: 0x04
	float AutoAimingConfig_OuterRange_AdsorbMaxAttenuationDis; // Offset: 0x94 // Size: 0x04
	float AutoAimingConfig_OuterRange_AdsorbActiveMinRange; // Offset: 0x98 // Size: 0x04
	float AutoAimingConfig_ScopeRange_Speed; // Offset: 0x9c // Size: 0x04
	float AutoAimingConfig_ScopeRange_CenterSpeedRate; // Offset: 0xa0 // Size: 0x04
	float AutoAimingConfig_ScopeRange_RangeRate; // Offset: 0xa4 // Size: 0x04
	float AutoAimingConfig_ScopeRange_SpeedRate; // Offset: 0xa8 // Size: 0x04
	float AutoAimingConfig_ScopeRange_RangeRateSight; // Offset: 0xac // Size: 0x04
	float AutoAimingConfig_ScopeRange_SpeedRateSight; // Offset: 0xb0 // Size: 0x04
	float AutoAimingConfig_ScopeRange_CrouchRate; // Offset: 0xb4 // Size: 0x04
	float AutoAimingConfig_ScopeRange_ProneRate; // Offset: 0xb8 // Size: 0x04
	float AutoAimingConfig_ScopeRange_DyingRate; // Offset: 0xbc // Size: 0x04
	float AutoAimingConfig_ScopeRange_DriveVehicleRate; // Offset: 0xc0 // Size: 0x04
	float AutoAimingConfig_ScopeRange_InVehicleRate; // Offset: 0xc4 // Size: 0x04
	float AutoAimingConfig_ScopeRange_FreeFallRate; // Offset: 0xc8 // Size: 0x04
	float AutoAimingConfig_ScopeRange_OpeningRate; // Offset: 0xcc // Size: 0x04
	float AutoAimingConfig_ScopeRange_LandingRate; // Offset: 0xd0 // Size: 0x04
	float AutoAimingConfig_ScopeRange_AdsorbMaxRange; // Offset: 0xd4 // Size: 0x04
	float AutoAimingConfig_ScopeRange_AdsorbMinRange; // Offset: 0xd8 // Size: 0x04
	float AutoAimingConfig_ScopeRange_AdsorbMinAttenuationDis; // Offset: 0xdc // Size: 0x04
	float AutoAimingConfig_ScopeRange_AdsorbMaxAttenuationDis; // Offset: 0xe0 // Size: 0x04
	float AutoAimingConfig_ScopeRange_AdsorbActiveMinRange; // Offset: 0xe4 // Size: 0x04
	float AutoAimingConfig_FollowTimeMax; // Offset: 0xe8 // Size: 0x04
	float AutoAimingConfig_MaxAngle; // Offset: 0xec // Size: 0x04
	int AutoAimingConfig_TriggerBeforeFire; // Offset: 0xf0 // Size: 0x04
	char pad_0xF4[0x4]; // Offset: 0xf4 // Size: 0x04
	struct FString AutoAimingConfig_SpeedCurvePath; // Offset: 0xf8 // Size: 0x10
	struct FString AutoAimingConfig_DistanceCurvePath; // Offset: 0x108 // Size: 0x10
	struct FString AutoAimingConfig_SensitiveCurvePath; // Offset: 0x118 // Size: 0x10
	float AccessoriesVRecoilFactor; // Offset: 0x128 // Size: 0x04
	float AccessoriesHRecoilFactor; // Offset: 0x12c // Size: 0x04
	float AccessoriesRecoveryFactor; // Offset: 0x130 // Size: 0x04
	float RecoilLeftMax; // Offset: 0x134 // Size: 0x04
	float RecoilRightMax; // Offset: 0x138 // Size: 0x04
	float RecoilKickADS; // Offset: 0x13c // Size: 0x04
	float ExtraHitPerformScale; // Offset: 0x140 // Size: 0x04
	float DeviationBase; // Offset: 0x144 // Size: 0x04
	float DeviationBaseAim; // Offset: 0x148 // Size: 0x04
	float DeviationRecoilGain; // Offset: 0x14c // Size: 0x04
	float DeviationRecoilGainAim; // Offset: 0x150 // Size: 0x04
	float DeviationMaxMove; // Offset: 0x154 // Size: 0x04
	float DeviationMoveMultiplier; // Offset: 0x158 // Size: 0x04
	float DeviationStanceJump; // Offset: 0x15c // Size: 0x04
	float DeviationShoulderMultiplier; // Offset: 0x160 // Size: 0x04
	float GameDeviationFactor; // Offset: 0x164 // Size: 0x04
	float HitPartCoffHead; // Offset: 0x168 // Size: 0x04
	float HitPartCoffBody; // Offset: 0x16c // Size: 0x04
	float HitPartCoffLimbs; // Offset: 0x170 // Size: 0x04
	float HitPartCoffHand; // Offset: 0x174 // Size: 0x04
	float HitPartCoffFoot; // Offset: 0x178 // Size: 0x04
	float ZombileHitPartCoffHead; // Offset: 0x17c // Size: 0x04
	float ZombileHitPartCoffBody; // Offset: 0x180 // Size: 0x04
	float ZombileHitPartCoffLimbs; // Offset: 0x184 // Size: 0x04
	float ZombileHitPartCoffHand; // Offset: 0x188 // Size: 0x04
	float ZombileHitPartCoffFoot; // Offset: 0x18c // Size: 0x04
	float BaseImpactDamage; // Offset: 0x190 // Size: 0x04
	float RangeModifier; // Offset: 0x194 // Size: 0x04
	float ReferenceDistance; // Offset: 0x198 // Size: 0x04
	float IgnoreRangeAttenuatDis; // Offset: 0x19c // Size: 0x04
	float ReloadTime; // Offset: 0x1a0 // Size: 0x04
	float ReloadTimeTactical; // Offset: 0x1a4 // Size: 0x04
	float ReloadTimeMagOut; // Offset: 0x1a8 // Size: 0x04
	float ReloadTimeMagIn; // Offset: 0x1ac // Size: 0x04
	float ReloadDurationStart; // Offset: 0x1b0 // Size: 0x04
	float ReloadDurationLoop; // Offset: 0x1b4 // Size: 0x04
	float MaxBulletNumInOneClip; // Offset: 0x1b8 // Size: 0x04
	float InitBulletInClip; // Offset: 0x1bc // Size: 0x04
	float BulletFireSpeed; // Offset: 0x1c0 // Size: 0x04
	float ImpactEffectSkipDistance; // Offset: 0x1c4 // Size: 0x04
	float MaxImpactEffectSkipTime; // Offset: 0x1c8 // Size: 0x04
	int bEnableVehicleShoot; // Offset: 0x1cc // Size: 0x04
	int bEnableLeanOutHolding; // Offset: 0x1d0 // Size: 0x04
	float Bullet_RadialDamageParams_BaseDamage; // Offset: 0x1d4 // Size: 0x04
	float Bullet_RadialDamageParams_MinimumDamage; // Offset: 0x1d8 // Size: 0x04
	float Bullet_RadialDamageParams_DamageInnerRadius; // Offset: 0x1dc // Size: 0x04
	float Bullet_RadialDamageParams_DamageOuterRadius; // Offset: 0x1e0 // Size: 0x04
	float Bullet_RadialDamageParams_DamageFalloff; // Offset: 0x1e4 // Size: 0x04
	float Bullet_MaxNoGravityRange; // Offset: 0x1e8 // Size: 0x04
	float Bullet_LaunchGravityScale; // Offset: 0x1ec // Size: 0x04
	struct FString Bullet_RadialDamageParams_DamageTypeClass; // Offset: 0x1f0 // Size: 0x10
	struct FString ImpactActorTemplatePath; // Offset: 0x200 // Size: 0x10
	struct FString BulletTemplatePath; // Offset: 0x210 // Size: 0x10
	int ReloadWithNoCost; // Offset: 0x220 // Size: 0x04
	char pad_0x224[0x4]; // Offset: 0x224 // Size: 0x04
	struct FString MuzzleFX; // Offset: 0x228 // Size: 0x10
	struct FString ScopeMuzzleFX; // Offset: 0x238 // Size: 0x10
	struct FString RemoteMuzzleFX; // Offset: 0x248 // Size: 0x10
	struct FString LocalSilencerMuzzleFX; // Offset: 0x258 // Size: 0x10
	struct FString ScopeSilencerMuzzleFX; // Offset: 0x268 // Size: 0x10
	struct FString RemoteSilencerMuzzleFX; // Offset: 0x278 // Size: 0x10
	struct FString LocalFiringSuppressorMuzzleFX; // Offset: 0x288 // Size: 0x10
	struct FString ScopeFiringSuppressorMuzzleFX; // Offset: 0x298 // Size: 0x10
	struct FString RemoteFiringSuppressorMuzzleFX; // Offset: 0x2a8 // Size: 0x10
	struct FString LocalCompensatorMuzzleFX; // Offset: 0x2b8 // Size: 0x10
	struct FString ScopeCompensatorMuzzleFX; // Offset: 0x2c8 // Size: 0x10
	struct FString RemoteCompensatorMuzzleFX; // Offset: 0x2d8 // Size: 0x10
	struct FString Bullet_AutonomousFPPFX; // Offset: 0x2e8 // Size: 0x10
	struct FString Bullet_AutonomousTPPFX; // Offset: 0x2f8 // Size: 0x10
	struct FString Bullet_AutonomousGunADSFX; // Offset: 0x308 // Size: 0x10
	struct FString Bullet_OBFPPFX; // Offset: 0x318 // Size: 0x10
	struct FString Bullet_OBTPPFX; // Offset: 0x328 // Size: 0x10
	struct FString Bullet_OBGunADSFX; // Offset: 0x338 // Size: 0x10
	struct FString Bullet_ReplayFPPFX; // Offset: 0x348 // Size: 0x10
	struct FString Bullet_ReplayTPPFX; // Offset: 0x358 // Size: 0x10
	struct FString Bullet_ReplayGunADSFX; // Offset: 0x368 // Size: 0x10
	struct FString Bullet_DefaultFX; // Offset: 0x378 // Size: 0x10
	int bSimulateBulletOptimize; // Offset: 0x388 // Size: 0x04
	char pad_0x38C[0x1c]; // Offset: 0x38c // Size: 0x1c
	int WeaponDurability; // Offset: 0x3a8 // Size: 0x04
	int ShootReduceDurabilityAmount; // Offset: 0x3ac // Size: 0x04
	struct FString CameraShakeNormalPath; // Offset: 0x3b0 // Size: 0x10
	struct FString CameraShakeNearPath; // Offset: 0x3c0 // Size: 0x10
	struct FString CameraShakeAimPath; // Offset: 0x3d0 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.GameDataMining
// Size: 0x48 // Inherited bytes: 0x00
struct FGameDataMining {
	// Fields
	struct FString BattleID; // Offset: 0x00 // Size: 0x10
	struct FVector PlaneStartPoint; // Offset: 0x10 // Size: 0x0c
	struct FVector PlaneEndPoint; // Offset: 0x1c // Size: 0x0c
	struct TArray<struct FCircleDataMining> CircleDataMining; // Offset: 0x28 // Size: 0x10
	struct TArray<struct FGameWatchReport> WatchReport; // Offset: 0x38 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.GameWatchReport
// Size: 0x38 // Inherited bytes: 0x00
struct FGameWatchReport {
	// Fields
	uint16_t AreaID; // Offset: 0x00 // Size: 0x02
	uint8_t PlatID; // Offset: 0x02 // Size: 0x01
	char pad_0x3[0x5]; // Offset: 0x03 // Size: 0x05
	struct FString ZoneID; // Offset: 0x08 // Size: 0x10
	uint64 player_uid; // Offset: 0x18 // Size: 0x08
	float total_time; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
	struct TArray<struct FWatchFlow> watch_flow; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.WatchFlow
// Size: 0x10 // Inherited bytes: 0x00
struct FWatchFlow {
	// Fields
	uint64 UId; // Offset: 0x00 // Size: 0x08
	uint32_t sec; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.CircleDataMining
// Size: 0x14 // Inherited bytes: 0x00
struct FCircleDataMining {
	// Fields
	struct FVector WhiteCircleCenter; // Offset: 0x00 // Size: 0x0c
	bool bDestinyCircle; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
	int LeftPlayerNum; // Offset: 0x10 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.GameModePlayerShowUpassInfo
// Size: 0xa0 // Inherited bytes: 0x00
struct FGameModePlayerShowUpassInfo {
	// Fields
	struct FString PlayerName; // Offset: 0x00 // Size: 0x10
	int updateTime; // Offset: 0x10 // Size: 0x04
	int upassLevel; // Offset: 0x14 // Size: 0x04
	int upassScore; // Offset: 0x18 // Size: 0x04
	int planeAvatarId; // Offset: 0x1c // Size: 0x04
	bool isBattleTitle; // Offset: 0x20 // Size: 0x01
	bool isUI; // Offset: 0x21 // Size: 0x01
	bool battleShow; // Offset: 0x22 // Size: 0x01
	bool isBuy; // Offset: 0x23 // Size: 0x01
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
	struct FString iconUrl; // Offset: 0x28 // Size: 0x10
	struct FString Nation; // Offset: 0x38 // Size: 0x10
	struct FGameModePlayerAliasInfo AliasInfo; // Offset: 0x48 // Size: 0x48
	int upassKeepBuy; // Offset: 0x90 // Size: 0x04
	int upassCurValue; // Offset: 0x94 // Size: 0x04
	int nUpassPrimePlusCard; // Offset: 0x98 // Size: 0x04
	char pad_0x9C[0x4]; // Offset: 0x9c // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.LobbyWatchInfo
// Size: 0x08 // Inherited bytes: 0x00
struct FLobbyWatchInfo {
	// Fields
	uint32_t WatchedPlayerKey; // Offset: 0x00 // Size: 0x04
	bool bIsHawkEyeSpectator; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
};

// Object Name: ScriptStruct Gameplay.VehicleAvatarSkinList
// Size: 0x10 // Inherited bytes: 0x00
struct FVehicleAvatarSkinList {
	// Fields
	struct TArray<int> SkinList; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.GameModeWeaponAvatarData
// Size: 0x08 // Inherited bytes: 0x00
struct FGameModeWeaponAvatarData {
	// Fields
	int ParentID; // Offset: 0x00 // Size: 0x04
	int AvatarSpecificID; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.GameModePlayerItems
// Size: 0x10 // Inherited bytes: 0x00
struct FGameModePlayerItems {
	// Fields
	struct TArray<struct FGameModePlayerItem> Items; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.PlayerOBInfo
// Size: 0x38 // Inherited bytes: 0x00
struct FPlayerOBInfo {
	// Fields
	bool IsEnableOB; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	uint64 UId; // Offset: 0x08 // Size: 0x08
	int ZoneID; // Offset: 0x10 // Size: 0x04
	uint32_t PlayerKey; // Offset: 0x14 // Size: 0x04
	int BattleMode; // Offset: 0x18 // Size: 0x04
	bool ValidBattleInfo; // Offset: 0x1c // Size: 0x01
	char pad_0x1D[0x3]; // Offset: 0x1d // Size: 0x03
	int GameCount; // Offset: 0x20 // Size: 0x04
	int WinCount; // Offset: 0x24 // Size: 0x04
	int TopTenCount; // Offset: 0x28 // Size: 0x04
	int KillNum; // Offset: 0x2c // Size: 0x04
	float KDNum; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.PlayerNetStats
// Size: 0x40 // Inherited bytes: 0x00
struct FPlayerNetStats {
	// Fields
	struct FString ClientAddr; // Offset: 0x00 // Size: 0x10
	struct FString LocalAddr; // Offset: 0x10 // Size: 0x10
	float AvgPing; // Offset: 0x20 // Size: 0x04
	float MaxPing; // Offset: 0x24 // Size: 0x04
	float HighPingPercent; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x14]; // Offset: 0x2c // Size: 0x14
};

// Object Name: ScriptStruct Gameplay.PlayerBaseInfoInOB
// Size: 0x7c // Inherited bytes: 0x00
struct FPlayerBaseInfoInOB {
	// Fields
	struct FVector_NetQuantize Location; // Offset: 0x00 // Size: 0x0c
	int Health; // Offset: 0x0c // Size: 0x04
	int HealthMax; // Offset: 0x10 // Size: 0x04
	int LiveState; // Offset: 0x14 // Size: 0x04
	int KillNum; // Offset: 0x18 // Size: 0x04
	int KillNumBeforeDie; // Offset: 0x1c // Size: 0x04
	uint32_t PlayerKey; // Offset: 0x20 // Size: 0x04
	int GotAirDropNum; // Offset: 0x24 // Size: 0x04
	int MaxKillDistance; // Offset: 0x28 // Size: 0x04
	int Damage; // Offset: 0x2c // Size: 0x04
	int InDamage; // Offset: 0x30 // Size: 0x04
	int Heal; // Offset: 0x34 // Size: 0x04
	int HeadShotNum; // Offset: 0x38 // Size: 0x04
	int KillNumInVehicle; // Offset: 0x3c // Size: 0x04
	int SurvivalTime; // Offset: 0x40 // Size: 0x04
	int DriveDistance; // Offset: 0x44 // Size: 0x04
	int marchDistance; // Offset: 0x48 // Size: 0x04
	int Assists; // Offset: 0x4c // Size: 0x04
	int KillNumByGrenade; // Offset: 0x50 // Size: 0x04
	int Rank; // Offset: 0x54 // Size: 0x04
	bool IsOutsideBlueCircle; // Offset: 0x58 // Size: 0x01
	char pad_0x59[0x3]; // Offset: 0x59 // Size: 0x03
	float OutsideBlueCircleTime; // Offset: 0x5c // Size: 0x04
	int Knockouts; // Offset: 0x60 // Size: 0x04
	int rescueTimes; // Offset: 0x64 // Size: 0x04
	int UseSmokeGrenadeNum; // Offset: 0x68 // Size: 0x04
	int UseFragGrenadeNum; // Offset: 0x6c // Size: 0x04
	int UseBurnGrenadeNum; // Offset: 0x70 // Size: 0x04
	int UseFlashGrenadeNum; // Offset: 0x74 // Size: 0x04
	int CurWeaponID; // Offset: 0x78 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.PlayerStaticInfoInOB
// Size: 0x48 // Inherited bytes: 0x00
struct FPlayerStaticInfoInOB {
	// Fields
	struct FString PlayerName; // Offset: 0x00 // Size: 0x10
	struct FString PlayerOpenID; // Offset: 0x10 // Size: 0x10
	struct FString PicUrl; // Offset: 0x20 // Size: 0x10
	int TeamID; // Offset: 0x30 // Size: 0x04
	char IndexInMap; // Offset: 0x34 // Size: 0x01
	char pad_0x35[0x3]; // Offset: 0x35 // Size: 0x03
	uint64 UId; // Offset: 0x38 // Size: 0x08
	uint32_t PlayerKey; // Offset: 0x40 // Size: 0x04
	char pad_0x44[0x4]; // Offset: 0x44 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.AllStarReportData
// Size: 0x08 // Inherited bytes: 0x00
struct FAllStarReportData {
	// Fields
	bool bShowReportFlag; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int BeReportedNum; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.DailyTaskReportInfo
// Size: 0x30 // Inherited bytes: 0x00
struct FDailyTaskReportInfo {
	// Fields
	uint64 UId; // Offset: 0x00 // Size: 0x08
	uint32_t PlayerKey; // Offset: 0x08 // Size: 0x04
	uint32_t TaskSyncToDsTs; // Offset: 0x0c // Size: 0x04
	struct TArray<struct FDailyTaskStoreInfo> TaskInfo; // Offset: 0x10 // Size: 0x10
	struct TArray<struct FDailyTaskAwardInfo> RewardInfo; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.DailyTaskAwardInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FDailyTaskAwardInfo {
	// Fields
	int TaskId; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FTaskAwardItemInfo> AwardList; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.TaskAwardItemInfo
// Size: 0x08 // Inherited bytes: 0x00
struct FTaskAwardItemInfo {
	// Fields
	int ItemID; // Offset: 0x00 // Size: 0x04
	int ItemNum; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.PlayerInfoInOB
// Size: 0xf8 // Inherited bytes: 0x7c
struct FPlayerInfoInOB : FPlayerBaseInfoInOB {
	// Fields
	char pad_0x7C[0x4]; // Offset: 0x7c // Size: 0x04
	uint64 UId; // Offset: 0x80 // Size: 0x08
	struct FString PlayerName; // Offset: 0x88 // Size: 0x10
	struct FString PlayerOpenID; // Offset: 0x98 // Size: 0x10
	struct FString PicUrl; // Offset: 0xa8 // Size: 0x10
	bool ShowPicUrl; // Offset: 0xb8 // Size: 0x01
	char pad_0xB9[0x3]; // Offset: 0xb9 // Size: 0x03
	int TeamID; // Offset: 0xbc // Size: 0x04
	struct FString TeamName; // Offset: 0xc0 // Size: 0x10
	struct TWeakObjectPtr<struct APawn> Character; // Offset: 0xd0 // Size: 0x08
	bool IsFiring; // Offset: 0xd8 // Size: 0x01
	bool bHasDied; // Offset: 0xd9 // Size: 0x01
	char pad_0xDA[0x1e]; // Offset: 0xda // Size: 0x1e
};

// Object Name: ScriptStruct Gameplay.ParachuteData
// Size: 0x90 // Inherited bytes: 0x00
struct FParachuteData {
	// Fields
	uint64 UId; // Offset: 0x00 // Size: 0x08
	float SlideDuration; // Offset: 0x08 // Size: 0x04
	char FollowState; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
	struct FVector ClientLandLocation; // Offset: 0x10 // Size: 0x0c
	struct FVector ClientLocation; // Offset: 0x1c // Size: 0x0c
	struct FVector ServerLandLocation; // Offset: 0x28 // Size: 0x0c
	float SlideStartTime; // Offset: 0x34 // Size: 0x04
	float SlideEndTime; // Offset: 0x38 // Size: 0x04
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
	struct FString InputCount; // Offset: 0x40 // Size: 0x10
	struct FString PositionCheck; // Offset: 0x50 // Size: 0x10
	struct FString ClientPositionDiff; // Offset: 0x60 // Size: 0x10
	float LastCorrectionTime; // Offset: 0x70 // Size: 0x04
	float LastCorrectionHeight; // Offset: 0x74 // Size: 0x04
	struct FVector LastCorrectionLocation; // Offset: 0x78 // Size: 0x0c
	struct FVector LastCorrectedLocation; // Offset: 0x84 // Size: 0x0c
};

// Object Name: ScriptStruct Gameplay.PlayerPositionFlow
// Size: 0x48 // Inherited bytes: 0x00
struct FPlayerPositionFlow {
	// Fields
	struct FPlayBaseInfo PlayerBaseInfo; // Offset: 0x00 // Size: 0x30
	int FirstPointTimestamp; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
	struct TArray<struct FIntPosition2D> PointList; // Offset: 0x38 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.IntPosition2D
// Size: 0x08 // Inherited bytes: 0x00
struct FIntPosition2D {
	// Fields
	int X; // Offset: 0x00 // Size: 0x04
	int Y; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.PlayBaseInfo
// Size: 0x30 // Inherited bytes: 0x00
struct FPlayBaseInfo {
	// Fields
	uint64 RoleID; // Offset: 0x00 // Size: 0x08
	struct FString OpenID; // Offset: 0x08 // Size: 0x10
	uint8_t PlatID; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x1]; // Offset: 0x19 // Size: 0x01
	uint16_t AreaID; // Offset: 0x1a // Size: 0x02
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct FString ZoneID; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.VehicleMoveFlow
// Size: 0x40 // Inherited bytes: 0x00
struct FVehicleMoveFlow {
	// Fields
	uint64 RoleID; // Offset: 0x00 // Size: 0x08
	struct FString OpenID; // Offset: 0x08 // Size: 0x10
	uint8_t PlatID; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x1]; // Offset: 0x19 // Size: 0x01
	uint16_t AreaID; // Offset: 0x1a // Size: 0x02
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct FString ZoneID; // Offset: 0x20 // Size: 0x10
	struct TArray<struct FVehicleMovePoint> PointList; // Offset: 0x30 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.VehicleMovePoint
// Size: 0x28 // Inherited bytes: 0x00
struct FVehicleMovePoint {
	// Fields
	uint32_t UniqueId; // Offset: 0x00 // Size: 0x04
	uint8_t Type; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
	int X; // Offset: 0x08 // Size: 0x04
	int Y; // Offset: 0x0c // Size: 0x04
	int Z; // Offset: 0x10 // Size: 0x04
	int Speed; // Offset: 0x14 // Size: 0x04
	uint8_t VehicleN2oUse; // Offset: 0x18 // Size: 0x01
	uint8_t VehicleCarPetUse; // Offset: 0x19 // Size: 0x01
	char pad_0x1A[0x2]; // Offset: 0x1a // Size: 0x02
	int VehicleMoveDistance; // Offset: 0x1c // Size: 0x04
	int TimeStamp; // Offset: 0x20 // Size: 0x04
	uint8_t RoleType; // Offset: 0x24 // Size: 0x01
	char pad_0x25[0x3]; // Offset: 0x25 // Size: 0x03
};

// Object Name: ScriptStruct Gameplay.OBPlayerWeaponRecord
// Size: 0x18 // Inherited bytes: 0x00
struct FOBPlayerWeaponRecord {
	// Fields
	uint64 OBPlayerWeaponRecord_UID; // Offset: 0x00 // Size: 0x08
	struct TArray<struct FOBSingleWeaponRecord> WeaponReport; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.OBSingleWeaponRecord
// Size: 0x10 // Inherited bytes: 0x00
struct FOBSingleWeaponRecord {
	// Fields
	int OBSingleWeaponRecord_WeaponID; // Offset: 0x00 // Size: 0x04
	float TotalDamage; // Offset: 0x04 // Size: 0x04
	int KillCount; // Offset: 0x08 // Size: 0x04
	int KnockDownCount; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.AIPlayerInfoInOB
// Size: 0x20 // Inherited bytes: 0x00
struct FAIPlayerInfoInOB {
	// Fields
	struct FString PlayerKey; // Offset: 0x00 // Size: 0x10
	int TeamID; // Offset: 0x10 // Size: 0x04
	struct TWeakObjectPtr<struct APawn> Character; // Offset: 0x14 // Size: 0x08
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.FriendObserver
// Size: 0x18 // Inherited bytes: 0x00
struct FFriendObserver {
	// Fields
	struct FString PlayerName; // Offset: 0x00 // Size: 0x10
	char gender; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x7]; // Offset: 0x11 // Size: 0x07
};

// Object Name: ScriptStruct Gameplay.InfectionSpringUseData
// Size: 0x1c // Inherited bytes: 0x00
struct FInfectionSpringUseData {
	// Fields
	int SpringTag; // Offset: 0x00 // Size: 0x04
	int NormalPlayerUseTimes; // Offset: 0x04 // Size: 0x04
	int AvengerPlayerUseTimes; // Offset: 0x08 // Size: 0x04
	int MotherZombieUseTimes; // Offset: 0x0c // Size: 0x04
	int NormalZombieUseTimes; // Offset: 0x10 // Size: 0x04
	int InvisibleZombieUseTimes; // Offset: 0x14 // Size: 0x04
	int ThrowerZombieUseTimes; // Offset: 0x18 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.InfectionPlayerDeadTlogData
// Size: 0x20 // Inherited bytes: 0x00
struct FInfectionPlayerDeadTlogData {
	// Fields
	int DeadPawnSubType; // Offset: 0x00 // Size: 0x04
	float DeadPosiX; // Offset: 0x04 // Size: 0x04
	float DeadPosiY; // Offset: 0x08 // Size: 0x04
	float DeadPosiZ; // Offset: 0x0c // Size: 0x04
	int KillPawnSubType; // Offset: 0x10 // Size: 0x04
	float KillPosiX; // Offset: 0x14 // Size: 0x04
	float KillPosiY; // Offset: 0x18 // Size: 0x04
	float KillPosiZ; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.InfectionRoundTlogGuidData
// Size: 0x0c // Inherited bytes: 0x00
struct FInfectionRoundTlogGuidData {
	// Fields
	int GuidTriggerCount; // Offset: 0x00 // Size: 0x04
	int GuidHandCloseCount; // Offset: 0x04 // Size: 0x04
	int GuidArriveCloseCount; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.VehicleCampKills
// Size: 0x08 // Inherited bytes: 0x00
struct FVehicleCampKills {
	// Fields
	int CampID; // Offset: 0x00 // Size: 0x04
	int Kills; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.BattleResultData
// Size: 0x88 // Inherited bytes: 0x00
struct FBattleResultData {
	// Fields
	struct FString Reason; // Offset: 0x00 // Size: 0x10
	uint32_t RemainingPlayerCount; // Offset: 0x10 // Size: 0x04
	uint32_t TotalPlayerCount; // Offset: 0x14 // Size: 0x04
	uint32_t RemainingTeamCount; // Offset: 0x18 // Size: 0x04
	uint32_t TotalTeamCount; // Offset: 0x1c // Size: 0x04
	bool IsSolo; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x3]; // Offset: 0x21 // Size: 0x03
	uint32_t ShootWeaponShotNum; // Offset: 0x24 // Size: 0x04
	uint32_t ShootWeaponShotAndHitPlayerNum; // Offset: 0x28 // Size: 0x04
	uint32_t HealTimes; // Offset: 0x2c // Size: 0x04
	float marchDistance; // Offset: 0x30 // Size: 0x04
	float DriveDistance; // Offset: 0x34 // Size: 0x04
	uint32_t destroyVehicleNum; // Offset: 0x38 // Size: 0x04
	uint32_t add_exp; // Offset: 0x3c // Size: 0x04
	uint32_t add_gold; // Offset: 0x40 // Size: 0x04
	char pad_0x44[0x4]; // Offset: 0x44 // Size: 0x04
	uint64 battle_id; // Offset: 0x48 // Size: 0x08
	uint32_t max_game_num; // Offset: 0x50 // Size: 0x04
	uint32_t person_rank; // Offset: 0x54 // Size: 0x04
	uint32_t team_rank; // Offset: 0x58 // Size: 0x04
	char pad_0x5C[0x4]; // Offset: 0x5c // Size: 0x04
	struct TArray<struct FMemBTResultData> BP_ARRAY_TeammateList; // Offset: 0x60 // Size: 0x10
	struct FResultRatingData BP_STRUCT_BTRating; // Offset: 0x70 // Size: 0x18
};

// Object Name: ScriptStruct Gameplay.ResultRatingData
// Size: 0x18 // Inherited bytes: 0x00
struct FResultRatingData {
	// Fields
	int rank_rating; // Offset: 0x00 // Size: 0x04
	int kill_rating; // Offset: 0x04 // Size: 0x04
	int win_rating; // Offset: 0x08 // Size: 0x04
	int change_rank_rating; // Offset: 0x0c // Size: 0x04
	int change_kill_rating; // Offset: 0x10 // Size: 0x04
	int change_win_rating; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.MemBTResultData
// Size: 0x58 // Inherited bytes: 0x00
struct FMemBTResultData {
	// Fields
	struct FString Name; // Offset: 0x00 // Size: 0x10
	uint32_t Kill; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct FString State; // Offset: 0x18 // Size: 0x10
	float travelDistance; // Offset: 0x28 // Size: 0x04
	float DamageAmount; // Offset: 0x2c // Size: 0x04
	float surviveTime; // Offset: 0x30 // Size: 0x04
	uint32_t AssistNum; // Offset: 0x34 // Size: 0x04
	uint32_t HeadShotNum; // Offset: 0x38 // Size: 0x04
	uint32_t rescueTimes; // Offset: 0x3c // Size: 0x04
	float HealAmount; // Offset: 0x40 // Size: 0x04
	char pad_0x44[0x4]; // Offset: 0x44 // Size: 0x04
	uint64 UId; // Offset: 0x48 // Size: 0x08
	uint8_t ShouldShowAddFriendBtn; // Offset: 0x50 // Size: 0x01
	char pad_0x51[0x7]; // Offset: 0x51 // Size: 0x07
};

// Object Name: ScriptStruct Gameplay.VehCharAnimData
// Size: 0x40 // Inherited bytes: 0x00
struct FVehCharAnimData {
	// Fields
	enum class ECharacterVehicleAnimType VehAnimType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct UAnimationAsset* VehAnimSoftPtr; // Offset: 0x08 // Size: 0x28
	char pad_0x30[0x10]; // Offset: 0x30 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.LobbyCharacterWeaponAnimData
// Size: 0x28 // Inherited bytes: 0x00
struct FLobbyCharacterWeaponAnimData {
	// Fields
	enum class ELobbyCharacterPosIndex PosIndex; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FString CharPosName; // Offset: 0x08 // Size: 0x10
	struct TArray<struct FLobbyCharacterGenderWeaponAnimData> GenderWeaponAnimList; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.LobbyCharacterGenderWeaponAnimData
// Size: 0x78 // Inherited bytes: 0x00
struct FLobbyCharacterGenderWeaponAnimData {
	// Fields
	enum class ELobbyCharacterAnimType GenderType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FString GenderTypeName; // Offset: 0x08 // Size: 0x10
	struct UAnimationAsset* WeaponAnimSoftPtr; // Offset: 0x18 // Size: 0x28
	struct UAnimationAsset* WeaponAddAnimSoftPtr; // Offset: 0x40 // Size: 0x28
	struct TArray<struct UAnimationAsset*> WeaponPlayAnimSoftPtrArray; // Offset: 0x68 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.SpotGroupProperty
// Size: 0x28 // Inherited bytes: 0x00
struct FSpotGroupProperty {
	// Fields
	enum class ESpotGroupType SpotGroupType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int SpotGroupPercent; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FSpotTypeProperty> SpotTypeProperties; // Offset: 0x08 // Size: 0x10
	bool bRepeatGenerateItem; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x3]; // Offset: 0x19 // Size: 0x03
	float RepeatGenerateItemCDMin; // Offset: 0x1c // Size: 0x04
	float RepeatGenerateItemCDMax; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.SpotTypeProperty
// Size: 0x38 // Inherited bytes: 0x00
struct FSpotTypeProperty {
	// Fields
	enum class ESpotType SpotType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int SpotPercentMin; // Offset: 0x04 // Size: 0x04
	int SpotPercentMax; // Offset: 0x08 // Size: 0x04
	int SpotPercentDot; // Offset: 0x0c // Size: 0x04
	int ItemPerSpotMin; // Offset: 0x10 // Size: 0x04
	int ItemPerSpotMax; // Offset: 0x14 // Size: 0x04
	struct TArray<struct FSpotWeight> WeightsPerValue; // Offset: 0x18 // Size: 0x10
	struct TArray<struct FSpotWeight> WeightsPerCategory; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.SpotWeight
// Size: 0x18 // Inherited bytes: 0x00
struct FSpotWeight {
	// Fields
	struct FString Name; // Offset: 0x00 // Size: 0x10
	int Weight; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.ItemGenerateSpawnData
// Size: 0x68 // Inherited bytes: 0x00
struct FItemGenerateSpawnData {
	// Fields
	int KeyID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString ItemValue; // Offset: 0x08 // Size: 0x10
	struct FString ItemCategory; // Offset: 0x18 // Size: 0x10
	int ItemWeight; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct FString ItemPath; // Offset: 0x30 // Size: 0x10
	int ItemStackCount; // Offset: 0x40 // Size: 0x04
	char pad_0x44[0x4]; // Offset: 0x44 // Size: 0x04
	struct FString ItemTogetherPath; // Offset: 0x48 // Size: 0x10
	int ItemTogetherStackCount; // Offset: 0x58 // Size: 0x04
	int ItemTogetherCountMin; // Offset: 0x5c // Size: 0x04
	int ItemTogetherCountMax; // Offset: 0x60 // Size: 0x04
	char pad_0x64[0x4]; // Offset: 0x64 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.AIStrategyInfo
// Size: 0x38 // Inherited bytes: 0x00
struct FAIStrategyInfo {
	// Fields
	int64_t TS; // Offset: 0x00 // Size: 0x08
	uint8_t circle; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x7]; // Offset: 0x09 // Size: 0x07
	uint64 BattleID; // Offset: 0x10 // Size: 0x08
	int MapId; // Offset: 0x18 // Size: 0x04
	int rai; // Offset: 0x1c // Size: 0x04
	int fai; // Offset: 0x20 // Size: 0x04
	int zone; // Offset: 0x24 // Size: 0x04
	struct TArray<struct FAIstrategyPlayerTeam> Teams; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.AIstrategyPlayerTeam
// Size: 0x20 // Inherited bytes: 0x00
struct FAIstrategyPlayerTeam {
	// Fields
	struct TArray<struct FAIstrategyPlayerInfo> teamMember; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FString> countries; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.AIstrategyPlayerInfo
// Size: 0x10 // Inherited bytes: 0x00
struct FAIstrategyPlayerInfo {
	// Fields
	struct TArray<uint64> PlayerInfo; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.SpecialPickInfo
// Size: 0x0c // Inherited bytes: 0x00
struct FSpecialPickInfo {
	// Fields
	int item_id; // Offset: 0x00 // Size: 0x04
	int cur_count; // Offset: 0x04 // Size: 0x04
	int total_count; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.CustomAccessoriesData
// Size: 0x0c // Inherited bytes: 0x00
struct FCustomAccessoriesData {
	// Fields
	int WeaponID; // Offset: 0x00 // Size: 0x04
	int Index; // Offset: 0x04 // Size: 0x04
	int ItemID; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.IncNetArray
// Size: 0x20 // Inherited bytes: 0x00
struct FIncNetArray {
	// Fields
	struct TArray<struct FNetArrayUnit> IncArray; // Offset: 0x00 // Size: 0x10
	char pad_0x10[0x10]; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.NetArrayUnit
// Size: 0x50 // Inherited bytes: 0x00
struct FNetArrayUnit {
	// Fields
	struct FBattleItemNet Unit; // Offset: 0x00 // Size: 0x48
	bool bMarkDelete; // Offset: 0x48 // Size: 0x01
	char pad_0x49[0x7]; // Offset: 0x49 // Size: 0x07
};

// Object Name: ScriptStruct Gameplay.BattleItemNet
// Size: 0x48 // Inherited bytes: 0x00
struct FBattleItemNet {
	// Fields
	struct FItemDefineID DefineID; // Offset: 0x00 // Size: 0x18
	int Count; // Offset: 0x18 // Size: 0x04
	bool bEquipping; // Offset: 0x1c // Size: 0x01
	enum class EItemStoreArea ItemStoreArea; // Offset: 0x1d // Size: 0x01
	char pad_0x1E[0x2]; // Offset: 0x1e // Size: 0x02
	struct TArray<struct FBattleItemAdditionalData> AdditionalData; // Offset: 0x20 // Size: 0x10
	struct TArray<struct FItemAssociation> Associations; // Offset: 0x30 // Size: 0x10
	int Durability; // Offset: 0x40 // Size: 0x04
	char pad_0x44[0x4]; // Offset: 0x44 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.WorldTileSpotArray
// Size: 0x18 // Inherited bytes: 0x00
struct FWorldTileSpotArray {
	// Fields
	int WorldCompositionID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<struct USpotSceneComponent*> AllSpotComponents; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.GroupSpotComponentArray
// Size: 0x18 // Inherited bytes: 0x00
struct FGroupSpotComponentArray {
	// Fields
	enum class ESpotGroupType GroupType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct TArray<struct UGroupSpotSceneComponent*> AllGroupComponents; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.PlayerAvatarData
// Size: 0x18 // Inherited bytes: 0x01
struct FPlayerAvatarData : FResponResult {
	// Fields
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct TArray<struct FAvatarBackpack> AvatarBackpackData; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.AvatarBackpack
// Size: 0x20 // Inherited bytes: 0x00
struct FAvatarBackpack {
	// Fields
	struct TArray<int> WeaponAvatarList; // Offset: 0x00 // Size: 0x10
	struct TArray<int> VehicleAvatarList; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.PlayerInfoData
// Size: 0xc0 // Inherited bytes: 0x01
struct FPlayerInfoData : FResponResult {
	// Fields
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FString PlayerType; // Offset: 0x08 // Size: 0x10
	struct FString PlayerName; // Offset: 0x18 // Size: 0x10
	uint32_t PlayerKey; // Offset: 0x28 // Size: 0x04
	bool bIsGM; // Offset: 0x2c // Size: 0x01
	char PlayerGender; // Offset: 0x2d // Size: 0x01
	char pad_0x2E[0x2]; // Offset: 0x2e // Size: 0x02
	int TeamID; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
	int64_t CampID; // Offset: 0x38 // Size: 0x08
	int PlayerBornPointID; // Offset: 0x40 // Size: 0x04
	char pad_0x44[0x4]; // Offset: 0x44 // Size: 0x04
	struct TArray<struct FGameModePlayerItem> ItemList; // Offset: 0x48 // Size: 0x10
	struct TArray<struct FGameModePlayerExpressionItem> ExpressionItemList; // Offset: 0x58 // Size: 0x10
	struct FGameModePlayerEquipmentAvatar EquipmentAvatar; // Offset: 0x68 // Size: 0x0c
	char pad_0x74[0x4]; // Offset: 0x74 // Size: 0x04
	struct TArray<struct FGameModePlayerRolewearInfo> AllWear; // Offset: 0x78 // Size: 0x10
	struct FGameModePlayerUpassInfo UpassInfo; // Offset: 0x88 // Size: 0x30
	int planeAvatarId; // Offset: 0xb8 // Size: 0x04
	int RolewearIndex; // Offset: 0xbc // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.CollectedEventKeysValues
// Size: 0x20 // Inherited bytes: 0x00
struct FCollectedEventKeysValues {
	// Fields
	struct TArray<struct FString> Keys; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FString> Values; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.GenerateMonsterFlow
// Size: 0x28 // Inherited bytes: 0x00
struct FGenerateMonsterFlow {
	// Fields
	struct FString BattleID; // Offset: 0x00 // Size: 0x10
	int BattleMode; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct TArray<struct FGenerateMonsterPhaseFlow> GenerateMonsterPhaseList; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.GenerateMonsterPhaseFlow
// Size: 0x18 // Inherited bytes: 0x00
struct FGenerateMonsterPhaseFlow {
	// Fields
	int WeatherID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FGenerateOneMonsterFlow> GenerateOneMonsterFlowList; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.GenerateOneMonsterFlow
// Size: 0x10 // Inherited bytes: 0x00
struct FGenerateOneMonsterFlow {
	// Fields
	int MonsterID; // Offset: 0x00 // Size: 0x04
	int GenerateNum; // Offset: 0x04 // Size: 0x04
	int DeadNum; // Offset: 0x08 // Size: 0x04
	int KilledByPlayerNum; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.CharacterStateChangedParams
// Size: 0x18 // Inherited bytes: 0x00
struct FCharacterStateChangedParams {
	// Fields
	struct FPlayerID PlayerID; // Offset: 0x00 // Size: 0x10
	struct FName CharacterState; // Offset: 0x10 // Size: 0x08
};

// Object Name: ScriptStruct Gameplay.PlayerID
// Size: 0x10 // Inherited bytes: 0x00
struct FPlayerID {
	// Fields
	struct FName PlayerType; // Offset: 0x00 // Size: 0x08
	uint32_t PlayerKey; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.CharacterTeamIDChangedParams
// Size: 0x18 // Inherited bytes: 0x00
struct FCharacterTeamIDChangedParams {
	// Fields
	struct FPlayerID PlayerID; // Offset: 0x00 // Size: 0x10
	int TeamID; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.PlayerStateChangedParams
// Size: 0x38 // Inherited bytes: 0x00
struct FPlayerStateChangedParams {
	// Fields
	struct FPlayerID PlayerID; // Offset: 0x00 // Size: 0x10
	struct FName PlayerState; // Offset: 0x10 // Size: 0x08
	struct FString Reason; // Offset: 0x18 // Size: 0x10
	struct FString BanMsg; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.GameModePatchTableData
// Size: 0x140 // Inherited bytes: 0x00
struct FGameModePatchTableData {
	// Fields
	struct TMap<int, struct FItemTableStruct> Item; // Offset: 0x00 // Size: 0x50
	struct TMap<int, struct FPickUpCountSettingTableStruct> PickUpCountSetting; // Offset: 0x50 // Size: 0x50
	struct TMap<int, struct FBackpackMappingTableStruct> BackpackMapping; // Offset: 0xa0 // Size: 0x50
	struct TMap<int, struct FWeaponAttachmentsTableStruct> WeaponAttachments; // Offset: 0xf0 // Size: 0x50
};

// Object Name: ScriptStruct Gameplay.WeaponAttachmentsTableStruct
// Size: 0x7c // Inherited bytes: 0x00
struct FWeaponAttachmentsTableStruct {
	// Fields
	int KeyID; // Offset: 0x00 // Size: 0x04
	int Muzzle1ID; // Offset: 0x04 // Size: 0x04
	int Muzzle2ID; // Offset: 0x08 // Size: 0x04
	int Muzzle3ID; // Offset: 0x0c // Size: 0x04
	int Muzzle4ID; // Offset: 0x10 // Size: 0x04
	int Muzzle5ID; // Offset: 0x14 // Size: 0x04
	int Muzzle6ID; // Offset: 0x18 // Size: 0x04
	int Upper1ID; // Offset: 0x1c // Size: 0x04
	int Upper2ID; // Offset: 0x20 // Size: 0x04
	int Upper3ID; // Offset: 0x24 // Size: 0x04
	int Upper4ID; // Offset: 0x28 // Size: 0x04
	int Upper5ID; // Offset: 0x2c // Size: 0x04
	int Upper6ID; // Offset: 0x30 // Size: 0x04
	int Upper7ID; // Offset: 0x34 // Size: 0x04
	int Stock1ID; // Offset: 0x38 // Size: 0x04
	int Stock2ID; // Offset: 0x3c // Size: 0x04
	int Magazine1ID; // Offset: 0x40 // Size: 0x04
	int Magazine2ID; // Offset: 0x44 // Size: 0x04
	int Magazine3ID; // Offset: 0x48 // Size: 0x04
	int Magazine4ID; // Offset: 0x4c // Size: 0x04
	int Magazine5ID; // Offset: 0x50 // Size: 0x04
	int Magazine6ID; // Offset: 0x54 // Size: 0x04
	int Lower1ID; // Offset: 0x58 // Size: 0x04
	int Lower2ID; // Offset: 0x5c // Size: 0x04
	int Lower3ID; // Offset: 0x60 // Size: 0x04
	int Lower4ID; // Offset: 0x64 // Size: 0x04
	int Lower5ID; // Offset: 0x68 // Size: 0x04
	int BulletID; // Offset: 0x6c // Size: 0x04
	int ProposeBulletNum; // Offset: 0x70 // Size: 0x04
	int AIMinAttackDist; // Offset: 0x74 // Size: 0x04
	int AIMaxAttackDist; // Offset: 0x78 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.BackpackMappingTableStruct
// Size: 0x20 // Inherited bytes: 0x00
struct FBackpackMappingTableStruct {
	// Fields
	int SkinId; // Offset: 0x00 // Size: 0x04
	int ItemIDLv1; // Offset: 0x04 // Size: 0x04
	int ItemIDLv2; // Offset: 0x08 // Size: 0x04
	int ItemIDLv3; // Offset: 0x0c // Size: 0x04
	int SkinItemIDLv1; // Offset: 0x10 // Size: 0x04
	int SkinItemIDLv2; // Offset: 0x14 // Size: 0x04
	int SkinItemIDLv3; // Offset: 0x18 // Size: 0x04
	int LobbyShowItemID; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.PickUpCountSettingTableStruct
// Size: 0x08 // Inherited bytes: 0x00
struct FPickUpCountSettingTableStruct {
	// Fields
	int ItemID; // Offset: 0x00 // Size: 0x04
	int PickUpMaxCount; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.ItemTableStruct
// Size: 0xb0 // Inherited bytes: 0x00
struct FItemTableStruct {
	// Fields
	int ItemID; // Offset: 0x00 // Size: 0x04
	int ItemType; // Offset: 0x04 // Size: 0x04
	int ItemSubType; // Offset: 0x08 // Size: 0x04
	int BPID; // Offset: 0x0c // Size: 0x04
	int Durability; // Offset: 0x10 // Size: 0x04
	int AIFullVaule; // Offset: 0x14 // Size: 0x04
	bool Equippable; // Offset: 0x18 // Size: 0x01
	bool Consumable; // Offset: 0x19 // Size: 0x01
	bool AutoEquipandDrop; // Offset: 0x1a // Size: 0x01
	char pad_0x1B[0x1]; // Offset: 0x1b // Size: 0x01
	int MaxCount; // Offset: 0x1c // Size: 0x04
	int WeightforOrder; // Offset: 0x20 // Size: 0x04
	int UnitWeight_f; // Offset: 0x24 // Size: 0x04
	int RedEmotionFightId; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct FString PickupSound; // Offset: 0x30 // Size: 0x10
	struct FString DropSound; // Offset: 0x40 // Size: 0x10
	struct FString EquipSound; // Offset: 0x50 // Size: 0x10
	struct FString UnEquipSound; // Offset: 0x60 // Size: 0x10
	struct FString PickUpBank; // Offset: 0x70 // Size: 0x10
	struct FString DropBank; // Offset: 0x80 // Size: 0x10
	struct FString EquipBank; // Offset: 0x90 // Size: 0x10
	struct FString UnEquipBank; // Offset: 0xa0 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.GameModeIslandParams
// Size: 0x14 // Inherited bytes: 0x00
struct FGameModeIslandParams {
	// Fields
	int IslandDefaultLifeTime; // Offset: 0x00 // Size: 0x04
	int IslandSpecialLifeTime; // Offset: 0x04 // Size: 0x04
	int IslandMinimumPlayerNum; // Offset: 0x08 // Size: 0x04
	int IslandMinimumAliveTime; // Offset: 0x0c // Size: 0x04
	int IslandInactivePlayerKickoutTime; // Offset: 0x10 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.DynamicBattleRankInfo
// Size: 0x10 // Inherited bytes: 0x00
struct FDynamicBattleRankInfo {
	// Fields
	int BattleRank; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	uint64 PlayerUID; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct Gameplay.InfectionRoundTlogData
// Size: 0xe8 // Inherited bytes: 0x00
struct FInfectionRoundTlogData {
	// Fields
	int Round; // Offset: 0x00 // Size: 0x04
	int WinCamp; // Offset: 0x04 // Size: 0x04
	float PlayTime; // Offset: 0x08 // Size: 0x04
	bool bSpawnRevenger; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
	float RevengerExistTime; // Offset: 0x10 // Size: 0x04
	int RevengerDoSkillCount; // Offset: 0x14 // Size: 0x04
	int ZombieReviveCount; // Offset: 0x18 // Size: 0x04
	int NormalZombieDoSkillCount; // Offset: 0x1c // Size: 0x04
	int InvisibleZombieDoSkillCount; // Offset: 0x20 // Size: 0x04
	int ThrowerZombieDoSkillCount; // Offset: 0x24 // Size: 0x04
	int MotherZombieDoSkillCount; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct TArray<struct FInfectionPlayerDeadTlogData> DeadList; // Offset: 0x30 // Size: 0x10
	int NormalZombieChooseTimes; // Offset: 0x40 // Size: 0x04
	int InvisibleZombieChooseTimes; // Offset: 0x44 // Size: 0x04
	struct TArray<int> ZombieLevelList; // Offset: 0x48 // Size: 0x10
	struct TArray<int> EnhancerUserList; // Offset: 0x58 // Size: 0x10
	struct TArray<struct FInfectionSpringUseData> SpringUseList; // Offset: 0x68 // Size: 0x10
	struct TMap<int, struct FInfectionRoundTlogGuidData> GuidCount; // Offset: 0x78 // Size: 0x50
	int PlayerNumber; // Offset: 0xc8 // Size: 0x04
	float ZombieAbsorbingTime; // Offset: 0xcc // Size: 0x04
	float RevengerAbsorbingTime; // Offset: 0xd0 // Size: 0x04
	char pad_0xD4[0x4]; // Offset: 0xd4 // Size: 0x04
	struct TArray<struct FInfectionRoundPlayerTlogData> playerList; // Offset: 0xd8 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.InfectionRoundPlayerTlogData
// Size: 0xf8 // Inherited bytes: 0x00
struct FInfectionRoundPlayerTlogData {
	// Fields
	struct FString GameSvrId; // Offset: 0x00 // Size: 0x10
	int64_t dtEventTime; // Offset: 0x10 // Size: 0x08
	struct FString GameAppID; // Offset: 0x18 // Size: 0x10
	struct FString OpenID; // Offset: 0x28 // Size: 0x10
	uint16_t AreaID; // Offset: 0x38 // Size: 0x02
	uint8_t PlatID; // Offset: 0x3a // Size: 0x01
	char pad_0x3B[0x5]; // Offset: 0x3b // Size: 0x05
	struct FString ZoneID; // Offset: 0x40 // Size: 0x10
	uint64 BattleID; // Offset: 0x50 // Size: 0x08
	struct FString country; // Offset: 0x58 // Size: 0x10
	uint64 CharacterID; // Offset: 0x68 // Size: 0x08
	int64_t ClientStartTime; // Offset: 0x70 // Size: 0x08
	uint32_t PlayerKey; // Offset: 0x78 // Size: 0x04
	char pad_0x7C[0x4]; // Offset: 0x7c // Size: 0x04
	uint64 RoleID; // Offset: 0x80 // Size: 0x08
	uint8_t RoleType; // Offset: 0x88 // Size: 0x01
	uint8_t RoleTypeEnd; // Offset: 0x89 // Size: 0x01
	char pad_0x8A[0x2]; // Offset: 0x8a // Size: 0x02
	uint32_t RoleTypeSwitchTime; // Offset: 0x8c // Size: 0x04
	float PlayerJumpHeightMax; // Offset: 0x90 // Size: 0x04
	float PlayerJumpSpeedMax; // Offset: 0x94 // Size: 0x04
	uint32_t PlayerMoveDistance; // Offset: 0x98 // Size: 0x04
	uint32_t PlayerMoveTime; // Offset: 0x9c // Size: 0x04
	struct TArray<float> PlayerMoveSpeedArray; // Offset: 0xa0 // Size: 0x10
	uint32_t PlayerKilled; // Offset: 0xb0 // Size: 0x04
	uint32_t PlayerHurtCount; // Offset: 0xb4 // Size: 0x04
	uint32_t PlayerDamageCount; // Offset: 0xb8 // Size: 0x04
	uint32_t KillingCount; // Offset: 0xbc // Size: 0x04
	uint32_t AssistCount; // Offset: 0xc0 // Size: 0x04
	uint32_t GunKillingTimes; // Offset: 0xc4 // Size: 0x04
	uint32_t HeadshotCounts; // Offset: 0xc8 // Size: 0x04
	float DamageAmount; // Offset: 0xcc // Size: 0x04
	uint32_t GunHitTimes; // Offset: 0xd0 // Size: 0x04
	uint32_t GunShotTimes; // Offset: 0xd4 // Size: 0x04
	uint32_t MovingDistance; // Offset: 0xd8 // Size: 0x04
	uint32_t HealAmount; // Offset: 0xdc // Size: 0x04
	uint32_t CureCount; // Offset: 0xe0 // Size: 0x04
	uint32_t CareRoundCheckUp; // Offset: 0xe4 // Size: 0x04
	uint32_t KillZombiesCount; // Offset: 0xe8 // Size: 0x04
	uint32_t KillHumanCount; // Offset: 0xec // Size: 0x04
	float Damage4Avenger; // Offset: 0xf0 // Size: 0x04
	int Headshot4Avenger; // Offset: 0xf4 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.InfectionZombieLevelData
// Size: 0x08 // Inherited bytes: 0x00
struct FInfectionZombieLevelData {
	// Fields
	int Level; // Offset: 0x00 // Size: 0x04
	int Num; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.InfectionBattleResultData
// Size: 0x28 // Inherited bytes: 0x00
struct FInfectionBattleResultData {
	// Fields
	struct TArray<struct FInfectionPlayerBattleResultData> playerList; // Offset: 0x00 // Size: 0x10
	int PlayTime; // Offset: 0x10 // Size: 0x04
	int KillZombieNum; // Offset: 0x14 // Size: 0x04
	int InfectedHumanNum; // Offset: 0x18 // Size: 0x04
	int BecomeHeroNum; // Offset: 0x1c // Size: 0x04
	uint64 EscapePlayerUid; // Offset: 0x20 // Size: 0x08
};

// Object Name: ScriptStruct Gameplay.InfectionPlayerBattleResultData
// Size: 0x88 // Inherited bytes: 0x00
struct FInfectionPlayerBattleResultData {
	// Fields
	uint64 UId; // Offset: 0x00 // Size: 0x08
	uint32_t PlayerKey; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct FString PlayerName; // Offset: 0x10 // Size: 0x10
	int PlayerScore; // Offset: 0x20 // Size: 0x04
	int Rank; // Offset: 0x24 // Size: 0x04
	int Kills; // Offset: 0x28 // Size: 0x04
	int Infections; // Offset: 0x2c // Size: 0x04
	int DamageAmount; // Offset: 0x30 // Size: 0x04
	int RoundNum; // Offset: 0x34 // Size: 0x04
	float GamePlayTime; // Offset: 0x38 // Size: 0x04
	int BeMatrixMonsterTimes; // Offset: 0x3c // Size: 0x04
	int BeRevengerPlayerTimes; // Offset: 0x40 // Size: 0x04
	int RevengerPlayerKillWinTimes; // Offset: 0x44 // Size: 0x04
	int BeMonsterWinTimes; // Offset: 0x48 // Size: 0x04
	int BePersonWinTimes; // Offset: 0x4c // Size: 0x04
	int UseSpringJumpTimes; // Offset: 0x50 // Size: 0x04
	int UseEnhancerTimes; // Offset: 0x54 // Size: 0x04
	int DamageToMonster; // Offset: 0x58 // Size: 0x04
	int DamageToRevengerPlayer; // Offset: 0x5c // Size: 0x04
	int ChooseZombieFirstTimes; // Offset: 0x60 // Size: 0x04
	int ChooseZombieSecondTimes; // Offset: 0x64 // Size: 0x04
	float TotalDamage; // Offset: 0x68 // Size: 0x04
	float TotalSprintDistance; // Offset: 0x6c // Size: 0x04
	int OpenAirDropBoxesNum; // Offset: 0x70 // Size: 0x04
	char pad_0x74[0x4]; // Offset: 0x74 // Size: 0x04
	struct TArray<struct FString> KillFlow; // Offset: 0x78 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.VehicleBattleResultData
// Size: 0x68 // Inherited bytes: 0x00
struct FVehicleBattleResultData {
	// Fields
	struct TArray<struct FVehiclePlayerBattleResultData> playerList; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FVehicleCampKills> VehicleCampKills; // Offset: 0x10 // Size: 0x10
	int WinCampID; // Offset: 0x20 // Size: 0x04
	float GamePlayTime; // Offset: 0x24 // Size: 0x04
	int MatchPointNum; // Offset: 0x28 // Size: 0x04
	int WinCampTreasureScore; // Offset: 0x2c // Size: 0x04
	int FailCampTreasureScore; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
	struct TArray<struct FVehicleBattleVehicleStatiscs> VehicleStaticsList; // Offset: 0x38 // Size: 0x10
	struct TArray<struct FVehicleBattleWeaponStatiscs> WeaponStatiscsList; // Offset: 0x48 // Size: 0x10
	int VehicleStuckResetTimes; // Offset: 0x58 // Size: 0x04
	int HealthPropItemTimes; // Offset: 0x5c // Size: 0x04
	int NormalPropItemTimes; // Offset: 0x60 // Size: 0x04
	int SuperPropItemTimes; // Offset: 0x64 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.VehicleBattleWeaponStatiscs
// Size: 0x10 // Inherited bytes: 0x00
struct FVehicleBattleWeaponStatiscs {
	// Fields
	int WeaponID; // Offset: 0x00 // Size: 0x04
	int ChooseTimes; // Offset: 0x04 // Size: 0x04
	int TotalDamage; // Offset: 0x08 // Size: 0x04
	int Kills; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.VehicleBattleVehicleStatiscs
// Size: 0x18 // Inherited bytes: 0x00
struct FVehicleBattleVehicleStatiscs {
	// Fields
	int VehicleID; // Offset: 0x00 // Size: 0x04
	int ChooseTimes; // Offset: 0x04 // Size: 0x04
	int DeadTimes; // Offset: 0x08 // Size: 0x04
	int Kills; // Offset: 0x0c // Size: 0x04
	float VehicleWeaponDamage; // Offset: 0x10 // Size: 0x04
	float HitDamage; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.VehiclePlayerBattleResultData
// Size: 0x98 // Inherited bytes: 0x00
struct FVehiclePlayerBattleResultData {
	// Fields
	uint64 UId; // Offset: 0x00 // Size: 0x08
	uint32_t PlayerKey; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct FString PlayerName; // Offset: 0x10 // Size: 0x10
	int TeamID; // Offset: 0x20 // Size: 0x04
	int CampID; // Offset: 0x24 // Size: 0x04
	int Score; // Offset: 0x28 // Size: 0x04
	int Distance; // Offset: 0x2c // Size: 0x04
	int KillNum; // Offset: 0x30 // Size: 0x04
	int AssistKillNum; // Offset: 0x34 // Size: 0x04
	int DriverKillNum; // Offset: 0x38 // Size: 0x04
	int ShooterKillNum; // Offset: 0x3c // Size: 0x04
	int BeKillNum; // Offset: 0x40 // Size: 0x04
	int TeamKillNum; // Offset: 0x44 // Size: 0x04
	int GetItemNum; // Offset: 0x48 // Size: 0x04
	int OpenTreasureNum; // Offset: 0x4c // Size: 0x04
	int ShootTreasureNum; // Offset: 0x50 // Size: 0x04
	char pad_0x54[0x4]; // Offset: 0x54 // Size: 0x04
	struct TArray<struct FUseItemFlow> UseItemFlow; // Offset: 0x58 // Size: 0x10
	int StrikeKillVehicleNum; // Offset: 0x68 // Size: 0x04
	int ItemKillVehicleNum; // Offset: 0x6c // Size: 0x04
	int GunKillVehicleNum; // Offset: 0x70 // Size: 0x04
	float CauseDamage; // Offset: 0x74 // Size: 0x04
	int GemStoneCount; // Offset: 0x78 // Size: 0x04
	bool HasFinished; // Offset: 0x7c // Size: 0x01
	char pad_0x7D[0x3]; // Offset: 0x7d // Size: 0x03
	float FinishedTime; // Offset: 0x80 // Size: 0x04
	bool IsEscape; // Offset: 0x84 // Size: 0x01
	char pad_0x85[0x3]; // Offset: 0x85 // Size: 0x03
	int VehicleID; // Offset: 0x88 // Size: 0x04
	int VehicleShapeType; // Offset: 0x8c // Size: 0x04
	float ExitPlayerPlayTime; // Offset: 0x90 // Size: 0x04
	char pad_0x94[0x4]; // Offset: 0x94 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.VehicleReportList
// Size: 0x10 // Inherited bytes: 0x00
struct FVehicleReportList {
	// Fields
	struct TArray<struct FVehicleReportEntry> VehicleReports; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.AntiCheatDetailData
// Size: 0x28 // Inherited bytes: 0x00
struct FAntiCheatDetailData {
	// Fields
	uint16_t AreaID; // Offset: 0x00 // Size: 0x02
	uint8_t PlatID; // Offset: 0x02 // Size: 0x01
	char pad_0x3[0x5]; // Offset: 0x03 // Size: 0x05
	struct FString ZoneID; // Offset: 0x08 // Size: 0x10
	struct TArray<struct FWeaponAntiData> WeaponAntiDataList; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.WeaponAntiData
// Size: 0x18 // Inherited bytes: 0x00
struct FWeaponAntiData {
	// Fields
	uint16_t MuzzleFloorHeight; // Offset: 0x00 // Size: 0x02
	int16_t MuzzleActorHeadHeight; // Offset: 0x02 // Size: 0x02
	uint16_t ImplactPointAndActorDis; // Offset: 0x04 // Size: 0x02
	uint16_t ImplactPointAndBulletDis; // Offset: 0x06 // Size: 0x02
	uint16_t ImplactPoinPosChange; // Offset: 0x08 // Size: 0x02
	uint16_t BulletAndGunAngle; // Offset: 0x0a // Size: 0x02
	uint16_t NetDelay; // Offset: 0x0c // Size: 0x02
	char pad_0xE[0x2]; // Offset: 0x0e // Size: 0x02
	uint32_t ShooterPosDis; // Offset: 0x10 // Size: 0x04
	uint32_t VictmPosDis; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.AntiMoveCheatFlow
// Size: 0x28 // Inherited bytes: 0x00
struct FAntiMoveCheatFlow {
	// Fields
	uint16_t AreaID; // Offset: 0x00 // Size: 0x02
	uint8_t PlatID; // Offset: 0x02 // Size: 0x01
	char pad_0x3[0x5]; // Offset: 0x03 // Size: 0x05
	struct FString ZoneID; // Offset: 0x08 // Size: 0x10
	int CheatType1; // Offset: 0x18 // Size: 0x04
	int CheatType2; // Offset: 0x1c // Size: 0x04
	int CheatType3; // Offset: 0x20 // Size: 0x04
	float Ping; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.AntiCheatMovementRawData
// Size: 0x18 // Inherited bytes: 0x00
struct FAntiCheatMovementRawData {
	// Fields
	int16_t MinVelocity; // Offset: 0x00 // Size: 0x02
	int16_t MaxVelocity; // Offset: 0x02 // Size: 0x02
	int16_t AvgVelocity; // Offset: 0x04 // Size: 0x02
	char pad_0x6[0x2]; // Offset: 0x06 // Size: 0x02
	uint64 PlayerStatus; // Offset: 0x08 // Size: 0x08
	int16_t PlayerPing; // Offset: 0x10 // Size: 0x02
	char SpecialFlags; // Offset: 0x12 // Size: 0x01
	char pad_0x13[0x5]; // Offset: 0x13 // Size: 0x05
};

// Object Name: ScriptStruct Gameplay.DSNetHandleInfo
// Size: 0x54 // Inherited bytes: 0x00
struct FDSNetHandleInfo {
	// Fields
	uint32_t NumClientsMax; // Offset: 0x00 // Size: 0x04
	uint32_t NumClientsAvg; // Offset: 0x04 // Size: 0x04
	uint32_t NumClientsMin; // Offset: 0x08 // Size: 0x04
	uint32_t OutLossMax; // Offset: 0x0c // Size: 0x04
	uint32_t OutLossAvg; // Offset: 0x10 // Size: 0x04
	uint32_t OutLossMin; // Offset: 0x14 // Size: 0x04
	uint32_t InLossMax; // Offset: 0x18 // Size: 0x04
	uint32_t InLossAvg; // Offset: 0x1c // Size: 0x04
	uint32_t InLossMin; // Offset: 0x20 // Size: 0x04
	uint32_t OutRateMax; // Offset: 0x24 // Size: 0x04
	uint32_t OutRateAvg; // Offset: 0x28 // Size: 0x04
	uint32_t OutRateMin; // Offset: 0x2c // Size: 0x04
	uint32_t InRateMax; // Offset: 0x30 // Size: 0x04
	uint32_t InRateAvg; // Offset: 0x34 // Size: 0x04
	uint32_t InRateMin; // Offset: 0x38 // Size: 0x04
	uint32_t OutSaturationMax; // Offset: 0x3c // Size: 0x04
	uint32_t OutSaturationAvg; // Offset: 0x40 // Size: 0x04
	uint32_t OutSaturationMin; // Offset: 0x44 // Size: 0x04
	uint32_t FPSMax; // Offset: 0x48 // Size: 0x04
	uint32_t FPSAvg; // Offset: 0x4c // Size: 0x04
	uint32_t FPSMin; // Offset: 0x50 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.ZNQBattleResultData
// Size: 0x4c // Inherited bytes: 0x00
struct FZNQBattleResultData {
	// Fields
	int DuckGameCount; // Offset: 0x00 // Size: 0x04
	int BeeGameCount; // Offset: 0x04 // Size: 0x04
	int BlindBoxCount; // Offset: 0x08 // Size: 0x04
	int DuckShootingRangeCount; // Offset: 0x0c // Size: 0x04
	int ActivedDuckGameNum; // Offset: 0x10 // Size: 0x04
	int ActivedBeeGameNum; // Offset: 0x14 // Size: 0x04
	int ActivedBlindBoxNum; // Offset: 0x18 // Size: 0x04
	int ActivedDuckShootingRangeNum; // Offset: 0x1c // Size: 0x04
	int MaxCoinCarried; // Offset: 0x20 // Size: 0x04
	int ParachutePlaygroundPlayer; // Offset: 0x24 // Size: 0x04
	int DuckGameHighCount; // Offset: 0x28 // Size: 0x04
	int DuckGameMiddleCount; // Offset: 0x2c // Size: 0x04
	int DuckGameLowCount; // Offset: 0x30 // Size: 0x04
	int BeeGameHighCount; // Offset: 0x34 // Size: 0x04
	int BeeGameMiddleCount; // Offset: 0x38 // Size: 0x04
	int BeeGameLowCount; // Offset: 0x3c // Size: 0x04
	int DuckShootingRangeHighCount; // Offset: 0x40 // Size: 0x04
	int DuckShootingRangeMiddleCount; // Offset: 0x44 // Size: 0x04
	int DuckShootingRangeLowCount; // Offset: 0x48 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.HardPointBattleResultData
// Size: 0x28 // Inherited bytes: 0x00
struct FHardPointBattleResultData {
	// Fields
	float HardPointEnterOccupiedStateMaxTime; // Offset: 0x00 // Size: 0x04
	int TotalPoint; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FTLog_HardPointActorFlow> HardPointActorFlowList; // Offset: 0x08 // Size: 0x10
	struct TArray<struct FHardPointTeamBattleResultData> TeamResultDatas; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.HardPointTeamBattleResultData
// Size: 0x18 // Inherited bytes: 0x00
struct FHardPointTeamBattleResultData {
	// Fields
	int TeamID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FHardPointPlayerBattleResultData> TeamPlayerResultDatas; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.HardPointPlayerBattleResultData
// Size: 0x30 // Inherited bytes: 0x00
struct FHardPointPlayerBattleResultData {
	// Fields
	uint64 UId; // Offset: 0x00 // Size: 0x08
	int OccupyScore; // Offset: 0x08 // Size: 0x04
	float OccupyTime; // Offset: 0x0c // Size: 0x04
	int OccupyNum; // Offset: 0x10 // Size: 0x04
	float DamageToTheInHardPointEnemy; // Offset: 0x14 // Size: 0x04
	int PickUpWeaponBoxNum; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct TArray<struct FTLog_PickUpItemFlow> PickUpItemFlowData; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.TLog_HardPointActorFlow
// Size: 0x28 // Inherited bytes: 0x00
struct FTLog_HardPointActorFlow {
	// Fields
	int HardPointID; // Offset: 0x00 // Size: 0x04
	float ActivatedTime; // Offset: 0x04 // Size: 0x04
	struct TArray<int> OccupiedTeamSequenceRecords; // Offset: 0x08 // Size: 0x10
	struct TArray<struct FHardPointActorTeamScoreResultData> TeamScoreDataList; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.HardPointActorTeamScoreResultData
// Size: 0x08 // Inherited bytes: 0x00
struct FHardPointActorTeamScoreResultData {
	// Fields
	int TeamID; // Offset: 0x00 // Size: 0x04
	int Score; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.DeathMatchBattleResultData
// Size: 0x58 // Inherited bytes: 0x00
struct FDeathMatchBattleResultData {
	// Fields
	enum class EDeathMatchSubModeType SubModeType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct TArray<struct FDeathMatchTeamBattleResultData> TeamResultDatas; // Offset: 0x08 // Size: 0x10
	int PlayerNumber; // Offset: 0x18 // Size: 0x04
	int RealPlayerNumber; // Offset: 0x1c // Size: 0x04
	int PlayTime; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
	uint64 FirstKillPlayer; // Offset: 0x28 // Size: 0x08
	uint64 LastKillPlayer; // Offset: 0x30 // Size: 0x08
	struct FString VsTeamGameFlow; // Offset: 0x38 // Size: 0x10
	struct TArray<struct FBRTDMWinLevelInfoTeamScoreResultData> WinLevelInfo; // Offset: 0x48 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.BRTDMWinLevelInfoTeamScoreResultData
// Size: 0x08 // Inherited bytes: 0x00
struct FBRTDMWinLevelInfoTeamScoreResultData {
	// Fields
	int LevelIndex; // Offset: 0x00 // Size: 0x04
	int WinBornArea; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.DeathMatchTeamBattleResultData
// Size: 0x30 // Inherited bytes: 0x00
struct FDeathMatchTeamBattleResultData {
	// Fields
	int TeamID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString Result; // Offset: 0x08 // Size: 0x10
	int TeamRank; // Offset: 0x18 // Size: 0x04
	int TeamScore; // Offset: 0x1c // Size: 0x04
	struct TArray<struct FDeathMatchPlayerBattleResultData> TeamPlayerResultDatas; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.DeathMatchPlayerBattleResultData
// Size: 0x258 // Inherited bytes: 0x00
struct FDeathMatchPlayerBattleResultData {
	// Fields
	uint64 UId; // Offset: 0x00 // Size: 0x08
	uint32_t PlayerKey; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct FString PlayerName; // Offset: 0x10 // Size: 0x10
	int TeamID; // Offset: 0x20 // Size: 0x04
	int PlayerScore; // Offset: 0x24 // Size: 0x04
	int Rank; // Offset: 0x28 // Size: 0x04
	int Kills; // Offset: 0x2c // Size: 0x04
	int rescueTimes; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
	struct TArray<uint64> RescueTeammatesList; // Offset: 0x38 // Size: 0x10
	int Assists; // Offset: 0x48 // Size: 0x04
	char pad_0x4C[0x4]; // Offset: 0x4c // Size: 0x04
	struct TArray<uint64> AssistTeammatesList; // Offset: 0x50 // Size: 0x10
	int OccupyScore; // Offset: 0x60 // Size: 0x04
	int Deaths; // Offset: 0x64 // Size: 0x04
	int MaxContinuouKills; // Offset: 0x68 // Size: 0x04
	int SuperGodNum; // Offset: 0x6c // Size: 0x04
	int RevengeNum; // Offset: 0x70 // Size: 0x04
	int DieInBaseRegionNum; // Offset: 0x74 // Size: 0x04
	int DamageAmount; // Offset: 0x78 // Size: 0x04
	int HeadShotNum; // Offset: 0x7c // Size: 0x04
	int ShootWeaponShotNum; // Offset: 0x80 // Size: 0x04
	int ShootWeaponShotAndHitPlayerNum; // Offset: 0x84 // Size: 0x04
	int GunKillingTimes; // Offset: 0x88 // Size: 0x04
	int MeleeKillTimes; // Offset: 0x8c // Size: 0x04
	float RangedDamagedAmount; // Offset: 0x90 // Size: 0x04
	float MeleeDamageAmount; // Offset: 0x94 // Size: 0x04
	float MovingDistance; // Offset: 0x98 // Size: 0x04
	float HealAmount; // Offset: 0x9c // Size: 0x04
	int CureCount; // Offset: 0xa0 // Size: 0x04
	char pad_0xA4[0x4]; // Offset: 0xa4 // Size: 0x04
	struct FEquipmentData EquipmentData; // Offset: 0xa8 // Size: 0x70
	struct TArray<uint64> TeamMemberList; // Offset: 0x118 // Size: 0x10
	struct TMap<int, int> MedalList; // Offset: 0x128 // Size: 0x50
	float surviveTime; // Offset: 0x178 // Size: 0x04
	char pad_0x17C[0x4]; // Offset: 0x17c // Size: 0x04
	struct TArray<struct FTLog_PickUpItemFlow> TLog_PickUpItemFlowData; // Offset: 0x180 // Size: 0x10
	struct TArray<struct FUseItemFlow> UseItemFlow; // Offset: 0x190 // Size: 0x10
	float TotalDamage; // Offset: 0x1a0 // Size: 0x04
	float TotalSprintDistance; // Offset: 0x1a4 // Size: 0x04
	int OpenAirDropBoxesNum; // Offset: 0x1a8 // Size: 0x04
	char pad_0x1AC[0x4]; // Offset: 0x1ac // Size: 0x04
	struct FOnePlayerWeapon WeaponRecord; // Offset: 0x1b0 // Size: 0x20
	float Pronetime; // Offset: 0x1d0 // Size: 0x04
	char pad_0x1D4[0x4]; // Offset: 0x1d4 // Size: 0x04
	struct TArray<struct FString> KillFlow; // Offset: 0x1d8 // Size: 0x10
	bool HasEscape; // Offset: 0x1e8 // Size: 0x01
	char pad_0x1E9[0x7]; // Offset: 0x1e9 // Size: 0x07
	struct FString VsReadinessSwitchFlow; // Offset: 0x1f0 // Size: 0x10
	int CostGold; // Offset: 0x200 // Size: 0x04
	char pad_0x204[0x4]; // Offset: 0x204 // Size: 0x04
	struct TMap<int, int> GeneralCounterMap; // Offset: 0x208 // Size: 0x50
};

// Object Name: ScriptStruct Gameplay.AirDropBoxDataFlow
// Size: 0x20 // Inherited bytes: 0x00
struct FAirDropBoxDataFlow {
	// Fields
	struct TArray<struct FAirDropBoxData> AirDropBoxDataList; // Offset: 0x00 // Size: 0x10
	struct FString BattleID; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.AirDropBoxData
// Size: 0x38 // Inherited bytes: 0x00
struct FAirDropBoxData {
	// Fields
	int AirDropBoxId; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FAirDropBoxDataItem> DataList; // Offset: 0x08 // Size: 0x10
	int Reason; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	uint64 CallerPlayerID; // Offset: 0x20 // Size: 0x08
	struct FVector Location; // Offset: 0x28 // Size: 0x0c
	float DropTime; // Offset: 0x34 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.AirDropBoxDataItem
// Size: 0x08 // Inherited bytes: 0x00
struct FAirDropBoxDataItem {
	// Fields
	int ItemSpesificID; // Offset: 0x00 // Size: 0x04
	int Count; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.RoomCustomParams
// Size: 0x40 // Inherited bytes: 0x00
struct FRoomCustomParams {
	// Fields
	int CircleSpeedMultiplicator; // Offset: 0x00 // Size: 0x04
	bool bAutoOpendoor; // Offset: 0x04 // Size: 0x01
	bool bAutoPickup; // Offset: 0x05 // Size: 0x01
	bool bAudioVisual; // Offset: 0x06 // Size: 0x01
	bool bShowSkull; // Offset: 0x07 // Size: 0x01
	bool bAutoAimAt; // Offset: 0x08 // Size: 0x01
	bool bGunRemoveBullet; // Offset: 0x09 // Size: 0x01
	char pad_0xA[0x2]; // Offset: 0x0a // Size: 0x02
	int BlueCircleDamageMultiplicator; // Offset: 0x0c // Size: 0x04
	bool bUseFirstWhiteCircleDelayTime; // Offset: 0x10 // Size: 0x01
	bool bUseFirstSafeZoneAppearTime; // Offset: 0x11 // Size: 0x01
	bool bUseFirstWhiteCircleRadiusMultiplicator; // Offset: 0x12 // Size: 0x01
	char pad_0x13[0x1]; // Offset: 0x13 // Size: 0x01
	int FirstWhiteCircleDelayTime; // Offset: 0x14 // Size: 0x04
	int FirstSafeZoneAppearTime; // Offset: 0x18 // Size: 0x04
	int FirstWhiteCircleRadiusMultiplicator; // Offset: 0x1c // Size: 0x04
	bool EnableRedZone; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x7]; // Offset: 0x21 // Size: 0x07
	struct TArray<struct FCustomCircleParams> CustomCircleParamsList; // Offset: 0x28 // Size: 0x10
	bool bFuzzyInformation; // Offset: 0x38 // Size: 0x01
	char pad_0x39[0x7]; // Offset: 0x39 // Size: 0x07
};

// Object Name: ScriptStruct Gameplay.CustomCircleParams
// Size: 0x1c // Inherited bytes: 0x00
struct FCustomCircleParams {
	// Fields
	int Stage; // Offset: 0x00 // Size: 0x04
	int DelayTime; // Offset: 0x04 // Size: 0x04
	int SafeZoneAppeartime; // Offset: 0x08 // Size: 0x04
	int LastTime; // Offset: 0x0c // Size: 0x04
	int CircleDamage; // Offset: 0x10 // Size: 0x04
	int BlueCircleRadius; // Offset: 0x14 // Size: 0x04
	int WhiteCircleRadius; // Offset: 0x18 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.BattleCustomConfig
// Size: 0x18 // Inherited bytes: 0x00
struct FBattleCustomConfig {
	// Fields
	struct FString Config; // Offset: 0x00 // Size: 0x10
	float Value; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.GameModeGameOverData
// Size: 0x01 // Inherited bytes: 0x00
struct FGameModeGameOverData {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x00 // Size: 0x01
};

// Object Name: ScriptStruct Gameplay.PlayerTotalWeaponsConfig
// Size: 0x18 // Inherited bytes: 0x00
struct FPlayerTotalWeaponsConfig {
	// Fields
	int DefaultSelectedIndex; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FPlayerWeaponsConfig> WeaponsConfigList; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.PlayerWeaponsConfig
// Size: 0x20 // Inherited bytes: 0x00
struct FPlayerWeaponsConfig {
	// Fields
	struct FString ConfigName; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FSingleWeaponConfig> WeaponDataList; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.SingleWeaponConfig
// Size: 0x18 // Inherited bytes: 0x00
struct FSingleWeaponConfig {
	// Fields
	int WeaponID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<int> AttachMentIDList; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.BornItem
// Size: 0x0c // Inherited bytes: 0x00
struct FBornItem {
	// Fields
	int BornItemID; // Offset: 0x00 // Size: 0x04
	int BornItemCount; // Offset: 0x04 // Size: 0x04
	int BornItemFlags; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.GameModePlayerItemPackInfo
// Size: 0x30 // Inherited bytes: 0x00
struct FGameModePlayerItemPackInfo {
	// Fields
	int SlotIndex; // Offset: 0x00 // Size: 0x04
	int ItemID; // Offset: 0x04 // Size: 0x04
	int Count; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	uint64 InstanceID; // Offset: 0x10 // Size: 0x08
	int ItemDurability; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct TArray<struct FGameModePlayerItemAttachData> AttachList; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.GameModePlayerItemAttachData
// Size: 0x10 // Inherited bytes: 0x00
struct FGameModePlayerItemAttachData {
	// Fields
	int SlotIndex; // Offset: 0x00 // Size: 0x04
	int ItemID; // Offset: 0x04 // Size: 0x04
	uint64 InstanceID; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct Gameplay.GameModePlayerWeaponPackInfo
// Size: 0x30 // Inherited bytes: 0x00
struct FGameModePlayerWeaponPackInfo {
	// Fields
	int SlotIndex; // Offset: 0x00 // Size: 0x04
	int ItemID; // Offset: 0x04 // Size: 0x04
	int Count; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	uint64 InstanceID; // Offset: 0x10 // Size: 0x08
	int WeaponDurability; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct TArray<struct FGameModePlayerWeaponAttachData> AttachList; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.GameModePlayerWeaponAttachData
// Size: 0x10 // Inherited bytes: 0x00
struct FGameModePlayerWeaponAttachData {
	// Fields
	int SlotIndex; // Offset: 0x00 // Size: 0x04
	int ItemID; // Offset: 0x04 // Size: 0x04
	uint64 InstanceID; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct Gameplay.GameModePlayerArmorPackInfo
// Size: 0x28 // Inherited bytes: 0x00
struct FGameModePlayerArmorPackInfo {
	// Fields
	int ItemID; // Offset: 0x00 // Size: 0x04
	int Count; // Offset: 0x04 // Size: 0x04
	uint64 InstanceID; // Offset: 0x08 // Size: 0x08
	int ItemDurability; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct TArray<struct FGameModePlayerArmorAttachData> AttachList; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.GameModePlayerArmorAttachData
// Size: 0x10 // Inherited bytes: 0x00
struct FGameModePlayerArmorAttachData {
	// Fields
	int SlotIndex; // Offset: 0x00 // Size: 0x04
	int ItemID; // Offset: 0x04 // Size: 0x04
	uint64 InstanceID; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct Gameplay.SocialIslandGameResult
// Size: 0x70 // Inherited bytes: 0x00
struct FSocialIslandGameResult {
	// Fields
	uint64 UId; // Offset: 0x00 // Size: 0x08
	uint32_t PlayerKey; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct TArray<struct FDailyTaskStoreInfo> TaskInfo; // Offset: 0x10 // Size: 0x10
	struct TArray<struct FDailyTaskAwardInfo> RewardInfo; // Offset: 0x20 // Size: 0x10
	int HighScoreCount; // Offset: 0x30 // Size: 0x04
	int TrainCount; // Offset: 0x34 // Size: 0x04
	int TotalTargetScore; // Offset: 0x38 // Size: 0x04
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
	struct TArray<uint64> Interaction; // Offset: 0x40 // Size: 0x10
	int StayTime; // Offset: 0x50 // Size: 0x04
	char pad_0x54[0x4]; // Offset: 0x54 // Size: 0x04
	struct TArray<int> DuelDurations; // Offset: 0x58 // Size: 0x10
	int DuelApplyCount; // Offset: 0x68 // Size: 0x04
	int DuelStartCount; // Offset: 0x6c // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.PlayerOBBattleInfo
// Size: 0x30 // Inherited bytes: 0x00
struct FPlayerOBBattleInfo {
	// Fields
	uint64 UId; // Offset: 0x00 // Size: 0x08
	int BattleMode; // Offset: 0x08 // Size: 0x04
	bool ValidBattleInfo; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
	int GameCount; // Offset: 0x10 // Size: 0x04
	int WinCount; // Offset: 0x14 // Size: 0x04
	int TopTenCount; // Offset: 0x18 // Size: 0x04
	int KillNum; // Offset: 0x1c // Size: 0x04
	struct FString KDNum; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.ParachuteInfo
// Size: 0x28 // Inherited bytes: 0x00
struct FParachuteInfo {
	// Fields
	int LeaderCount; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	uint64 LastGameLeaderUID; // Offset: 0x08 // Size: 0x08
	struct TArray<uint64> LastGameTeammatesUID; // Offset: 0x10 // Size: 0x10
	uint64 LastGameBattleID; // Offset: 0x20 // Size: 0x08
};

// Object Name: ScriptStruct Gameplay.PickUpSpecialItemFlow
// Size: 0x08 // Inherited bytes: 0x00
struct FPickUpSpecialItemFlow {
	// Fields
	int ItemSpesificID; // Offset: 0x00 // Size: 0x04
	int pickCount; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.HeavyWeaponBoxItemFlow
// Size: 0x20 // Inherited bytes: 0x00
struct FHeavyWeaponBoxItemFlow {
	// Fields
	struct FString BoxName; // Offset: 0x00 // Size: 0x10
	struct TArray<int> ItemIdList; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.HeavyWeaponBoxOpenPlayerFlow
// Size: 0x28 // Inherited bytes: 0x00
struct FHeavyWeaponBoxOpenPlayerFlow {
	// Fields
	struct FString BoxName; // Offset: 0x00 // Size: 0x10
	int WaitTimeFromActiveToOpen; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	int64_t UId; // Offset: 0x18 // Size: 0x08
	uint32_t TeamID; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.HeavyWeaponBoxActivationFlow
// Size: 0x18 // Inherited bytes: 0x00
struct FHeavyWeaponBoxActivationFlow {
	// Fields
	struct FString BoxName; // Offset: 0x00 // Size: 0x10
	int64_t ActiveTime; // Offset: 0x10 // Size: 0x08
};

// Object Name: ScriptStruct Gameplay.HeavyWeaponBoxSpawnFlow
// Size: 0x28 // Inherited bytes: 0x00
struct FHeavyWeaponBoxSpawnFlow {
	// Fields
	struct FString BoxName; // Offset: 0x00 // Size: 0x10
	int64_t SpawnTime; // Offset: 0x10 // Size: 0x08
	struct FString SpawnLocation; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.ItemRegionCircle
// Size: 0x38 // Inherited bytes: 0x00
struct FItemRegionCircle {
	// Fields
	struct FVector Center; // Offset: 0x00 // Size: 0x0c
	float Radius; // Offset: 0x0c // Size: 0x04
	float RadiusSquared2D; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x24]; // Offset: 0x14 // Size: 0x24
};

// Object Name: ScriptStruct Gameplay.GroupTypeSceneComponents
// Size: 0x18 // Inherited bytes: 0x00
struct FGroupTypeSceneComponents {
	// Fields
	int GroupType; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<struct USceneComponent*> SceneComponents; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.ItemSpawnClass
// Size: 0x10 // Inherited bytes: 0x00
struct FItemSpawnClass {
	// Fields
	struct UObject* ItemClass; // Offset: 0x00 // Size: 0x08
	int ItemCount; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.ItemSpawnData
// Size: 0x70 // Inherited bytes: 0x00
struct FItemSpawnData {
	// Fields
	struct FName RowName; // Offset: 0x00 // Size: 0x08
	int KeyID; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct FString ItemValue; // Offset: 0x10 // Size: 0x10
	struct FString ItemCategory; // Offset: 0x20 // Size: 0x10
	int ItemWeight; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
	struct FString ItemPath; // Offset: 0x38 // Size: 0x10
	int ItemStackCount; // Offset: 0x48 // Size: 0x04
	char pad_0x4C[0x4]; // Offset: 0x4c // Size: 0x04
	struct FString ItemTogetherPath; // Offset: 0x50 // Size: 0x10
	int ItemTogetherStackCount; // Offset: 0x60 // Size: 0x04
	int ItemTogetherCountMin; // Offset: 0x64 // Size: 0x04
	int ItemTogetherCountMax; // Offset: 0x68 // Size: 0x04
	char pad_0x6C[0x4]; // Offset: 0x6c // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.PrimeItemCircleConfig
// Size: 0x10 // Inherited bytes: 0x00
struct FPrimeItemCircleConfig {
	// Fields
	struct TArray<struct FSpotGroupProperty> PrimeItemCircleProperties; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.DynamicSpotConfig
// Size: 0x30 // Inherited bytes: 0x00
struct FDynamicSpotConfig {
	// Fields
	struct FString DynamicSpotPath; // Offset: 0x00 // Size: 0x10
	struct FCustomSpotConfig CustomSpotConfig; // Offset: 0x10 // Size: 0x10
	struct TArray<struct FSpotGroupProperty> SpotGroupProperties; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.CustomSpotConfig
// Size: 0x10 // Inherited bytes: 0x00
struct FCustomSpotConfig {
	// Fields
	bool bGroupNumCtrl; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int NeedGroupMin; // Offset: 0x04 // Size: 0x04
	int NeedGroupMax; // Offset: 0x08 // Size: 0x04
	bool bUseCookedRotator; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
};

// Object Name: ScriptStruct Gameplay.RepeatItemSpotData
// Size: 0x118 // Inherited bytes: 0x00
struct FRepeatItemSpotData {
	// Fields
	char pad_0x0[0xb8]; // Offset: 0x00 // Size: 0xb8
	float RepeatGenerateCD; // Offset: 0xb8 // Size: 0x04
	char pad_0xBC[0x4]; // Offset: 0xbc // Size: 0x04
	int64_t LastGenerateItemTime; // Offset: 0xc0 // Size: 0x08
	struct TMap<struct FString, int> CacheItemValeCategory; // Offset: 0xc8 // Size: 0x50
};

// Object Name: ScriptStruct Gameplay.ItemGenerateSpawnDataArray
// Size: 0x20 // Inherited bytes: 0x00
struct FItemGenerateSpawnDataArray {
	// Fields
	struct FString ValueCatetory; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FItemGenerateSpawnData> AllGenerateSpawnDatas; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.ExtraItemSpawn
// Size: 0x28 // Inherited bytes: 0x00
struct FExtraItemSpawn {
	// Fields
	int SpawnPercent; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString SpawnItemValue; // Offset: 0x08 // Size: 0x10
	struct FString SpawnItemCategory; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.AreaItemsLimit
// Size: 0xc0 // Inherited bytes: 0x00
struct FAreaItemsLimit {
	// Fields
	struct FRegionID RegionID; // Offset: 0x00 // Size: 0x0c
	bool IsBeginGenerateItem; // Offset: 0x0c // Size: 0x01
	bool IsCheckRecoverItem; // Offset: 0x0d // Size: 0x01
	char pad_0xE[0x2]; // Offset: 0x0e // Size: 0x02
	struct TArray<struct FVector> AvailablePosi; // Offset: 0x10 // Size: 0x10
	struct TMap<int, struct FAreaItemsNum> ItemsMaxLimit; // Offset: 0x20 // Size: 0x50
	struct TMap<int, struct FAreaItemsNum> ItemsMinLimit; // Offset: 0x70 // Size: 0x50
};

// Object Name: ScriptStruct Gameplay.AreaItemsNum
// Size: 0x18 // Inherited bytes: 0x00
struct FAreaItemsNum {
	// Fields
	int LimitNum; // Offset: 0x00 // Size: 0x04
	int CurNum; // Offset: 0x04 // Size: 0x04
	struct FString WrapperPath; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.AreaItemsLimitEdit
// Size: 0x28 // Inherited bytes: 0x00
struct FAreaItemsLimitEdit {
	// Fields
	int AreaX; // Offset: 0x00 // Size: 0x04
	int AreaY; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FGenerateItemLimit> ItemsMaxLimitEdit; // Offset: 0x08 // Size: 0x10
	struct TArray<struct FGenerateItemLimit> ItemsMinLimitEdit; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.GenerateItemLimit
// Size: 0x18 // Inherited bytes: 0x00
struct FGenerateItemLimit {
	// Fields
	int ItemID; // Offset: 0x00 // Size: 0x04
	int ItemNum; // Offset: 0x04 // Size: 0x04
	struct FString WrapperPath; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.ItemGenerateTableRow
// Size: 0x40 // Inherited bytes: 0x08
struct FItemGenerateTableRow : FTableRowBase {
	// Fields
	int ID; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct FString Value; // Offset: 0x10 // Size: 0x10
	struct FString Catetory; // Offset: 0x20 // Size: 0x10
	struct TArray<struct FItemGenerateSpawnData> AllGenerateSpawnDatas; // Offset: 0x30 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.ItemSpotSceneComponentArray
// Size: 0x18 // Inherited bytes: 0x00
struct FItemSpotSceneComponentArray {
	// Fields
	enum class ESpotType SpotType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct TArray<struct UItemSpotSceneComponent*> AllSpots; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.RevivalRecordBaseInfo
// Size: 0x40 // Inherited bytes: 0x00
struct FRevivalRecordBaseInfo {
	// Fields
	struct FString OpenID; // Offset: 0x00 // Size: 0x10
	uint16_t AreaID; // Offset: 0x10 // Size: 0x02
	uint8_t PlatID; // Offset: 0x12 // Size: 0x01
	char pad_0x13[0x5]; // Offset: 0x13 // Size: 0x05
	struct FString ZoneID; // Offset: 0x18 // Size: 0x10
	struct FString UserName; // Offset: 0x28 // Size: 0x10
	uint64 RoleID; // Offset: 0x38 // Size: 0x08
};

// Object Name: ScriptStruct Gameplay.ReportIDCardDestroyFlow
// Size: 0x58 // Inherited bytes: 0x40
struct FReportIDCardDestroyFlow : FRevivalRecordBaseInfo {
	// Fields
	char DestroyReason; // Offset: 0x40 // Size: 0x01
	char pad_0x41[0x7]; // Offset: 0x41 // Size: 0x07
	struct FString DestroyTime; // Offset: 0x48 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.ReportIDCardPickUpFlow
// Size: 0x50 // Inherited bytes: 0x40
struct FReportIDCardPickUpFlow : FRevivalRecordBaseInfo {
	// Fields
	uint64 PickerUID; // Offset: 0x40 // Size: 0x08
	int RemainingCountDown; // Offset: 0x48 // Size: 0x04
	char pad_0x4C[0x4]; // Offset: 0x4c // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.ReportIDCardProduceFlow
// Size: 0x50 // Inherited bytes: 0x40
struct FReportIDCardProduceFlow : FRevivalRecordBaseInfo {
	// Fields
	struct FString DeathTime; // Offset: 0x40 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.ReportRevivalFlow
// Size: 0x78 // Inherited bytes: 0x40
struct FReportRevivalFlow : FRevivalRecordBaseInfo {
	// Fields
	char RevivalFailedReason; // Offset: 0x40 // Size: 0x01
	char pad_0x41[0x7]; // Offset: 0x41 // Size: 0x07
	struct FString TowerLocation; // Offset: 0x48 // Size: 0x10
	struct FString RevivalTime; // Offset: 0x58 // Size: 0x10
	struct TArray<struct FPlayerRevivalInfo> PlayerRevivalInfos; // Offset: 0x68 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.PlayerRevivalInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FPlayerRevivalInfo {
	// Fields
	int64_t RevivedPlayerUID; // Offset: 0x00 // Size: 0x08
	int64_t PickerUID; // Offset: 0x08 // Size: 0x08
	int TimeAfterIDCardPicked; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.TssAntiFlow
// Size: 0x18 // Inherited bytes: 0x00
struct FTssAntiFlow {
	// Fields
	int GunID; // Offset: 0x00 // Size: 0x04
	int KillAICnt; // Offset: 0x04 // Size: 0x04
	int KillRealPlayerCnt; // Offset: 0x08 // Size: 0x04
	uint32_t ShotTime; // Offset: 0x0c // Size: 0x04
	uint32_t SendIndex; // Offset: 0x10 // Size: 0x04
	char ErrorCode; // Offset: 0x14 // Size: 0x01
	char pad_0x15[0x3]; // Offset: 0x15 // Size: 0x03
};

// Object Name: ScriptStruct Gameplay.PlayerNetworkData
// Size: 0x10 // Inherited bytes: 0x00
struct FPlayerNetworkData {
	// Fields
	uint64 UId; // Offset: 0x00 // Size: 0x08
	int TotalOutOfOrderPackets; // Offset: 0x08 // Size: 0x04
	int MaxOutOfOrderPacketsPerSec; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.ClientNetworkData
// Size: 0x30 // Inherited bytes: 0x00
struct FClientNetworkData {
	// Fields
	uint64 UId; // Offset: 0x00 // Size: 0x08
	int AvgPing; // Offset: 0x08 // Size: 0x04
	int MaxPing; // Offset: 0x0c // Size: 0x04
	int MinPing; // Offset: 0x10 // Size: 0x04
	int LostPackRate; // Offset: 0x14 // Size: 0x04
	int AvgNoOutlier; // Offset: 0x18 // Size: 0x04
	int StdNoOutlier; // Offset: 0x1c // Size: 0x04
	int NumNoOutlier; // Offset: 0x20 // Size: 0x04
	int InLoss; // Offset: 0x24 // Size: 0x04
	int OutLoss; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.NetworkData
// Size: 0x2c // Inherited bytes: 0x00
struct FNetworkData {
	// Fields
	int AlivePlayerNum; // Offset: 0x00 // Size: 0x04
	int ConnectionNum; // Offset: 0x04 // Size: 0x04
	int OnlineNum; // Offset: 0x08 // Size: 0x04
	int HighPingNum; // Offset: 0x0c // Size: 0x04
	int NoConPktPerSec; // Offset: 0x10 // Size: 0x04
	int NoConBadPktPerSec; // Offset: 0x14 // Size: 0x04
	int DisConPktPerSec; // Offset: 0x18 // Size: 0x04
	int WorstFrameMSPerSec; // Offset: 0x1c // Size: 0x04
	int BlockNonConnBurst; // Offset: 0x20 // Size: 0x04
	int BlockNetConnBurst; // Offset: 0x24 // Size: 0x04
	int DropPktCntPerSec; // Offset: 0x28 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.EquipmentFlow
// Size: 0x78 // Inherited bytes: 0x00
struct FEquipmentFlow {
	// Fields
	uint64 UId; // Offset: 0x00 // Size: 0x08
	int EventType; // Offset: 0x08 // Size: 0x04
	int GameTime; // Offset: 0x0c // Size: 0x04
	int MainWeapon1ID; // Offset: 0x10 // Size: 0x04
	int MainWeapon2ID; // Offset: 0x14 // Size: 0x04
	int ViceWeaponID; // Offset: 0x18 // Size: 0x04
	int HelmetID; // Offset: 0x1c // Size: 0x04
	int VestID; // Offset: 0x20 // Size: 0x04
	int BackPackID; // Offset: 0x24 // Size: 0x04
	struct TMap<int, int> Equipments; // Offset: 0x28 // Size: 0x50
};

// Object Name: ScriptStruct Gameplay.RealtimeVerifyInfo
// Size: 0x78 // Inherited bytes: 0x00
struct FRealtimeVerifyInfo {
	// Fields
	uint16_t AreaID; // Offset: 0x00 // Size: 0x02
	uint8_t PlatID; // Offset: 0x02 // Size: 0x01
	char pad_0x3[0x5]; // Offset: 0x03 // Size: 0x05
	struct FString ZoneID; // Offset: 0x08 // Size: 0x10
	int HitCountsNoAI; // Offset: 0x18 // Size: 0x04
	int HeadshotCountsNoAI; // Offset: 0x1c // Size: 0x04
	int ShotCounts; // Offset: 0x20 // Size: 0x04
	int Kills; // Offset: 0x24 // Size: 0x04
	int PrisonBreaks; // Offset: 0x28 // Size: 0x04
	int MoveSpeedAcc1; // Offset: 0x2c // Size: 0x04
	int MoveSpeedAcc2; // Offset: 0x30 // Size: 0x04
	int JumpMaxHeight2; // Offset: 0x34 // Size: 0x04
	int SkeletonLengthCheckInvaildNum; // Offset: 0x38 // Size: 0x04
	int MuzzleAndOwnerPosInVaildNum; // Offset: 0x3c // Size: 0x04
	int ImpactActorPosOffsetBigNum; // Offset: 0x40 // Size: 0x04
	int TotalImpactCharacterNum; // Offset: 0x44 // Size: 0x04
	int WeaponScopeHeightBigNum; // Offset: 0x48 // Size: 0x04
	int WeaponScopeDisBigNum; // Offset: 0x4c // Size: 0x04
	int OwnerHeadAndMuzzleBlockNum; // Offset: 0x50 // Size: 0x04
	int ImpactPointAndBulletDisBigNum; // Offset: 0x54 // Size: 0x04
	int ShootVerifyInvalidNum; // Offset: 0x58 // Size: 0x04
	float TotalSkeletonLengthMax; // Offset: 0x5c // Size: 0x04
	float TimeAccTotal; // Offset: 0x60 // Size: 0x04
	int TimeAccTimes; // Offset: 0x64 // Size: 0x04
	int SpeedQuickCheck; // Offset: 0x68 // Size: 0x04
	float ShootVerifyClientHitAABBCount; // Offset: 0x6c // Size: 0x04
	float ShootVerifyDSAABBMissCount; // Offset: 0x70 // Size: 0x04
	float PlayerZ; // Offset: 0x74 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.SecMrpcsFlow
// Size: 0x88 // Inherited bytes: 0x00
struct FSecMrpcsFlow {
	// Fields
	struct FString GameSvrId; // Offset: 0x00 // Size: 0x10
	int64_t dtEventTime; // Offset: 0x10 // Size: 0x08
	struct FString GameAppID; // Offset: 0x18 // Size: 0x10
	struct FString OpenID; // Offset: 0x28 // Size: 0x10
	uint8_t PlatID; // Offset: 0x38 // Size: 0x01
	char pad_0x39[0x1]; // Offset: 0x39 // Size: 0x01
	uint16_t AreaID; // Offset: 0x3a // Size: 0x02
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
	struct FString ZoneID; // Offset: 0x40 // Size: 0x10
	uint64 BattleID; // Offset: 0x50 // Size: 0x08
	struct FString UserName; // Offset: 0x58 // Size: 0x10
	uint64 SvrRoleID; // Offset: 0x68 // Size: 0x08
	char SecMrpcsFlowID; // Offset: 0x70 // Size: 0x01
	char pad_0x71[0x7]; // Offset: 0x71 // Size: 0x07
	struct FString MrpcsFlowStr; // Offset: 0x78 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.ClientSecMrpcsFlow
// Size: 0x18 // Inherited bytes: 0x00
struct FClientSecMrpcsFlow {
	// Fields
	char SecMrpcsFlowID; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct TArray<char> MrpcsFlowData; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.GameMisKillFlow
// Size: 0x80 // Inherited bytes: 0x00
struct FGameMisKillFlow {
	// Fields
	struct FString GameSvrId; // Offset: 0x00 // Size: 0x10
	int64_t dtEventTime; // Offset: 0x10 // Size: 0x08
	struct FString GameAppID; // Offset: 0x18 // Size: 0x10
	uint64 MyRoleID; // Offset: 0x28 // Size: 0x08
	struct FString MyOpenID; // Offset: 0x30 // Size: 0x10
	uint16_t AreaID; // Offset: 0x40 // Size: 0x02
	uint8_t PlatID; // Offset: 0x42 // Size: 0x01
	char pad_0x43[0x5]; // Offset: 0x43 // Size: 0x05
	struct FString ZoneID; // Offset: 0x48 // Size: 0x10
	uint64 BattleID; // Offset: 0x58 // Size: 0x08
	struct FString DeadDamangeType; // Offset: 0x60 // Size: 0x10
	uint64 TeammateRoleID; // Offset: 0x70 // Size: 0x08
	int bConfirmMisKill; // Offset: 0x78 // Size: 0x04
	char pad_0x7C[0x4]; // Offset: 0x7c // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.GameEndReport
// Size: 0xb0 // Inherited bytes: 0x00
struct FGameEndReport {
	// Fields
	int PvePoliceOfficeTriggerCount; // Offset: 0x00 // Size: 0x04
	int PveZombieGrenadeCount; // Offset: 0x04 // Size: 0x04
	int PveGenerateZombieByNoTeamMate; // Offset: 0x08 // Size: 0x04
	int NoneAIGameTime; // Offset: 0x0c // Size: 0x04
	struct TMap<int, int> AISpawnCountMap; // Offset: 0x10 // Size: 0x50
	struct TMap<int, int> AIEnterFightingCountMap; // Offset: 0x60 // Size: 0x50
};

// Object Name: ScriptStruct Gameplay.VerifyInfoFlow
// Size: 0x40 // Inherited bytes: 0x00
struct FVerifyInfoFlow {
	// Fields
	struct FString GameAppID; // Offset: 0x00 // Size: 0x10
	struct FString OpenID; // Offset: 0x10 // Size: 0x10
	uint64 UId; // Offset: 0x20 // Size: 0x08
	uint64 BattleID; // Offset: 0x28 // Size: 0x08
	int LocationX; // Offset: 0x30 // Size: 0x04
	int LocationY; // Offset: 0x34 // Size: 0x04
	int LocationZ; // Offset: 0x38 // Size: 0x04
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.GvoiceTeamQuit
// Size: 0x30 // Inherited bytes: 0x00
struct FGvoiceTeamQuit {
	// Fields
	struct FString GVoiceTeamID; // Offset: 0x00 // Size: 0x10
	struct FString GVoiceRoomID; // Offset: 0x10 // Size: 0x10
	int GVoiceTeamMemberID; // Offset: 0x20 // Size: 0x04
	int GVoiceRoomMemberID; // Offset: 0x24 // Size: 0x04
	uint64 UId; // Offset: 0x28 // Size: 0x08
};

// Object Name: ScriptStruct Gameplay.GvoiceTeamCreate
// Size: 0x30 // Inherited bytes: 0x00
struct FGvoiceTeamCreate {
	// Fields
	struct FString GVoiceTeamID; // Offset: 0x00 // Size: 0x10
	struct FString GVoiceRoomID; // Offset: 0x10 // Size: 0x10
	int GVoiceTeamMemberID; // Offset: 0x20 // Size: 0x04
	int GVoiceRoomMemberID; // Offset: 0x24 // Size: 0x04
	uint64 UId; // Offset: 0x28 // Size: 0x08
};

// Object Name: ScriptStruct Gameplay.WatchGamePlayerInfoClickFlow
// Size: 0x10 // Inherited bytes: 0x00
struct FWatchGamePlayerInfoClickFlow {
	// Fields
	uint64 WatchPlayer_UID; // Offset: 0x00 // Size: 0x08
	int WatchTimes; // Offset: 0x08 // Size: 0x04
	float Duration; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.GameSetting
// Size: 0x118 // Inherited bytes: 0x00
struct FGameSetting {
	// Fields
	uint64 RoleID; // Offset: 0x00 // Size: 0x08
	struct FGameSetting_BasicSetting BasicSetting; // Offset: 0x08 // Size: 0x2c
	struct FGameSetting_ArtQuality ArtQuality; // Offset: 0x34 // Size: 0x08
	struct FGameSetting_Operate Operate; // Offset: 0x3c // Size: 0x08
	struct FGameSetting_Vehicle Vehicle; // Offset: 0x44 // Size: 0x08
	struct FGameSetting_Sensibility Sensibility; // Offset: 0x4c // Size: 0x88
	char pad_0xD4[0x4]; // Offset: 0xd4 // Size: 0x04
	struct FGameSetting_PickUp PickUp; // Offset: 0xd8 // Size: 0x40
};

// Object Name: ScriptStruct Gameplay.GameSetting_PickUp
// Size: 0x40 // Inherited bytes: 0x00
struct FGameSetting_PickUp {
	// Fields
	bool AutoPickUpSwitcher; // Offset: 0x00 // Size: 0x01
	bool AutoPickupPistol; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x2]; // Offset: 0x02 // Size: 0x02
	struct FGameSetting_PickUp_Drug Drug; // Offset: 0x04 // Size: 0x18
	struct FGamesetting_PickUp_Grenade Grenade; // Offset: 0x1c // Size: 0x10
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct TArray<struct FGameSetting_PickUp_WeaponBullet> WeaponBulletList; // Offset: 0x30 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.GameSetting_PickUp_WeaponBullet
// Size: 0x08 // Inherited bytes: 0x00
struct FGameSetting_PickUp_WeaponBullet {
	// Fields
	int WeaponID; // Offset: 0x00 // Size: 0x04
	int BulletCount; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.Gamesetting_PickUp_Grenade
// Size: 0x10 // Inherited bytes: 0x00
struct FGamesetting_PickUp_Grenade {
	// Fields
	int IncendiaryBomb; // Offset: 0x00 // Size: 0x04
	int ShockBomb; // Offset: 0x04 // Size: 0x04
	int SmokeBomb; // Offset: 0x08 // Size: 0x04
	int GrenadeFragmented; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.GameSetting_PickUp_Drug
// Size: 0x18 // Inherited bytes: 0x00
struct FGameSetting_PickUp_Drug {
	// Fields
	int MedicalTreatment; // Offset: 0x00 // Size: 0x04
	int Bandage; // Offset: 0x04 // Size: 0x04
	int PainKiller; // Offset: 0x08 // Size: 0x04
	int Adrenaline; // Offset: 0x0c // Size: 0x04
	int EnergyDrink; // Offset: 0x10 // Size: 0x04
	int FirstAidKit; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.GameSetting_Sensibility
// Size: 0x88 // Inherited bytes: 0x00
struct FGameSetting_Sensibility {
	// Fields
	int CameraLensSensibility; // Offset: 0x00 // Size: 0x04
	struct FGameSetting_Sensibility_FreeCam Sens_FreeCamera; // Offset: 0x04 // Size: 0x0c
	struct FGameSetting_Sensibility_Cam Sens_Camera; // Offset: 0x10 // Size: 0x28
	struct FGameSetting_Sensibility_Fire Sens_Fire; // Offset: 0x38 // Size: 0x28
	struct FGameSetting_Sensibility_Gyroscope Sens_Gyroscope; // Offset: 0x60 // Size: 0x28
};

// Object Name: ScriptStruct Gameplay.GameSetting_Sensibility_Gyroscope
// Size: 0x28 // Inherited bytes: 0x00
struct FGameSetting_Sensibility_Gyroscope {
	// Fields
	float GyroscopeSenNoneSniper; // Offset: 0x00 // Size: 0x04
	float GyroscopeSenNoneSniperFP; // Offset: 0x04 // Size: 0x04
	float GyroscopeSenRedDotSniper; // Offset: 0x08 // Size: 0x04
	float GyroscopeSen2XSniper; // Offset: 0x0c // Size: 0x04
	float GyroscopeSen3XSniper; // Offset: 0x10 // Size: 0x04
	float GyroscopeSen4XSniper; // Offset: 0x14 // Size: 0x04
	float GyroscopeSen6XSniper; // Offset: 0x18 // Size: 0x04
	float GyroscopeSen8XSniper; // Offset: 0x1c // Size: 0x04
	float GyroscopeShoulderSniper; // Offset: 0x20 // Size: 0x04
	float GyroscopeShoulderSniperFP; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.GameSetting_Sensibility_Fire
// Size: 0x28 // Inherited bytes: 0x00
struct FGameSetting_Sensibility_Fire {
	// Fields
	float FireCamLensSenNoneSniper; // Offset: 0x00 // Size: 0x04
	float FireCamLensSenNoneSniperFP; // Offset: 0x04 // Size: 0x04
	float FireCamLensSenRedDotSniper; // Offset: 0x08 // Size: 0x04
	float FireCamLensSen2XSniper; // Offset: 0x0c // Size: 0x04
	float FireCamLensSen3XSniper; // Offset: 0x10 // Size: 0x04
	float FireCamLensSen4XSniper; // Offset: 0x14 // Size: 0x04
	float FireCamLensSen6XSniper; // Offset: 0x18 // Size: 0x04
	float FireCamLensSen8XSniper; // Offset: 0x1c // Size: 0x04
	float FireCamLensSenShoulderSniper; // Offset: 0x20 // Size: 0x04
	float FireCamLensSenShoulderSniperFP; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.GameSetting_Sensibility_Cam
// Size: 0x28 // Inherited bytes: 0x00
struct FGameSetting_Sensibility_Cam {
	// Fields
	float CamLensSenNoneSniper; // Offset: 0x00 // Size: 0x04
	float CamLensSenNoneSniperFP; // Offset: 0x04 // Size: 0x04
	float CamLensSenRedDotSniper; // Offset: 0x08 // Size: 0x04
	float CamLensSen2XSniper; // Offset: 0x0c // Size: 0x04
	float CamLensSen3XSniper; // Offset: 0x10 // Size: 0x04
	float CamLensSen4XSniper; // Offset: 0x14 // Size: 0x04
	float CamLensSen6XSniper; // Offset: 0x18 // Size: 0x04
	float CamLensSen8XSniper; // Offset: 0x1c // Size: 0x04
	float CamLensSenShoulderSniper; // Offset: 0x20 // Size: 0x04
	float CamLensSenShoulderSniperFP; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.GameSetting_Sensibility_FreeCam
// Size: 0x0c // Inherited bytes: 0x00
struct FGameSetting_Sensibility_FreeCam {
	// Fields
	float VehicleEye; // Offset: 0x00 // Size: 0x04
	float ParachuteEye; // Offset: 0x04 // Size: 0x04
	float CamFpFreeEye; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.GameSetting_Vehicle
// Size: 0x08 // Inherited bytes: 0x00
struct FGameSetting_Vehicle {
	// Fields
	int VehicleControlMode; // Offset: 0x00 // Size: 0x04
	int DrivingViewMode; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.GameSetting_Operate
// Size: 0x08 // Inherited bytes: 0x00
struct FGameSetting_Operate {
	// Fields
	int FireMode; // Offset: 0x00 // Size: 0x04
	bool Touch_3D_Switcher; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
};

// Object Name: ScriptStruct Gameplay.GameSetting_ArtQuality
// Size: 0x08 // Inherited bytes: 0x00
struct FGameSetting_ArtQuality {
	// Fields
	int ArtStyle; // Offset: 0x00 // Size: 0x04
	bool AntiAliasingSwitch; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
};

// Object Name: ScriptStruct Gameplay.GameSetting_BasicSetting
// Size: 0x2c // Inherited bytes: 0x00
struct FGameSetting_BasicSetting {
	// Fields
	int CrossHairColor; // Offset: 0x00 // Size: 0x04
	bool AimAssist; // Offset: 0x04 // Size: 0x01
	bool WallFeedBack; // Offset: 0x05 // Size: 0x01
	char pad_0x6[0x2]; // Offset: 0x06 // Size: 0x02
	int SingleShotWeaponShootMode; // Offset: 0x08 // Size: 0x04
	int ShotGunShootMode; // Offset: 0x0c // Size: 0x04
	bool LeftRightShoot; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x3]; // Offset: 0x11 // Size: 0x03
	int LRShootMode; // Offset: 0x14 // Size: 0x04
	bool LRShootSniperSwitch; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x3]; // Offset: 0x19 // Size: 0x03
	int LeftHandFire; // Offset: 0x1c // Size: 0x04
	int Gyroscope; // Offset: 0x20 // Size: 0x04
	bool AutoOpenDoor; // Offset: 0x24 // Size: 0x01
	bool IntelligentDrugs; // Offset: 0x25 // Size: 0x01
	bool ActorAnimationSwitch; // Offset: 0x26 // Size: 0x01
	bool FPViewSwitch; // Offset: 0x27 // Size: 0x01
	bool ShoulderEnable; // Offset: 0x28 // Size: 0x01
	bool ShoulderMode; // Offset: 0x29 // Size: 0x01
	char pad_0x2A[0x2]; // Offset: 0x2a // Size: 0x02
};

// Object Name: ScriptStruct Gameplay.SecPlayerKillFlow
// Size: 0x108 // Inherited bytes: 0x00
struct FSecPlayerKillFlow {
	// Fields
	struct FString GameSvrId; // Offset: 0x00 // Size: 0x10
	int64_t dtEventTime; // Offset: 0x10 // Size: 0x08
	struct FString GameAppID; // Offset: 0x18 // Size: 0x10
	struct FString OpenID; // Offset: 0x28 // Size: 0x10
	uint8_t PlatID; // Offset: 0x38 // Size: 0x01
	char pad_0x39[0x1]; // Offset: 0x39 // Size: 0x01
	uint16_t AreaID; // Offset: 0x3a // Size: 0x02
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
	struct FString ZoneID; // Offset: 0x40 // Size: 0x10
	uint64 BattleID; // Offset: 0x50 // Size: 0x08
	struct FString UserName; // Offset: 0x58 // Size: 0x10
	uint64 SvrRoleID; // Offset: 0x68 // Size: 0x08
	int64_t ClientStartTime; // Offset: 0x70 // Size: 0x08
	uint8_t SecPlayerKillFlowID; // Offset: 0x78 // Size: 0x01
	char pad_0x79[0x3]; // Offset: 0x79 // Size: 0x03
	int GunID; // Offset: 0x7c // Size: 0x04
	uint64 KilledPlayerRoleID; // Offset: 0x80 // Size: 0x08
	struct FRecoilInfo RecoilInfo; // Offset: 0x88 // Size: 0x36
	char pad_0xBE[0x2]; // Offset: 0xbe // Size: 0x02
	int LocationX; // Offset: 0xc0 // Size: 0x04
	int LocationY; // Offset: 0xc4 // Size: 0x04
	int LocationZ; // Offset: 0xc8 // Size: 0x04
	int KilledLocationX; // Offset: 0xcc // Size: 0x04
	int KilledLocationY; // Offset: 0xd0 // Size: 0x04
	int KilledLocationZ; // Offset: 0xd4 // Size: 0x04
	int BornPointID; // Offset: 0xd8 // Size: 0x04
	int KilledBornPointID; // Offset: 0xdc // Size: 0x04
	int TeamID; // Offset: 0xe0 // Size: 0x04
	char pad_0xE4[0x4]; // Offset: 0xe4 // Size: 0x04
	struct FString GameModeID; // Offset: 0xe8 // Size: 0x10
	uint64 PawnState; // Offset: 0xf8 // Size: 0x08
	uint64 KilledPawnState; // Offset: 0x100 // Size: 0x08
};

// Object Name: ScriptStruct Gameplay.RecoilInfo
// Size: 0x36 // Inherited bytes: 0x00
struct FRecoilInfo {
	// Fields
	int16_t VerticalRecoilMin; // Offset: 0x00 // Size: 0x02
	int16_t VerticalRecoilMax; // Offset: 0x02 // Size: 0x02
	int16_t VerticalRecoilVariation; // Offset: 0x04 // Size: 0x02
	int16_t VerticalRecoveryModifier; // Offset: 0x06 // Size: 0x02
	int16_t VerticalRecoveryClamp; // Offset: 0x08 // Size: 0x02
	int16_t VerticalRecoveryMax; // Offset: 0x0a // Size: 0x02
	int16_t LeftMax; // Offset: 0x0c // Size: 0x02
	int16_t RightMax; // Offset: 0x0e // Size: 0x02
	int16_t HorizontalTendency; // Offset: 0x10 // Size: 0x02
	int16_t BulletPerSwitch; // Offset: 0x12 // Size: 0x02
	int16_t TimePerSwitch; // Offset: 0x14 // Size: 0x02
	bool SwitchOnTime; // Offset: 0x16 // Size: 0x01
	char pad_0x17[0x1]; // Offset: 0x17 // Size: 0x01
	int16_t RecoilSpeedVertical; // Offset: 0x18 // Size: 0x02
	int16_t RecoilSpeedHorizontal; // Offset: 0x1a // Size: 0x02
	int16_t RecovertySpeedVertical; // Offset: 0x1c // Size: 0x02
	int16_t RecoilValueClimb; // Offset: 0x1e // Size: 0x02
	int16_t RecoilValueFail; // Offset: 0x20 // Size: 0x02
	int16_t RecoilModifierStand; // Offset: 0x22 // Size: 0x02
	int16_t RecoilModifierCrouch; // Offset: 0x24 // Size: 0x02
	int16_t RecoilModifierProne; // Offset: 0x26 // Size: 0x02
	int16_t RecoilHorizontalMinScalar; // Offset: 0x28 // Size: 0x02
	int16_t BurstEmptyDelay; // Offset: 0x2a // Size: 0x02
	bool ShootSightReturn; // Offset: 0x2c // Size: 0x01
	char pad_0x2D[0x1]; // Offset: 0x2d // Size: 0x01
	int16_t ShootSightReturnSpeed; // Offset: 0x2e // Size: 0x02
	int16_t AccessoriesVRecoilFactor; // Offset: 0x30 // Size: 0x02
	int16_t AccessoriesHRecoilFactor; // Offset: 0x32 // Size: 0x02
	int16_t AccessoriesRecoveryFactor; // Offset: 0x34 // Size: 0x02
};

// Object Name: ScriptStruct Gameplay.ClientSecPlayerKillFlow
// Size: 0x90 // Inherited bytes: 0x00
struct FClientSecPlayerKillFlow {
	// Fields
	int64_t ClientStartTime; // Offset: 0x00 // Size: 0x08
	uint8_t SecPlayerKillFlowID; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
	int GunID; // Offset: 0x0c // Size: 0x04
	uint32_t KilledPlayerKey; // Offset: 0x10 // Size: 0x04
	struct FRecoilInfo RecoilInfo; // Offset: 0x14 // Size: 0x36
	char pad_0x4A[0x2]; // Offset: 0x4a // Size: 0x02
	int LocationX; // Offset: 0x4c // Size: 0x04
	int LocationY; // Offset: 0x50 // Size: 0x04
	int LocationZ; // Offset: 0x54 // Size: 0x04
	int KilledLocationX; // Offset: 0x58 // Size: 0x04
	int KilledLocationY; // Offset: 0x5c // Size: 0x04
	int KilledLocationZ; // Offset: 0x60 // Size: 0x04
	int KilledTeamID; // Offset: 0x64 // Size: 0x04
	int TeamID; // Offset: 0x68 // Size: 0x04
	char pad_0x6C[0x4]; // Offset: 0x6c // Size: 0x04
	struct FString GameModeID; // Offset: 0x70 // Size: 0x10
	uint64 PawnState; // Offset: 0x80 // Size: 0x08
	uint64 KilledPawnState; // Offset: 0x88 // Size: 0x08
};

// Object Name: ScriptStruct Gameplay.PlayerRouteFlow
// Size: 0x78 // Inherited bytes: 0x00
struct FPlayerRouteFlow {
	// Fields
	struct FString GameAppID; // Offset: 0x00 // Size: 0x10
	uint8_t PlatID; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x7]; // Offset: 0x11 // Size: 0x07
	struct FString OpenID; // Offset: 0x18 // Size: 0x10
	uint64 UId; // Offset: 0x28 // Size: 0x08
	uint64 BattleID; // Offset: 0x30 // Size: 0x08
	uint8_t SeasonID; // Offset: 0x38 // Size: 0x01
	char pad_0x39[0x7]; // Offset: 0x39 // Size: 0x07
	struct FString PlayerName; // Offset: 0x40 // Size: 0x10
	struct TArray<struct FPosAndTime> Route; // Offset: 0x50 // Size: 0x10
	struct FPosAndTime End; // Offset: 0x60 // Size: 0x18
};

// Object Name: ScriptStruct Gameplay.PosAndTime
// Size: 0x18 // Inherited bytes: 0x00
struct FPosAndTime {
	// Fields
	int LocationX; // Offset: 0x00 // Size: 0x04
	int LocationY; // Offset: 0x04 // Size: 0x04
	int LocationZ; // Offset: 0x08 // Size: 0x04
	int Time; // Offset: 0x0c // Size: 0x04
	uint64 PlayerState; // Offset: 0x10 // Size: 0x08
};

// Object Name: ScriptStruct Gameplay.PlayerBehaviorFlow
// Size: 0x98 // Inherited bytes: 0x00
struct FPlayerBehaviorFlow {
	// Fields
	uint64 FrameCounter; // Offset: 0x00 // Size: 0x08
	uint64 BattleID; // Offset: 0x08 // Size: 0x08
	bool IsTargetPlayer; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x7]; // Offset: 0x11 // Size: 0x07
	struct FString Name; // Offset: 0x18 // Size: 0x10
	uint32_t PlayerKey; // Offset: 0x28 // Size: 0x04
	uint32_t RelevantPlayerKey; // Offset: 0x2c // Size: 0x04
	int LocationX; // Offset: 0x30 // Size: 0x04
	int LocationY; // Offset: 0x34 // Size: 0x04
	int LocationZ; // Offset: 0x38 // Size: 0x04
	int RotationP; // Offset: 0x3c // Size: 0x04
	int RotationY; // Offset: 0x40 // Size: 0x04
	int RotationR; // Offset: 0x44 // Size: 0x04
	struct FString Stats; // Offset: 0x48 // Size: 0x10
	bool IsDying; // Offset: 0x58 // Size: 0x01
	char pad_0x59[0x3]; // Offset: 0x59 // Size: 0x03
	float Breath; // Offset: 0x5c // Size: 0x04
	int SpeedX; // Offset: 0x60 // Size: 0x04
	int SpeedY; // Offset: 0x64 // Size: 0x04
	int SpeedZ; // Offset: 0x68 // Size: 0x04
	float Health; // Offset: 0x6c // Size: 0x04
	float Energy; // Offset: 0x70 // Size: 0x04
	int CurrentWeaponID; // Offset: 0x74 // Size: 0x04
	int Ammo; // Offset: 0x78 // Size: 0x04
	int SightId; // Offset: 0x7c // Size: 0x04
	bool IsBeAttacking; // Offset: 0x80 // Size: 0x01
	char pad_0x81[0x3]; // Offset: 0x81 // Size: 0x03
	int BeAttackDirX; // Offset: 0x84 // Size: 0x04
	int BeAttackDirY; // Offset: 0x88 // Size: 0x04
	int BeAttackDirZ; // Offset: 0x8c // Size: 0x04
	int MedicineId; // Offset: 0x90 // Size: 0x04
	bool IsHaveSound; // Offset: 0x94 // Size: 0x01
	char pad_0x95[0x3]; // Offset: 0x95 // Size: 0x03
};

// Object Name: ScriptStruct Gameplay.HurtFlow
// Size: 0x120 // Inherited bytes: 0x00
struct FHurtFlow {
	// Fields
	struct FString GameSvrId; // Offset: 0x00 // Size: 0x10
	int64_t dtEventTime; // Offset: 0x10 // Size: 0x08
	struct FString GameAppID; // Offset: 0x18 // Size: 0x10
	struct FString OpenID; // Offset: 0x28 // Size: 0x10
	uint8_t PlatID; // Offset: 0x38 // Size: 0x01
	char pad_0x39[0x1]; // Offset: 0x39 // Size: 0x01
	uint16_t AreaID; // Offset: 0x3a // Size: 0x02
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
	struct FString ZoneID; // Offset: 0x40 // Size: 0x10
	uint64 BattleID; // Offset: 0x50 // Size: 0x08
	int64_t ClientStartTime; // Offset: 0x58 // Size: 0x08
	int MrpcsFlowcount_; // Offset: 0x60 // Size: 0x04
	char pad_0x64[0x4]; // Offset: 0x64 // Size: 0x04
	struct TArray<int> MrpcsFlow; // Offset: 0x68 // Size: 0x10
	struct FString UserName; // Offset: 0x78 // Size: 0x10
	uint64 RoleID; // Offset: 0x88 // Size: 0x08
	uint8_t RoleType; // Offset: 0x90 // Size: 0x01
	char pad_0x91[0x7]; // Offset: 0x91 // Size: 0x07
	struct FString EnemyOpenID; // Offset: 0x98 // Size: 0x10
	struct FString EnemyUserName; // Offset: 0xa8 // Size: 0x10
	uint64 EnemyRoleID; // Offset: 0xb8 // Size: 0x08
	int EnemyRoleType; // Offset: 0xc0 // Size: 0x04
	uint32_t HurtTime; // Offset: 0xc4 // Size: 0x04
	int HurtType; // Offset: 0xc8 // Size: 0x04
	int HitType; // Offset: 0xcc // Size: 0x04
	int DamageStart; // Offset: 0xd0 // Size: 0x04
	int DamageReduce; // Offset: 0xd4 // Size: 0x04
	int ArmorDef; // Offset: 0xd8 // Size: 0x04
	int HPstart; // Offset: 0xdc // Size: 0x04
	int HPEnd; // Offset: 0xe0 // Size: 0x04
	int ArmorHPStart1; // Offset: 0xe4 // Size: 0x04
	int ArmorHPEnd1; // Offset: 0xe8 // Size: 0x04
	int ArmorHPStart2; // Offset: 0xec // Size: 0x04
	int ArmorHPEnd2; // Offset: 0xf0 // Size: 0x04
	int CarHPStart; // Offset: 0xf4 // Size: 0x04
	int CarHPEnd; // Offset: 0xf8 // Size: 0x04
	int FallHeight; // Offset: 0xfc // Size: 0x04
	int HypoxiaTime; // Offset: 0x100 // Size: 0x04
	int HypoxiaHurtTotal; // Offset: 0x104 // Size: 0x04
	int PlayerKilled; // Offset: 0x108 // Size: 0x04
	int ArmorKill; // Offset: 0x10c // Size: 0x04
	int CarKill; // Offset: 0x110 // Size: 0x04
	int IfIsAI; // Offset: 0x114 // Size: 0x04
	int CircleIndex; // Offset: 0x118 // Size: 0x04
	uint32_t HurtFlowID; // Offset: 0x11c // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.SecAttackFlow
// Size: 0xc0 // Inherited bytes: 0x00
struct FSecAttackFlow {
	// Fields
	struct FString GameSvrId; // Offset: 0x00 // Size: 0x10
	int64_t dtEventTime; // Offset: 0x10 // Size: 0x08
	struct FString GameAppID; // Offset: 0x18 // Size: 0x10
	struct FString OpenID; // Offset: 0x28 // Size: 0x10
	uint8_t PlatID; // Offset: 0x38 // Size: 0x01
	char pad_0x39[0x1]; // Offset: 0x39 // Size: 0x01
	uint16_t AreaID; // Offset: 0x3a // Size: 0x02
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
	struct FString ZoneID; // Offset: 0x40 // Size: 0x10
	uint64 BattleID; // Offset: 0x50 // Size: 0x08
	int64_t ClientStartTime; // Offset: 0x58 // Size: 0x08
	uint64 RoleID; // Offset: 0x60 // Size: 0x08
	struct FString TargetUserName; // Offset: 0x68 // Size: 0x10
	struct FString TargetOpenID; // Offset: 0x78 // Size: 0x10
	uint64 TargetRoleID; // Offset: 0x88 // Size: 0x08
	struct FString HitPart; // Offset: 0x90 // Size: 0x10
	int GunID; // Offset: 0xa0 // Size: 0x04
	char PlayerKill; // Offset: 0xa4 // Size: 0x01
	char pad_0xA5[0x3]; // Offset: 0xa5 // Size: 0x03
	uint64 AttackFlowID; // Offset: 0xa8 // Size: 0x08
	int KillAICnt; // Offset: 0xb0 // Size: 0x04
	int KillRealPlayerCnt; // Offset: 0xb4 // Size: 0x04
	int16_t BulletDown; // Offset: 0xb8 // Size: 0x02
	char pad_0xBA[0x6]; // Offset: 0xba // Size: 0x06
};

// Object Name: ScriptStruct Gameplay.AttackFlow
// Size: 0x1c8 // Inherited bytes: 0x00
struct FAttackFlow {
	// Fields
	struct FString GameSvrId; // Offset: 0x00 // Size: 0x10
	int64_t dtEventTime; // Offset: 0x10 // Size: 0x08
	struct FString GameAppID; // Offset: 0x18 // Size: 0x10
	struct FString OpenID; // Offset: 0x28 // Size: 0x10
	uint16_t AreaID; // Offset: 0x38 // Size: 0x02
	uint8_t PlatID; // Offset: 0x3a // Size: 0x01
	char pad_0x3B[0x5]; // Offset: 0x3b // Size: 0x05
	struct FString ZoneID; // Offset: 0x40 // Size: 0x10
	uint64 BattleID; // Offset: 0x50 // Size: 0x08
	int64_t ClientStartTime; // Offset: 0x58 // Size: 0x08
	int MrpcsFlowcount_; // Offset: 0x60 // Size: 0x04
	char pad_0x64[0x4]; // Offset: 0x64 // Size: 0x04
	struct TArray<int> MrpcsFlow; // Offset: 0x68 // Size: 0x10
	struct FString UserName; // Offset: 0x78 // Size: 0x10
	uint64 RoleID; // Offset: 0x88 // Size: 0x08
	uint8_t RoleType; // Offset: 0x90 // Size: 0x01
	char pad_0x91[0x7]; // Offset: 0x91 // Size: 0x07
	struct FString TargetOpenID; // Offset: 0x98 // Size: 0x10
	struct FString TargetUserName; // Offset: 0xa8 // Size: 0x10
	uint64 TargetRoleID; // Offset: 0xb8 // Size: 0x08
	uint8_t TargetRoleType; // Offset: 0xc0 // Size: 0x01
	char pad_0xC1[0x7]; // Offset: 0xc1 // Size: 0x07
	struct FString GunName; // Offset: 0xc8 // Size: 0x10
	struct FString GunPartsType; // Offset: 0xd8 // Size: 0x10
	uint8_t SightType; // Offset: 0xe8 // Size: 0x01
	char pad_0xE9[0x3]; // Offset: 0xe9 // Size: 0x03
	int BulletSpeed; // Offset: 0xec // Size: 0x04
	uint8_t MagazineMax; // Offset: 0xf0 // Size: 0x01
	uint8_t MagazineLeft; // Offset: 0xf1 // Size: 0x01
	char pad_0xF2[0x2]; // Offset: 0xf2 // Size: 0x02
	int ShotFrequency; // Offset: 0xf4 // Size: 0x04
	int BulletDamage; // Offset: 0xf8 // Size: 0x04
	int16_t BulletDown; // Offset: 0xfc // Size: 0x02
	char BulletDamageReduce; // Offset: 0xfe // Size: 0x01
	char pad_0xFF[0x1]; // Offset: 0xff // Size: 0x01
	int Recoil; // Offset: 0x100 // Size: 0x04
	int ReloadTime; // Offset: 0x104 // Size: 0x04
	struct FString PlayerState; // Offset: 0x108 // Size: 0x10
	char ShotPose; // Offset: 0x118 // Size: 0x01
	char FireType; // Offset: 0x119 // Size: 0x01
	char bHoldBreath : 1; // Offset: 0x11a // Size: 0x01
	char pad_0x11A_1 : 7; // Offset: 0x11a // Size: 0x01
	char Sideways; // Offset: 0x11b // Size: 0x01
	int ShootingDeviationX; // Offset: 0x11c // Size: 0x04
	int ShootingDeviationY; // Offset: 0x120 // Size: 0x04
	uint32_t ZeroDistance; // Offset: 0x124 // Size: 0x04
	uint32_t ShotTime; // Offset: 0x128 // Size: 0x04
	int HitTime; // Offset: 0x12c // Size: 0x04
	int PlayerPositionX; // Offset: 0x130 // Size: 0x04
	int PlayerPositionY; // Offset: 0x134 // Size: 0x04
	int PlayerPositionZ; // Offset: 0x138 // Size: 0x04
	int GunPositionX; // Offset: 0x13c // Size: 0x04
	int GunPositionY; // Offset: 0x140 // Size: 0x04
	int GunPositionZ; // Offset: 0x144 // Size: 0x04
	int BulletsBornPositionX; // Offset: 0x148 // Size: 0x04
	int BulletsBornPositionY; // Offset: 0x14c // Size: 0x04
	int BulletsBornPositionZ; // Offset: 0x150 // Size: 0x04
	uint32_t LastHitTime; // Offset: 0x154 // Size: 0x04
	uint32_t BulletFlyDistance; // Offset: 0x158 // Size: 0x04
	uint32_t BulletFlyTime; // Offset: 0x15c // Size: 0x04
	int HitPositionX; // Offset: 0x160 // Size: 0x04
	int HitPositionY; // Offset: 0x164 // Size: 0x04
	int HitPositionZ; // Offset: 0x168 // Size: 0x04
	char HitPart; // Offset: 0x16c // Size: 0x01
	char bHitCar : 1; // Offset: 0x16d // Size: 0x01
	char bTireOut : 1; // Offset: 0x16d // Size: 0x01
	char pad_0x16D_2 : 6; // Offset: 0x16d // Size: 0x01
	char BulletCost; // Offset: 0x16e // Size: 0x01
	char pad_0x16F[0x1]; // Offset: 0x16f // Size: 0x01
	int HPstart; // Offset: 0x170 // Size: 0x04
	int HPEnd; // Offset: 0x174 // Size: 0x04
	int ArmorHPStart; // Offset: 0x178 // Size: 0x04
	int ArmorHPEnd; // Offset: 0x17c // Size: 0x04
	int CarHPStart; // Offset: 0x180 // Size: 0x04
	int CarHPEnd; // Offset: 0x184 // Size: 0x04
	char PlayerKill; // Offset: 0x188 // Size: 0x01
	char bArmorKill : 1; // Offset: 0x189 // Size: 0x01
	char bCarKill : 1; // Offset: 0x189 // Size: 0x01
	char pad_0x189_2 : 6; // Offset: 0x189 // Size: 0x01
	char pad_0x18A[0x2]; // Offset: 0x18a // Size: 0x02
	int RecoilMoveX; // Offset: 0x18c // Size: 0x04
	int RecoilMoveY; // Offset: 0x190 // Size: 0x04
	int WeaponAimFOV; // Offset: 0x194 // Size: 0x04
	int BulletDamageDebuff; // Offset: 0x198 // Size: 0x04
	int BulletDamageBuff; // Offset: 0x19c // Size: 0x04
	uint32_t AtackFlowID; // Offset: 0x1a0 // Size: 0x04
	int AutoAimSpeed; // Offset: 0x1a4 // Size: 0x04
	int AutoAimSpeedRateMax; // Offset: 0x1a8 // Size: 0x04
	int AutoAimRangeMax; // Offset: 0x1ac // Size: 0x04
	int AutoAimRangeRateMax; // Offset: 0x1b0 // Size: 0x04
	int GunID; // Offset: 0x1b4 // Size: 0x04
	int IfIsOnCar; // Offset: 0x1b8 // Size: 0x04
	bool InMoveablePlatform; // Offset: 0x1bc // Size: 0x01
	char pad_0x1BD[0x3]; // Offset: 0x1bd // Size: 0x03
	int KillAICnt; // Offset: 0x1c0 // Size: 0x04
	int KillRealPlayerCnt; // Offset: 0x1c4 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.AimFlow
// Size: 0x128 // Inherited bytes: 0x00
struct FAimFlow {
	// Fields
	struct FString GameSvrId; // Offset: 0x00 // Size: 0x10
	int64_t dtEventTime; // Offset: 0x10 // Size: 0x08
	struct FString GameAppID; // Offset: 0x18 // Size: 0x10
	struct FString OpenID; // Offset: 0x28 // Size: 0x10
	uint16_t AreaID; // Offset: 0x38 // Size: 0x02
	uint8_t PlatID; // Offset: 0x3a // Size: 0x01
	char pad_0x3B[0x5]; // Offset: 0x3b // Size: 0x05
	struct FString ZoneID; // Offset: 0x40 // Size: 0x10
	uint64 BattleID; // Offset: 0x50 // Size: 0x08
	int64_t ClientStartTime; // Offset: 0x58 // Size: 0x08
	int MrpcsFlowcount_; // Offset: 0x60 // Size: 0x04
	char pad_0x64[0x4]; // Offset: 0x64 // Size: 0x04
	struct TArray<int> MrpcsFlow; // Offset: 0x68 // Size: 0x10
	struct FString UserName; // Offset: 0x78 // Size: 0x10
	uint64 RoleID; // Offset: 0x88 // Size: 0x08
	uint8_t RoleType; // Offset: 0x90 // Size: 0x01
	char pad_0x91[0x3]; // Offset: 0x91 // Size: 0x03
	int AimTime; // Offset: 0x94 // Size: 0x04
	struct FString ShotCDTime; // Offset: 0x98 // Size: 0x10
	int ShotCount; // Offset: 0xa8 // Size: 0x04
	int ShotHitCount; // Offset: 0xac // Size: 0x04
	int ShotHeadHitCount; // Offset: 0xb0 // Size: 0x04
	int ShotPersonHitCount; // Offset: 0xb4 // Size: 0x04
	int ShotPersonKillCount; // Offset: 0xb8 // Size: 0x04
	char pad_0xBC[0x4]; // Offset: 0xbc // Size: 0x04
	struct FString HitDistance; // Offset: 0xc0 // Size: 0x10
	struct FString HitEachDistance; // Offset: 0xd0 // Size: 0x10
	struct FString HitAngle; // Offset: 0xe0 // Size: 0x10
	struct FString HitEachCdTime; // Offset: 0xf0 // Size: 0x10
	struct FString HitPartInfo; // Offset: 0x100 // Size: 0x10
	struct FString PlayerState; // Offset: 0x110 // Size: 0x10
	char bHoldBreath : 1; // Offset: 0x120 // Size: 0x01
	char pad_0x120_1 : 7; // Offset: 0x120 // Size: 0x01
	uint8_t SightType; // Offset: 0x121 // Size: 0x01
	char pad_0x122[0x2]; // Offset: 0x122 // Size: 0x02
	uint32_t AimFlowID; // Offset: 0x124 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.GameEndFlow
// Size: 0x200 // Inherited bytes: 0x00
struct FGameEndFlow {
	// Fields
	struct FString GameSvrId; // Offset: 0x00 // Size: 0x10
	int64_t dtEventTime; // Offset: 0x10 // Size: 0x08
	struct FString GameAppID; // Offset: 0x18 // Size: 0x10
	struct FString OpenID; // Offset: 0x28 // Size: 0x10
	uint16_t AreaID; // Offset: 0x38 // Size: 0x02
	uint8_t PlatID; // Offset: 0x3a // Size: 0x01
	char pad_0x3B[0x5]; // Offset: 0x3b // Size: 0x05
	struct FString ZoneID; // Offset: 0x40 // Size: 0x10
	uint64 BattleID; // Offset: 0x50 // Size: 0x08
	int64_t ClientStartTime; // Offset: 0x58 // Size: 0x08
	int MrpcsFlowcount_; // Offset: 0x60 // Size: 0x04
	char pad_0x64[0x4]; // Offset: 0x64 // Size: 0x04
	struct TArray<int> MrpcsFlow; // Offset: 0x68 // Size: 0x10
	struct FString UserName; // Offset: 0x78 // Size: 0x10
	uint64 RoleID; // Offset: 0x88 // Size: 0x08
	uint8_t RoleType; // Offset: 0x90 // Size: 0x01
	char pad_0x91[0x7]; // Offset: 0x91 // Size: 0x07
	struct FString ClientVersion; // Offset: 0x98 // Size: 0x10
	uint32_t OverTime; // Offset: 0xa8 // Size: 0x04
	uint8_t EndType; // Offset: 0xac // Size: 0x01
	char KillCount; // Offset: 0xad // Size: 0x01
	char AssistsCount; // Offset: 0xae // Size: 0x01
	char DropCount; // Offset: 0xaf // Size: 0x01
	char SaveCount; // Offset: 0xb0 // Size: 0x01
	char RebornCount; // Offset: 0xb1 // Size: 0x01
	char AliveType : 1; // Offset: 0xb2 // Size: 0x01
	char pad_0xB2_1 : 7; // Offset: 0xb2 // Size: 0x01
	char pad_0xB3[0x1]; // Offset: 0xb3 // Size: 0x01
	int GoldGet; // Offset: 0xb4 // Size: 0x04
	int DiamondGet; // Offset: 0xb8 // Size: 0x04
	int ExpGet; // Offset: 0xbc // Size: 0x04
	char WinRank; // Offset: 0xc0 // Size: 0x01
	char TotalPlayers; // Offset: 0xc1 // Size: 0x01
	char pad_0xC2[0x2]; // Offset: 0xc2 // Size: 0x02
	int PlayerRank; // Offset: 0xc4 // Size: 0x04
	int RankEnd; // Offset: 0xc8 // Size: 0x04
	int TeamID; // Offset: 0xcc // Size: 0x04
	struct FString TeamPlayer1; // Offset: 0xd0 // Size: 0x10
	struct FString TeamPlayer2; // Offset: 0xe0 // Size: 0x10
	struct FString TeamPlayer3; // Offset: 0xf0 // Size: 0x10
	char TeamPlayer1AliveType : 1; // Offset: 0x100 // Size: 0x01
	char TeamPlayer2AliveType : 1; // Offset: 0x100 // Size: 0x01
	char TeamPlayer3AliveType : 1; // Offset: 0x100 // Size: 0x01
	char pad_0x100_3 : 5; // Offset: 0x100 // Size: 0x01
	char TeamPlayer1Kill; // Offset: 0x101 // Size: 0x01
	char TeamPlayer2Kill; // Offset: 0x102 // Size: 0x01
	char TeamPlayer3Kill; // Offset: 0x103 // Size: 0x01
	uint32_t GameEndFlowID; // Offset: 0x104 // Size: 0x04
	char AIKillCount; // Offset: 0x108 // Size: 0x01
	char KillHeadShotCount; // Offset: 0x109 // Size: 0x01
	char RoundCircleCount; // Offset: 0x10a // Size: 0x01
	char PlayerLastKillGet; // Offset: 0x10b // Size: 0x01
	int ChangeWearingCount; // Offset: 0x10c // Size: 0x04
	struct TArray<int> ChangeWearingCountInReady; // Offset: 0x110 // Size: 0x10
	struct TArray<int> ChangeWearingCountInBattle; // Offset: 0x120 // Size: 0x10
	float AllowChangeWearingTime; // Offset: 0x130 // Size: 0x04
	float BattleStateTime; // Offset: 0x134 // Size: 0x04
	struct TArray<int> UseQuickMsgIDArray; // Offset: 0x138 // Size: 0x10
	struct TArray<int> UseQuickMsgCountArray; // Offset: 0x148 // Size: 0x10
	struct TArray<int> UseWheelMsgIDArray; // Offset: 0x158 // Size: 0x10
	struct TArray<int> UseWheelMsgCountArray; // Offset: 0x168 // Size: 0x10
	struct TArray<int> InexistentAvatarStat; // Offset: 0x178 // Size: 0x10
	struct TArray<int> InexistentAvatarInBornStat; // Offset: 0x188 // Size: 0x10
	struct TArray<int> InexistentWeaponAvatarStat; // Offset: 0x198 // Size: 0x10
	struct TArray<int> InexistentVehicleAvatarStat; // Offset: 0x1a8 // Size: 0x10
	int InexistentPlaneAvatarStat; // Offset: 0x1b8 // Size: 0x04
	int InexistentEmoteAvatarStat; // Offset: 0x1bc // Size: 0x04
	char ShowMsgCnt; // Offset: 0x1c0 // Size: 0x01
	char UserConfirmCnt; // Offset: 0x1c1 // Size: 0x01
	char UserCancelCnt; // Offset: 0x1c2 // Size: 0x01
	char UserDoNothingCnt; // Offset: 0x1c3 // Size: 0x01
	float FPSBeforeAdapt; // Offset: 0x1c4 // Size: 0x04
	float FPSAfterAdapt; // Offset: 0x1c8 // Size: 0x04
	float TeammateMicrophoneTime; // Offset: 0x1cc // Size: 0x04
	float TeammateSpeakerTime; // Offset: 0x1d0 // Size: 0x04
	float EnemyMicrophoneTime; // Offset: 0x1d4 // Size: 0x04
	float EnemySpeakerTime; // Offset: 0x1d8 // Size: 0x04
	float TeammateInterphoneTime; // Offset: 0x1dc // Size: 0x04
	float EnemyInterphoneTime; // Offset: 0x1e0 // Size: 0x04
	char PlayerUseQuickSight; // Offset: 0x1e4 // Size: 0x01
	char PlayerUseShoulderCnt; // Offset: 0x1e5 // Size: 0x01
	char pad_0x1E6[0x2]; // Offset: 0x1e6 // Size: 0x02
	int MaxVehicleToLandHeight; // Offset: 0x1e8 // Size: 0x04
	int MaxVehicleInAirInterval; // Offset: 0x1ec // Size: 0x04
	int PlayerMoveSpeedMax; // Offset: 0x1f0 // Size: 0x04
	int PlayerJumpHeightMax; // Offset: 0x1f4 // Size: 0x04
	int PlayerJumpSpeedMax; // Offset: 0x1f8 // Size: 0x04
	char pad_0x1FC[0x4]; // Offset: 0x1fc // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.TeammatHurtFlow
// Size: 0x10 // Inherited bytes: 0x00
struct FTeammatHurtFlow {
	// Fields
	struct TArray<struct FTeammatHurtFlowNode> TeammatHurtList; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.TeammatHurtFlowNode
// Size: 0x60 // Inherited bytes: 0x00
struct FTeammatHurtFlowNode {
	// Fields
	struct FString HurtPlayerName; // Offset: 0x00 // Size: 0x10
	int GameModeType; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct FString MakeHurtPlayerName; // Offset: 0x18 // Size: 0x10
	struct FString DataTimes; // Offset: 0x28 // Size: 0x10
	uint16_t AreaID; // Offset: 0x38 // Size: 0x02
	uint8_t PlatID; // Offset: 0x3a // Size: 0x01
	char pad_0x3B[0x5]; // Offset: 0x3b // Size: 0x05
	struct FString ZoneID; // Offset: 0x40 // Size: 0x10
	struct FString OpenID; // Offset: 0x50 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.ForbitPickFlow
// Size: 0x10 // Inherited bytes: 0x00
struct FForbitPickFlow {
	// Fields
	struct TArray<struct FForbitPickFlowNode> forbitList; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.ForbitPickFlowNode
// Size: 0x48 // Inherited bytes: 0x00
struct FForbitPickFlowNode {
	// Fields
	struct FString PlayerName; // Offset: 0x00 // Size: 0x10
	uint16_t AreaID; // Offset: 0x10 // Size: 0x02
	uint8_t PlatID; // Offset: 0x12 // Size: 0x01
	char pad_0x13[0x5]; // Offset: 0x13 // Size: 0x05
	struct FString ZoneID; // Offset: 0x18 // Size: 0x10
	struct FString OpenID; // Offset: 0x28 // Size: 0x10
	struct TArray<int> forbitNumList; // Offset: 0x38 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.ClientGameEndFlow
// Size: 0x148 // Inherited bytes: 0x00
struct FClientGameEndFlow {
	// Fields
	int64_t ClientStartTime; // Offset: 0x00 // Size: 0x08
	struct TArray<int> MrpcsFlow; // Offset: 0x08 // Size: 0x10
	struct FString ClientVersion; // Offset: 0x18 // Size: 0x10
	uint32_t OverTime; // Offset: 0x28 // Size: 0x04
	uint8_t EndType; // Offset: 0x2c // Size: 0x01
	char KillCount; // Offset: 0x2d // Size: 0x01
	char AssistsCount; // Offset: 0x2e // Size: 0x01
	char DropCount; // Offset: 0x2f // Size: 0x01
	char SaveCount; // Offset: 0x30 // Size: 0x01
	char RebornCount; // Offset: 0x31 // Size: 0x01
	char AliveType : 1; // Offset: 0x32 // Size: 0x01
	char pad_0x32_1 : 7; // Offset: 0x32 // Size: 0x01
	char pad_0x33[0x1]; // Offset: 0x33 // Size: 0x01
	int GoldGet; // Offset: 0x34 // Size: 0x04
	int DiamondGet; // Offset: 0x38 // Size: 0x04
	int ExpGet; // Offset: 0x3c // Size: 0x04
	char WinRank; // Offset: 0x40 // Size: 0x01
	char TotalPlayers; // Offset: 0x41 // Size: 0x01
	char pad_0x42[0x2]; // Offset: 0x42 // Size: 0x02
	int PlayerRank; // Offset: 0x44 // Size: 0x04
	int RankEnd; // Offset: 0x48 // Size: 0x04
	int TeamID; // Offset: 0x4c // Size: 0x04
	struct FString TeamPlayer1; // Offset: 0x50 // Size: 0x10
	struct FString TeamPlayer2; // Offset: 0x60 // Size: 0x10
	struct FString TeamPlayer3; // Offset: 0x70 // Size: 0x10
	char TeamPlayer1AliveType : 1; // Offset: 0x80 // Size: 0x01
	char TeamPlayer2AliveType : 1; // Offset: 0x80 // Size: 0x01
	char TeamPlayer3AliveType : 1; // Offset: 0x80 // Size: 0x01
	char pad_0x80_3 : 5; // Offset: 0x80 // Size: 0x01
	char TeamPlayer1Kill; // Offset: 0x81 // Size: 0x01
	char TeamPlayer2Kill; // Offset: 0x82 // Size: 0x01
	char TeamPlayer3Kill; // Offset: 0x83 // Size: 0x01
	uint32_t GameEndFlowID; // Offset: 0x84 // Size: 0x04
	char RoundCircleCount; // Offset: 0x88 // Size: 0x01
	char pad_0x89[0x7]; // Offset: 0x89 // Size: 0x07
	struct TArray<int> UseQuickMsgIDArray; // Offset: 0x90 // Size: 0x10
	struct TArray<int> UseQuickMsgCountArray; // Offset: 0xa0 // Size: 0x10
	struct TArray<int> UseWheelMsgIDArray; // Offset: 0xb0 // Size: 0x10
	struct TArray<int> UseWheelMsgCountArray; // Offset: 0xc0 // Size: 0x10
	struct TArray<int> InexistentAvatarStat; // Offset: 0xd0 // Size: 0x10
	struct TArray<int> InexistentAvatarInBornStat; // Offset: 0xe0 // Size: 0x10
	struct TArray<int> InexistentWeaponAvatarStat; // Offset: 0xf0 // Size: 0x10
	struct TArray<int> InexistentVehicleAvatarStat; // Offset: 0x100 // Size: 0x10
	int InexistentPlaneAvatarStat; // Offset: 0x110 // Size: 0x04
	int InexistentEmoteAvatarStat; // Offset: 0x114 // Size: 0x04
	char ShowMsgCnt; // Offset: 0x118 // Size: 0x01
	char UserConfirmCnt; // Offset: 0x119 // Size: 0x01
	char UserCancelCnt; // Offset: 0x11a // Size: 0x01
	char UserDoNothingCnt; // Offset: 0x11b // Size: 0x01
	float FPSBeforeAdapt; // Offset: 0x11c // Size: 0x04
	float FPSAfterAdapt; // Offset: 0x120 // Size: 0x04
	float TeammateMicrophoneTime; // Offset: 0x124 // Size: 0x04
	float TeammateSpeakerTime; // Offset: 0x128 // Size: 0x04
	float EnemyMicrophoneTime; // Offset: 0x12c // Size: 0x04
	float EnemySpeakerTime; // Offset: 0x130 // Size: 0x04
	float TeammateInterphoneTime; // Offset: 0x134 // Size: 0x04
	float EnemyInterphoneTime; // Offset: 0x138 // Size: 0x04
	char PlayerUseQuickSight; // Offset: 0x13c // Size: 0x01
	char PlayerUseShoulderCnt; // Offset: 0x13d // Size: 0x01
	char pad_0x13E[0x2]; // Offset: 0x13e // Size: 0x02
	int PlayerMoveSpeedMax; // Offset: 0x140 // Size: 0x04
	char pad_0x144[0x4]; // Offset: 0x144 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.InexistentAvatarFlow
// Size: 0x1e0 // Inherited bytes: 0x00
struct FInexistentAvatarFlow {
	// Fields
	char pad_0x0[0x1e0]; // Offset: 0x00 // Size: 0x1e0
};

// Object Name: ScriptStruct Gameplay.CircleFlow
// Size: 0x1f8 // Inherited bytes: 0x00
struct FCircleFlow {
	// Fields
	struct FString GameSvrId; // Offset: 0x00 // Size: 0x10
	int64_t dtEventTime; // Offset: 0x10 // Size: 0x08
	struct FString GameAppID; // Offset: 0x18 // Size: 0x10
	struct FString OpenID; // Offset: 0x28 // Size: 0x10
	uint16_t AreaID; // Offset: 0x38 // Size: 0x02
	uint8_t PlatID; // Offset: 0x3a // Size: 0x01
	char pad_0x3B[0x5]; // Offset: 0x3b // Size: 0x05
	struct FString ZoneID; // Offset: 0x40 // Size: 0x10
	uint64 BattleID; // Offset: 0x50 // Size: 0x08
	int64_t ClientStartTime; // Offset: 0x58 // Size: 0x08
	int MrpcsFlowcount_; // Offset: 0x60 // Size: 0x04
	char pad_0x64[0x4]; // Offset: 0x64 // Size: 0x04
	struct TArray<int> MrpcsFlow; // Offset: 0x68 // Size: 0x10
	struct FString UserName; // Offset: 0x78 // Size: 0x10
	struct FString PicUrl; // Offset: 0x88 // Size: 0x10
	uint64 RoleID; // Offset: 0x98 // Size: 0x08
	uint8_t RoleType; // Offset: 0xa0 // Size: 0x01
	char pad_0xA1[0x3]; // Offset: 0xa1 // Size: 0x03
	uint32_t GameStartTime; // Offset: 0xa4 // Size: 0x04
	uint32_t NewCircleBornTime; // Offset: 0xa8 // Size: 0x04
	int NewCirclePositionX; // Offset: 0xac // Size: 0x04
	int NewCirclePositionY; // Offset: 0xb0 // Size: 0x04
	int NewCirclePositionRadius; // Offset: 0xb4 // Size: 0x04
	int NewCircleCount; // Offset: 0xb8 // Size: 0x04
	int PlayerPositionX; // Offset: 0xbc // Size: 0x04
	int PlayerPositionY; // Offset: 0xc0 // Size: 0x04
	int PlayerPositionZ; // Offset: 0xc4 // Size: 0x04
	int PlayerHP; // Offset: 0xc8 // Size: 0x04
	uint32_t OldCircleMoveTime; // Offset: 0xcc // Size: 0x04
	uint32_t OldCircleMoveEndTime; // Offset: 0xd0 // Size: 0x04
	int PlayerOutTime; // Offset: 0xd4 // Size: 0x04
	int CirclePoisonCount; // Offset: 0xd8 // Size: 0x04
	int CirclePoisonMin; // Offset: 0xdc // Size: 0x04
	int CirclePoisonMax; // Offset: 0xe0 // Size: 0x04
	int CirclePoisonAvg; // Offset: 0xe4 // Size: 0x04
	int CirclePoisonTotal; // Offset: 0xe8 // Size: 0x04
	int CirclePoisonDrop; // Offset: 0xec // Size: 0x04
	int CirclePoisonDead; // Offset: 0xf0 // Size: 0x04
	int RecoveryCount; // Offset: 0xf4 // Size: 0x04
	int RecoveryMin; // Offset: 0xf8 // Size: 0x04
	int RecoveryMax; // Offset: 0xfc // Size: 0x04
	int RecoveryTotal; // Offset: 0x100 // Size: 0x04
	int EnergyRecoveryCount; // Offset: 0x104 // Size: 0x04
	int EnergyRecoveryMin; // Offset: 0x108 // Size: 0x04
	int EnergyRecoveryMax; // Offset: 0x10c // Size: 0x04
	int EnergyRecoveryTotal; // Offset: 0x110 // Size: 0x04
	int EnergyStartLv; // Offset: 0x114 // Size: 0x04
	int EnergyStartTime; // Offset: 0x118 // Size: 0x04
	char pad_0x11C[0x4]; // Offset: 0x11c // Size: 0x04
	struct FString EnergyItemUse; // Offset: 0x120 // Size: 0x10
	int EnergyLvTimeInfo; // Offset: 0x130 // Size: 0x04
	char pad_0x134[0x4]; // Offset: 0x134 // Size: 0x04
	struct FString EnergyRunFastTime; // Offset: 0x138 // Size: 0x10
	struct FString EnergyRecoveryLvTimeInfo; // Offset: 0x148 // Size: 0x10
	int EnergyEndLv; // Offset: 0x158 // Size: 0x04
	int EnergyEndTime; // Offset: 0x15c // Size: 0x04
	int PlayerMoveDis; // Offset: 0x160 // Size: 0x04
	int PlayerSpeedMax; // Offset: 0x164 // Size: 0x04
	int PlayerSpeedAvg; // Offset: 0x168 // Size: 0x04
	int PlayerCarSpeedMax; // Offset: 0x16c // Size: 0x04
	int PlayerCarSpeedAvg; // Offset: 0x170 // Size: 0x04
	int PlayerSquatMoveDis; // Offset: 0x174 // Size: 0x04
	int PlayerSquatMoveTime; // Offset: 0x178 // Size: 0x04
	int PlayerCreepMoveDis; // Offset: 0x17c // Size: 0x04
	int PlayerCreepMoveTime; // Offset: 0x180 // Size: 0x04
	int PlayerRunMoveDis; // Offset: 0x184 // Size: 0x04
	int PlayerRunMoveTime; // Offset: 0x188 // Size: 0x04
	int PlayerDriveMoveDis; // Offset: 0x18c // Size: 0x04
	int PlayerDriveMoveTime; // Offset: 0x190 // Size: 0x04
	int PlayerCar; // Offset: 0x194 // Size: 0x04
	int PlayerCameraDistanceMax; // Offset: 0x198 // Size: 0x04
	uint32_t SecCircleFlowID; // Offset: 0x19c // Size: 0x04
	char AutoAimType; // Offset: 0x1a0 // Size: 0x01
	char pad_0x1A1[0x3]; // Offset: 0x1a1 // Size: 0x03
	int AutoAimTime; // Offset: 0x1a4 // Size: 0x04
	int PlayerKillCount; // Offset: 0x1a8 // Size: 0x04
	int PlayerKillAICount; // Offset: 0x1ac // Size: 0x04
	int PlayerHeadKillCount; // Offset: 0x1b0 // Size: 0x04
	int PlayerHatID; // Offset: 0x1b4 // Size: 0x04
	int PlayerMaskID; // Offset: 0x1b8 // Size: 0x04
	int PlayerShirtID; // Offset: 0x1bc // Size: 0x04
	int PlayerPantsID; // Offset: 0x1c0 // Size: 0x04
	int MainWeaponId1; // Offset: 0x1c4 // Size: 0x04
	int MainWeaponBulletId1; // Offset: 0x1c8 // Size: 0x04
	int MainWeaponBulletNum1; // Offset: 0x1cc // Size: 0x04
	int MainWeaponId2; // Offset: 0x1d0 // Size: 0x04
	int MainWeaponBulletId2; // Offset: 0x1d4 // Size: 0x04
	int MainWeaponBulletNum2; // Offset: 0x1d8 // Size: 0x04
	int SubWeaponId; // Offset: 0x1dc // Size: 0x04
	int SubWeaponBulletId; // Offset: 0x1e0 // Size: 0x04
	int SubWeaponBulletNum; // Offset: 0x1e4 // Size: 0x04
	struct FString MrpcsFlowStr; // Offset: 0x1e8 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.ClientCircleFlow
// Size: 0x138 // Inherited bytes: 0x00
struct FClientCircleFlow {
	// Fields
	int64_t ClientStartTime; // Offset: 0x00 // Size: 0x08
	struct TArray<int> MrpcsFlow; // Offset: 0x08 // Size: 0x10
	struct FString PicUrl; // Offset: 0x18 // Size: 0x10
	uint32_t GameStartTime; // Offset: 0x28 // Size: 0x04
	uint32_t NewCircleBornTime; // Offset: 0x2c // Size: 0x04
	int NewCirclePositionX; // Offset: 0x30 // Size: 0x04
	int NewCirclePositionY; // Offset: 0x34 // Size: 0x04
	int NewCirclePositionRadius; // Offset: 0x38 // Size: 0x04
	int NewCircleCount; // Offset: 0x3c // Size: 0x04
	int PlayerPositionX; // Offset: 0x40 // Size: 0x04
	int PlayerPositionY; // Offset: 0x44 // Size: 0x04
	int PlayerPositionZ; // Offset: 0x48 // Size: 0x04
	int PlayerHP; // Offset: 0x4c // Size: 0x04
	uint32_t OldCircleMoveTime; // Offset: 0x50 // Size: 0x04
	uint32_t OldCircleMoveEndTime; // Offset: 0x54 // Size: 0x04
	uint32_t PlayerOutTime; // Offset: 0x58 // Size: 0x04
	int CirclePoisonCount; // Offset: 0x5c // Size: 0x04
	int CirclePoisonMin; // Offset: 0x60 // Size: 0x04
	int CirclePoisonMax; // Offset: 0x64 // Size: 0x04
	int CirclePoisonAvg; // Offset: 0x68 // Size: 0x04
	int CirclePoisonTotal; // Offset: 0x6c // Size: 0x04
	int CirclePoisonDrop; // Offset: 0x70 // Size: 0x04
	int CirclePoisonDead; // Offset: 0x74 // Size: 0x04
	int RecoveryCount; // Offset: 0x78 // Size: 0x04
	int RecoveryMin; // Offset: 0x7c // Size: 0x04
	int RecoveryMax; // Offset: 0x80 // Size: 0x04
	int RecoveryTotal; // Offset: 0x84 // Size: 0x04
	int EnergyRecoveryCount; // Offset: 0x88 // Size: 0x04
	int EnergyRecoveryMin; // Offset: 0x8c // Size: 0x04
	int EnergyRecoveryMax; // Offset: 0x90 // Size: 0x04
	int EnergyRecoveryTotal; // Offset: 0x94 // Size: 0x04
	int EnergyStartLv; // Offset: 0x98 // Size: 0x04
	int EnergyStartTime; // Offset: 0x9c // Size: 0x04
	struct FString EnergyItemUse; // Offset: 0xa0 // Size: 0x10
	int EnergyLvTimeInfo; // Offset: 0xb0 // Size: 0x04
	char pad_0xB4[0x4]; // Offset: 0xb4 // Size: 0x04
	struct FString EnergyRunFastTime; // Offset: 0xb8 // Size: 0x10
	struct FString EnergyRecoveryLvTimeInfo; // Offset: 0xc8 // Size: 0x10
	int EnergyEndLv; // Offset: 0xd8 // Size: 0x04
	int EnergyEndTime; // Offset: 0xdc // Size: 0x04
	int PlayerMoveDis; // Offset: 0xe0 // Size: 0x04
	int PlayerSpeedMax; // Offset: 0xe4 // Size: 0x04
	int PlayerSpeedAvg; // Offset: 0xe8 // Size: 0x04
	int PlayerCarSpeedMax; // Offset: 0xec // Size: 0x04
	int PlayerCarSpeedAvg; // Offset: 0xf0 // Size: 0x04
	int PlayerSquatMoveDis; // Offset: 0xf4 // Size: 0x04
	int PlayerSquatMoveTime; // Offset: 0xf8 // Size: 0x04
	int PlayerCreepMoveDis; // Offset: 0xfc // Size: 0x04
	int PlayerCreepMoveTime; // Offset: 0x100 // Size: 0x04
	int PlayerRunMoveDis; // Offset: 0x104 // Size: 0x04
	int PlayerRunMoveTime; // Offset: 0x108 // Size: 0x04
	int PlayerDriveMoveDis; // Offset: 0x10c // Size: 0x04
	int PlayerDriveMoveTime; // Offset: 0x110 // Size: 0x04
	int PlayerCar; // Offset: 0x114 // Size: 0x04
	int PlayerCameraDistanceMax; // Offset: 0x118 // Size: 0x04
	uint32_t SecCircleFlowID; // Offset: 0x11c // Size: 0x04
	char AutoAimType; // Offset: 0x120 // Size: 0x01
	char pad_0x121[0x3]; // Offset: 0x121 // Size: 0x03
	int AutoAimTime; // Offset: 0x124 // Size: 0x04
	struct TArray<char> MrpcsFlowData; // Offset: 0x128 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.JumpFlow
// Size: 0x150 // Inherited bytes: 0x00
struct FJumpFlow {
	// Fields
	struct FString GameSvrId; // Offset: 0x00 // Size: 0x10
	int64_t dtEventTime; // Offset: 0x10 // Size: 0x08
	struct FString GameAppID; // Offset: 0x18 // Size: 0x10
	struct FString OpenID; // Offset: 0x28 // Size: 0x10
	uint16_t AreaID; // Offset: 0x38 // Size: 0x02
	uint8_t PlatID; // Offset: 0x3a // Size: 0x01
	char pad_0x3B[0x5]; // Offset: 0x3b // Size: 0x05
	struct FString ZoneID; // Offset: 0x40 // Size: 0x10
	uint64 BattleID; // Offset: 0x50 // Size: 0x08
	int64_t ClientStartTime; // Offset: 0x58 // Size: 0x08
	int MrpcsFlowcount_; // Offset: 0x60 // Size: 0x04
	char pad_0x64[0x4]; // Offset: 0x64 // Size: 0x04
	struct TArray<int> MrpcsFlow; // Offset: 0x68 // Size: 0x10
	struct FString UserName; // Offset: 0x78 // Size: 0x10
	uint64 RoleID; // Offset: 0x88 // Size: 0x08
	uint8_t RoleType; // Offset: 0x90 // Size: 0x01
	char pad_0x91[0x7]; // Offset: 0x91 // Size: 0x07
	struct FString PicUrl; // Offset: 0x98 // Size: 0x10
	struct FString MapName; // Offset: 0xa8 // Size: 0x10
	uint8_t WeatherID; // Offset: 0xb8 // Size: 0x01
	char pad_0xB9[0x7]; // Offset: 0xb9 // Size: 0x07
	int64_t GameStartTime; // Offset: 0xc0 // Size: 0x08
	uint32_t StartJumpTime; // Offset: 0xc8 // Size: 0x04
	uint32_t EndJumpTime; // Offset: 0xcc // Size: 0x04
	uint32_t PlayerJumpTime; // Offset: 0xd0 // Size: 0x04
	uint32_t PlayerOpenTime; // Offset: 0xd4 // Size: 0x04
	uint32_t PlayerLandTime; // Offset: 0xd8 // Size: 0x04
	int PlayerJumpPositionX; // Offset: 0xdc // Size: 0x04
	int PlayerJumpPositionY; // Offset: 0xe0 // Size: 0x04
	int PlayerJumpPositionZ; // Offset: 0xe4 // Size: 0x04
	int PlaneJumpPositionX; // Offset: 0xe8 // Size: 0x04
	int PlaneJumpPositionY; // Offset: 0xec // Size: 0x04
	int PlaneJumpPositionZ; // Offset: 0xf0 // Size: 0x04
	int PlayerLandPositionX; // Offset: 0xf4 // Size: 0x04
	int PlayerLandPositionY; // Offset: 0xf8 // Size: 0x04
	int PlayerLandPositionZ; // Offset: 0xfc // Size: 0x04
	uint32_t PlayerLandDistance; // Offset: 0x100 // Size: 0x04
	uint32_t PlayerSpeedMax1; // Offset: 0x104 // Size: 0x04
	uint32_t PlayerSpeedMax2; // Offset: 0x108 // Size: 0x04
	char pad_0x10C[0x4]; // Offset: 0x10c // Size: 0x04
	struct FString GVoiceTeamID; // Offset: 0x110 // Size: 0x10
	struct FString GVoiceRoomID; // Offset: 0x120 // Size: 0x10
	int GVoiceTeamMemberID; // Offset: 0x130 // Size: 0x04
	int GVoiceRoomMemberID; // Offset: 0x134 // Size: 0x04
	struct FString FollowPlayerUID; // Offset: 0x138 // Size: 0x10
	uint32_t ExitFollowTime; // Offset: 0x148 // Size: 0x04
	char pad_0x14C[0x4]; // Offset: 0x14c // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.ClientJumpFlow
// Size: 0xc0 // Inherited bytes: 0x00
struct FClientJumpFlow {
	// Fields
	int64_t ClientStartTime; // Offset: 0x00 // Size: 0x08
	struct TArray<int> MrpcsFlow; // Offset: 0x08 // Size: 0x10
	struct FString MapName; // Offset: 0x18 // Size: 0x10
	uint8_t WeatherID; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x7]; // Offset: 0x29 // Size: 0x07
	int64_t GameStartTime; // Offset: 0x30 // Size: 0x08
	uint32_t StartJumpTime; // Offset: 0x38 // Size: 0x04
	uint32_t EndJumpTime; // Offset: 0x3c // Size: 0x04
	uint32_t PlayerJumpTime; // Offset: 0x40 // Size: 0x04
	uint32_t PlayerOpenTime; // Offset: 0x44 // Size: 0x04
	uint32_t PlayerLandTime; // Offset: 0x48 // Size: 0x04
	char pad_0x4C[0x4]; // Offset: 0x4c // Size: 0x04
	struct FString FollowPlayerUID; // Offset: 0x50 // Size: 0x10
	uint32_t ExitFollowTime; // Offset: 0x60 // Size: 0x04
	int PlayerJumpPositionX; // Offset: 0x64 // Size: 0x04
	int PlayerJumpPositionY; // Offset: 0x68 // Size: 0x04
	int PlayerJumpPositionZ; // Offset: 0x6c // Size: 0x04
	int PlaneJumpPositionX; // Offset: 0x70 // Size: 0x04
	int PlaneJumpPositionY; // Offset: 0x74 // Size: 0x04
	int PlaneJumpPositionZ; // Offset: 0x78 // Size: 0x04
	int PlayerLandPositionX; // Offset: 0x7c // Size: 0x04
	int PlayerLandPositionY; // Offset: 0x80 // Size: 0x04
	int PlayerLandPositionZ; // Offset: 0x84 // Size: 0x04
	uint32_t PlayerLandDistance; // Offset: 0x88 // Size: 0x04
	uint32_t PlayerSpeedMax1; // Offset: 0x8c // Size: 0x04
	uint32_t PlayerSpeedMax2; // Offset: 0x90 // Size: 0x04
	char pad_0x94[0x4]; // Offset: 0x94 // Size: 0x04
	struct FString GVoiceTeamID; // Offset: 0x98 // Size: 0x10
	struct FString GVoiceRoomID; // Offset: 0xa8 // Size: 0x10
	int GVoiceTeamMemberID; // Offset: 0xb8 // Size: 0x04
	int GVoiceRoomMemberID; // Offset: 0xbc // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.GameStartFlow
// Size: 0x1b8 // Inherited bytes: 0x00
struct FGameStartFlow {
	// Fields
	struct FString GameSvrId; // Offset: 0x00 // Size: 0x10
	int64_t dtEventTime; // Offset: 0x10 // Size: 0x08
	struct FString GameAppID; // Offset: 0x18 // Size: 0x10
	struct FString OpenID; // Offset: 0x28 // Size: 0x10
	uint16_t AreaID; // Offset: 0x38 // Size: 0x02
	uint8_t PlatID; // Offset: 0x3a // Size: 0x01
	char pad_0x3B[0x5]; // Offset: 0x3b // Size: 0x05
	struct FString ZoneID; // Offset: 0x40 // Size: 0x10
	uint64 BattleID; // Offset: 0x50 // Size: 0x08
	int64_t ClientStartTime; // Offset: 0x58 // Size: 0x08
	int MrpcsFlowcount_; // Offset: 0x60 // Size: 0x04
	char pad_0x64[0x4]; // Offset: 0x64 // Size: 0x04
	struct TArray<int> MrpcsFlow; // Offset: 0x68 // Size: 0x10
	struct FString UserName; // Offset: 0x78 // Size: 0x10
	uint64 RoleID; // Offset: 0x88 // Size: 0x08
	uint8_t RoleType; // Offset: 0x90 // Size: 0x01
	char pad_0x91[0x7]; // Offset: 0x91 // Size: 0x07
	struct FString PicUrl; // Offset: 0x98 // Size: 0x10
	uint32_t SvrUserMoney1; // Offset: 0xa8 // Size: 0x04
	uint32_t SvrUserMoney2; // Offset: 0xac // Size: 0x04
	uint32_t SvrUserMoney3; // Offset: 0xb0 // Size: 0x04
	int SvrRoundRank; // Offset: 0xb4 // Size: 0x04
	int SvrRoundRank1; // Offset: 0xb8 // Size: 0x04
	int SvrRoundRank2; // Offset: 0xbc // Size: 0x04
	int SvrRoundRank3; // Offset: 0xc0 // Size: 0x04
	char pad_0xC4[0x4]; // Offset: 0xc4 // Size: 0x04
	uint64 SvrRoleID; // Offset: 0xc8 // Size: 0x08
	uint8_t SvrRoleType; // Offset: 0xd0 // Size: 0x01
	char pad_0xD1[0x7]; // Offset: 0xd1 // Size: 0x07
	struct FString SvrMapName; // Offset: 0xd8 // Size: 0x10
	uint8_t SvrWeatherid; // Offset: 0xe8 // Size: 0x01
	char pad_0xE9[0x7]; // Offset: 0xe9 // Size: 0x07
	struct FString SvrItemList; // Offset: 0xf0 // Size: 0x10
	int64_t WaitStartTime; // Offset: 0x100 // Size: 0x08
	int64_t WaitEndTime; // Offset: 0x108 // Size: 0x08
	struct FString MapName; // Offset: 0x110 // Size: 0x10
	uint8_t WeatherID; // Offset: 0x120 // Size: 0x01
	char pad_0x121[0x7]; // Offset: 0x121 // Size: 0x07
	struct FString ItemList; // Offset: 0x128 // Size: 0x10
	uint8_t GameType; // Offset: 0x138 // Size: 0x01
	uint8_t TeamType; // Offset: 0x139 // Size: 0x01
	char AutoMatch; // Offset: 0x13a // Size: 0x01
	char PlayerCount; // Offset: 0x13b // Size: 0x01
	int TeamID; // Offset: 0x13c // Size: 0x04
	struct FString TeamPlayer1; // Offset: 0x140 // Size: 0x10
	struct FString TeamPlayer2; // Offset: 0x150 // Size: 0x10
	struct FString TeamPlayer3; // Offset: 0x160 // Size: 0x10
	int TeamPlayer1Rank; // Offset: 0x170 // Size: 0x04
	int TeamPlayer2Rank; // Offset: 0x174 // Size: 0x04
	int TeamPlayer3Rank; // Offset: 0x178 // Size: 0x04
	uint32_t SecGameStartFlowFlowID; // Offset: 0x17c // Size: 0x04
	struct FString GVoiceTeamID; // Offset: 0x180 // Size: 0x10
	struct FString GVoiceRoomID; // Offset: 0x190 // Size: 0x10
	int GVoiceTeamMemberID; // Offset: 0x1a0 // Size: 0x04
	int GVoiceRoomMemberID; // Offset: 0x1a4 // Size: 0x04
	struct FString IP; // Offset: 0x1a8 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.ClientGameStartFlow
// Size: 0xa8 // Inherited bytes: 0x00
struct FClientGameStartFlow {
	// Fields
	int64_t ClientStartTime; // Offset: 0x00 // Size: 0x08
	struct TArray<int> MrpcsFlow; // Offset: 0x08 // Size: 0x10
	struct FString MapName; // Offset: 0x18 // Size: 0x10
	uint8_t WeatherID; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x7]; // Offset: 0x29 // Size: 0x07
	struct FString ItemList; // Offset: 0x30 // Size: 0x10
	uint8_t TeamType; // Offset: 0x40 // Size: 0x01
	char pad_0x41[0x3]; // Offset: 0x41 // Size: 0x03
	int TeamID; // Offset: 0x44 // Size: 0x04
	struct FString TeamPlayer1; // Offset: 0x48 // Size: 0x10
	struct FString TeamPlayer2; // Offset: 0x58 // Size: 0x10
	struct FString TeamPlayer3; // Offset: 0x68 // Size: 0x10
	uint32_t SecGameStartFlowFlowID; // Offset: 0x78 // Size: 0x04
	char pad_0x7C[0x4]; // Offset: 0x7c // Size: 0x04
	struct FString GVoiceTeamID; // Offset: 0x80 // Size: 0x10
	struct FString GVoiceRoomID; // Offset: 0x90 // Size: 0x10
	int GVoiceTeamMemberID; // Offset: 0xa0 // Size: 0x04
	int GVoiceRoomMemberID; // Offset: 0xa4 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.IntPosition3D
// Size: 0x0c // Inherited bytes: 0x00
struct FIntPosition3D {
	// Fields
	int X; // Offset: 0x00 // Size: 0x04
	int Y; // Offset: 0x04 // Size: 0x04
	int Z; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.ItemGenerateSpawnClass
// Size: 0xd8 // Inherited bytes: 0x00
struct FItemGenerateSpawnClass {
	// Fields
	int ID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct UObject* ItemClass; // Offset: 0x08 // Size: 0x08
	struct FString ItemPath; // Offset: 0x10 // Size: 0x10
	int ItemCount; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
	struct FString MetaData; // Offset: 0x28 // Size: 0x10
	struct FString ItemValue; // Offset: 0x38 // Size: 0x10
	struct FString ItemCategory; // Offset: 0x48 // Size: 0x10
	bool bRepeatGenerateItem; // Offset: 0x58 // Size: 0x01
	bool IsNearItem; // Offset: 0x59 // Size: 0x01
	char pad_0x5A[0x2]; // Offset: 0x5a // Size: 0x02
	struct FVector SpotGenerateLoc; // Offset: 0x5c // Size: 0x0c
	struct FVector SpotGroupLoc; // Offset: 0x68 // Size: 0x0c
	struct FRotator SpotRotator; // Offset: 0x74 // Size: 0x0c
	int SpotPercent; // Offset: 0x80 // Size: 0x04
	char pad_0x84[0x4]; // Offset: 0x84 // Size: 0x04
	struct FString SpotDefaultTag; // Offset: 0x88 // Size: 0x10
	char pad_0x98[0x8]; // Offset: 0x98 // Size: 0x08
	struct AActor* HostActor; // Offset: 0xa0 // Size: 0x08
	struct AActor* AttachedActor; // Offset: 0xa8 // Size: 0x08
	char pad_0xB0[0x14]; // Offset: 0xb0 // Size: 0x14
	int SpotIndex; // Offset: 0xc4 // Size: 0x04
	bool Random; // Offset: 0xc8 // Size: 0x01
	bool IsStickToTheGround; // Offset: 0xc9 // Size: 0x01
	char pad_0xCA[0x2]; // Offset: 0xca // Size: 0x02
	struct FVector RelativeLoc; // Offset: 0xcc // Size: 0x0c
};

// Object Name: ScriptStruct Gameplay.VehicleSpotDebugData
// Size: 0x38 // Inherited bytes: 0x00
struct FVehicleSpotDebugData {
	// Fields
	struct FString VehicleSpotName; // Offset: 0x00 // Size: 0x10
	enum class ESpotType SpotType; // Offset: 0x10 // Size: 0x01
	enum class ESpotGroupType SpotGroupType; // Offset: 0x11 // Size: 0x01
	char pad_0x12[0x6]; // Offset: 0x12 // Size: 0x06
	struct FString VehiclePath; // Offset: 0x18 // Size: 0x10
	float VehicleLocationX; // Offset: 0x28 // Size: 0x04
	float VehicleLocationY; // Offset: 0x2c // Size: 0x04
	float VehicleLocationZ; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.VehicleGenerateStatisticsData
// Size: 0x60 // Inherited bytes: 0x00
struct FVehicleGenerateStatisticsData {
	// Fields
	struct TArray<struct FVehicleSpotStatisticsData> VehicleSpotStatisticsData; // Offset: 0x00 // Size: 0x10
	struct TMap<struct FString, struct FVehicleClassStatisticsData> VehicleClassStatisticsData; // Offset: 0x10 // Size: 0x50
};

// Object Name: ScriptStruct Gameplay.VehicleClassStatisticsData
// Size: 0x20 // Inherited bytes: 0x08
struct FVehicleClassStatisticsData : FTableRowBase {
	// Fields
	struct FString VehiclePath; // Offset: 0x08 // Size: 0x10
	bool bValidPath; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x3]; // Offset: 0x19 // Size: 0x03
	int AllVehicleCount; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.VehicleSpotStatisticsData
// Size: 0x30 // Inherited bytes: 0x08
struct FVehicleSpotStatisticsData : FTableRowBase {
	// Fields
	enum class ESpotType SpotType; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x7]; // Offset: 0x09 // Size: 0x07
	struct FString VehiclePath; // Offset: 0x10 // Size: 0x10
	float VehicleLocationX; // Offset: 0x20 // Size: 0x04
	float VehicleLocationY; // Offset: 0x24 // Size: 0x04
	float VehicleLocationZ; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.ItemGenerateStatisticsData
// Size: 0x110 // Inherited bytes: 0x00
struct FItemGenerateStatisticsData {
	// Fields
	int AllGroupSpotCount; // Offset: 0x00 // Size: 0x04
	int AllValidGroupSpotCount; // Offset: 0x04 // Size: 0x04
	int AllSpotCount; // Offset: 0x08 // Size: 0x04
	int AllValidSpotCount; // Offset: 0x0c // Size: 0x04
	struct TMap<enum class ESpotGroupType, struct FItemGroupStatisticsData> GroupStatisticsData; // Offset: 0x10 // Size: 0x50
	struct TMap<struct FString, struct FBuildingStatisticsData> BuildingStatisticsData; // Offset: 0x60 // Size: 0x50
	struct TMap<struct FString, struct FItemClassStatisticsData> ItemStatisticsData; // Offset: 0xb0 // Size: 0x50
	struct TArray<struct FAreaItemStatisticsData> AreaItemStatisticsData; // Offset: 0x100 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.AreaItemStatisticsData
// Size: 0x50 // Inherited bytes: 0x08
struct FAreaItemStatisticsData : FTableRowBase {
	// Fields
	struct FString ItemName; // Offset: 0x08 // Size: 0x10
	int UId; // Offset: 0x18 // Size: 0x04
	int ItemID; // Offset: 0x1c // Size: 0x04
	int GroupType; // Offset: 0x20 // Size: 0x04
	int SpotType; // Offset: 0x24 // Size: 0x04
	struct FString AreaName; // Offset: 0x28 // Size: 0x10
	struct FVector Location; // Offset: 0x38 // Size: 0x0c
	float X; // Offset: 0x44 // Size: 0x04
	float Y; // Offset: 0x48 // Size: 0x04
	int GameTime; // Offset: 0x4c // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.ItemClassStatisticsData
// Size: 0x38 // Inherited bytes: 0x08
struct FItemClassStatisticsData : FTableRowBase {
	// Fields
	struct FString ItemPath; // Offset: 0x08 // Size: 0x10
	bool bValidPath; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x3]; // Offset: 0x19 // Size: 0x03
	int ItemCount; // Offset: 0x1c // Size: 0x04
	struct FString ItemTogetherPath; // Offset: 0x20 // Size: 0x10
	int ItemTogetherCount; // Offset: 0x30 // Size: 0x04
	bool bValidTogetherPath; // Offset: 0x34 // Size: 0x01
	char pad_0x35[0x3]; // Offset: 0x35 // Size: 0x03
};

// Object Name: ScriptStruct Gameplay.BuildingStatisticsData
// Size: 0x80 // Inherited bytes: 0x08
struct FBuildingStatisticsData : FTableRowBase {
	// Fields
	struct FString BuildingName; // Offset: 0x08 // Size: 0x10
	float BuildingLocationX; // Offset: 0x18 // Size: 0x04
	float BuildingLocationY; // Offset: 0x1c // Size: 0x04
	int AllGroupSpotCount; // Offset: 0x20 // Size: 0x04
	int AllValidGroupSpotCount; // Offset: 0x24 // Size: 0x04
	int AllSpotCount; // Offset: 0x28 // Size: 0x04
	int AllValidSpotCount; // Offset: 0x2c // Size: 0x04
	struct TMap<enum class ESpotType, struct FItemSpotStatisticsData> SpotStatisticsData; // Offset: 0x30 // Size: 0x50
};

// Object Name: ScriptStruct Gameplay.ItemSpotStatisticsData
// Size: 0x18 // Inherited bytes: 0x08
struct FItemSpotStatisticsData : FTableRowBase {
	// Fields
	enum class ESpotType SpotType; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
	int AllSpotCount; // Offset: 0x0c // Size: 0x04
	int AllValidSpotCount; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.ItemGroupStatisticsData
// Size: 0x20 // Inherited bytes: 0x08
struct FItemGroupStatisticsData : FTableRowBase {
	// Fields
	enum class ESpotGroupType SpotGroupType; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
	int AllGroupSpotCount; // Offset: 0x0c // Size: 0x04
	int AllValidGroupSpotCount; // Offset: 0x10 // Size: 0x04
	int AllSpotCount; // Offset: 0x14 // Size: 0x04
	int AllValidSpotCount; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.SpotStatisticsData
// Size: 0x58 // Inherited bytes: 0x08
struct FSpotStatisticsData : FTableRowBase {
	// Fields
	enum class ESpotGroupType GroupType; // Offset: 0x08 // Size: 0x01
	enum class ESpotType SpotType; // Offset: 0x09 // Size: 0x01
	char pad_0xA[0x6]; // Offset: 0x0a // Size: 0x06
	struct FString AreaName; // Offset: 0x10 // Size: 0x10
	struct FString SpotDefaultTag; // Offset: 0x20 // Size: 0x10
	struct FVector Location; // Offset: 0x30 // Size: 0x0c
	float X; // Offset: 0x3c // Size: 0x04
	float Y; // Offset: 0x40 // Size: 0x04
	float Z; // Offset: 0x44 // Size: 0x04
	bool RandomRot; // Offset: 0x48 // Size: 0x01
	char pad_0x49[0x3]; // Offset: 0x49 // Size: 0x03
	struct FRotator Rotator; // Offset: 0x4c // Size: 0x0c
};

// Object Name: ScriptStruct Gameplay.VehicleGenerateRandomInfo
// Size: 0x28 // Inherited bytes: 0x00
struct FVehicleGenerateRandomInfo {
	// Fields
	struct FString VehicleType; // Offset: 0x00 // Size: 0x10
	struct FString VehiclePath; // Offset: 0x10 // Size: 0x10
	float FuelPercent; // Offset: 0x20 // Size: 0x04
	bool SnapFloor; // Offset: 0x24 // Size: 0x01
	bool bActiveByStartVolume; // Offset: 0x25 // Size: 0x01
	char pad_0x26[0x2]; // Offset: 0x26 // Size: 0x02
};

// Object Name: ScriptStruct Gameplay.VehicleGenerateSpawnData
// Size: 0x30 // Inherited bytes: 0x00
struct FVehicleGenerateSpawnData {
	// Fields
	int KeyID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString VehicleType; // Offset: 0x08 // Size: 0x10
	struct FString VehiclePath; // Offset: 0x18 // Size: 0x10
	int VehicleWeight; // Offset: 0x28 // Size: 0x04
	bool SnapFloor; // Offset: 0x2c // Size: 0x01
	char pad_0x2D[0x3]; // Offset: 0x2d // Size: 0x03
};

// Object Name: ScriptStruct Gameplay.TreasureBoxSpotProperty
// Size: 0x20 // Inherited bytes: 0x00
struct FTreasureBoxSpotProperty {
	// Fields
	enum class ESpotType SpotType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct TArray<struct FSpotWeight> WeightsPerCategory; // Offset: 0x08 // Size: 0x10
	int TotalCountRangeMin; // Offset: 0x18 // Size: 0x04
	int TotalCountRangeMax; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.VehicleSpotProperty
// Size: 0x38 // Inherited bytes: 0x00
struct FVehicleSpotProperty {
	// Fields
	enum class ESpotType SpotType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct TArray<struct FSpotWeight> WeightsPerCategory; // Offset: 0x08 // Size: 0x10
	int FuelPercentMin; // Offset: 0x18 // Size: 0x04
	int FuelPercentMax; // Offset: 0x1c // Size: 0x04
	bool bActiveByStartVolume; // Offset: 0x20 // Size: 0x01
	enum class EVehicleSpotRandomType RandomType; // Offset: 0x21 // Size: 0x01
	char pad_0x22[0x2]; // Offset: 0x22 // Size: 0x02
	float TotalCountMultiplierWithPalyerCount; // Offset: 0x24 // Size: 0x04
	int TotalCountRangeMin; // Offset: 0x28 // Size: 0x04
	int TotalCountRangeMax; // Offset: 0x2c // Size: 0x04
	float ProbabilityPersent; // Offset: 0x30 // Size: 0x04
	float ProbabilityPersentWithPalyerCount; // Offset: 0x34 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.CharParachuteAnimData
// Size: 0x48 // Inherited bytes: 0x00
struct FCharParachuteAnimData {
	// Fields
	enum class ECharacterParachuteAnimType ParachuteAnimType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct UAnimationAsset* ParachuteAnimSoftPtr; // Offset: 0x08 // Size: 0x28
	struct UAnimationAsset* ParachuteAnim; // Offset: 0x30 // Size: 0x08
	char pad_0x38[0x10]; // Offset: 0x38 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.GetAnimUtil
// Size: 0x20 // Inherited bytes: 0x00
struct FGetAnimUtil {
	// Fields
	struct TArray<struct FSoftObjectPath> PendingList; // Offset: 0x00 // Size: 0x10
	struct UUAECharacterAnimListSubSystem* AnimListSubSystem; // Offset: 0x10 // Size: 0x08
	char pad_0x18[0x8]; // Offset: 0x18 // Size: 0x08
};

// Object Name: ScriptStruct Gameplay.CharacterVehAnimModifyData
// Size: 0x38 // Inherited bytes: 0x00
struct FCharacterVehAnimModifyData {
	// Fields
	enum class ESVehAnimVehicleType VehicleType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int SeatIdx; // Offset: 0x04 // Size: 0x04
	enum class ECharacterVehicleAnimType VehicleAnimType; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x7]; // Offset: 0x09 // Size: 0x07
	struct UAnimationAsset* VehicleAnimSoftPtr; // Offset: 0x10 // Size: 0x28
};

// Object Name: ScriptStruct Gameplay.CharacterShieldAnimData
// Size: 0xa0 // Inherited bytes: 0x00
struct FCharacterShieldAnimData {
	// Fields
	enum class ECharacterShieldAnimType AnimType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FName AnimTypeName; // Offset: 0x08 // Size: 0x08
	struct FChararacterPoseAnimData PoseAnim_Stand; // Offset: 0x10 // Size: 0x30
	struct FChararacterPoseAnimData PoseAnim_Crouch; // Offset: 0x40 // Size: 0x30
	struct FChararacterPoseAnimData PoseAnim_Prone; // Offset: 0x70 // Size: 0x30
};

// Object Name: ScriptStruct Gameplay.ChararacterPoseAnimData
// Size: 0x30 // Inherited bytes: 0x00
struct FChararacterPoseAnimData {
	// Fields
	enum class ECharacterPoseType PoseType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct UAnimationAsset* PoseAnimSoftPtr; // Offset: 0x08 // Size: 0x28
};

// Object Name: ScriptStruct Gameplay.AsyncLoadCharAnimParams
// Size: 0x28 // Inherited bytes: 0x00
struct FAsyncLoadCharAnimParams {
	// Fields
	char pad_0x0[0x28]; // Offset: 0x00 // Size: 0x28
};

// Object Name: ScriptStruct Gameplay.CharAnimModifyData
// Size: 0x38 // Inherited bytes: 0x00
struct FCharAnimModifyData {
	// Fields
	int AppliedGameMode; // Offset: 0x00 // Size: 0x04
	enum class ECharaAnimListType ModifyAnimListType; // Offset: 0x04 // Size: 0x01
	enum class ECharacterAnimType AnimType; // Offset: 0x05 // Size: 0x01
	enum class ECharacterPoseType PoseType; // Offset: 0x06 // Size: 0x01
	enum class ECharacterJumpType JumpType; // Offset: 0x07 // Size: 0x01
	enum class ECharacterJumpPhase JumpPhase; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x7]; // Offset: 0x09 // Size: 0x07
	struct UAnimationAsset* PoseAnimSoftPtr; // Offset: 0x10 // Size: 0x28
};

// Object Name: ScriptStruct Gameplay.CharacterMovementAnimData
// Size: 0xa0 // Inherited bytes: 0x00
struct FCharacterMovementAnimData {
	// Fields
	enum class ECharacterAnimType AnimType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FName AnimTypeName; // Offset: 0x08 // Size: 0x08
	struct FChararacterPoseAnimData PoseAnim_Stand; // Offset: 0x10 // Size: 0x30
	struct FChararacterPoseAnimData PoseAnim_Crouch; // Offset: 0x40 // Size: 0x30
	struct FChararacterPoseAnimData PoseAnim_Prone; // Offset: 0x70 // Size: 0x30
};

// Object Name: ScriptStruct Gameplay.CharacterAnimStartAsynLoadParam
// Size: 0x02 // Inherited bytes: 0x00
struct FCharacterAnimStartAsynLoadParam {
	// Fields
	enum class ECharacterAnimTypeAsynLoaded AnimType; // Offset: 0x00 // Size: 0x01
	enum class ECharacterViewType CharacterViewType; // Offset: 0x01 // Size: 0x01
};

// Object Name: ScriptStruct Gameplay.CharacterAnimAsynLoadCompleteParam
// Size: 0x48 // Inherited bytes: 0x00
struct FCharacterAnimAsynLoadCompleteParam {
	// Fields
	enum class ECharacterAnimTypeAsynLoaded AnimTypeAsynLoaded; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FString AnimsCatorgeryName; // Offset: 0x08 // Size: 0x10
	enum class ECharacterViewType CharacterViewType; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x7]; // Offset: 0x19 // Size: 0x07
	struct UAnimationAsset* SoftPtrAnimation; // Offset: 0x20 // Size: 0x28
};

// Object Name: ScriptStruct Gameplay.CharacterAsynLoadedTypeAnim
// Size: 0x78 // Inherited bytes: 0x00
struct FCharacterAsynLoadedTypeAnim {
	// Fields
	enum class ECharacterAnimTypeAsynLoaded AnimTypeAsynLoaded; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FString AnimsCatorgeryName; // Offset: 0x08 // Size: 0x10
	struct FCharacterAnimTypeAsynLoadedPhaseData Anim; // Offset: 0x18 // Size: 0x60
};

// Object Name: ScriptStruct Gameplay.CharacterAnimTypeAsynLoadedPhaseData
// Size: 0x60 // Inherited bytes: 0x00
struct FCharacterAnimTypeAsynLoadedPhaseData {
	// Fields
	struct FString PhaseName; // Offset: 0x00 // Size: 0x10
	struct TMap<enum class ECharacterViewType, struct UAnimationAsset*> PhaseAnimSoftPtr; // Offset: 0x10 // Size: 0x50
};

// Object Name: ScriptStruct Gameplay.CharacterShovelAnimData
// Size: 0xc0 // Inherited bytes: 0x00
struct FCharacterShovelAnimData {
	// Fields
	struct FCharacterShovelPhaseData ShovelPhase_Enter; // Offset: 0x00 // Size: 0x30
	struct FCharacterShovelPhaseData ShovelPhase_Shoveling; // Offset: 0x30 // Size: 0x30
	struct FCharacterShovelPhaseData ShovelPhase_Leave; // Offset: 0x60 // Size: 0x30
	struct FCharacterShovelPhaseData ShovelPhase_Crouch_Leave; // Offset: 0x90 // Size: 0x30
};

// Object Name: ScriptStruct Gameplay.CharacterShovelPhaseData
// Size: 0x30 // Inherited bytes: 0x00
struct FCharacterShovelPhaseData {
	// Fields
	enum class ECharacterShovelPhase ShovelPhase; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct UAnimationAsset* PhaseAnimSoftPtr; // Offset: 0x08 // Size: 0x28
};

// Object Name: ScriptStruct Gameplay.CharacterJumpAnimData
// Size: 0x1c0 // Inherited bytes: 0x00
struct FCharacterJumpAnimData {
	// Fields
	enum class ECharacterJumpType JumpType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FName JumpTypeName; // Offset: 0x08 // Size: 0x08
	struct FChararacterJumpPhaseData JumpPhase_PreJump; // Offset: 0x10 // Size: 0x30
	struct FChararacterJumpPhaseData JumpPhase_FallLoop0; // Offset: 0x40 // Size: 0x30
	struct FChararacterJumpPhaseData JumpPhase_FallLoop1; // Offset: 0x70 // Size: 0x30
	struct FChararacterJumpPhaseData JumpPhase_Land0; // Offset: 0xa0 // Size: 0x30
	struct FChararacterJumpPhaseData JumpPhase_Land1; // Offset: 0xd0 // Size: 0x30
	struct FChararacterJumpPhaseData JumpPhase_GrenadeJump_1; // Offset: 0x100 // Size: 0x30
	struct FChararacterJumpPhaseData JumpPhase_GrenadeJump_2; // Offset: 0x130 // Size: 0x30
	struct FChararacterJumpPhaseData JumpPhase_GrenadeFall_1; // Offset: 0x160 // Size: 0x30
	struct FChararacterJumpPhaseData JumpPhase_GrenadeFall_2; // Offset: 0x190 // Size: 0x30
};

// Object Name: ScriptStruct Gameplay.ChararacterJumpPhaseData
// Size: 0x30 // Inherited bytes: 0x00
struct FChararacterJumpPhaseData {
	// Fields
	enum class ECharacterJumpPhase JumpPhase; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct UAnimationAsset* PhaseAnimSoftPtr; // Offset: 0x08 // Size: 0x28
};

// Object Name: ScriptStruct Gameplay.AsyncLoadCharVehAnimParams
// Size: 0x18 // Inherited bytes: 0x00
struct FAsyncLoadCharVehAnimParams {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x00 // Size: 0x18
};

// Object Name: ScriptStruct Gameplay.SpawnItemStat
// Size: 0x38 // Inherited bytes: 0x00
struct FSpawnItemStat {
	// Fields
	struct FString ItemCategory; // Offset: 0x00 // Size: 0x10
	struct FString ItemValue; // Offset: 0x10 // Size: 0x10
	int Together; // Offset: 0x20 // Size: 0x04
	int Count; // Offset: 0x24 // Size: 0x04
	struct FString TriggerName; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.DamageMatchGroup
// Size: 0x50 // Inherited bytes: 0x00
struct FDamageMatchGroup {
	// Fields
	struct TMap<int, float> DamageMatchPairs; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct Gameplay.CharSpecialLevelSequenceData
// Size: 0xf0 // Inherited bytes: 0x00
struct FCharSpecialLevelSequenceData {
	// Fields
	enum class ECharSpecialLevelSequenceType LevelSequenceType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FLevelSequenceConfig LevelSequenceConfig; // Offset: 0x08 // Size: 0xe8
};

// Object Name: ScriptStruct Gameplay.LevelSequenceConfig
// Size: 0xe8 // Inherited bytes: 0x00
struct FLevelSequenceConfig {
	// Fields
	struct FSoftClassPath SequenceActorTemplate; // Offset: 0x00 // Size: 0x18
	struct ULevelSequence* LevelSequence; // Offset: 0x18 // Size: 0x28
	float LevelSequenceDuration; // Offset: 0x40 // Size: 0x04
	char pad_0x44[0x4]; // Offset: 0x44 // Size: 0x04
	struct TMap<struct FString, struct FString> TrackBindingInfos; // Offset: 0x48 // Size: 0x50
	struct TMap<struct FString, struct FSoftObjectPath> TrackBindingObjects; // Offset: 0x98 // Size: 0x50
};

// Object Name: ScriptStruct Gameplay.LobbyAsyncLoadCharAnimParams
// Size: 0x20 // Inherited bytes: 0x00
struct FLobbyAsyncLoadCharAnimParams {
	// Fields
	char pad_0x0[0x20]; // Offset: 0x00 // Size: 0x20
};

// Object Name: ScriptStruct Gameplay.PlayerFiringList
// Size: 0x10 // Inherited bytes: 0x00
struct FPlayerFiringList {
	// Fields
	uint64 PlayerFiringIndexLow; // Offset: 0x00 // Size: 0x08
	uint64 PlayerFiringIndexHigh; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct Gameplay.PlayerBreathInfoList
// Size: 0x20 // Inherited bytes: 0x00
struct FPlayerBreathInfoList {
	// Fields
	uint64 PlayerIndexLow; // Offset: 0x00 // Size: 0x08
	uint64 PlayerIndexHigh; // Offset: 0x08 // Size: 0x08
	struct TArray<char> BreathList; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.PlayerKeyIndexForSort
// Size: 0x08 // Inherited bytes: 0x00
struct FPlayerKeyIndexForSort {
	// Fields
	uint32_t PlayerKey; // Offset: 0x00 // Size: 0x04
	uint32_t Index; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.PlanAGPlayerReportData
// Size: 0x30 // Inherited bytes: 0x00
struct FPlanAGPlayerReportData {
	// Fields
	uint64 UId; // Offset: 0x00 // Size: 0x08
	int TeamID; // Offset: 0x08 // Size: 0x04
	int TwoTargetScore; // Offset: 0x0c // Size: 0x04
	int FiveTargetScore; // Offset: 0x10 // Size: 0x04
	int FourColorTargetScore; // Offset: 0x14 // Size: 0x04
	int GophersTargetScore; // Offset: 0x18 // Size: 0x04
	int DishTargetScore; // Offset: 0x1c // Size: 0x04
	int AirdropTargetScore; // Offset: 0x20 // Size: 0x04
	int SpeedUpTargetNum; // Offset: 0x24 // Size: 0x04
	int BulletNum; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.PlanAGTeamReportData
// Size: 0x38 // Inherited bytes: 0x00
struct FPlanAGTeamReportData {
	// Fields
	int TeamID; // Offset: 0x00 // Size: 0x04
	int TwoTargetScore; // Offset: 0x04 // Size: 0x04
	int FiveTargetScore; // Offset: 0x08 // Size: 0x04
	int FourColorTargetScore; // Offset: 0x0c // Size: 0x04
	int GophersTargetScore; // Offset: 0x10 // Size: 0x04
	int DishTargetScore; // Offset: 0x14 // Size: 0x04
	int AirdropTargetScore; // Offset: 0x18 // Size: 0x04
	int SpeedUpTargetNum; // Offset: 0x1c // Size: 0x04
	int ShootingAccuracy; // Offset: 0x20 // Size: 0x04
	int TeamChecktime; // Offset: 0x24 // Size: 0x04
	int Fuel; // Offset: 0x28 // Size: 0x04
	int FuelMax; // Offset: 0x2c // Size: 0x04
	int Speed; // Offset: 0x30 // Size: 0x04
	int RefuelingTime; // Offset: 0x34 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.TeamInfoInOB
// Size: 0x38 // Inherited bytes: 0x00
struct FTeamInfoInOB {
	// Fields
	int TeamID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString TeamName; // Offset: 0x08 // Size: 0x10
	bool IsShowLogo; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x7]; // Offset: 0x19 // Size: 0x07
	struct FString LogoPicUrl; // Offset: 0x20 // Size: 0x10
	int KillNum; // Offset: 0x30 // Size: 0x04
	int LiveMemberNum; // Offset: 0x34 // Size: 0x04
};

// Object Name: ScriptStruct Gameplay.UAESpawnActorParam
// Size: 0x90 // Inherited bytes: 0x00
struct FUAESpawnActorParam {
	// Fields
	int TemplateID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct UObject* ActorClass; // Offset: 0x08 // Size: 0x08
	struct FVector SpawnLocation; // Offset: 0x10 // Size: 0x0c
	struct FRotator SpawnRotator; // Offset: 0x1c // Size: 0x0c
	struct FVector SpawnOffsetLoc; // Offset: 0x28 // Size: 0x0c
	enum class ESpawnActorCollisionHandlingMethod CollisionHandling; // Offset: 0x34 // Size: 0x01
	char pad_0x35[0x3]; // Offset: 0x35 // Size: 0x03
	float RandomRadius; // Offset: 0x38 // Size: 0x04
	bool RandomRotYaw; // Offset: 0x3c // Size: 0x01
	char pad_0x3D[0x3]; // Offset: 0x3d // Size: 0x03
	struct TArray<struct AActor*> TraceAvoidClass; // Offset: 0x40 // Size: 0x10
	struct AActor* Owner; // Offset: 0x50 // Size: 0x08
	struct APawn* Instigator; // Offset: 0x58 // Size: 0x08
	struct FString MakerName; // Offset: 0x60 // Size: 0x10
	bool IsTracePos; // Offset: 0x70 // Size: 0x01
	bool IsHalfCapsulePull; // Offset: 0x71 // Size: 0x01
	enum class EActorSpawnType SpawnType; // Offset: 0x72 // Size: 0x01
	char pad_0x73[0x1]; // Offset: 0x73 // Size: 0x01
	int ZTraceOffset; // Offset: 0x74 // Size: 0x04
	int MonsterBornType; // Offset: 0x78 // Size: 0x04
	int MonsterFrontBornType; // Offset: 0x7c // Size: 0x04
	enum class EFeatureSetType FeatureSetType; // Offset: 0x80 // Size: 0x01
	char pad_0x81[0xf]; // Offset: 0x81 // Size: 0x0f
};

// Object Name: ScriptStruct Gameplay.UAESpotDataSerialize
// Size: 0x1b0 // Inherited bytes: 0x00
struct FUAESpotDataSerialize {
	// Fields
	char pad_0x0[0x1b0]; // Offset: 0x00 // Size: 0x1b0
};

// Object Name: ScriptStruct Gameplay.UAEWindowPackageData
// Size: 0x60 // Inherited bytes: 0x00
struct FUAEWindowPackageData {
	// Fields
	struct TWeakObjectPtr<struct AUAEHouseActor> HouseActor; // Offset: 0x00 // Size: 0x08
	struct UObject* WindowClass; // Offset: 0x08 // Size: 0x08
	struct FUAEWindowRepData WindowData; // Offset: 0x10 // Size: 0x50
};

// Object Name: ScriptStruct Gameplay.BackupVehicleSpotData
// Size: 0x24 // Inherited bytes: 0x00
struct FBackupVehicleSpotData {
	// Fields
	int ID; // Offset: 0x00 // Size: 0x04
	enum class ESpotGroupType SpotGroupType; // Offset: 0x04 // Size: 0x01
	enum class ESpotType SpotType; // Offset: 0x05 // Size: 0x01
	char pad_0x6[0x2]; // Offset: 0x06 // Size: 0x02
	struct FVector SpotGenerateLoc; // Offset: 0x08 // Size: 0x0c
	struct FRotator SpotRotator; // Offset: 0x14 // Size: 0x0c
	bool bRandomRotation; // Offset: 0x20 // Size: 0x01
	bool bUsed; // Offset: 0x21 // Size: 0x01
	char pad_0x22[0x2]; // Offset: 0x22 // Size: 0x02
};

// Object Name: ScriptStruct Gameplay.VehicleSpotComponentArray
// Size: 0x18 // Inherited bytes: 0x00
struct FVehicleSpotComponentArray {
	// Fields
	enum class ESpotType SpotType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct TArray<struct UVehicleSpotSceneComponent*> AllSpots; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.VehicleGenerateSpawnDataArray
// Size: 0x20 // Inherited bytes: 0x00
struct FVehicleGenerateSpawnDataArray {
	// Fields
	struct FString Catetory; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FVehicleGenerateSpawnData> AllGenerateSpawnDatas; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.TotalWeaponReport
// Size: 0x28 // Inherited bytes: 0x00
struct FTotalWeaponReport {
	// Fields
	struct FString BattleID; // Offset: 0x00 // Size: 0x10
	int BattleMode; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct TArray<struct FOnePlayerWeapon> TotalWeaponRecord; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct Gameplay.WeatherLevelInfo
// Size: 0x20 // Inherited bytes: 0x00
struct FWeatherLevelInfo {
	// Fields
	int WeatherID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString WeatherLevelName; // Offset: 0x08 // Size: 0x10
	float WeatherTime; // Offset: 0x18 // Size: 0x04
	int WeatherSyncCount; // Offset: 0x1c // Size: 0x04
};

