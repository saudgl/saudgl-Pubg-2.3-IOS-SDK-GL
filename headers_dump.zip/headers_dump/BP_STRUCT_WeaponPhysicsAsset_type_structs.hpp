#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_WeaponPhysicsAsset_type.BP_STRUCT_WeaponPhysicsAsset_type
// Size: 0x14 // Inherited bytes: 0x00
struct FBP_STRUCT_WeaponPhysicsAsset_type {
	// Fields
	struct FString physics_asset_0_69E2394033CBBC235121B81B0E14C0C4; // Offset: 0x00 // Size: 0x10
	int weapon_id_1_7F95664030BA5D031B0BF5E204A4AB84; // Offset: 0x10 // Size: 0x04
};

