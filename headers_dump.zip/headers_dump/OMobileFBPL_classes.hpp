#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class OMobileFBPL.OMobileFBPL
// Size: 0x28 // Inherited bytes: 0x28
struct UOMobileFBPL : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function OMobileFBPL.OMobileFBPL.IsRunningOnBattery
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsRunningOnBattery(); // Offset: 0x1020128c4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function OMobileFBPL.OMobileFBPL.IsBatteryStateCharging
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsBatteryStateCharging(); // Offset: 0x102012890 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function OMobileFBPL.OMobileFBPL.GetVolumeState
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetVolumeState(); // Offset: 0x10201285c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function OMobileFBPL.OMobileFBPL.GetDeviceName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetDeviceName(); // Offset: 0x1020127f8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function OMobileFBPL.OMobileFBPL.GetBatteryTemperature
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	float GetBatteryTemperature(); // Offset: 0x1020127c4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function OMobileFBPL.OMobileFBPL.GetBatteryLevel
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetBatteryLevel(); // Offset: 0x102012790 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function OMobileFBPL.OMobileFBPL.AreHeadphonesPluggedIn
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool AreHeadphonesPluggedIn(); // Offset: 0x10201275c // Return & Params: Num(1) Size(0x1)
};

