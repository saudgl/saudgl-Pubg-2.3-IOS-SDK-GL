#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_LobbyQueuePopUI_ControlCfg_type.BP_STRUCT_LobbyQueuePopUI_ControlCfg_type
// Size: 0x98 // Inherited bytes: 0x00
struct FBP_STRUCT_LobbyQueuePopUI_ControlCfg_type {
	// Fields
	int ID_0_0BA3EF404F6475BD1E6FE45008F72164; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString Param1_1_24C7548014C9F29039BB818000D07121; // Offset: 0x08 // Size: 0x10
	struct FString Param2_2_24C854C014C9F29139BB818300D07122; // Offset: 0x18 // Size: 0x10
	int PlayerType_3_19426FC0346C75AB738ACCCD08E76A15; // Offset: 0x28 // Size: 0x04
	int Priority_4_41C6A4800413E6784183E7190011B079; // Offset: 0x2c // Size: 0x04
	int ShowCount1_5_1C20E2C01A9314C74E8483D50CC6A2E1; // Offset: 0x30 // Size: 0x04
	int ShowCount2_6_1C21E3001A9314C84E8483CA0CC6A2E2; // Offset: 0x34 // Size: 0x04
	int ShowCount3_7_1C22E3401A9314C94E8483CB0CC6A2E3; // Offset: 0x38 // Size: 0x04
	int ShowCount4_8_1C23E3801A9314CA4E8483C80CC6A2E4; // Offset: 0x3c // Size: 0x04
	struct FString TimeSpan1_9_1EB280801EF352EA5D7D5EA50CD86791; // Offset: 0x40 // Size: 0x10
	struct FString TimeSpan2_10_1EB380C01EF352EB5D7D5EA60CD86792; // Offset: 0x50 // Size: 0x10
	struct FString TimeSpan3_11_1EB481001EF352EC5D7D5EA70CD86793; // Offset: 0x60 // Size: 0x10
	struct FString TimeSpan4_12_1EB581401EF352ED5D7D5EA80CD86794; // Offset: 0x70 // Size: 0x10
	int UIKey_13_0CA41DC03F4B979D51E5360602026EB9; // Offset: 0x80 // Size: 0x04
	char pad_0x84[0x4]; // Offset: 0x84 // Size: 0x04
	struct FString UIName_14_706EB3C05B7141B320FA92730026B115; // Offset: 0x88 // Size: 0x10
};

