#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_WeaponDIYList_type.BP_STRUCT_WeaponDIYList_type
// Size: 0x198 // Inherited bytes: 0x00
struct FBP_STRUCT_WeaponDIYList_type {
	// Fields
	struct FString DefaultIcon_0_4CE794005B13840E212C9F540712CA7E; // Offset: 0x00 // Size: 0x10
	int DefaultStep_1_2EBBD8C05ABDC6AB26A8A87507139AE0; // Offset: 0x10 // Size: 0x04
	int DIYMaxIcon_2_64E7A5C077C93D59588BD9A4095E807E; // Offset: 0x14 // Size: 0x04
	int DIYMaxLayer_3_7906C2C043F4BA497F8EB43905FAED52; // Offset: 0x18 // Size: 0x04
	int ID_4_6DDB83C03F8D67BD4620788B08CAD2D4; // Offset: 0x1c // Size: 0x04
	struct FString name_5_58C948C02DCFF62B0831A4090AD150F5; // Offset: 0x20 // Size: 0x10
	struct FString part1_6_6407DA803234F17C158654120D1605D1; // Offset: 0x30 // Size: 0x10
	struct FString part2_7_6408DAC03234F17D158654110D1605D2; // Offset: 0x40 // Size: 0x10
	struct FString part3_8_6409DB003234F17E158654100D1605D3; // Offset: 0x50 // Size: 0x10
	struct FString part4_9_640ADB403234F17F158654170D1605D4; // Offset: 0x60 // Size: 0x10
	int Sort_12_67E64A803FE2E3C4082C1B1D0AD3AE54; // Offset: 0x70 // Size: 0x04
	char pad_0x74[0x4]; // Offset: 0x74 // Size: 0x04
	struct FString icon1_13_0F06170025F25AA8007C99900D0F2AB1; // Offset: 0x78 // Size: 0x10
	struct FString icon2_14_0F07174025F25AA9007C99910D0F2AB2; // Offset: 0x88 // Size: 0x10
	struct FString icon3_15_0F08178025F25AAA007C99920D0F2AB3; // Offset: 0x98 // Size: 0x10
	struct FString icon4_16_0F0917C025F25AAB007C99930D0F2AB4; // Offset: 0xa8 // Size: 0x10
	struct FString icon0_17_0F0516C025F25AA7007C99970D0F2AB0; // Offset: 0xb8 // Size: 0x10
	struct FString part0_18_6406DA403234F17B158654130D1605D0; // Offset: 0xc8 // Size: 0x10
	struct FString begin_time_19_4EC9C540305F9139734A98B406F62D25; // Offset: 0xd8 // Size: 0x10
	struct FString preName_20_1C7E12805CF01838148C04270706EB25; // Offset: 0xe8 // Size: 0x10
	struct FString icon_select0_21_532B8E8068F16B9C06792D01095010C0; // Offset: 0xf8 // Size: 0x10
	struct FString icon_select1_22_532C8EC068F16B9D06792D7E095010C1; // Offset: 0x108 // Size: 0x10
	struct FString icon_select2_23_532D8F0068F16B9E06792D7F095010C2; // Offset: 0x118 // Size: 0x10
	struct FString icon_select3_24_532E8F4068F16B9F06792D7C095010C3; // Offset: 0x128 // Size: 0x10
	struct FString icon_select4_25_532F8F8068F16BA006792D7D095010C4; // Offset: 0x138 // Size: 0x10
	int direction0_26_75D9BCC024DD4F936DA7F138017A5E50; // Offset: 0x148 // Size: 0x04
	int direction1_27_75DABD0024DD4F946DA7F139017A5E51; // Offset: 0x14c // Size: 0x04
	int direction2_28_75DBBD4024DD4F956DA7F13E017A5E52; // Offset: 0x150 // Size: 0x04
	int direction3_29_75DCBD8024DD4F966DA7F13F017A5E53; // Offset: 0x154 // Size: 0x04
	int direction4_30_75DDBDC024DD4F976DA7F13C017A5E54; // Offset: 0x158 // Size: 0x04
	int slotType0_31_1ED9658079861BCC33E0568D0A371C30; // Offset: 0x15c // Size: 0x04
	int slotType1_32_1EDA65C079861BCD33E0568C0A371C31; // Offset: 0x160 // Size: 0x04
	int slotType2_33_1EDB660079861BCE33E0568F0A371C32; // Offset: 0x164 // Size: 0x04
	int slotType3_34_1EDC664079861BCF33E0568E0A371C33; // Offset: 0x168 // Size: 0x04
	int slotType4_35_1EDD668079861BD033E056F10A371C34; // Offset: 0x16c // Size: 0x04
	int banDecal0_36_196B4F00011E674C2F357AE60E069EF0; // Offset: 0x170 // Size: 0x04
	int banDecal1_37_196C4F40011E674D2F357AE50E069EF1; // Offset: 0x174 // Size: 0x04
	int banDecal2_38_196D4F80011E674E2F357AE40E069EF2; // Offset: 0x178 // Size: 0x04
	int banDecal3_39_196E4FC0011E674F2F357AE30E069EF3; // Offset: 0x17c // Size: 0x04
	int banDecal4_40_196F5000011E67502F357AE20E069EF4; // Offset: 0x180 // Size: 0x04
	char pad_0x184[0x4]; // Offset: 0x184 // Size: 0x04
	struct FString MeshPath_41_0035070008DE1ED4234ACA510457BB98; // Offset: 0x188 // Size: 0x10
};

