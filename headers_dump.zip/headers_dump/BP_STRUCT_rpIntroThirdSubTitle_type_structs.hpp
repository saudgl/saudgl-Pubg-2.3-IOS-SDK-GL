#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_rpIntroThirdSubTitle_type.BP_STRUCT_rpIntroThirdSubTitle_type
// Size: 0x50 // Inherited bytes: 0x00
struct FBP_STRUCT_rpIntroThirdSubTitle_type {
	// Fields
	struct FString BPPath_0_485AD2800A76E6125015100B09BFBBF8; // Offset: 0x00 // Size: 0x10
	float endTime_f_1_5191CD804D14642A7968D10A049B83B6; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct FString imagePath_2_19554EC044A16CC12ABCAA1A0AEFDC38; // Offset: 0x18 // Size: 0x10
	bool is_center_aligin_3_63D76E800CADC1F608D98F6B0F9B8DFE; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x3]; // Offset: 0x29 // Size: 0x03
	int KeyIndex_4_72DFF300244C7CD2675066FF060D1018; // Offset: 0x2c // Size: 0x04
	struct FString localID_5_0F8C30C011AAA4C76FA1FE110FF45514; // Offset: 0x30 // Size: 0x10
	float startTime_f_6_24B08B40086B58B5298F38540C0A40F6; // Offset: 0x40 // Size: 0x04
	int textIndex_7_6258DA0048C9AD4E1BF5B04802BBECA8; // Offset: 0x44 // Size: 0x04
	int x_8_4FE848C013D2DBBF10FB0C110CAD35A8; // Offset: 0x48 // Size: 0x04
	int y_9_4FE9490013D2DBC010FB0C120CAD35A9; // Offset: 0x4c // Size: 0x04
};

