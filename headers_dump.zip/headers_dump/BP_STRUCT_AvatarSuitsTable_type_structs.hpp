#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_AvatarSuitsTable_type.BP_STRUCT_AvatarSuitsTable_type
// Size: 0x28 // Inherited bytes: 0x00
struct FBP_STRUCT_AvatarSuitsTable_type {
	// Fields
	struct FString FemaleSuits_0_5E12F5C00D5F71393EDCFF620F8ED0B3; // Offset: 0x00 // Size: 0x10
	int ItemID_1_644CE440325AB977296AC86003848904; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct FString MaleSuits_2_5E52230026563E4833623FFF0E279B13; // Offset: 0x18 // Size: 0x10
};

