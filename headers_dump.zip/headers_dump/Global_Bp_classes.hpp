#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Global_Bp.Global_Bp_C
// Size: 0x538 // Inherited bytes: 0x418
struct UGlobal_Bp_C : UUAEUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x418 // Size: 0x08
	struct USettingConfig_C* SettingConfigObject; // Offset: 0x420 // Size: 0x08
	struct TMap<struct FString, struct UTexture2D*> corpsIconTextureMap; // Offset: 0x428 // Size: 0x50
	struct Abp_global_C* bp_global; // Offset: 0x478 // Size: 0x08
	struct TMap<struct FString, struct UTexture2D*> rankTextureMap; // Offset: 0x480 // Size: 0x50
	struct TMap<int, struct UUserWidget*> dragDropItemMap; // Offset: 0x4d0 // Size: 0x50
	bool isPostProcessVolumeInit; // Offset: 0x520 // Size: 0x01
	char pad_0x521[0x7]; // Offset: 0x521 // Size: 0x07
	struct APostProcessVolume* postProcessClassic; // Offset: 0x528 // Size: 0x08
	struct ACameraPostProcessActor_C* cameraPostProcessActor; // Offset: 0x530 // Size: 0x08

	// Functions

	// Object Name: Function Global_Bp.Global_Bp_C.InitFireGyroSensibilitySettingData
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void InitFireGyroSensibilitySettingData(struct USettingConfig_C* ServerSettingConfig); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Global_Bp.Global_Bp_C.MapFromCBToESBH
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void MapFromCBToESBH(struct USettingConfig_C* SettingConfig); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Global_Bp.Global_Bp_C.InitMirrorObjMapPickupSetting
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void InitMirrorObjMapPickupSetting(struct USettingConfig_C* ServerSettingConfig); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Global_Bp.Global_Bp_C.InitThrowObjMapPickupSetting
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void InitThrowObjMapPickupSetting(struct USettingConfig_C* ServerSettingConfig); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Global_Bp.Global_Bp_C.InitDrugMapPickupSetting
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void InitDrugMapPickupSetting(struct USettingConfig_C* ServerSettingConfig); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Global_Bp.Global_Bp_C.InitBasicSettingData
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void InitBasicSettingData(struct USettingConfig_C* ServerSettingConfig); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Global_Bp.Global_Bp_C.InitPickupSettingData_XT
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void InitPickupSettingData_XT(struct USettingConfig_C* SettingConfig); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Global_Bp.Global_Bp_C.InitPickupSettingData
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void InitPickupSettingData(struct USettingConfig_C* ServerSettingConfig); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Global_Bp.Global_Bp_C.InitSensibilitySettingData
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void InitSensibilitySettingData(struct USettingConfig_C* ServerSettingConfig); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Global_Bp.Global_Bp_C.SetGrenadeDefaultPickValue
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetGrenadeDefaultPickValue(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Bp.Global_Bp_C.InitMapFromCBToES
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void InitMapFromCBToES(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Bp.Global_Bp_C.MapFromCBToESGlobal
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void MapFromCBToESGlobal(struct USettingConfig_C* SettingConfig); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Global_Bp.Global_Bp_C.MapFromCBToESJK
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void MapFromCBToESJK(struct USettingConfig_C* SettingConfig); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Global_Bp.Global_Bp_C.MapFromCBToESVN
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void MapFromCBToESVN(struct USettingConfig_C* SettingConfig); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Global_Bp.Global_Bp_C.LoadSettingConfigFromSlot
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void LoadSettingConfigFromSlot(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Bp.Global_Bp_C.UpdateBigHandOperateRedPoint
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void UpdateBigHandOperateRedPoint(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Bp.Global_Bp_C.SetPostProcessSettings
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetPostProcessSettings(int ID, float Time, bool isReverse, bool isClosing); // Offset: 0x103df3e6c // Return & Params: Num(4) Size(0xa)

	// Object Name: Function Global_Bp.Global_Bp_C.ShowItemPreviewPress
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void ShowItemPreviewPress(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Bp.Global_Bp_C.ShowItemPreviewClick
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void ShowItemPreviewClick(int ItemID); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Global_Bp.Global_Bp_C.SaveAnniversaryNeedShow
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SaveAnniversaryNeedShow(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Bp.Global_Bp_C.GetAnniversaryNeedShow
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void GetAnniversaryNeedShow(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Bp.Global_Bp_C.SaveResidentEvilNeedShow
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SaveResidentEvilNeedShow(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Bp.Global_Bp_C.GetResidentEvilNeedShow
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void GetResidentEvilNeedShow(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Bp.Global_Bp_C.SaveChristmasNeedShow
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SaveChristmasNeedShow(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Bp.Global_Bp_C.GetChristmasNeedShow
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void GetChristmasNeedShow(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Bp.Global_Bp_C.GetDragDropWidget
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void GetDragDropWidget(int dragDropType); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Global_Bp.Global_Bp_C.GetRankTexture
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void GetRankTexture(int rankIntegral, struct UTexture2D*& Output); // Offset: 0x103df3e6c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Global_Bp.Global_Bp_C.GetCorpsIconTexture
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void GetCorpsIconTexture(int IconID, struct UTexture2D*& Value); // Offset: 0x103df3e6c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Global_Bp.Global_Bp_C.GetFrameTexture
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void GetFrameTexture(int frameLevel, struct UTexture2D*& Output); // Offset: 0x103df3e6c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Global_Bp.Global_Bp_C.EnterCreateRoleDelay
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void EnterCreateRoleDelay(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Bp.Global_Bp_C.EnterCreateRole
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void EnterCreateRole(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Bp.Global_Bp_C.EventAndroidQuitGame
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void EventAndroidQuitGame(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Bp.Global_Bp_C.QuitGame
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void QuitGame(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Bp.Global_Bp_C.EnterLobby
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void EnterLobby(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Bp.Global_Bp_C.EnterLogin
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void EnterLogin(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Bp.Global_Bp_C.RecoverMaxFps
	// Flags: [BlueprintCallable|BlueprintEvent]
	void RecoverMaxFps(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Bp.Global_Bp_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Global_Bp.Global_Bp_C.ExecuteUbergraph_Global_Bp
	// Flags: [None]
	void ExecuteUbergraph_Global_Bp(int EntryPoint); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x4)
};

