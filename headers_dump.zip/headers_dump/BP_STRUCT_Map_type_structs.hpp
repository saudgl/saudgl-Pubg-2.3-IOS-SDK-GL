#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_Map_type.BP_STRUCT_Map_type
// Size: 0x140 // Inherited bytes: 0x00
struct FBP_STRUCT_Map_type {
	// Fields
	struct FString MapName_0_99C86D5F4EEAC838D927A895ABB469F4; // Offset: 0x00 // Size: 0x10
	int ResId_3_6A18D49C4C648A6B96E15C9CD0C9406D; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct FString MapPath_2_556AB4C74A5227AA1355AA8C60EF15BB; // Offset: 0x18 // Size: 0x10
	struct FString MiniMapPath_7_626C20754C65FDF1DF3BE882DFD06DB2; // Offset: 0x28 // Size: 0x10
	struct FString ShowImg_9_997F417E43ACA5F7ADE34991024B8A47; // Offset: 0x38 // Size: 0x10
	struct FString MainMode_10_F894E3F44BC17997549883BAE6037772; // Offset: 0x48 // Size: 0x10
	struct FString WatchingName_22_1E163A80197C082E6ED9EA62071623F5; // Offset: 0x58 // Size: 0x10
	int minimapscale_25_4D9A69C02EE150831A1405BB03C31435; // Offset: 0x68 // Size: 0x04
	int IsFpp_26_2FEF658020791EA605663E18029811B0; // Offset: 0x6c // Size: 0x04
	int IsObEnable_27_3C343A000A4AE4D404D752C60AADFBB5; // Offset: 0x70 // Size: 0x04
	int IsSingleValid_28_237210807451A52237EF47D40A4944A4; // Offset: 0x74 // Size: 0x04
	int IsTeamValid_29_01F3B9C04B9B6A5D6461122F06B4A484; // Offset: 0x78 // Size: 0x04
	int IsDoubleValid_30_3E486EC02BC356FD5EE53D960ABBEBD4; // Offset: 0x7c // Size: 0x04
	int RoomModeId_31_0A7DE0C045E9C26D13A178350E2CBD54; // Offset: 0x80 // Size: 0x04
	char pad_0x84[0x4]; // Offset: 0x84 // Size: 0x04
	struct FString MapKey_34_7C1F1EC057F596C138AC113C09BE9DE9; // Offset: 0x88 // Size: 0x10
	struct FString MapImage_37_5B95AD4015935BF959B4DDB00E841E65; // Offset: 0x98 // Size: 0x10
	struct FString ShowName_38_0FA0B58004CBF1EE4DD372DE09A86F25; // Offset: 0xa8 // Size: 0x10
	int DebugAI_Num_39_6706ED00455805583339F7C509DDF0CD; // Offset: 0xb8 // Size: 0x04
	char pad_0xBC[0x4]; // Offset: 0xbc // Size: 0x04
	struct TArray<struct FString> DeathReplayConfig_as_40_2DB7C4004600B556401B450008A1FF43; // Offset: 0xc0 // Size: 0x10
	struct FString RersultAvatarLevel_41_385FFF0064C51EE42E74DC0802F052BC; // Offset: 0xd0 // Size: 0x10
	struct FString ResultPoseSeq_Double_42_16B66B4029DF893D58B88E2B0F643505; // Offset: 0xe0 // Size: 0x10
	struct FString ResultPoseSeq_Four_43_33E2FB8018431B622C0CEB100C2F4442; // Offset: 0xf0 // Size: 0x10
	struct FString DefaultWeatherLevel_44_797D304037CFC8310E17E4C007790CEC; // Offset: 0x100 // Size: 0x10
	struct FString WeatherIds_45_59D0C900081800187E44747406C532F3; // Offset: 0x110 // Size: 0x10
	struct FString WeatherLevels_46_049C5BC06952395B73716DAD04F8A863; // Offset: 0x120 // Size: 0x10
	struct FString WeatherWeights_47_59DCF7C042A109616C35015900F91A93; // Offset: 0x130 // Size: 0x10
};

