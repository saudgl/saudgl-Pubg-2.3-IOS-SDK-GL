#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_WeaponMatParamCfg_type.BP_STRUCT_WeaponMatParamCfg_type
// Size: 0x68 // Inherited bytes: 0x00
struct FBP_STRUCT_WeaponMatParamCfg_type {
	// Fields
	int ID_0_01306C0006E69B6C5E6CBB190B10ADC4; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString RotateMax_1_34BDAE003728AED6240ED2BB0B806958; // Offset: 0x08 // Size: 0x10
	struct FString RotateMin_2_2CDAAD805AF7CA44240ED7AF0B80692E; // Offset: 0x18 // Size: 0x10
	struct FString ShakeMax_3_5CDAED403E5A84016FD5821105714F08; // Offset: 0x28 // Size: 0x10
	struct FString ShakeMin_4_54F7ECC024AD0C3F6FD58F7905714F7E; // Offset: 0x38 // Size: 0x10
	struct FString RotateStartMax_5_1B3031800163A6B0438B0A0A07319588; // Offset: 0x48 // Size: 0x10
	struct FString RotateStartMin_6_134D310064C8066E438B0902073195FE; // Offset: 0x58 // Size: 0x10
};

