#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class UAEStateMachine.TestStatemachine
// Size: 0x3e0 // Inherited bytes: 0x3d8
struct ATestStatemachine : AActor {
	// Fields
	struct UUAEStateMachineComponent* UAEStateMachineComponent; // Offset: 0x3d8 // Size: 0x08
};

// Object Name: Class UAEStateMachine.UAEStateMachineComponent
// Size: 0x1c8 // Inherited bytes: 0x110
struct UUAEStateMachineComponent : UActorComponent {
	// Fields
	struct FScriptMulticastDelegate OnBeforeTransientEvent; // Offset: 0x110 // Size: 0x10
	struct FScriptMulticastDelegate OnAfterTransientEvent; // Offset: 0x120 // Size: 0x10
	struct FString Tag; // Offset: 0x130 // Size: 0x10
	struct TArray<struct UUAEState*> States; // Offset: 0x140 // Size: 0x10
	struct TMap<struct FString, struct FUAEStateMachineTransition> Transitions; // Offset: 0x150 // Size: 0x50
	struct FUAETransitionState StartState; // Offset: 0x1a0 // Size: 0x10
	struct FUAETransitionState EndState; // Offset: 0x1b0 // Size: 0x10
	struct UUAEState* CurrentState; // Offset: 0x1c0 // Size: 0x08

	// Functions

	// Object Name: Function UAEStateMachine.UAEStateMachineComponent.Start
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Start(); // Offset: 0x10233e244 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UAEStateMachine.UAEStateMachineComponent.SetTag
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTag(struct FString InTag); // Offset: 0x10233e188 // Return & Params: Num(1) Size(0x10)

	// Object Name: DelegateFunction UAEStateMachine.UAEStateMachineComponent.OnTransientEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnTransientEvent__DelegateSignature(struct FString TransientEvent, struct FString CurrentState, struct FString TransientToState); // Offset: 0x103df3e6c // Return & Params: Num(3) Size(0x30)

	// Object Name: Function UAEStateMachine.UAEStateMachineComponent.IsInState
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsInState(struct FString StateName); // Offset: 0x10233e0bc // Return & Params: Num(2) Size(0x11)

	// Object Name: Function UAEStateMachine.UAEStateMachineComponent.GetCurrentState
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UUAEState* GetCurrentState(); // Offset: 0x10233e0a0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UAEStateMachine.UAEStateMachineComponent.ForceDoEvent
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ForceDoEvent(struct FString EventName); // Offset: 0x10233dfe4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UAEStateMachine.UAEStateMachineComponent.Finish
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Finish(); // Offset: 0x10233dfd0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UAEStateMachine.UAEStateMachineComponent.DoEvent
	// Flags: [Final|Native|Public|BlueprintCallable]
	void DoEvent(struct FString EventName); // Offset: 0x10233df14 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UAEStateMachine.UAEStateMachineComponent.CanDoEvent
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool CanDoEvent(struct FString EventName); // Offset: 0x10233de48 // Return & Params: Num(2) Size(0x11)
};

// Object Name: Class UAEStateMachine.UAEState
// Size: 0x28 // Inherited bytes: 0x28
struct UUAEState : UObject {
	// Functions

	// Object Name: Function UAEStateMachine.UAEState.Update
	// Flags: [Native|Event|Public|BlueprintEvent]
	void Update(float DeltaTime); // Offset: 0x10233d920 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UAEStateMachine.UAEState.OnLeave
	// Flags: [Native|Event|Public|BlueprintEvent]
	void OnLeave(struct UUAEState* TranitToState); // Offset: 0x10233d89c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UAEStateMachine.UAEState.OnEnter
	// Flags: [Native|Event|Public|BlueprintEvent]
	void OnEnter(struct UUAEState* PrevState); // Offset: 0x10233d818 // Return & Params: Num(1) Size(0x8)
};

