#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_MapPakTable_type.BP_STRUCT_MapPakTable_type
// Size: 0x78 // Inherited bytes: 0x00
struct FBP_STRUCT_MapPakTable_type {
	// Fields
	struct FString MapKey_1_4544DFC0334EDD5D34A9E30F069493F9; // Offset: 0x00 // Size: 0x10
	int event_3_25231680475817D804605AFA03760874; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct FString filepre_4_2B7BC7C0632F3D5963C50A7D064EE4F5; // Offset: 0x18 // Size: 0x10
	struct FString name_7_6D2B96401074429F2CEED5770238ECF5; // Offset: 0x28 // Size: 0x10
	int showInDownloader_8_3CAC6FC048591B6B353B8E2C0F01DF42; // Offset: 0x38 // Size: 0x04
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
	struct FString mapDesc_9_07F67D406147490D7FA0665A09488F13; // Offset: 0x40 // Size: 0x10
	int defaultMount_12_73E00C002F28DAD84178E075049562C4; // Offset: 0x50 // Size: 0x04
	char pad_0x54[0x4]; // Offset: 0x54 // Size: 0x04
	struct FString depends_13_29F406C059A081A1635ED9E4000AA7C3; // Offset: 0x58 // Size: 0x10
	struct FString showImage_14_38FD17001E8554142273AC440A9D54E5; // Offset: 0x68 // Size: 0x10
};

