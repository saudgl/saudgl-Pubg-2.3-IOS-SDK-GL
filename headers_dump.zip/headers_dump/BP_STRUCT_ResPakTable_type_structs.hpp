#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_ResPakTable_type.BP_STRUCT_ResPakTable_type
// Size: 0x40 // Inherited bytes: 0x00
struct FBP_STRUCT_ResPakTable_type {
	// Fields
	struct FString Key_0_46BAFB4028818B237E8A905308936BD9; // Offset: 0x00 // Size: 0x10
	struct FString ResDesc_1_547D7B4048C39C554F9F96A102DF3FD3; // Offset: 0x10 // Size: 0x10
	struct FString ResName_2_0E5D7BC02ABE679B4F53C24202E0D575; // Offset: 0x20 // Size: 0x10
	struct FString ResIcon_3_42729DC02699E9534F64C01C02DF6B1E; // Offset: 0x30 // Size: 0x10
};

