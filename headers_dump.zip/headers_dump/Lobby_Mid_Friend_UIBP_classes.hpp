#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Lobby_Mid_Friend_UIBP.Lobby_Mid_Friend_UIBP_C
// Size: 0x310 // Inherited bytes: 0x260
struct ULobby_Mid_Friend_UIBP_C : UUserWidget {
	// Fields
	struct UWidgetAnimation* Friend_Remind; // Offset: 0x260 // Size: 0x08
	struct UWidgetAnimation* Anim_Loop; // Offset: 0x268 // Size: 0x08
	struct UButton* Button_OnlinePlayers2; // Offset: 0x270 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_18; // Offset: 0x278 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_20; // Offset: 0x280 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_New; // Offset: 0x288 // Size: 0x08
	struct UImage* Image_15; // Offset: 0x290 // Size: 0x08
	struct UImage* Image_16; // Offset: 0x298 // Size: 0x08
	struct ULobby_Mid_Tips_Friend_UIBP_C* Lobby_Mid_Tips_Friend_UIBP_C_1; // Offset: 0x2a0 // Size: 0x08
	struct ULoopScrollBox* LoopScrollBox_1; // Offset: 0x2a8 // Size: 0x08
	struct UTextBlock* TextBlock_1; // Offset: 0x2b0 // Size: 0x08
	struct UTextBlock* TextBlock_2; // Offset: 0x2b8 // Size: 0x08
	struct FSlateColor MentorWhiteColor; // Offset: 0x2c0 // Size: 0x28
	struct FSlateColor MentorYellowColor; // Offset: 0x2e8 // Size: 0x28
};

