#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UAnimationBudgetBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary.SetAnimationBudgetParameters
	// Flags: [Final|Native|Static|Private|HasOutParms|BlueprintCallable]
	void SetAnimationBudgetParameters(struct UObject* WorldContextObject, struct FAnimationBudgetAllocatorParameters& InParameters); // Offset: 0x1021e9c00 // Return & Params: Num(2) Size(0x58)

	// Object Name: Function AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary.EnableAnimationBudget
	// Flags: [Final|Native|Static|Private|BlueprintCallable]
	void EnableAnimationBudget(struct UObject* WorldContextObject, bool bEnabled); // Offset: 0x1021e9b48 // Return & Params: Num(2) Size(0x9)
};

// Object Name: Class AnimationBudgetAllocator.SkeletalMeshComponentBudgeted
// Size: 0xdd0 // Inherited bytes: 0xdb0
struct USkeletalMeshComponentBudgeted : USkeletalMeshComponent {
	// Fields
	char pad_0xDB0[0x18]; // Offset: 0xdb0 // Size: 0x18
	char bAutoRegisterWithBudgetAllocator : 1; // Offset: 0xdc8 // Size: 0x01
	char bAutoCalculateSignificance : 1; // Offset: 0xdc8 // Size: 0x01
	char bShouldUseActorRenderedFlag : 1; // Offset: 0xdc8 // Size: 0x01
	char pad_0xDC8_3 : 5; // Offset: 0xdc8 // Size: 0x01
	char pad_0xDC9[0x7]; // Offset: 0xdc9 // Size: 0x07

	// Functions

	// Object Name: Function AnimationBudgetAllocator.SkeletalMeshComponentBudgeted.SetAutoRegisterWithBudgetAllocator
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAutoRegisterWithBudgetAllocator(bool bInAutoRegisterWithBudgetAllocator); // Offset: 0x1021e9ed4 // Return & Params: Num(1) Size(0x1)
};

