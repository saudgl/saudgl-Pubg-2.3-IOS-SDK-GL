#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_WeaponDIYColorTable_type.BP_STRUCT_WeaponDIYColorTable_type
// Size: 0x14 // Inherited bytes: 0x00
struct FBP_STRUCT_WeaponDIYColorTable_type {
	// Fields
	struct FString ColorString_0_4E7650C0415307B368226BB801F47B77; // Offset: 0x00 // Size: 0x10
	int ID_1_7AE1B68005F218745C79F2BF0B6565A4; // Offset: 0x10 // Size: 0x04
};

