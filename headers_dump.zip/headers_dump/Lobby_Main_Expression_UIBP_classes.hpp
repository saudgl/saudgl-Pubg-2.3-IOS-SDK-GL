#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Lobby_Main_Expression_UIBP.Lobby_Main_Expression_UIBP_C
// Size: 0x468 // Inherited bytes: 0x418
struct ULobby_Main_Expression_UIBP_C : UUAEUserWidget {
	// Fields
	struct UWidgetAnimation* DX_Transitions_Enter; // Offset: 0x418 // Size: 0x08
	struct UWidgetAnimation* DX_Transitions_StartEnter; // Offset: 0x420 // Size: 0x08
	struct UButton* Button_Overlay_Ainm_2; // Offset: 0x428 // Size: 0x08
	struct UButton* Button_Overlay_Ainm_3; // Offset: 0x430 // Size: 0x08
	struct UImage* Image_8; // Offset: 0x438 // Size: 0x08
	struct UCanvasPanel* lobby_root_anchor; // Offset: 0x440 // Size: 0x08
	struct UOverlay* Overlay_Ainm_2; // Offset: 0x448 // Size: 0x08
	struct UOverlay* Overlay_Ainm_3; // Offset: 0x450 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_2; // Offset: 0x458 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_Ainm; // Offset: 0x460 // Size: 0x08
};

