#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Common_Avatar_BP.Common_Avatar_BP_C
// Size: 0x330 // Inherited bytes: 0x2d0
struct UCommon_Avatar_BP_C : ULuaUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x2d0 // Size: 0x08
	struct UGridPanel* GridPanel_1; // Offset: 0x2d8 // Size: 0x08
	struct FString PlayerUID; // Offset: 0x2e0 // Size: 0x10
	struct UUserWidget* targetUI; // Offset: 0x2f0 // Size: 0x08
	struct UButton* buttonItem; // Offset: 0x2f8 // Size: 0x08
	struct FScriptMulticastDelegate OnClickItemCallback; // Offset: 0x300 // Size: 0x10
	struct UImage* ImageRoleNation; // Offset: 0x310 // Size: 0x08
	bool IsForceUpdate; // Offset: 0x318 // Size: 0x01
	bool IsNeedAsyncLoad; // Offset: 0x319 // Size: 0x01
	char pad_0x31A[0x6]; // Offset: 0x31a // Size: 0x06
	struct FScriptMulticastDelegate DownloadSuc; // Offset: 0x320 // Size: 0x10

	// Functions

	// Object Name: Function Common_Avatar_BP.Common_Avatar_BP_C.SetPlayerBanned
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetPlayerBanned(bool bIsBanned); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Common_Avatar_BP.Common_Avatar_BP_C.OnDownloadSuc
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void OnDownloadSuc(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Common_Avatar_BP.Common_Avatar_BP_C.SetUsePool
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetUsePool(bool usePool); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Common_Avatar_BP.Common_Avatar_BP_C.SetAssetLoadingMethod
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetAssetLoadingMethod(bool Async); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Common_Avatar_BP.Common_Avatar_BP_C.SetIconSize
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetIconSize(int X, int Y); // Offset: 0x103df3e6c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Common_Avatar_BP.Common_Avatar_BP_C.SetFrameTextureExt
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void SetFrameTextureExt(int frameLevel, struct UTexture2D* Texture2D, struct UTexture2D*& Output); // Offset: 0x103df3e6c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Common_Avatar_BP.Common_Avatar_BP_C.SetFrameTexture
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetFrameTexture(struct UTexture2D* Texture2D); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Common_Avatar_BP.Common_Avatar_BP_C.SetPlayerLevel
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetPlayerLevel(int Level); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Common_Avatar_BP.Common_Avatar_BP_C.SetPlayerGender
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetPlayerGender(int Gd); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Common_Avatar_BP.Common_Avatar_BP_C.SetPlayerUid
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetPlayerUid(struct FString UId); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Common_Avatar_BP.Common_Avatar_BP_C.GetRankFrameLevelPath
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetRankFrameLevelPath(int frameLevel, struct FString& Path); // Offset: 0x103df3e6c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Common_Avatar_BP.Common_Avatar_BP_C.SetFrame
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetFrame(int Level); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Common_Avatar_BP.Common_Avatar_BP_C.SetDefaultIcon
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetDefaultIcon(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Common_Avatar_BP.Common_Avatar_BP_C.SetPlayerIcon
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetPlayerIcon(struct FString URL); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Common_Avatar_BP.Common_Avatar_BP_C.InitView
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void InitView(int Style, struct FString UId, struct FString iconUrl, int gender, int frameLevel, int PlayerLevel, bool ignoreFrame, struct FString RoleNation); // Offset: 0x103df3e6c // Return & Params: Num(8) Size(0x48)

	// Object Name: Function Common_Avatar_BP.Common_Avatar_BP_C.OnClickItem
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnClickItem(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Common_Avatar_BP.Common_Avatar_BP_C.OnLoadIcon
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnLoadIcon(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Common_Avatar_BP.Common_Avatar_BP_C._BindEvent
	// Flags: [BlueprintCallable|BlueprintEvent]
	void _BindEvent(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Common_Avatar_BP.Common_Avatar_BP_C._ClearEvent
	// Flags: [BlueprintCallable|BlueprintEvent]
	void _ClearEvent(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Common_Avatar_BP.Common_Avatar_BP_C.ExecuteUbergraph_Common_Avatar_BP
	// Flags: [None]
	void ExecuteUbergraph_Common_Avatar_BP(int EntryPoint); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Common_Avatar_BP.Common_Avatar_BP_C.DownloadSuc__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void DownloadSuc__DelegateSignature(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Common_Avatar_BP.Common_Avatar_BP_C.OnClickItemCallback__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnClickItemCallback__DelegateSignature(struct FString UId); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x10)
};

