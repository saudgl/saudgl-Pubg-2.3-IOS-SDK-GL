#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_CycleMemoryTaskCfg_type.BP_STRUCT_CycleMemoryTaskCfg_type
// Size: 0x38 // Inherited bytes: 0x00
struct FBP_STRUCT_CycleMemoryTaskCfg_type {
	// Fields
	struct FString TaskDesc_0_61BC4D004EAB49B010CBD0200B859673; // Offset: 0x00 // Size: 0x10
	int TaskID_1_5647508030643F2A4E7C73130AEB85E4; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct FString TaskTitle_2_5C0A0DC06B28E7990C34E8AA09AAA595; // Offset: 0x18 // Size: 0x10
	struct FString JumpID_3_151592C01760E3950435F9EA0C595EE4; // Offset: 0x28 // Size: 0x10
};

