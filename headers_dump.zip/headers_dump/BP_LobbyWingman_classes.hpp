#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_LobbyWingman.BP_LobbyWingman_C
// Size: 0x40d // Inherited bytes: 0x3e0
struct ABP_LobbyWingman_C : ASTExtraLobbyWingman {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x3e0 // Size: 0x08
	struct UWingmanAvatarComp_BP_C* WingmanAvatarComp_BP; // Offset: 0x3e8 // Size: 0x08
	struct FScriptMulticastDelegate OnHallWingmanAnimPlay; // Offset: 0x3f0 // Size: 0x10
	float invincible; // Offset: 0x400 // Size: 0x04
	float Freq; // Offset: 0x404 // Size: 0x04
	float Speed; // Offset: 0x408 // Size: 0x04
	bool isNeedUpdate; // Offset: 0x40c // Size: 0x01

	// Functions

	// Object Name: Function BP_LobbyWingman.BP_LobbyWingman_C.SetHighLight
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetHighLight(float invincible, float Freq, float Speed); // Offset: 0x103df3e6c // Return & Params: Num(3) Size(0xc)

	// Object Name: Function BP_LobbyWingman.BP_LobbyWingman_C.PlayHallWingmanAnim
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void PlayHallWingmanAnim(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_LobbyWingman.BP_LobbyWingman_C.UserConstructionScript
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void UserConstructionScript(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_LobbyWingman.BP_LobbyWingman_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveBeginPlay(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_LobbyWingman.BP_LobbyWingman_C.WingmanAvatarEqiuped_Event_1
	// Flags: [BlueprintCallable|BlueprintEvent]
	void WingmanAvatarEqiuped_Event_1(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_LobbyWingman.BP_LobbyWingman_C.ExecuteUbergraph_BP_LobbyWingman
	// Flags: [None]
	void ExecuteUbergraph_BP_LobbyWingman(int EntryPoint); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BP_LobbyWingman.BP_LobbyWingman_C.OnHallWingmanAnimPlay__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnHallWingmanAnimPlay__DelegateSignature(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)
};

