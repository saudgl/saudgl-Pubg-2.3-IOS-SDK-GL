#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_VehicleAttrBPTable_type.BP_STRUCT_VehicleAttrBPTable_type
// Size: 0x25 // Inherited bytes: 0x00
struct FBP_STRUCT_VehicleAttrBPTable_type {
	// Fields
	struct FString BPPath_0_0D3462806070054A1BE4A9D10087ADF8; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FName> EnterVehicleSocket_an_1_75E790001273E7EA0ED1B75E010D0DBE; // Offset: 0x10 // Size: 0x10
	int ID_2_09285E002DD17CFC7DD2679C02C55024; // Offset: 0x20 // Size: 0x04
	bool bNewAttr_3_5B69248071070CB0214BD9B4060ED912; // Offset: 0x24 // Size: 0x01
};

