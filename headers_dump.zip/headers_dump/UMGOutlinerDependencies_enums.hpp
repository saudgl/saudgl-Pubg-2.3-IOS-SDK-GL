#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum UMGOutlinerDependencies.EUMGOutlinerEvent
enum class EUMGOutlinerEvent : int32 {
	None = -1,
	ResponseRebuildTreeView = 0,
	RequestSetItemExpansion = 1,
	RequestRebuildTreeView = 2,
	RequestPaintBorder = 3,
	RequestRemoveBorder = 4,
	RequestChangeProperty = 5,
	RequestCloseConnection = 6,
	EUMGOutlinerEvent_MAX = 7
};

