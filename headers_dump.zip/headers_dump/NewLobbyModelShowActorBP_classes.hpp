#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass NewLobbyModelShowActorBP.NewLobbyModelShowActorBP_C
// Size: 0x740 // Inherited bytes: 0x4a0
struct ANewLobbyModelShowActorBP_C : ALuaActor {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x4a0 // Size: 0x08
	struct UStaticMeshComponent* Sphere; // Offset: 0x4a8 // Size: 0x08
	struct UCapsuleComponent* Capsule; // Offset: 0x4b0 // Size: 0x08
	struct USceneComponent* Scene; // Offset: 0x4b8 // Size: 0x08
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x4c0 // Size: 0x08
	float WeaponMatTimeline_time_CC1B41C749E55AE85A5FF0A2EA7DF654; // Offset: 0x4c8 // Size: 0x04
	enum class ETimelineDirection WeaponMatTimeline__Direction_CC1B41C749E55AE85A5FF0A2EA7DF654; // Offset: 0x4cc // Size: 0x01
	char pad_0x4CD[0x3]; // Offset: 0x4cd // Size: 0x03
	struct UTimelineComponent* WeaponMatTimeline; // Offset: 0x4d0 // Size: 0x08
	struct ASTExtraWeapon* WeaponActor; // Offset: 0x4d8 // Size: 0x08
	struct UWeaponAvatarComponent* WeaponAvatarComponent; // Offset: 0x4e0 // Size: 0x08
	bool press; // Offset: 0x4e8 // Size: 0x01
	enum class ETouchIndex FingerIndex; // Offset: 0x4e9 // Size: 0x01
	char pad_0x4EA[0x2]; // Offset: 0x4ea // Size: 0x02
	float LocationX; // Offset: 0x4ec // Size: 0x04
	bool canAutoRotateZ; // Offset: 0x4f0 // Size: 0x01
	char pad_0x4F1[0x3]; // Offset: 0x4f1 // Size: 0x03
	float zRotateSpeed; // Offset: 0x4f4 // Size: 0x04
	float LocationY; // Offset: 0x4f8 // Size: 0x04
	bool canAutoRotateX; // Offset: 0x4fc // Size: 0x01
	char pad_0x4FD[0x3]; // Offset: 0x4fd // Size: 0x03
	float backTime; // Offset: 0x500 // Size: 0x04
	float curBackTime; // Offset: 0x504 // Size: 0x04
	float disinteractDis; // Offset: 0x508 // Size: 0x04
	float yIntensity; // Offset: 0x50c // Size: 0x04
	float yDisinteractRatio; // Offset: 0x510 // Size: 0x04
	float originX; // Offset: 0x514 // Size: 0x04
	float originY; // Offset: 0x518 // Size: 0x04
	bool alreadyRotate; // Offset: 0x51c // Size: 0x01
	bool alreadyRotateY; // Offset: 0x51d // Size: 0x01
	bool canRotateBack; // Offset: 0x51e // Size: 0x01
	char pad_0x51F[0x1]; // Offset: 0x51f // Size: 0x01
	int ShowType; // Offset: 0x520 // Size: 0x04
	bool needXRotation; // Offset: 0x524 // Size: 0x01
	char pad_0x525[0x3]; // Offset: 0x525 // Size: 0x03
	struct ACharacter* PlaneCharacter; // Offset: 0x528 // Size: 0x08
	float XRotateMin; // Offset: 0x530 // Size: 0x04
	float XRotateMax; // Offset: 0x534 // Size: 0x04
	float YRotateMin; // Offset: 0x538 // Size: 0x04
	float YRotateMax; // Offset: 0x53c // Size: 0x04
	int CurrentItemID; // Offset: 0x540 // Size: 0x04
	char pad_0x544[0x4]; // Offset: 0x544 // Size: 0x04
	struct ABP_Lobby_Grenade_C* grenadeActor; // Offset: 0x548 // Size: 0x08
	bool isTouching; // Offset: 0x550 // Size: 0x01
	char pad_0x551[0x7]; // Offset: 0x551 // Size: 0x07
	struct TArray<struct FVector> projectilePredictArray; // Offset: 0x558 // Size: 0x10
	int projectileTickIndex; // Offset: 0x568 // Size: 0x04
	float xRotateSpeed; // Offset: 0x56c // Size: 0x04
	struct FRotator AttachPointDefaultRotate; // Offset: 0x570 // Size: 0x0c
	char pad_0x57C[0x4]; // Offset: 0x57c // Size: 0x04
	struct ALobbyModelCommonActorBP_C* bagWidgetActor; // Offset: 0x580 // Size: 0x08
	char pad_0x588[0x8]; // Offset: 0x588 // Size: 0x08
	struct FTransform SpawnTransform; // Offset: 0x590 // Size: 0x30
	struct ABP_LobbyVehicle_C* VehicleActor; // Offset: 0x5c0 // Size: 0x08
	bool canRotate; // Offset: 0x5c8 // Size: 0x01
	char pad_0x5C9[0x3]; // Offset: 0x5c9 // Size: 0x03
	int curGrenadeIndex; // Offset: 0x5cc // Size: 0x04
	int spawnIndex; // Offset: 0x5d0 // Size: 0x04
	char pad_0x5D4[0x4]; // Offset: 0x5d4 // Size: 0x04
	struct TMap<int, struct FShowActorData> ShowActorDataArray; // Offset: 0x5d8 // Size: 0x50
	struct ABP_LobbyVehicle_C* refitVehicleActor; // Offset: 0x628 // Size: 0x08
	struct ALobbyModelCommonActorBP_C* parachuteActor; // Offset: 0x630 // Size: 0x08
	int curVehicleIndex; // Offset: 0x638 // Size: 0x04
	char pad_0x63C[0x4]; // Offset: 0x63c // Size: 0x04
	struct TArray<struct FString> ExtraData; // Offset: 0x640 // Size: 0x10
	bool EnableInput_2; // Offset: 0x650 // Size: 0x01
	bool RotateBackZ; // Offset: 0x651 // Size: 0x01
	char pad_0x652[0x6]; // Offset: 0x652 // Size: 0x06
	struct ANewLobbyModelShowActorBP_C* nextShowActor; // Offset: 0x658 // Size: 0x08
	bool isAsyncLoading; // Offset: 0x660 // Size: 0x01
	bool weaponDynMatChanged; // Offset: 0x661 // Size: 0x01
	char pad_0x662[0x6]; // Offset: 0x662 // Size: 0x06
	struct ALobbyModelCommonActorBP_C* icon3DActor; // Offset: 0x668 // Size: 0x08
	struct TSet<int> HasShakeEffectItem; // Offset: 0x670 // Size: 0x50
	struct ALobbyModelCommonActorBP_C* bagActor; // Offset: 0x6c0 // Size: 0x08
	struct FBP_STRUCT_WeaponMatParamCfg_type WeaponMatParam; // Offset: 0x6c8 // Size: 0x68
	float MatAlpha; // Offset: 0x730 // Size: 0x04
	char pad_0x734[0x4]; // Offset: 0x734 // Size: 0x04
	struct ABP_LobbyWingman_C* WingmanActor; // Offset: 0x738 // Size: 0x08

	// Functions

	// Object Name: Function NewLobbyModelShowActorBP.NewLobbyModelShowActorBP_C.Get3DHandleMatAndTex
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void Get3DHandleMatAndTex(struct UBackpack3DIconHandle* SoftObjectRef, struct UObject*& maleMat, struct UObject*& Tex); // Offset: 0x103df3e6c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function NewLobbyModelShowActorBP.NewLobbyModelShowActorBP_C.GetAttachPoint
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetAttachPoint(struct AActor*& attachPoint); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function NewLobbyModelShowActorBP.NewLobbyModelShowActorBP_C.ArrayFind
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void ArrayFind(struct FString Input, bool& Index); // Offset: 0x103df3e6c // Return & Params: Num(2) Size(0x11)

	// Object Name: Function NewLobbyModelShowActorBP.NewLobbyModelShowActorBP_C.SetCastShadow
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetCastShadow(bool CastShadow); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function NewLobbyModelShowActorBP.NewLobbyModelShowActorBP_C.UpdateWeaponMatParam
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void UpdateWeaponMatParam(float Alpha); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function NewLobbyModelShowActorBP.NewLobbyModelShowActorBP_C.PlayProjectileEffect
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void PlayProjectileEffect(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function NewLobbyModelShowActorBP.NewLobbyModelShowActorBP_C.UserConstructionScript
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void UserConstructionScript(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function NewLobbyModelShowActorBP.NewLobbyModelShowActorBP_C.WeaponMatTimeline__FinishedFunc
	// Flags: [BlueprintEvent]
	void WeaponMatTimeline__FinishedFunc(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function NewLobbyModelShowActorBP.NewLobbyModelShowActorBP_C.WeaponMatTimeline__UpdateFunc
	// Flags: [BlueprintEvent]
	void WeaponMatTimeline__UpdateFunc(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function NewLobbyModelShowActorBP.NewLobbyModelShowActorBP_C.Projectile
	// Flags: [BlueprintCallable|BlueprintEvent]
	void Projectile(float X, float Y, float Z); // Offset: 0x103df3e6c // Return & Params: Num(3) Size(0xc)

	// Object Name: Function NewLobbyModelShowActorBP.NewLobbyModelShowActorBP_C.TickWeaponMat
	// Flags: [BlueprintCallable|BlueprintEvent]
	void TickWeaponMat(float fromShake, float toShake); // Offset: 0x103df3e6c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function NewLobbyModelShowActorBP.NewLobbyModelShowActorBP_C.ReceiveTick
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveTick(float DeltaSeconds); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function NewLobbyModelShowActorBP.NewLobbyModelShowActorBP_C.ExecuteUbergraph_NewLobbyModelShowActorBP
	// Flags: [HasDefaults]
	void ExecuteUbergraph_NewLobbyModelShowActorBP(int EntryPoint); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x4)
};

