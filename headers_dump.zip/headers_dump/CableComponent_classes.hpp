#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class CableComponent.CableActor
// Size: 0x3e0 // Inherited bytes: 0x3d8
struct ACableActor : AActor {
	// Fields
	struct UCableComponent* CableComponent; // Offset: 0x3d8 // Size: 0x08
};

// Object Name: Class CableComponent.CableComponent
// Size: 0x7a0 // Inherited bytes: 0x730
struct UCableComponent : UMeshComponent {
	// Fields
	bool bAttachStart; // Offset: 0x725 // Size: 0x01
	bool bAttachEnd; // Offset: 0x726 // Size: 0x01
	struct FComponentReference AttachEndTo; // Offset: 0x728 // Size: 0x18
	struct FName AttachEndToSocketName; // Offset: 0x740 // Size: 0x08
	struct FVector EndLocation; // Offset: 0x748 // Size: 0x0c
	float CableLength; // Offset: 0x754 // Size: 0x04
	int NumSegments; // Offset: 0x758 // Size: 0x04
	float SubstepTime; // Offset: 0x75c // Size: 0x04
	int SolverIterations; // Offset: 0x760 // Size: 0x04
	bool bEnableStiffness; // Offset: 0x764 // Size: 0x01
	bool bEnableCollision; // Offset: 0x765 // Size: 0x01
	float CollisionFriction; // Offset: 0x768 // Size: 0x04
	struct FVector CableForce; // Offset: 0x76c // Size: 0x0c
	float CableGravityScale; // Offset: 0x778 // Size: 0x04
	float CableWidth; // Offset: 0x77c // Size: 0x04
	int NumSides; // Offset: 0x780 // Size: 0x04
	float TileMaterial; // Offset: 0x784 // Size: 0x04
	char pad_0x790[0x10]; // Offset: 0x790 // Size: 0x10

	// Functions

	// Object Name: Function CableComponent.CableComponent.SetAttachEndTo
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAttachEndTo(struct AActor* Actor, struct FName ComponentProperty, struct FName SocketName); // Offset: 0x10250ee2c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function CableComponent.CableComponent.GetCableParticleLocations
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetCableParticleLocations(struct TArray<struct FVector>& Locations); // Offset: 0x10250ed84 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function CableComponent.CableComponent.GetAttachedComponent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct USceneComponent* GetAttachedComponent(); // Offset: 0x10250ed50 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function CableComponent.CableComponent.GetAttachedActor
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct AActor* GetAttachedActor(); // Offset: 0x10250ed1c // Return & Params: Num(1) Size(0x8)
};

