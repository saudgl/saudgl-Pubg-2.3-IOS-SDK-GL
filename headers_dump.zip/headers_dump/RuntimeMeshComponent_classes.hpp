#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class RuntimeMeshComponent.RuntimeMeshComponent
// Size: 0x830 // Inherited bytes: 0x730
struct URuntimeMeshComponent : UMeshComponent {
	// Fields
	struct FScriptMulticastDelegate CollisionUpdated; // Offset: 0x730 // Size: 0x10
	bool bUseComplexAsSimpleCollision; // Offset: 0x740 // Size: 0x01
	bool bUseAsyncCooking; // Offset: 0x741 // Size: 0x01
	bool bShouldSerializeMeshData; // Offset: 0x742 // Size: 0x01
	enum class ERuntimeMeshCollisionCookingMode CollisionMode; // Offset: 0x743 // Size: 0x01
	char pad_0x744[0x4]; // Offset: 0x744 // Size: 0x04
	struct UBodySetup* BodySetup; // Offset: 0x748 // Size: 0x08
	char pad_0x750[0x30]; // Offset: 0x750 // Size: 0x30
	struct TArray<struct FRuntimeMeshCollisionSection> MeshCollisionSections; // Offset: 0x780 // Size: 0x10
	struct TArray<struct FRuntimeConvexCollisionSection> ConvexCollisionSections; // Offset: 0x790 // Size: 0x10
	struct FBoxSphereBounds LocalBounds; // Offset: 0x7a0 // Size: 0x1c
	char pad_0x7BC[0x4]; // Offset: 0x7bc // Size: 0x04
	struct FRuntimeMeshComponentPrePhysicsTickFunction PrePhysicsTick; // Offset: 0x7c0 // Size: 0x58
	struct TArray<struct UBodySetup*> AsyncBodySetupQueue; // Offset: 0x818 // Size: 0x10
	char pad_0x828[0x8]; // Offset: 0x828 // Size: 0x08

	// Functions

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.UpdateMeshSection_Blueprint
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void UpdateMeshSection_Blueprint(int SectionIndex, struct TArray<struct FVector>& Vertices, struct TArray<int>& Triangles, struct TArray<struct FVector>& Normals, struct TArray<struct FRuntimeMeshTangent>& Tangents, struct TArray<struct FVector2D>& UV0, struct TArray<struct FVector2D>& UV1, struct TArray<struct FLinearColor>& Colors, bool bCalculateNormalTangent, bool bGenerateTessellationTriangles); // Offset: 0x1022e1fec // Return & Params: Num(10) Size(0x7a)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.SetSectionTessellationTriangles
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetSectionTessellationTriangles(int SectionIndex, struct TArray<int>& TessellationTriangles, bool bShouldMoveArray); // Offset: 0x1022e1eb4 // Return & Params: Num(3) Size(0x19)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.SetMeshSectionVisible
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMeshSectionVisible(int SectionIndex, bool bNewVisibility); // Offset: 0x1022e1df8 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.SetMeshSectionCollisionEnabled
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMeshSectionCollisionEnabled(int SectionIndex, bool bNewCollisionEnabled); // Offset: 0x1022e1d3c // Return & Params: Num(2) Size(0x5)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.SetMeshSectionCastsShadow
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMeshSectionCastsShadow(int SectionIndex, bool bNewCastsShadow); // Offset: 0x1022e1c80 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.SetMeshCollisionSection
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetMeshCollisionSection(int CollisionSectionIndex, struct TArray<struct FVector>& Vertices, struct TArray<int>& Triangles); // Offset: 0x1022e1b2c // Return & Params: Num(3) Size(0x28)

	// Object Name: DelegateFunction RuntimeMeshComponent.RuntimeMeshComponent.RuntimeMeshCollisionUpdatedDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void RuntimeMeshCollisionUpdatedDelegate__DelegateSignature(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.IsMeshSectionVisible
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsMeshSectionVisible(int SectionIndex); // Offset: 0x1022e1aa0 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.IsMeshSectionCollisionEnabled
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsMeshSectionCollisionEnabled(int SectionIndex); // Offset: 0x1022e1a14 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.IsMeshSectionCastingShadows
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsMeshSectionCastingShadows(int SectionIndex); // Offset: 0x1022e1988 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.GetNumSections
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetNumSections(); // Offset: 0x1022e1954 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.GetLastSectionIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetLastSectionIndex(); // Offset: 0x1022e1920 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.FirstAvailableMeshSectionIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int FirstAvailableMeshSectionIndex(); // Offset: 0x1022e18ec // Return & Params: Num(1) Size(0x4)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.EndBatchUpdates
	// Flags: [Final|Native|Public|BlueprintCallable]
	void EndBatchUpdates(); // Offset: 0x1022e18d8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.DoesSectionExist
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool DoesSectionExist(int SectionIndex); // Offset: 0x1022e184c // Return & Params: Num(2) Size(0x5)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.CreateMeshSection_Blueprint
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void CreateMeshSection_Blueprint(int SectionIndex, struct TArray<struct FVector>& Vertices, struct TArray<int>& Triangles, struct TArray<struct FVector>& Normals, struct TArray<struct FRuntimeMeshTangent>& Tangents, struct TArray<struct FVector2D>& UV0, struct TArray<struct FVector2D>& UV1, struct TArray<struct FLinearColor>& Colors, bool bCreateCollision, bool bCalculateNormalTangent, bool bGenerateTessellationTriangles, enum class EUpdateFrequency UpdateFrequency); // Offset: 0x1022e139c // Return & Params: Num(12) Size(0x7c)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.CookCollisionNow
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CookCollisionNow(); // Offset: 0x1022e1388 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.ClearMeshSection
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearMeshSection(int SectionIndex); // Offset: 0x1022e130c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.ClearMeshCollisionSection
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearMeshCollisionSection(int CollisionSectionIndex); // Offset: 0x1022e1290 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.ClearCollisionConvexMeshes
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearCollisionConvexMeshes(); // Offset: 0x1022e127c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.ClearAllMeshSections
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearAllMeshSections(); // Offset: 0x1022e1268 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.ClearAllMeshCollisionSections
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearAllMeshCollisionSections(); // Offset: 0x1022e1254 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.BeginBatchUpdates
	// Flags: [Final|Native|Public|BlueprintCallable]
	void BeginBatchUpdates(); // Offset: 0x1022e1238 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshComponent.AddCollisionConvexMesh
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddCollisionConvexMesh(struct TArray<struct FVector> ConvexVerts); // Offset: 0x1022e1154 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class RuntimeMeshComponent.RuntimeMeshLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct URuntimeMeshLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshLibrary.GetSectionFromStaticMesh
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetSectionFromStaticMesh(struct UStaticMesh* InMesh, int LODIndex, int SectionIndex, struct TArray<struct FVector>& Vertices, struct TArray<int>& Triangles, struct TArray<struct FVector>& Normals, struct TArray<struct FVector2D>& UVs, struct TArray<struct FRuntimeMeshTangent>& Tangents); // Offset: 0x1022e3a64 // Return & Params: Num(8) Size(0x60)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshLibrary.GenerateTessellationIndexBuffer
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GenerateTessellationIndexBuffer(struct TArray<struct FVector>& Vertices, struct TArray<int>& Triangles, struct TArray<struct FVector2D>& UVs, struct TArray<struct FVector>& Normals, struct TArray<struct FRuntimeMeshTangent>& Tangents, struct TArray<int>& OutTessTriangles); // Offset: 0x1022e37ac // Return & Params: Num(6) Size(0x60)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshLibrary.CreateGridMeshTriangles
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void CreateGridMeshTriangles(int NumX, int NumY, bool bWinding, struct TArray<int>& Triangles); // Offset: 0x1022e3650 // Return & Params: Num(4) Size(0x20)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshLibrary.CreateBoxMesh
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void CreateBoxMesh(struct FVector BoxRadius, struct TArray<struct FVector>& Vertices, struct TArray<int>& Triangles, struct TArray<struct FVector>& Normals, struct TArray<struct FVector2D>& UVs, struct TArray<struct FRuntimeMeshTangent>& Tangents); // Offset: 0x1022e33c4 // Return & Params: Num(6) Size(0x60)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshLibrary.CopyRuntimeMeshFromStaticMeshComponent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void CopyRuntimeMeshFromStaticMeshComponent(struct UStaticMeshComponent* StaticMeshComp, int LODIndex, struct URuntimeMeshComponent* RuntimeMeshComp, bool bShouldCreateCollision); // Offset: 0x1022e3294 // Return & Params: Num(4) Size(0x19)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshLibrary.ConvertQuadToTriangles
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void ConvertQuadToTriangles(struct TArray<int>& Triangles, int Vert0, int Vert1, int Vert2, int Vert3); // Offset: 0x1022e30f8 // Return & Params: Num(5) Size(0x20)

	// Object Name: Function RuntimeMeshComponent.RuntimeMeshLibrary.CalculateTangentsForMesh
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void CalculateTangentsForMesh(struct TArray<struct FVector>& Vertices, struct TArray<int>& Triangles, struct TArray<struct FVector2D>& UVs, struct TArray<struct FVector>& Normals, struct TArray<struct FRuntimeMeshTangent>& Tangents); // Offset: 0x1022e2ea8 // Return & Params: Num(5) Size(0x50)
};

