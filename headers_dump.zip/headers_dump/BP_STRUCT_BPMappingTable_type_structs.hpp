#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_BPMappingTable_type.BP_STRUCT_BPMappingTable_type
// Size: 0x14 // Inherited bytes: 0x00
struct FBP_STRUCT_BPMappingTable_type {
	// Fields
	struct FString BPMapping_0_359D8E805EAA95B608F926810D8E6097; // Offset: 0x00 // Size: 0x10
	int ItemID_2_53343E0047BD3A720C3CF0DE04726144; // Offset: 0x10 // Size: 0x04
};

