#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_ActivityCenterConfig_type.BP_STRUCT_ActivityCenterConfig_type
// Size: 0x90 // Inherited bytes: 0x00
struct FBP_STRUCT_ActivityCenterConfig_type {
	// Fields
	int ShowType_0_05733740375524D9752F7B7A0F475AE5; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString Condition4_1_2901FD404F76C8BB0434B7C302F17474; // Offset: 0x08 // Size: 0x10
	struct FString Condition6_2_2903FDC04F76C8BD0434B7C102F17476; // Offset: 0x18 // Size: 0x10
	struct FString Condition2_3_28FFFCC04F76C8B90434B7C502F17472; // Offset: 0x28 // Size: 0x10
	struct FString Condition7_4_2904FE004F76C8BE0434B7CE02F17477; // Offset: 0x38 // Size: 0x10
	struct FString Condition1_5_28FEFC804F76C8B80434B7C402F17471; // Offset: 0x48 // Size: 0x10
	struct FString Condition3_6_2900FD004F76C8BA0434B7C202F17473; // Offset: 0x58 // Size: 0x10
	struct FString Condition8_7_2905FE404F76C8BF0434B7CF02F17478; // Offset: 0x68 // Size: 0x10
	struct FString Condition5_8_2902FD804F76C8BC0434B7C002F17475; // Offset: 0x78 // Size: 0x10
	int Type_9_41764F0053D8665E43DBA22C0BFAB045; // Offset: 0x88 // Size: 0x04
	int SwitchType_10_2C604B80151A18782E38B1A601671E45; // Offset: 0x8c // Size: 0x04
};

