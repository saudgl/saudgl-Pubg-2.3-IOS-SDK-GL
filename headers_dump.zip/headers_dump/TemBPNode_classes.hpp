#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class TemBPNode.TemBPLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UTemBPLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function TemBPNode.TemBPLibrary.TempUIMsgInvokeRef
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void TempUIMsgInvokeRef(struct UObject* ObjContext, struct FString MsgName, struct FString ModuleName, struct TArray<struct FTemBPDataAddr>& ParamArray); // Offset: 0x1021a34f0 // Return & Params: Num(4) Size(0x38)

	// Object Name: Function TemBPNode.TemBPLibrary.TempBridgeEventInvokeRef
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void TempBridgeEventInvokeRef(struct UObject* ObjContext, struct FString EventType, struct FString EventId, struct TArray<struct FTemBPDataAddr>& ParamArray); // Offset: 0x1021a336c // Return & Params: Num(4) Size(0x38)

	// Object Name: Function TemBPNode.TemBPLibrary.AddrFromWild
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FTemBPDataAddr AddrFromWild(struct FString DataType, struct FTemBPDataAddr& InAny); // Offset: 0x1021a3360 // Return & Params: Num(3) Size(0x40)

	// Object Name: Function TemBPNode.TemBPLibrary.AddrFromSet
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FTemBPDataAddr AddrFromSet(struct FString DataType, struct TSet<int>& InAny); // Offset: 0x1021a3354 // Return & Params: Num(3) Size(0x78)

	// Object Name: Function TemBPNode.TemBPLibrary.AddrFromMap
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FTemBPDataAddr AddrFromMap(struct FString DataType, struct TMap<int, int>& InAny); // Offset: 0x1021a3348 // Return & Params: Num(3) Size(0x78)

	// Object Name: Function TemBPNode.TemBPLibrary.AddrFromArray
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FTemBPDataAddr AddrFromArray(struct FString DataType, struct TArray<int>& InAny); // Offset: 0x1021a333c // Return & Params: Num(3) Size(0x38)
};

// Object Name: Class TemBPNode.LuaTemBPData
// Size: 0x28 // Inherited bytes: 0x28
struct ULuaTemBPData : UObject {
};

// Object Name: Class TemBPNode.LuaTemBPData_bool
// Size: 0x30 // Inherited bytes: 0x28
struct ULuaTemBPData_bool : ULuaTemBPData {
	// Fields
	bool Data; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x7]; // Offset: 0x29 // Size: 0x07
};

// Object Name: Class TemBPNode.LuaTemBPData_int
// Size: 0x30 // Inherited bytes: 0x28
struct ULuaTemBPData_int : ULuaTemBPData {
	// Fields
	int Data; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
};

// Object Name: Class TemBPNode.LuaTemBPData_float
// Size: 0x30 // Inherited bytes: 0x28
struct ULuaTemBPData_float : ULuaTemBPData {
	// Fields
	float Data; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
};

// Object Name: Class TemBPNode.LuaTemBPData_string
// Size: 0x38 // Inherited bytes: 0x28
struct ULuaTemBPData_string : ULuaTemBPData {
	// Fields
	struct FString Data; // Offset: 0x28 // Size: 0x10
};

// Object Name: Class TemBPNode.LuaTemBPData_object
// Size: 0x30 // Inherited bytes: 0x28
struct ULuaTemBPData_object : ULuaTemBPData {
	// Fields
	struct UObject* Data; // Offset: 0x28 // Size: 0x08
};

