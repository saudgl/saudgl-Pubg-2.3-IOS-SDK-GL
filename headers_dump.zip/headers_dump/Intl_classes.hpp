#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class Intl.StatManager
// Size: 0x1d8 // Inherited bytes: 0x28
struct UStatManager : UObject {
	// Fields
	char pad_0x28[0x1b0]; // Offset: 0x28 // Size: 0x1b0

	// Functions

	// Object Name: Function Intl.StatManager.ReportEventWithString
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ReportEventWithString(int EventType, struct FString _eventBody, bool isRealTime); // Offset: 0x10547b6e0 // Return & Params: Num(3) Size(0x19)

	// Object Name: Function Intl.StatManager.ReportEventWithParam
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ReportEventWithParam(int EventType, struct TMap<struct FString, struct FString> _params, bool isRealTime); // Offset: 0x10547b590 // Return & Params: Num(3) Size(0x59)

	// Object Name: Function Intl.StatManager.ReportEventWithNoParam
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ReportEventWithNoParam(int EventType, bool isRealTime); // Offset: 0x10547b4d4 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Intl.StatManager.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UStatManager* GetInstance(); // Offset: 0x10547b4a0 // Return & Params: Num(1) Size(0x8)
};

