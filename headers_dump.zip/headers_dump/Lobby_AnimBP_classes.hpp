#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: AnimBlueprintGeneratedClass Lobby_AnimBP.Lobby_AnimBP_C
// Size: 0x4bed // Inherited bytes: 0x480
struct ULobby_AnimBP_C : USTPawnAnimInstanceBase {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x480 // Size: 0x08
	struct FAnimNode_Root AnimGraphNode_Root_AFF52F6C457272B774D5C286273B97F4; // Offset: 0x488 // Size: 0x50
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_2BE462B7452BD6CC7AA9BEB99A15F46B; // Offset: 0x4d8 // Size: 0x2c0
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_9A8BCB494C60C4E6B163B69FBF189C85; // Offset: 0x798 // Size: 0x50
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_9E8CA6A84B12F57225A6DB8E983D5123; // Offset: 0x7e8 // Size: 0x50
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_473AC4274B4CEED81B20C9A9ACC2EB17; // Offset: 0x838 // Size: 0x70
	struct FAnimNode_ApplyAdditive AnimGraphNode_ApplyAdditive_47BBD58E47BA952B4BC65BB1577F4EF6; // Offset: 0x8a8 // Size: 0x80
	struct FAnimNode_Slot AnimGraphNode_Slot_32F8A3014A4B2F525C7DD4B2D614EA15; // Offset: 0x928 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_F7A0422648E25AB4352F9A96EDFC9CC3; // Offset: 0x998 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_4BF41F204D641F3C8FA2F1AC89979187; // Offset: 0xa08 // Size: 0x70
	struct FAnimNode_ApplyAdditive AnimGraphNode_ApplyAdditive_736936E84C48BB5C4165BA8DD7CEB90D; // Offset: 0xa78 // Size: 0x80
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_3A66873B4D49DFF418B19B8623248317; // Offset: 0xaf8 // Size: 0x50
	struct FAnimNode_ApplyAdditive AnimGraphNode_ApplyAdditive_D1F9C59643EF5AB6506D33B1FAF9BEAE; // Offset: 0xb48 // Size: 0x80
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_4F7536174C45371D788EBA946ED43248; // Offset: 0xbc8 // Size: 0x70
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_F8943D434E6AAE1B07C0F1B3ABB0DA78; // Offset: 0xc38 // Size: 0x50
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_D25BB41445101287DBCE3EB4CAB67171; // Offset: 0xc88 // Size: 0xc0
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_17F5FAB949FCF7C783F62AAB483AC447; // Offset: 0xd48 // Size: 0x50
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_A5A477CB4316043DAC6FF4A95217783D; // Offset: 0xd98 // Size: 0x50
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_C2D2D97E414325A1E172869DEE2DE416; // Offset: 0xde8 // Size: 0xc0
	struct FAnimNode_Slot AnimGraphNode_Slot_B65895564C080E77F70DF7AA5C4C1300; // Offset: 0xea8 // Size: 0x70
	struct FAnimNode_BlendListByInt AnimGraphNode_BlendListByInt_4A815C384984B5A2B5386299F2DEED85; // Offset: 0xf18 // Size: 0xd0
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_986285904B872DCB94CF8CBAB9A90888; // Offset: 0xfe8 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_5E0C64FC43AAF3BD99CE0D84DCFD52A2; // Offset: 0x1058 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_D49905424D9E64B1DC1DB58770E63F03; // Offset: 0x10c8 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2A1BA28C41B59FDC94DD439E6E4AA51F; // Offset: 0x1138 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_EE27731C4EE1344DDB785FBD062BE8C6; // Offset: 0x11a8 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_07AFE46040E954CBDBB3088F734467E2; // Offset: 0x1218 // Size: 0x70
	struct FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_9A8F47724807B36A5929E3A6B1860F7F; // Offset: 0x1288 // Size: 0xe8
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_0E60BE884F4F2D4D549762803828DD05; // Offset: 0x1370 // Size: 0xd0
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_DDCBB29A4A3C78BA06EDE9BE0F603F0F; // Offset: 0x1440 // Size: 0xd0
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_EDCBB4A3451F17C986B87E830382CD73; // Offset: 0x1510 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3608C9064898C777D090B8A2B9FD3A3F; // Offset: 0x1580 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_8B9AEDA847AFF35B2E42148070E80DB9; // Offset: 0x15f0 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_35658A8340547480AEB0B78E19C1027F; // Offset: 0x1660 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_DF4F569A4918899597E2E89D3D11B3E5; // Offset: 0x16d0 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_222D007B405FDA5EFDB3568AEF39D531; // Offset: 0x1740 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_561B31A044E65E1E340CFB9B6FFB51F4; // Offset: 0x17b0 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2B079C8B4A4419E004261EA1DA8759A6; // Offset: 0x1820 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_191DC67A40173F2F0C4DA0BFA2CB665E; // Offset: 0x1890 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_92153E9547C3807F57A62BB6447C559F; // Offset: 0x1900 // Size: 0x70
	struct FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_A513AE2D43A39ABB4CF95CBA42F46E4F; // Offset: 0x1970 // Size: 0xe8
	struct FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_2FC4424843DAD0EDAC532EA346B5B3D5; // Offset: 0x1a58 // Size: 0xe8
	struct FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_626A8657450B700E04EA978275350404; // Offset: 0x1b40 // Size: 0xe8
	struct FAnimNode_Root AnimGraphNode_StateResult_DBA75E85412A18376FC1B782D7D7E62C; // Offset: 0x1c28 // Size: 0x50
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine_7C66CC2046E30C0FE71EDAA15CA235DE; // Offset: 0x1c78 // Size: 0xd8
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_522010E9411D43F7B58CC1AF78D43D8A; // Offset: 0x1d50 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_A3B9C9E74B16C14BA3BA058316F50B1E; // Offset: 0x1dc0 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_DE62A7724E25812FD8462382C57B45E9; // Offset: 0x1e30 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_5D9907374142A88F15EE6B90BB047A33; // Offset: 0x1ea0 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_154F5C224665119F224224BFB88AB20B; // Offset: 0x1f10 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_5DCE8DF8407A1A155A85C9A64A110AB3; // Offset: 0x1f80 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_9A993A8E41FF247B76D393AE30694D7A; // Offset: 0x1ff0 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_6832A2A44278A823895A78B13D0407AE; // Offset: 0x2060 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_FB8EC6B14686D6CA087EF683B30E4775; // Offset: 0x20d0 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_25A38C25417C4448092CE6B9B98EFA0B; // Offset: 0x2140 // Size: 0x70
	struct FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_C898A5D7416E49C0B875F381E8BFDFD3; // Offset: 0x21b0 // Size: 0xe8
	struct FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_C095363F4AC15D76C347A2BFF205FCE4; // Offset: 0x2298 // Size: 0xe8
	struct FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_696616664DC8F8B31B7072B548CDF566; // Offset: 0x2380 // Size: 0xe8
	struct FAnimNode_Root AnimGraphNode_StateResult_CE1AF3FA4F5795623E54058D50259456; // Offset: 0x2468 // Size: 0x50
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine_ECEB81AF4DF2907A26DEEDB8C9420083; // Offset: 0x24b8 // Size: 0xd8
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_C324BED34DCE43458C6D94B3C571BD2B; // Offset: 0x2590 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_BF7DAE5C4CDEC269AD6AA192CF1FD6E3; // Offset: 0x2600 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_08930DDA4CE34DAC3601EA9E39D422B7; // Offset: 0x2670 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_F8307FC74803EA2024D30A983FE9ACB8; // Offset: 0x26e0 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_A33B190241873044F5EBE3B405869D1E; // Offset: 0x2750 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_894802A74CD4DA76D55CC2821BC7E8B8; // Offset: 0x27c0 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_B0F3F91644D9E68047C8B29D4E54742B; // Offset: 0x2830 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_00960CA54A347CA1F2B7D0A0D94B4130; // Offset: 0x28a0 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_14188E96493882B251D35C9BA78D0203; // Offset: 0x2910 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_0300AC2D4493E991FCFCB9898896AB33; // Offset: 0x2980 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_96B8F204402ECDB76F7B92ACC8A0BE2E; // Offset: 0x29f0 // Size: 0x70
	struct FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_8EBE0B9340BA1548E3FEF392CAAB88A2; // Offset: 0x2a60 // Size: 0xe8
	struct FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_A347A3ED47331AAA671B7A9F8D626390; // Offset: 0x2b48 // Size: 0xe8
	struct FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_59BB895B4FABFB558D844FBD547DA6DF; // Offset: 0x2c30 // Size: 0xe8
	struct FAnimNode_Root AnimGraphNode_StateResult_384935F8419BF996A60784881AF1D3B3; // Offset: 0x2d18 // Size: 0x50
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine_809461744C84751F661513B46DECC19B; // Offset: 0x2d68 // Size: 0xd8
	struct FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_19A367B64AA6A6E557F95895FD546B0C; // Offset: 0x2e40 // Size: 0xe8
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_99BEBB72474B296808E67BA89EF360C4; // Offset: 0x2f28 // Size: 0xd0
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_321CC3564AC8D96DE5675E932E6FEF7D; // Offset: 0x2ff8 // Size: 0x50
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_7C925F734DBE08D09FE001810C0F531B; // Offset: 0x3048 // Size: 0x50
	struct FAnimNode_ApplyAdditive AnimGraphNode_ApplyAdditive_5053D59846A79D34177D06809EAC19A4; // Offset: 0x3098 // Size: 0x80
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_02C27FD84D09FAB2A76F7B819BE4E02E; // Offset: 0x3118 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_6B1B765D4DFCF3ED170D2CA6BA912335; // Offset: 0x3188 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_DC74B3834291C85A1C11BB907AA1CC44; // Offset: 0x31f8 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_1CD7157D4AA33BBC8A249794003DA92D; // Offset: 0x3268 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_26E2FBDA45BCCD35C178208267A47E3C; // Offset: 0x32d8 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_19EA61F347E92E523233C0973F710EDD; // Offset: 0x3348 // Size: 0x70
	struct FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_D7A166DD41A3E24756434FA7A0BABDE8; // Offset: 0x33b8 // Size: 0xe8
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_74C05CBE44C7AF6CB793908D2C8B0F08; // Offset: 0x34a0 // Size: 0xd0
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_7AA3FDDC4DB88E4C3BF7D381DD41B451; // Offset: 0x3570 // Size: 0xd0
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_BF58387E48A88C32CE645889704BEDAD; // Offset: 0x3640 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_4783BF5640FA982A7AA637AA42C69C70; // Offset: 0x36b0 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_04BD4ED24183152C50D642A1D4388436; // Offset: 0x3720 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_7DC95E0E4A9B2D7D1EBCB89DE4EF31C1; // Offset: 0x3790 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_29E59FC34629BD25792B509EFC764F4A; // Offset: 0x3800 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_48692B984CAAD645C93D54810082B97C; // Offset: 0x3870 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_DAFCF9AD457485E2574BE0BEC62DD94E; // Offset: 0x38e0 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_6C98737A4088A65309A42492B704105D; // Offset: 0x3950 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_D91B8B374C9F3B0AD4F3A3B6D5BD2362; // Offset: 0x39c0 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_1390D01F41C22BB4411FF9A65A7635C2; // Offset: 0x3a30 // Size: 0x70
	struct FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_30941A2F402EFF78369C75A196BA5486; // Offset: 0x3aa0 // Size: 0xe8
	struct FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_8C3B06B446591B5653A365BDE61AB753; // Offset: 0x3b88 // Size: 0xe8
	struct FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_8C14C676414683DF8D852A8698630DF8; // Offset: 0x3c70 // Size: 0xe8
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_5638270D44D89786C59D70AC2704C84B; // Offset: 0x3d58 // Size: 0x70
	struct FAnimNode_Root AnimGraphNode_StateResult_710EE3A34294511D18494BB9EE5DAA05; // Offset: 0x3dc8 // Size: 0x50
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine_21B5B7CA42AEE0A65B4BD5B8D92EB13C; // Offset: 0x3e18 // Size: 0xd8
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_D7D50B3640A5D47DAC35FD98719D344C; // Offset: 0x3ef0 // Size: 0x48
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_95D7A7E54AE984099D67D6B88CE47F33; // Offset: 0x3f38 // Size: 0x48
	struct FAnimNode_Root AnimGraphNode_StateResult_5F4DD97047315E04527D889B2EE19674; // Offset: 0x3f80 // Size: 0x50
	struct FAnimNode_SequenceEvaluator AnimGraphNode_SequenceEvaluator_E4910DA347A6CAE2BAEDCA8E3EC3E099; // Offset: 0x3fd0 // Size: 0x70
	struct FAnimNode_Slot AnimGraphNode_Slot_5B4CA56049D0126526D84C8EBB0D0BCF; // Offset: 0x4040 // Size: 0x70
	struct FAnimNode_Root AnimGraphNode_StateResult_463FA7834E6D9D089FD601BF2B3FF7D9; // Offset: 0x40b0 // Size: 0x50
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine_3EBEABE248532586A00036A71F2AA1CB; // Offset: 0x4100 // Size: 0xd8
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_279239D64DB636652BBE09A92658848B; // Offset: 0x41d8 // Size: 0xd0
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_FBBDCD0F49F1D2BD9D457BBBF2FC29DA; // Offset: 0x42a8 // Size: 0xd0
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_6EF521ED4643F80A4B5E0C988B51E7C8; // Offset: 0x4378 // Size: 0x50
	char pad_0x43C8[0x8]; // Offset: 0x43c8 // Size: 0x08
	struct FAnimNode_TwoBoneIK AnimGraphNode_TwoBoneIK_720282BE43459404AFA330A354A0E023; // Offset: 0x43d0 // Size: 0x1c0
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_1F03D991489F4E88BB867CB145BDF6E9; // Offset: 0x4590 // Size: 0x50
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_A2FD588D42043858DCCF3B9069E220B4; // Offset: 0x45e0 // Size: 0x70
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_599E51EE4C0B0DD41DB11B8E82A9A27E; // Offset: 0x4650 // Size: 0xd0
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_15F183F84D6D9FF318939D9D62044D1B; // Offset: 0x4720 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_096829D44DB49579A8E89E836B5FB542; // Offset: 0x4790 // Size: 0x70
	struct FAnimNode_ApplyAdditive AnimGraphNode_ApplyAdditive_BE33BC5A47C226041CC75C875B3E3F48; // Offset: 0x4800 // Size: 0x80
	struct FAnimNode_Root AnimGraphNode_StateResult_FE4CF1244323B9682B264FAA1B8A245A; // Offset: 0x4880 // Size: 0x50
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine_85A946D3427055AA08C232BB98C9A520; // Offset: 0x48d0 // Size: 0xd8
	bool Man; // Offset: 0x49a8 // Size: 0x01
	bool IsFront; // Offset: 0x49a9 // Size: 0x01
	bool IsChange; // Offset: 0x49aa // Size: 0x01
	bool bUseHairAnimDynamics; // Offset: 0x49ab // Size: 0x01
	struct FAnimParamList CharacterAnimParam; // Offset: 0x49ac // Size: 0x138
	bool IsWeaponGrip; // Offset: 0x4ae4 // Size: 0x01
	bool Positon; // Offset: 0x4ae5 // Size: 0x01
	char pad_0x4AE6[0x2]; // Offset: 0x4ae6 // Size: 0x02
	struct ASTExtraLobbyCharacter* LobbyCharacter; // Offset: 0x4ae8 // Size: 0x08
	struct UAnimSequenceBase* WeaponAnimSeqBase; // Offset: 0x4af0 // Size: 0x08
	struct UAnimSequenceBase* WeaponAnimSeqBaseAdd; // Offset: 0x4af8 // Size: 0x08
	enum class ELobbyCharacterAnimType LobbyGenderType; // Offset: 0x4b00 // Size: 0x01
	enum class ECharacterShowSceneType charSceneType; // Offset: 0x4b01 // Size: 0x01
	char LobbyCharPosIdx; // Offset: 0x4b02 // Size: 0x01
	char pad_0x4B03[0x1]; // Offset: 0x4b03 // Size: 0x01
	struct FVector C_HurtDir; // Offset: 0x4b04 // Size: 0x0c
	int PoseStateIndex; // Offset: 0x4b10 // Size: 0x04
	char pad_0x4B14[0x4]; // Offset: 0x4b14 // Size: 0x04
	struct UPoseWithFriendComponent* PoseWithFriendComp; // Offset: 0x4b18 // Size: 0x08
	struct UAnimSequenceBase* PoseWithFriendAnimSeq; // Offset: 0x4b20 // Size: 0x08
	bool bPoseWithFriend; // Offset: 0x4b28 // Size: 0x01
	char pad_0x4B29[0x3]; // Offset: 0x4b29 // Size: 0x03
	float LastRotationYaw; // Offset: 0x4b2c // Size: 0x04
	float DeltaTimeX; // Offset: 0x4b30 // Size: 0x04
	struct FVector ExternalForce; // Offset: 0x4b34 // Size: 0x0c
	struct ABP_PlayerLobbyPawn_C* BP_LobbyPawn; // Offset: 0x4b40 // Size: 0x08
	bool IsBPLobbyPawnValid; // Offset: 0x4b48 // Size: 0x01
	char pad_0x4B49[0x7]; // Offset: 0x4b49 // Size: 0x07
	struct UAnimSequenceBase* WeaponPlayAnimSeqBase; // Offset: 0x4b50 // Size: 0x08
	bool bWeaponPlaying; // Offset: 0x4b58 // Size: 0x01
	char pad_0x4B59[0x3]; // Offset: 0x4b59 // Size: 0x03
	float WeaponIdleTimer; // Offset: 0x4b5c // Size: 0x04
	int ItemHasIdleAnim; // Offset: 0x4b60 // Size: 0x04
	char pad_0x4B64[0x4]; // Offset: 0x4b64 // Size: 0x04
	struct UAnimSequence* SpecialIdle; // Offset: 0x4b68 // Size: 0x08
	bool UseSpecialIdle; // Offset: 0x4b70 // Size: 0x01
	bool ForceUseIdle; // Offset: 0x4b71 // Size: 0x01
	char pad_0x4B72[0x6]; // Offset: 0x4b72 // Size: 0x06
	struct UAnimMontage* GoSkateAnim; // Offset: 0x4b78 // Size: 0x08
	bool isAircast; // Offset: 0x4b80 // Size: 0x01
	char pad_0x4B81[0x7]; // Offset: 0x4b81 // Size: 0x07
	struct UAnimSequenceBase* IdleSkateAnim; // Offset: 0x4b88 // Size: 0x08
	float weaponAnimCountDownTime; // Offset: 0x4b90 // Size: 0x04
	float lobbyIdleP1StartPosition; // Offset: 0x4b94 // Size: 0x04
	bool bTPosActive; // Offset: 0x4b98 // Size: 0x01
	char pad_0x4B99[0x3]; // Offset: 0x4b99 // Size: 0x03
	float skateAnimTime; // Offset: 0x4b9c // Size: 0x04
	bool GlideNeedRotate; // Offset: 0x4ba0 // Size: 0x01
	char pad_0x4BA1[0x7]; // Offset: 0x4ba1 // Size: 0x07
	struct UAnimSequenceBase* RerturnPose; // Offset: 0x4ba8 // Size: 0x08
	struct UAnimSequenceBase* ReturnPoseAdditive; // Offset: 0x4bb0 // Size: 0x08
	struct UAnimSequenceBase* ReturnRandPoseAdditive; // Offset: 0x4bb8 // Size: 0x08
	struct TArray<struct UAnimSequenceBase*> ReturnRandPoseList; // Offset: 0x4bc0 // Size: 0x10
	bool bPlayReturnRandPose; // Offset: 0x4bd0 // Size: 0x01
	char pad_0x4BD1[0x3]; // Offset: 0x4bd1 // Size: 0x03
	float RandPoseDelay; // Offset: 0x4bd4 // Size: 0x04
	float RandPoseTimer; // Offset: 0x4bd8 // Size: 0x04
	bool bIsReturnActivity; // Offset: 0x4bdc // Size: 0x01
	char pad_0x4BDD[0x3]; // Offset: 0x4bdd // Size: 0x03
	struct FVector ReturnPoseIKOffset; // Offset: 0x4be0 // Size: 0x0c
	bool bHasReturnPosePaused; // Offset: 0x4bec // Size: 0x01

	// Functions

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.TogglePauseReturnPose
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void TogglePauseReturnPose(bool bShouldPause); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.SetReturnIKOffset
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetReturnIKOffset(struct FVector Offset); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0xc)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.AddReturnRandPose
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void AddReturnRandPose(struct UAnimSequenceBase* RandPose); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.SetReturnIdleAnim
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetReturnIdleAnim(struct UAnimSequenceBase* IdlePose); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.SetReturnBaseAnim
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetReturnBaseAnim(struct UAnimSequenceBase* BasePose); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.StopReturnActivityPose
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void StopReturnActivityPose(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.StartReturnActivityPose
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void StartReturnActivityPose(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.CountDownReturnActivityRandPose
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void CountDownReturnActivityRandPose(float DeltaSeconds); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.SetTposActive
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetTposActive(bool bTPosActive); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.HandleSkatePose
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void HandleSkatePose(struct UBackpackAvatarHandle* AvatarHandle, bool IsEquiped, int ItemID, int SlotID); // Offset: 0x103df3e6c // Return & Params: Num(4) Size(0x14)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.UseSkatePose
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void UseSkatePose(int SlotID, struct FItemDefineID newID, struct FItemDefineID OldID); // Offset: 0x103df3e6c // Return & Params: Num(3) Size(0x38)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.CancleSkatePose
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void CancleSkatePose(int SlotID, struct FItemDefineID OldItemID); // Offset: 0x103df3e6c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.SetSkatePose
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetSkatePose(struct UAnimMontage* start_SkateAnim, struct UAnimSequenceBase* idle_SKateAnim); // Offset: 0x103df3e6c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.SetIsUsingSpecialIdle
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetIsUsingSpecialIdle(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.ProcessAvatarEquipmentChange
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void ProcessAvatarEquipmentChange(struct UBackpackAvatarHandle* AvatarHandle, bool IsEquiped, int ItemID, int SlotID); // Offset: 0x103df3e6c // Return & Params: Num(4) Size(0x14)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.WeaponPlayAnimEnd
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void WeaponPlayAnimEnd(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.StartWeaponPlayAnim
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void StartWeaponPlayAnim(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.CountDownForWeaponPlay
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void CountDownForWeaponPlay(float Delta); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.ProcessSceneTypeChange
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void ProcessSceneTypeChange(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.ProcessPosChange
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void ProcessPosChange(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.ProcessGenderChange
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void ProcessGenderChange(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.GetWeaponUseGenderType
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetWeaponUseGenderType(char PosIdx, enum class ELobbyCharacterAnimType gender, enum class ELobbyCharacterAnimType& gender_type); // Offset: 0x103df3e6c // Return & Params: Num(3) Size(0x3)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.SetWeaponAnimation
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetWeaponAnimation(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.UpdatePoseStateIndex
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void UpdatePoseStateIndex(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.SetWeaponGrip
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetWeaponGrip(bool WeaponGrip); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.OnCancelPoseWithFriend
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void OnCancelPoseWithFriend(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.OnPoseWithFriend
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void OnPoseWithFriend(struct UAnimSequence* AnimSeq); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.PlayWeaponAnim
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void PlayWeaponAnim(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_8EBE0B9340BA1548E3FEF392CAAB88A2
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_8EBE0B9340BA1548E3FEF392CAAB88A2(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_A347A3ED47331AAA671B7A9F8D626390
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_A347A3ED47331AAA671B7A9F8D626390(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_59BB895B4FABFB558D844FBD547DA6DF
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_59BB895B4FABFB558D844FBD547DA6DF(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_19A367B64AA6A6E557F95895FD546B0C
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_19A367B64AA6A6E557F95895FD546B0C(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByBool_99BEBB72474B296808E67BA89EF360C4
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByBool_99BEBB72474B296808E67BA89EF360C4(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_02C27FD84D09FAB2A76F7B819BE4E02E
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_02C27FD84D09FAB2A76F7B819BE4E02E(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_6B1B765D4DFCF3ED170D2CA6BA912335
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_6B1B765D4DFCF3ED170D2CA6BA912335(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_DC74B3834291C85A1C11BB907AA1CC44
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_DC74B3834291C85A1C11BB907AA1CC44(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_1CD7157D4AA33BBC8A249794003DA92D
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_1CD7157D4AA33BBC8A249794003DA92D(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_26E2FBDA45BCCD35C178208267A47E3C
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_26E2FBDA45BCCD35C178208267A47E3C(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_19EA61F347E92E523233C0973F710EDD
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_19EA61F347E92E523233C0973F710EDD(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_D7A166DD41A3E24756434FA7A0BABDE8
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_D7A166DD41A3E24756434FA7A0BABDE8(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByBool_74C05CBE44C7AF6CB793908D2C8B0F08
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByBool_74C05CBE44C7AF6CB793908D2C8B0F08(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByBool_7AA3FDDC4DB88E4C3BF7D381DD41B451
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByBool_7AA3FDDC4DB88E4C3BF7D381DD41B451(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_30941A2F402EFF78369C75A196BA5486
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_30941A2F402EFF78369C75A196BA5486(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_8C3B06B446591B5653A365BDE61AB753
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_8C3B06B446591B5653A365BDE61AB753(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_8C14C676414683DF8D852A8698630DF8
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_8C14C676414683DF8D852A8698630DF8(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_5638270D44D89786C59D70AC2704C84B
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_5638270D44D89786C59D70AC2704C84B(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_TransitionResult_D7D50B3640A5D47DAC35FD98719D344C
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_TransitionResult_D7D50B3640A5D47DAC35FD98719D344C(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_TransitionResult_95D7A7E54AE984099D67D6B88CE47F33
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_TransitionResult_95D7A7E54AE984099D67D6B88CE47F33(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequenceEvaluator_E4910DA347A6CAE2BAEDCA8E3EC3E099
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequenceEvaluator_E4910DA347A6CAE2BAEDCA8E3EC3E099(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_626A8657450B700E04EA978275350404
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_626A8657450B700E04EA978275350404(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_2FC4424843DAD0EDAC532EA346B5B3D5
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_2FC4424843DAD0EDAC532EA346B5B3D5(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByBool_279239D64DB636652BBE09A92658848B
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByBool_279239D64DB636652BBE09A92658848B(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByBool_FBBDCD0F49F1D2BD9D457BBBF2FC29DA
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByBool_FBBDCD0F49F1D2BD9D457BBBF2FC29DA(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_TwoBoneIK_720282BE43459404AFA330A354A0E023
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_TwoBoneIK_720282BE43459404AFA330A354A0E023(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_A2FD588D42043858DCCF3B9069E220B4
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_A2FD588D42043858DCCF3B9069E220B4(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByBool_599E51EE4C0B0DD41DB11B8E82A9A27E
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByBool_599E51EE4C0B0DD41DB11B8E82A9A27E(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_15F183F84D6D9FF318939D9D62044D1B
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_15F183F84D6D9FF318939D9D62044D1B(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_096829D44DB49579A8E89E836B5FB542
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_096829D44DB49579A8E89E836B5FB542(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_A513AE2D43A39ABB4CF95CBA42F46E4F
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_A513AE2D43A39ABB4CF95CBA42F46E4F(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_8B9AEDA847AFF35B2E42148070E80DB9
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_8B9AEDA847AFF35B2E42148070E80DB9(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_3608C9064898C777D090B8A2B9FD3A3F
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_3608C9064898C777D090B8A2B9FD3A3F(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_EDCBB4A3451F17C986B87E830382CD73
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_EDCBB4A3451F17C986B87E830382CD73(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByBool_DDCBB29A4A3C78BA06EDE9BE0F603F0F
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByBool_DDCBB29A4A3C78BA06EDE9BE0F603F0F(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByBool_0E60BE884F4F2D4D549762803828DD05
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByBool_0E60BE884F4F2D4D549762803828DD05(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_9A8F47724807B36A5929E3A6B1860F7F
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_9A8F47724807B36A5929E3A6B1860F7F(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_07AFE46040E954CBDBB3088F734467E2
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_07AFE46040E954CBDBB3088F734467E2(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_EE27731C4EE1344DDB785FBD062BE8C6
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_EE27731C4EE1344DDB785FBD062BE8C6(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_2A1BA28C41B59FDC94DD439E6E4AA51F
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_2A1BA28C41B59FDC94DD439E6E4AA51F(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_D49905424D9E64B1DC1DB58770E63F03
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_D49905424D9E64B1DC1DB58770E63F03(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_5E0C64FC43AAF3BD99CE0D84DCFD52A2
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_5E0C64FC43AAF3BD99CE0D84DCFD52A2(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_986285904B872DCB94CF8CBAB9A90888
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_986285904B872DCB94CF8CBAB9A90888(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByInt_4A815C384984B5A2B5386299F2DEED85
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByInt_4A815C384984B5A2B5386299F2DEED85(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_ModifyBone_C2D2D97E414325A1E172869DEE2DE416
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_ModifyBone_C2D2D97E414325A1E172869DEE2DE416(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_ModifyBone_D25BB41445101287DBCE3EB4CAB67171
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_ModifyBone_D25BB41445101287DBCE3EB4CAB67171(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_4BF41F204D641F3C8FA2F1AC89979187
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_4BF41F204D641F3C8FA2F1AC89979187(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_F7A0422648E25AB4352F9A96EDFC9CC3
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_SequencePlayer_F7A0422648E25AB4352F9A96EDFC9CC3(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_696616664DC8F8B31B7072B548CDF566
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_696616664DC8F8B31B7072B548CDF566(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_AnimDynamics_2BE462B7452BD6CC7AA9BEB99A15F46B
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_AnimDynamics_2BE462B7452BD6CC7AA9BEB99A15F46B(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.BlueprintUpdateAnimation
	// Flags: [Event|Public|BlueprintEvent]
	void BlueprintUpdateAnimation(float DeltaTimeX); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.BlueprintInitializeAnimation
	// Flags: [Event|Public|BlueprintEvent]
	void BlueprintInitializeAnimation(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.OnLobbyGenderAnimChange
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnLobbyGenderAnimChange(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.OnLobbyCharSceneTypeChange
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnLobbyCharSceneTypeChange(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.OnLobbyCharWeaponChange
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnLobbyCharWeaponChange(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.OnLobbyCharPosChange
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnLobbyCharPosChange(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_C095363F4AC15D76C347A2BFF205FCE4
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_C095363F4AC15D76C347A2BFF205FCE4(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.SetForceuseIdle
	// Flags: [BlueprintCallable|BlueprintEvent]
	void SetForceuseIdle(bool force); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_C898A5D7416E49C0B875F381E8BFDFD3
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Lobby_AnimBP_AnimGraphNode_BlendListByEnum_C898A5D7416E49C0B875F381E8BFDFD3(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.BindSkate
	// Flags: [BlueprintCallable|BlueprintEvent]
	void BindSkate(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.UnEquip
	// Flags: [BlueprintCallable|BlueprintEvent]
	void UnEquip(int SlotID, struct FItemDefineID OldItemID); // Offset: 0x103df3e6c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Lobby_AnimBP.Lobby_AnimBP_C.ExecuteUbergraph_Lobby_AnimBP
	// Flags: [HasDefaults]
	void ExecuteUbergraph_Lobby_AnimBP(int EntryPoint); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x4)
};

