#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_ZoneConfig_type.BP_STRUCT_ZoneConfig_type
// Size: 0x48 // Inherited bytes: 0x00
struct FBP_STRUCT_ZoneConfig_type {
	// Fields
	struct FString NameInChinese_0_179F480A43D68450578ED9A60DFEB1E4; // Offset: 0x00 // Size: 0x10
	struct FString NameInEnglish_1_B81817404D37E6DECDF39182C3C84D5D; // Offset: 0x10 // Size: 0x10
	int ZoneID_2_25BADFA44D29882BDEA26BA1D8923C64; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
	struct FString GVoiceServer_3_D482EC9D4F05594214C23F9157E39271; // Offset: 0x28 // Size: 0x10
	struct FString Abbreviation_6_4C2637806FA82E564BCE6B490463DB5E; // Offset: 0x38 // Size: 0x10
};

