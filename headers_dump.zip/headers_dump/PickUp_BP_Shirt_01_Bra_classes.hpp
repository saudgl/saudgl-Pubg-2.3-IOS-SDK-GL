#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass PickUp_BP_Shirt_01_Bra.PickUp_BP_Shirt_01_Bra_C
// Size: 0x838 // Inherited bytes: 0x830
struct APickUp_BP_Shirt_01_Bra_C : APickUpWrapperActor {
	// Fields
	struct UStaticMeshComponent* Bag_03_icon; // Offset: 0x830 // Size: 0x08

	// Functions

	// Object Name: Function PickUp_BP_Shirt_01_Bra.PickUp_BP_Shirt_01_Bra_C.UserConstructionScript
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void UserConstructionScript(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)
};

