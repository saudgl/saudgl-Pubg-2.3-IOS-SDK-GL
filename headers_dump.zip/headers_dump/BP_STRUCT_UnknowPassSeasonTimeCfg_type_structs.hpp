#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_UnknowPassSeasonTimeCfg_type.BP_STRUCT_UnknowPassSeasonTimeCfg_type
// Size: 0x100 // Inherited bytes: 0x00
struct FBP_STRUCT_UnknowPassSeasonTimeCfg_type {
	// Fields
	int MissionWeekCount_2_3CB96A402D71B7EF4EA765BA0A8008B4; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString SeasonName_4_198FC84010193A5D4BC03E0C0720EB85; // Offset: 0x08 // Size: 0x10
	int SeasonId_5_3B8D934038AA335B7B858D350DB71F54; // Offset: 0x18 // Size: 0x04
	int BuyPassItemId_6_30AE8E8065A87E267330F6C90EA73C94; // Offset: 0x1c // Size: 0x04
	struct FString ScoreRankEndTime_7_7EE3D94069FA9A2159155A850DBC7C95; // Offset: 0x20 // Size: 0x10
	struct FString SeasonStartTime_8_0E798F405F8F8D6164677B5B03E85045; // Offset: 0x30 // Size: 0x10
	struct FString DefaultWear_9_33A742C01852C10317B520BB0FF004F2; // Offset: 0x40 // Size: 0x10
	struct FString NormalOneTxt_11_4988E08017FE1CEC2DF6B76E0EE467C4; // Offset: 0x50 // Size: 0x10
	struct FString NormalTwoTxt_12_706186803DA56B081E42DD240C3E87C4; // Offset: 0x60 // Size: 0x10
	struct FString SuperOneTxt_13_7CCD8A0066CAA8FE1F94CE88049D0EC4; // Offset: 0x70 // Size: 0x10
	struct FString SuperTwoTxt_14_23A630006BDDA34C46A7D52D0265EEC4; // Offset: 0x80 // Size: 0x10
	int EliteItemId_15_11671980410B7BD4621304C80DC3F2A4; // Offset: 0x90 // Size: 0x04
	int NormalItemId_16_58673700213DA23423F9B9A10E8A8DC4; // Offset: 0x94 // Size: 0x04
	struct FString VersionStart_17_071E2AC00AF214F32E37281409C00E24; // Offset: 0x98 // Size: 0x10
	int CameraAction_18_45DCF78076C808C6211464D709D8AD8E; // Offset: 0xa8 // Size: 0x04
	char pad_0xAC[0x4]; // Offset: 0xac // Size: 0x04
	struct FString ResourseVerion_20_2E8400802432D43A7BFA747700751C7E; // Offset: 0xb0 // Size: 0x10
	struct FString SeasonEndTime_21_55A2518052ACDA7E7AF9B3990292DFC5; // Offset: 0xc0 // Size: 0x10
	struct FString RPScoreCoupon_24_1A96B24028A4D6594AA2C1EE0DBCB60E; // Offset: 0xd0 // Size: 0x10
	struct FString DefaultExchangeWear_25_45D88B800748A1B609DDD66205CB3A12; // Offset: 0xe0 // Size: 0x10
	struct FString DefaultSubwayWear_26_6F6B61804EEFBEA04A3200E0027EAF62; // Offset: 0xf0 // Size: 0x10
};

