#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_AvatarColor_Free.BP_AvatarColor_Free_C
// Size: 0x58 // Inherited bytes: 0x58
struct UBP_AvatarColor_Free_C : UBP_AvatarColor_Base_C {
};

