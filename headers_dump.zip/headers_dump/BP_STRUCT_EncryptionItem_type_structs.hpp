#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_EncryptionItem_type.BP_STRUCT_EncryptionItem_type
// Size: 0x24 // Inherited bytes: 0x00
struct FBP_STRUCT_EncryptionItem_type {
	// Fields
	struct FString ItemEncryptionDesc_0_399BA2402808603F271CFB4E03C1CA13; // Offset: 0x00 // Size: 0x10
	struct FString ItemEncryptionName_1_737BA2C03FBE98C5185E865403C222B5; // Offset: 0x10 // Size: 0x10
	int ItemID_2_3E285B007414EFB844C62E11094B6174; // Offset: 0x20 // Size: 0x04
};

