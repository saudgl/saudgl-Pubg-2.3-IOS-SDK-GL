#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct ClothingSystemRuntime.ClothConfig
// Size: 0xbc // Inherited bytes: 0x00
struct FClothConfig {
	// Fields
	enum class EClothingWindMethod WindMethod; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	struct FClothConstraintSetup VerticalConstraintConfig; // Offset: 0x04 // Size: 0x10
	struct FClothConstraintSetup HorizontalConstraintConfig; // Offset: 0x14 // Size: 0x10
	struct FClothConstraintSetup BendConstraintConfig; // Offset: 0x24 // Size: 0x10
	struct FClothConstraintSetup ShearConstraintConfig; // Offset: 0x34 // Size: 0x10
	float SelfCollisionRadius; // Offset: 0x44 // Size: 0x04
	float SelfCollisionStiffness; // Offset: 0x48 // Size: 0x04
	float SelfCollisionCullScale; // Offset: 0x4c // Size: 0x04
	struct FVector Damping; // Offset: 0x50 // Size: 0x0c
	float Friction; // Offset: 0x5c // Size: 0x04
	float WindDragCoefficient; // Offset: 0x60 // Size: 0x04
	float WindLiftCoefficient; // Offset: 0x64 // Size: 0x04
	struct FVector LinearDrag; // Offset: 0x68 // Size: 0x0c
	struct FVector AngularDrag; // Offset: 0x74 // Size: 0x0c
	struct FVector LinearInertiaScale; // Offset: 0x80 // Size: 0x0c
	struct FVector AngularInertiaScale; // Offset: 0x8c // Size: 0x0c
	struct FVector CentrifugalInertiaScale; // Offset: 0x98 // Size: 0x0c
	float SolverFrequency; // Offset: 0xa4 // Size: 0x04
	float StiffnessFrequency; // Offset: 0xa8 // Size: 0x04
	float GravityScale; // Offset: 0xac // Size: 0x04
	float TetherStiffness; // Offset: 0xb0 // Size: 0x04
	float TetherLimit; // Offset: 0xb4 // Size: 0x04
	float CollisionThickness; // Offset: 0xb8 // Size: 0x04
};

// Object Name: ScriptStruct ClothingSystemRuntime.ClothConstraintSetup
// Size: 0x10 // Inherited bytes: 0x00
struct FClothConstraintSetup {
	// Fields
	float Stiffness; // Offset: 0x00 // Size: 0x04
	float StiffnessMultiplier; // Offset: 0x04 // Size: 0x04
	float StretchLimit; // Offset: 0x08 // Size: 0x04
	float CompressionLimit; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct ClothingSystemRuntime.ClothLODData
// Size: 0xe8 // Inherited bytes: 0x00
struct FClothLODData {
	// Fields
	struct FClothPhysicalMeshData PhysicalMeshData; // Offset: 0x00 // Size: 0x98
	struct FClothCollisionData CollisionData; // Offset: 0x98 // Size: 0x30
	char pad_0xC8[0x20]; // Offset: 0xc8 // Size: 0x20
};

// Object Name: ScriptStruct ClothingSystemRuntime.ClothPhysicalMeshData
// Size: 0x98 // Inherited bytes: 0x00
struct FClothPhysicalMeshData {
	// Fields
	struct TArray<struct FVector> Vertices; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FVector> Normals; // Offset: 0x10 // Size: 0x10
	struct TArray<uint32_t> Indices; // Offset: 0x20 // Size: 0x10
	struct TArray<float> MaxDistances; // Offset: 0x30 // Size: 0x10
	struct TArray<float> BackstopDistances; // Offset: 0x40 // Size: 0x10
	struct TArray<float> BackstopRadiuses; // Offset: 0x50 // Size: 0x10
	struct TArray<float> InverseMasses; // Offset: 0x60 // Size: 0x10
	struct TArray<struct FClothVertBoneData> BoneData; // Offset: 0x70 // Size: 0x10
	int MaxBoneWeights; // Offset: 0x80 // Size: 0x04
	int NumFixedVerts; // Offset: 0x84 // Size: 0x04
	struct TArray<uint32_t> SelfCollisionIndices; // Offset: 0x88 // Size: 0x10
};

// Object Name: ScriptStruct ClothingSystemRuntime.ClothVertBoneData
// Size: 0x34 // Inherited bytes: 0x00
struct FClothVertBoneData {
	// Fields
	int NumInfluences; // Offset: 0x00 // Size: 0x04
	uint16_t BoneIndices[0x8]; // Offset: 0x04 // Size: 0x10
	float BoneWeights[0x8]; // Offset: 0x14 // Size: 0x20
};

// Object Name: ScriptStruct ClothingSystemRuntime.ClothParameterMask_PhysMesh
// Size: 0x30 // Inherited bytes: 0x00
struct FClothParameterMask_PhysMesh {
	// Fields
	struct FName MaskName; // Offset: 0x00 // Size: 0x08
	enum class MaskTarget_PhysMesh CurrentTarget; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
	float MaxValue; // Offset: 0x0c // Size: 0x04
	float MinValue; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct TArray<float> Values; // Offset: 0x18 // Size: 0x10
	bool bEnabled; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x7]; // Offset: 0x29 // Size: 0x07
};

