#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BattleItemHandle_WeapAttachment_Pendant.BattleItemHandle_WeapAttachment_Pendant_C
// Size: 0x448 // Inherited bytes: 0x448
struct UBattleItemHandle_WeapAttachment_Pendant_C : UBattleItemHandle_WeapAttachment_C {
};

