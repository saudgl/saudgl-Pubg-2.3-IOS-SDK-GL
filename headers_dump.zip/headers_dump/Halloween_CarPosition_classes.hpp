#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass Halloween_CarPosition.Halloween_CarPosition_C
// Size: 0x3e8 // Inherited bytes: 0x3d8
struct AHalloween_CarPosition_C : AActor {
	// Fields
	struct UArrowComponent* Arrow; // Offset: 0x3d8 // Size: 0x08
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x3e0 // Size: 0x08

	// Functions

	// Object Name: Function Halloween_CarPosition.Halloween_CarPosition_C.UserConstructionScript
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void UserConstructionScript(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)
};

