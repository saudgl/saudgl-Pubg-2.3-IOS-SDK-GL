#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class Skill.UTSkillBaseWidget
// Size: 0x60 // Inherited bytes: 0x28
struct UUTSkillBaseWidget : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
	bool bWidgetEnabled; // Offset: 0x30 // Size: 0x01
	char pad_0x31[0x7]; // Offset: 0x31 // Size: 0x07
	struct FString EffectName; // Offset: 0x38 // Size: 0x10
	struct AActor* BuffTargetActor; // Offset: 0x48 // Size: 0x08
	struct TWeakObjectPtr<struct AUTSkill> OwnerSkill; // Offset: 0x50 // Size: 0x08
	struct UActorComponent* CurOwnerActorComponent; // Offset: 0x58 // Size: 0x08

	// Functions

	// Object Name: Function Skill.UTSkillBaseWidget.SetValueAsWeakObject
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetValueAsWeakObject(struct FUAEBlackboardKeySelector& Key, struct UObject* ObjectValue); // Offset: 0x10539415c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillBaseWidget.SetValueAsVector
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void SetValueAsVector(struct FUAEBlackboardKeySelector& Key, struct FVector VectorValue); // Offset: 0x105393fe8 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Skill.UTSkillBaseWidget.SetValueAsString
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetValueAsString(struct FUAEBlackboardKeySelector& Key, struct FString StringValue); // Offset: 0x105393e28 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Skill.UTSkillBaseWidget.SetValueAsRotator
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void SetValueAsRotator(struct FUAEBlackboardKeySelector& Key, struct FRotator RotatorValue); // Offset: 0x105393cb4 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Skill.UTSkillBaseWidget.SetValueAsObject
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetValueAsObject(struct FUAEBlackboardKeySelector& Key, struct UObject* ObjectValue); // Offset: 0x105393b60 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillBaseWidget.SetValueAsName
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetValueAsName(struct FUAEBlackboardKeySelector& Key, struct FName NameValue); // Offset: 0x1053939e4 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillBaseWidget.SetValueAsInt
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetValueAsInt(struct FUAEBlackboardKeySelector& Key, int IntValue); // Offset: 0x105393890 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Skill.UTSkillBaseWidget.SetValueAsFloat
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetValueAsFloat(struct FUAEBlackboardKeySelector& Key, float FloatValue); // Offset: 0x10539373c // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Skill.UTSkillBaseWidget.SetValueAsEnum
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetValueAsEnum(struct FUAEBlackboardKeySelector& Key, char EnumValue); // Offset: 0x1053935e8 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Skill.UTSkillBaseWidget.SetValueAsClass
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetValueAsClass(struct FUAEBlackboardKeySelector& Key, struct UObject* ClassValue); // Offset: 0x105393494 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillBaseWidget.SetValueAsBool
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetValueAsBool(struct FUAEBlackboardKeySelector& Key, bool BoolValue); // Offset: 0x105393320 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Skill.UTSkillBaseWidget.IsExistWeakObject
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	bool IsExistWeakObject(struct FUAEBlackboardKeySelector& Key); // Offset: 0x105393220 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Skill.UTSkillBaseWidget.IsExistVector
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	bool IsExistVector(struct FUAEBlackboardKeySelector& Key); // Offset: 0x105393120 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Skill.UTSkillBaseWidget.IsExistString
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	bool IsExistString(struct FUAEBlackboardKeySelector& Key); // Offset: 0x105393020 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Skill.UTSkillBaseWidget.IsExistRotator
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	bool IsExistRotator(struct FUAEBlackboardKeySelector& Key); // Offset: 0x105392f20 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Skill.UTSkillBaseWidget.IsExistObject
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	bool IsExistObject(struct FUAEBlackboardKeySelector& Key); // Offset: 0x105392e20 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Skill.UTSkillBaseWidget.IsExistName
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	bool IsExistName(struct FUAEBlackboardKeySelector& Key); // Offset: 0x105392d20 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Skill.UTSkillBaseWidget.IsExistInt
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	bool IsExistInt(struct FUAEBlackboardKeySelector& Key); // Offset: 0x105392c20 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Skill.UTSkillBaseWidget.IsExistFloat
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	bool IsExistFloat(struct FUAEBlackboardKeySelector& Key); // Offset: 0x105392b20 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Skill.UTSkillBaseWidget.IsExistEnum
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	bool IsExistEnum(struct FUAEBlackboardKeySelector& Key); // Offset: 0x105392a20 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Skill.UTSkillBaseWidget.IsExistClass
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	bool IsExistClass(struct FUAEBlackboardKeySelector& Key); // Offset: 0x105392920 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Skill.UTSkillBaseWidget.IsExistBool
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	bool IsExistBool(struct FUAEBlackboardKeySelector& Key); // Offset: 0x105392820 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Skill.UTSkillBaseWidget.GetValueAsWeakObject
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	struct UObject* GetValueAsWeakObject(struct FUAEBlackboardKeySelector& Key); // Offset: 0x105392724 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillBaseWidget.GetValueAsWeakActor
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	struct AActor* GetValueAsWeakActor(struct FUAEBlackboardKeySelector& Key); // Offset: 0x1053925e0 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillBaseWidget.GetValueAsVector
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector GetValueAsVector(struct FUAEBlackboardKeySelector& Key); // Offset: 0x1053924cc // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Skill.UTSkillBaseWidget.GetValueAsString
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	struct FString GetValueAsString(struct FUAEBlackboardKeySelector& Key); // Offset: 0x1053923a0 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Skill.UTSkillBaseWidget.GetValueAsRotator
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FRotator GetValueAsRotator(struct FUAEBlackboardKeySelector& Key); // Offset: 0x10539228c // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Skill.UTSkillBaseWidget.GetValueAsObject
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	struct UObject* GetValueAsObject(struct FUAEBlackboardKeySelector& Key); // Offset: 0x105392190 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillBaseWidget.GetValueAsName
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	struct FName GetValueAsName(struct FUAEBlackboardKeySelector& Key); // Offset: 0x10539208c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillBaseWidget.GetValueAsInt
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	int GetValueAsInt(struct FUAEBlackboardKeySelector& Key); // Offset: 0x105391f90 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Skill.UTSkillBaseWidget.GetValueAsFloat
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	float GetValueAsFloat(struct FUAEBlackboardKeySelector& Key); // Offset: 0x105391e94 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Skill.UTSkillBaseWidget.GetValueAsEnum
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	char GetValueAsEnum(struct FUAEBlackboardKeySelector& Key); // Offset: 0x105391d98 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Skill.UTSkillBaseWidget.GetValueAsClass
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	struct UObject* GetValueAsClass(struct FUAEBlackboardKeySelector& Key); // Offset: 0x105391c9c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillBaseWidget.GetValueAsBool
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	bool GetValueAsBool(struct FUAEBlackboardKeySelector& Key); // Offset: 0x105391b9c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Skill.UTSkillBaseWidget.GetValueAsActor
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	struct AActor* GetValueAsActor(struct FUAEBlackboardKeySelector& Key); // Offset: 0x105391a58 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillBaseWidget.GetUAEBlackboardBySkillComp
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UUAEBlackboard* GetUAEBlackboardBySkillComp(struct UUTSkillManagerComponent* InOwnerSkillManager); // Offset: 0x10539198c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillBaseWidget.GetUAEBlackboard
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UUAEBlackboard* GetUAEBlackboard(); // Offset: 0x105391928 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillBaseWidget.GetOwnerSkillManager
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UUTSkillManagerComponent* GetOwnerSkillManager(); // Offset: 0x1053918c4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillBaseWidget.GetOwnerPawn
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct AActor* GetOwnerPawn(); // Offset: 0x105391860 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillBaseWidget.GetActorBlackboardBySkillComp
	// Flags: [Final|Native|Private|Const]
	struct TMap<struct TWeakObjectPtr<struct AActor>, struct UUAEBlackboard*> GetActorBlackboardBySkillComp(struct UUTSkillManagerComponent* InOwnerSkillManager); // Offset: 0x10539175c // Return & Params: Num(2) Size(0x58)

	// Object Name: Function Skill.UTSkillBaseWidget.GetActorBlackboard
	// Flags: [Final|Native|Private|Const]
	struct TMap<struct TWeakObjectPtr<struct AActor>, struct UUAEBlackboard*> GetActorBlackboard(); // Offset: 0x1053916d0 // Return & Params: Num(1) Size(0x50)
};

// Object Name: Class Skill.UTSkillCondition
// Size: 0x60 // Inherited bytes: 0x60
struct UUTSkillCondition : UUTSkillBaseWidget {
	// Functions

	// Object Name: Function Skill.UTSkillCondition.IsTargetOK
	// Flags: [Native|Event|Public|BlueprintEvent]
	bool IsTargetOK(struct UActorComponent* SkillManagerComponent, struct AActor* Target); // Offset: 0x105390e90 // Return & Params: Num(3) Size(0x11)

	// Object Name: Function Skill.UTSkillCondition.IsOK_Internal
	// Flags: [Native|Event|Protected|BlueprintEvent]
	bool IsOK_Internal(); // Offset: 0x105390e28 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Skill.UTSkillCondition.IsOK
	// Flags: [Native|Event|Public|BlueprintEvent]
	bool IsOK(struct UActorComponent* SkillManagerComponent); // Offset: 0x105390d58 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Skill.UTSkillCondition.GetOwnerSkill
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	struct AUTSkill* GetOwnerSkill(); // Offset: 0x105390cfc // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class Skill.UTSkillEffect
// Size: 0x78 // Inherited bytes: 0x60
struct UUTSkillEffect : UUTSkillBaseWidget {
	// Fields
	float fADScale; // Offset: 0x60 // Size: 0x04
	float fAPScale; // Offset: 0x64 // Size: 0x04
	struct TArray<struct UObject*> CacheSoftObject; // Offset: 0x68 // Size: 0x10

	// Functions

	// Object Name: Function Skill.UTSkillEffect.UpdateAction
	// Flags: [Native|Public]
	void UpdateAction(struct UUTSkillManagerComponent* SkillManagerComponent, float DeltaSeconds); // Offset: 0x1053956ac // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Skill.UTSkillEffect.UndoAction
	// Flags: [Native|Public]
	void UndoAction(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x1053955e8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillEffect.PreCloseSkill
	// Flags: [Native|Public]
	void PreCloseSkill(struct UUTSkillManagerComponent* SkillManagerComponent, struct AUTSkill* CurOwnerSkill); // Offset: 0x1053954c4 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillEffect.PostInitSkill
	// Flags: [Native|Public]
	void PostInitSkill(struct UUTSkillManagerComponent* SkillManagerComponent, struct AUTSkill* CurOwnerSkill); // Offset: 0x1053953a0 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillEffect.PostActiveSkill
	// Flags: [Native|Public]
	void PostActiveSkill(struct UUTSkillManagerComponent* SkillManagerComponent, struct AUTSkill* CurOwnerSkill); // Offset: 0x10539527c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillEffect.OnAsyncLoadSoftPathDone
	// Flags: [Final|Native|Public]
	void OnAsyncLoadSoftPathDone(); // Offset: 0x105395228 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillEffect.GetOwnerSkill
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	struct AUTSkill* GetOwnerSkill(); // Offset: 0x1053951cc // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillEffect.DoHurtAppearance
	// Flags: [Native|Public]
	void DoHurtAppearance(struct UUTSkillManagerComponent* SkillManagerComponent, struct AActor* Victim); // Offset: 0x1053950a8 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillEffect.DoAction
	// Flags: [Native|Public]
	bool DoAction(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x105394fd8 // Return & Params: Num(2) Size(0x9)
};

// Object Name: Class Skill.UTSkillAction
// Size: 0xa0 // Inherited bytes: 0x78
struct UUTSkillAction : UUTSkillEffect {
	// Fields
	struct FUTSkillActionCreateData BaseData; // Offset: 0x78 // Size: 0x08
	struct UUTSkillAction* OwnerPeriodAction; // Offset: 0x80 // Size: 0x08
	char pad_0x88[0x1]; // Offset: 0x88 // Size: 0x01
	bool bClearTimerAfterReset; // Offset: 0x89 // Size: 0x01
	char pad_0x8A[0x6]; // Offset: 0x8a // Size: 0x06
	struct UObject* EventObj; // Offset: 0x90 // Size: 0x08
	char pad_0x98[0x8]; // Offset: 0x98 // Size: 0x08

	// Functions

	// Object Name: Function Skill.UTSkillAction.UpdateAction_Internal
	// Flags: [Native|Public]
	void UpdateAction_Internal(float DeltaSeconds); // Offset: 0x10538b6d0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillAction.UpdateAction
	// Flags: [Final|Native|Public]
	void UpdateAction(struct UUTSkillManagerComponent* SkillManagerComponent, float DeltaSeconds); // Offset: 0x10538b5b4 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Skill.UTSkillAction.UndoAction_Internal
	// Flags: [Native|Public]
	void UndoAction_Internal(); // Offset: 0x10538b558 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillAction.UndoAction
	// Flags: [Final|Native|Public]
	void UndoAction(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x10538b49c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillAction.TimerRealDoAction
	// Flags: [Final|Native|Public]
	void TimerRealDoAction(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x10538b3e0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillAction.Reset_Internal
	// Flags: [Native|Public]
	void Reset_Internal(); // Offset: 0x10538b384 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillAction.Reset
	// Flags: [Final|Native|Public]
	void Reset(struct UActorComponent* SkillManagerComponent); // Offset: 0x10538b2c8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillAction.RealDoAction_Internal
	// Flags: [Native|Public]
	bool RealDoAction_Internal(); // Offset: 0x10538b260 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Skill.UTSkillAction.RealDoAction
	// Flags: [Final|Native|Public]
	bool RealDoAction(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x10538b198 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Skill.UTSkillAction.PreCloseSkill
	// Flags: [Native|Public]
	void PreCloseSkill(struct UUTSkillManagerComponent* SkillManagerComponent, struct AUTSkill* CurOwnerSkill); // Offset: 0x10538b074 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillAction.PostInitSkill
	// Flags: [Native|Public]
	void PostInitSkill(struct UUTSkillManagerComponent* SkillManagerComponent, struct AUTSkill* CurOwnerSkill); // Offset: 0x10538af50 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillAction.PostActiveSkill
	// Flags: [Native|Public]
	void PostActiveSkill(struct UUTSkillManagerComponent* SkillManagerComponent, struct AUTSkill* CurOwnerSkill); // Offset: 0x10538ae2c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillAction.OnAsyncLoadAssetDone
	// Flags: [Final|Native|Public]
	void OnAsyncLoadAssetDone(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x10538ad70 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillAction.JudgeNeedPhaseWait
	// Flags: [Native|Public]
	bool JudgeNeedPhaseWait(); // Offset: 0x10538ad08 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Skill.UTSkillAction.DoAction
	// Flags: [Native|Public]
	bool DoAction(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x10538ac38 // Return & Params: Num(2) Size(0x9)
};

// Object Name: Class Skill.UTSkill
// Size: 0x5b8 // Inherited bytes: 0x3d8
struct AUTSkill : AActor {
	// Fields
	char pad_0x3D8[0x10]; // Offset: 0x3d8 // Size: 0x10
	bool bNeedSync; // Offset: 0x3e8 // Size: 0x01
	char pad_0x3E9[0x7]; // Offset: 0x3e9 // Size: 0x07
	struct FString SkillName; // Offset: 0x3f0 // Size: 0x10
	struct FName SkillGroup; // Offset: 0x400 // Size: 0x08
	bool bSinglePhaseRep; // Offset: 0x408 // Size: 0x01
	enum class ESkillCastType SkillCastType; // Offset: 0x409 // Size: 0x01
	bool bShouldMonopolize; // Offset: 0x40a // Size: 0x01
	bool bMonopolizeSelf; // Offset: 0x40b // Size: 0x01
	int SkillID; // Offset: 0x40c // Size: 0x04
	int SkillTemplateID; // Offset: 0x410 // Size: 0x04
	char pad_0x414[0x4]; // Offset: 0x414 // Size: 0x04
	struct FString SkillDescription; // Offset: 0x418 // Size: 0x10
	struct FString SkillDetailDes; // Offset: 0x428 // Size: 0x10
	bool bMeleeSkill; // Offset: 0x438 // Size: 0x01
	bool bCheckFirstPhaseConditions; // Offset: 0x439 // Size: 0x01
	bool bNeedAutonomousClientSimulate; // Offset: 0x43a // Size: 0x01
	bool bKeepCastingWhenDisconnect; // Offset: 0x43b // Size: 0x01
	bool bClearInputCache; // Offset: 0x43c // Size: 0x01
	char pad_0x43D[0x3]; // Offset: 0x43d // Size: 0x03
	struct FUTSkillCreateData BaseData; // Offset: 0x440 // Size: 0x70
	int SkillCategory; // Offset: 0x4b0 // Size: 0x04
	bool bUseNewSkillCD; // Offset: 0x4b4 // Size: 0x01
	char pad_0x4B5[0x3]; // Offset: 0x4b5 // Size: 0x03
	struct TArray<struct FUAEBlackboardParameter> BlackboardParamList; // Offset: 0x4b8 // Size: 0x10
	bool bSetBlackboardDefaultData; // Offset: 0x4c8 // Size: 0x01
	bool bGsListener; // Offset: 0x4c9 // Size: 0x01
	char pad_0x4CA[0x6]; // Offset: 0x4ca // Size: 0x06
	struct FString SkillTimeScaleAttrName; // Offset: 0x4d0 // Size: 0x10
	struct TMap<struct UObject*, int> InstancedNodeNameToMemoryMap; // Offset: 0x4e0 // Size: 0x50
	int InstancedNodesTotalSize; // Offset: 0x530 // Size: 0x04
	char pad_0x534[0x4]; // Offset: 0x534 // Size: 0x04
	struct TArray<struct FString> ParentFolderPath; // Offset: 0x538 // Size: 0x10
	int64_t LastEditBluePrintTime; // Offset: 0x548 // Size: 0x08
	int CurComponentNameIndex; // Offset: 0x550 // Size: 0x04
	bool IsSkillEnabled; // Offset: 0x554 // Size: 0x01
	char pad_0x555[0x53]; // Offset: 0x555 // Size: 0x53
	struct TWeakObjectPtr<struct UUTSkillManagerComponent> SpecificSkillCompRef; // Offset: 0x5a8 // Size: 0x08
	struct TWeakObjectPtr<struct UUAEBlackboard> SpecificBlackBlackRef; // Offset: 0x5b0 // Size: 0x08

	// Functions

	// Object Name: Function Skill.UTSkill.StopSkillCoolDown
	// Flags: [Native|Public|BlueprintCallable]
	void StopSkillCoolDown(struct UUTSkillManagerComponent* SkillManagerComponent, int CoolDownIndex); // Offset: 0x10538a1b0 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Skill.UTSkill.SetSkillPhasePercentage
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSkillPhasePercentage(struct UUTSkillManagerComponent* SkillManagerComponent, float Percentage); // Offset: 0x10538a094 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Skill.UTSkill.OnEvent
	// Flags: [Native|Public|BlueprintCallable]
	bool OnEvent(struct UUTSkillManagerComponent* SkillManagerComponent, enum class UTSkillEventType TheEventType, int PhaseIndex); // Offset: 0x105389f04 // Return & Params: Num(4) Size(0x11)

	// Object Name: Function Skill.UTSkill.IsEnableSkillCoolDown
	// Flags: [Native|Public|BlueprintCallable]
	bool IsEnableSkillCoolDown(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x105389e34 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Skill.UTSkill.IsCDOK
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure]
	bool IsCDOK(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x105389d64 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Skill.UTSkill.GetSpecificSkillManager
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	struct UUTSkillManagerComponent* GetSpecificSkillManager(); // Offset: 0x105389d08 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkill.GetSpecificBlackboard
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	struct UUAEBlackboard* GetSpecificBlackboard(); // Offset: 0x105389cac // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkill.GetSkillPhasePercentage
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetSkillPhasePercentage(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x105389be8 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Skill.UTSkill.GetSkillPhaseByName
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure]
	struct UUTSkillPhase* GetSkillPhaseByName(struct FString PhaseName); // Offset: 0x105389ad8 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Skill.UTSkill.GetSkillPhase
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure]
	struct UUTSkillPhase* GetSkillPhase(int PhaseIndex); // Offset: 0x105389a0c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkill.GetSkillEffectByPhaseName
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure]
	struct UUTSkillBaseWidget* GetSkillEffectByPhaseName(struct FString PhaseName, struct FString EffectName); // Offset: 0x10538986c // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Skill.UTSkill.GetSkillEffectByPhaseIndex
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure]
	struct UUTSkillBaseWidget* GetSkillEffectByPhaseIndex(int PhaseIndex, struct FString EffectName); // Offset: 0x1053896fc // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Skill.UTSkill.GetRestCoolDownTime
	// Flags: [Native|Public|BlueprintCallable]
	float GetRestCoolDownTime(struct UUTSkillManagerComponent* SkillManagerComponent, int CoolDownIndex); // Offset: 0x1053895d0 // Return & Params: Num(3) Size(0x10)

	// Object Name: Function Skill.UTSkill.DoSkillCoolDown
	// Flags: [Native|Public|BlueprintCallable]
	void DoSkillCoolDown(struct UUTSkillManagerComponent* SkillManagerComponent, int CoolDownIndex); // Offset: 0x1053894ac // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Skill.UTSkill.CanBePlayed
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure]
	bool CanBePlayed(struct UUTSkillManagerComponent* SkillManagerComponent, bool bShowErrorMsg); // Offset: 0x105389354 // Return & Params: Num(3) Size(0xa)
};

// Object Name: Class Skill.UTSkillManagerComponent
// Size: 0x7e8 // Inherited bytes: 0x1d8
struct UUTSkillManagerComponent : ULuaActorComponent {
	// Fields
	char pad_0x1D8[0x58]; // Offset: 0x1d8 // Size: 0x58
	struct APawn* OwnerPawn; // Offset: 0x230 // Size: 0x08
	char pad_0x238[0x20]; // Offset: 0x238 // Size: 0x20
	bool bEnableSkillCoolDown; // Offset: 0x258 // Size: 0x01
	char pad_0x259[0x7]; // Offset: 0x259 // Size: 0x07
	struct AActor* OwnerActor; // Offset: 0x260 // Size: 0x08
	bool DestroySkillsOnDie; // Offset: 0x268 // Size: 0x01
	char pad_0x269[0x7]; // Offset: 0x269 // Size: 0x07
	struct TMap<int, struct TWeakObjectPtr<struct AUTSkill>> SkillIDToSkills; // Offset: 0x270 // Size: 0x50
	struct TMap<struct TWeakObjectPtr<struct AUTSkill>, struct UUAEBlackboard*> SkillsBlackboardMap; // Offset: 0x2c0 // Size: 0x50
	struct TMap<struct TWeakObjectPtr<struct AActor>, struct UUAEBlackboard*> ActorBlackboardMap; // Offset: 0x310 // Size: 0x50
	struct FScriptMulticastDelegate ChangeActorBlackboard; // Offset: 0x360 // Size: 0x10
	struct AActor* Target; // Offset: 0x370 // Size: 0x08
	struct TMap<int, struct FUTSkillCreateData> SkillBaseDataMaps; // Offset: 0x378 // Size: 0x50
	struct TArray<struct FUTSkillLastCastInfo> LastCastArray; // Offset: 0x3c8 // Size: 0x10
	struct FScriptMulticastDelegate OnSkillHit; // Offset: 0x3d8 // Size: 0x10
	struct FScriptMulticastDelegate OnSkillCast; // Offset: 0x3e8 // Size: 0x10
	float PhasePercentage; // Offset: 0x3f8 // Size: 0x04
	char pad_0x3FC[0x4]; // Offset: 0x3fc // Size: 0x04
	struct TMap<int, int> IDToSyncSkillActiveStateData; // Offset: 0x400 // Size: 0x50
	struct TArray<struct FSkillActiveRepData> SyncSkillActiveStateDatas; // Offset: 0x450 // Size: 0x10
	struct TMap<int, int> IDToSyncSkillCDDatas; // Offset: 0x460 // Size: 0x50
	struct FTeammateSkillCDRepData TeammateSkillCDRepData; // Offset: 0x4b0 // Size: 0x10
	struct FSkillDynamicRepData SyncDynamicRepData; // Offset: 0x4c0 // Size: 0x10
	struct TArray<struct FSkillCDRepData> SyncSkillCDDatas; // Offset: 0x4d0 // Size: 0x10
	char pad_0x4E0[0x8]; // Offset: 0x4e0 // Size: 0x08
	struct FUTSkillHitInfo SkillHitInfo; // Offset: 0x4e8 // Size: 0x30
	struct FUTSkillHitEnvInfo SkillHitEnvInfo; // Offset: 0x518 // Size: 0x30
	struct TArray<struct FString> MutexMontageGroupBeenPlayed; // Offset: 0x548 // Size: 0x10
	char pad_0x558[0x4]; // Offset: 0x558 // Size: 0x04
	int SkillSynRandomSeed; // Offset: 0x55c // Size: 0x04
	struct FRandomStream SkillSynRandStream; // Offset: 0x560 // Size: 0x08
	int SkillSynRandomSeedExpireCount; // Offset: 0x568 // Size: 0x04
	char pad_0x56C[0x4]; // Offset: 0x56c // Size: 0x04
	struct TMap<struct FString, struct FTimerHandle> SkillTimerMap; // Offset: 0x570 // Size: 0x50
	char pad_0x5C0[0x8]; // Offset: 0x5c0 // Size: 0x08
	struct TArray<struct FSkillParamater> SkillParamaters; // Offset: 0x5c8 // Size: 0x10
	struct TArray<struct FUTMutilSkillSynData> SkillSynData; // Offset: 0x5d8 // Size: 0x10
	char pad_0x5E8[0x10]; // Offset: 0x5e8 // Size: 0x10
	struct TArray<struct FUTSkillSynSinglePhaseData> SkillSynSinglePhaseData; // Offset: 0x5f8 // Size: 0x10
	char pad_0x608[0x18]; // Offset: 0x608 // Size: 0x18
	struct TMap<struct AUTSkill*, int> SkillCurPhaseIndexes; // Offset: 0x620 // Size: 0x50
	struct TMap<struct AUTSkill*, int> LastPhaseIndexes; // Offset: 0x670 // Size: 0x50
	char pad_0x6C0[0x60]; // Offset: 0x6c0 // Size: 0x60
	struct FScriptMulticastDelegate OnSkillInitSignature; // Offset: 0x720 // Size: 0x10
	struct FScriptMulticastDelegate SkillStartEvent; // Offset: 0x730 // Size: 0x10
	struct FScriptMulticastDelegate SkillStopEvent; // Offset: 0x740 // Size: 0x10
	struct FScriptMulticastDelegate SkillLevelChangeEvent; // Offset: 0x750 // Size: 0x10
	struct TArray<int> PendingRemoveSkillID; // Offset: 0x760 // Size: 0x10
	struct TMap<int, char> CurSKillLevels; // Offset: 0x770 // Size: 0x50
	struct TArray<struct FUTReplaceSkillData> ReplacedSkillDatas; // Offset: 0x7c0 // Size: 0x10
	bool bEnableSkillInst; // Offset: 0x7d0 // Size: 0x01
	char pad_0x7D1[0x7]; // Offset: 0x7d1 // Size: 0x07
	struct TArray<struct FUTSkillInstance> SkillInstArray; // Offset: 0x7d8 // Size: 0x10

	// Functions

	// Object Name: Function Skill.UTSkillManagerComponent.UpdateSyncSkillCDData
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UpdateSyncSkillCDData(int SkillID); // Offset: 0x1053a6158 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillManagerComponent.UpdateSyncSkillActiveState
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UpdateSyncSkillActiveState(int SkillID); // Offset: 0x1053a609c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillManagerComponent.UnRegisterActorBlackBorad
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UnRegisterActorBlackBorad(struct AActor* InActor); // Offset: 0x1053a5fe0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillManagerComponent.TryDeleteOneSkill
	// Flags: [Final|Native|Public|BlueprintCallable]
	void TryDeleteOneSkill(int SkillID, bool IsImmediately); // Offset: 0x1053a5ea4 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Skill.UTSkillManagerComponent.TryAddOneSkill
	// Flags: [Final|Native|Public|BlueprintCallable]
	void TryAddOneSkill(int SkillID, bool bActive); // Offset: 0x1053a5d68 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Skill.UTSkillManagerComponent.TriggerEvent_WithID
	// Flags: [Native|Public|HasOutParms]
	void TriggerEvent_WithID(int InSkillID, enum class UTSkillEventType InEventType, struct FUTSkillBBUploadData& SkillBBUploadData); // Offset: 0x1053a5b74 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Skill.UTSkillManagerComponent.TriggerEvent
	// Flags: [Native|Public|BlueprintCallable]
	void TriggerEvent(int SkillID, enum class UTSkillEventType EventType); // Offset: 0x1053a5a50 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Skill.UTSkillManagerComponent.TraceTarget
	// Flags: [Native|Public|HasOutParms|HasDefaults]
	bool TraceTarget(struct FVector StartTrace, struct FVector EndTrace, enum class UTPickerTargetType TargetType, float Radius, struct AActor*& TargetActor); // Offset: 0x1053a5788 // Return & Params: Num(6) Size(0x29)

	// Object Name: Function Skill.UTSkillManagerComponent.SyncOneSkillState
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SyncOneSkillState(bool RepSkillCD, bool RepSkillActiveState, int RequestID); // Offset: 0x1053a55d4 // Return & Params: Num(3) Size(0x8)

	// Object Name: Function Skill.UTSkillManagerComponent.StopSkillWithSlot
	// Flags: [Native|Public]
	bool StopSkillWithSlot(int SkillSlot, enum class UTSkillStopReason StopReason); // Offset: 0x1053a54a4 // Return & Params: Num(3) Size(0x6)

	// Object Name: Function Skill.UTSkillManagerComponent.StopSkillSpecific
	// Flags: [Final|Native|Public]
	void StopSkillSpecific(struct AUTSkill* Skill, enum class UTSkillStopReason StopReason); // Offset: 0x1053a5388 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Skill.UTSkillManagerComponent.StopSkillAll
	// Flags: [Native|Public|BlueprintCallable]
	void StopSkillAll(enum class UTSkillStopReason StopReason); // Offset: 0x1053a52c4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Skill.UTSkillManagerComponent.StopSkill_WithID
	// Flags: [Native|Public]
	int StopSkill_WithID(int SkillID, enum class UTSkillStopReason StopReason); // Offset: 0x1053a5198 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Skill.UTSkillManagerComponent.StopSkill
	// Flags: [Native|Public|BlueprintCallable]
	void StopSkill(int SkillID, enum class UTSkillStopReason StopReason); // Offset: 0x1053a5074 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Skill.UTSkillManagerComponent.ShouldTriggerEvent
	// Flags: [Native|Public|BlueprintCallable]
	bool ShouldTriggerEvent(int SkillID, enum class UTSkillEventType EventType); // Offset: 0x1053a4f44 // Return & Params: Num(3) Size(0x6)

	// Object Name: Function Skill.UTSkillManagerComponent.SetupOwnerAndSystem
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetupOwnerAndSystem(); // Offset: 0x1053a4ee4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Skill.UTSkillManagerComponent.SetSkillState
	// Flags: [Final|Native|Public|HasOutParms]
	void SetSkillState(struct TArray<struct FUTSkillStateSyncData>& InSyncStateDatas); // Offset: 0x1053a4da4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Skill.UTSkillManagerComponent.SetSkillOwner
	// Flags: [Native|Public|BlueprintCallable]
	void SetSkillOwner(struct AActor* tempActor); // Offset: 0x1053a4ce0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillManagerComponent.SetSkillLevel
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSkillLevel(int SkillID, int SkillLevel); // Offset: 0x1053a4bc4 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Skill.UTSkillManagerComponent.SetSkillLastPhase
	// Flags: [Final|Native|Public]
	void SetSkillLastPhase(struct AUTSkill* Skill, int PhaseIndex); // Offset: 0x1053a4aa8 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Skill.UTSkillManagerComponent.SetSkillCurPhase
	// Flags: [Final|Native|Public]
	void SetSkillCurPhase(struct AUTSkill* Skill, int PhaseIndex); // Offset: 0x1053a498c // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Skill.UTSkillManagerComponent.SetSkillActive
	// Flags: [Native|Public|BlueprintCallable]
	bool SetSkillActive(int SkillID, bool bActive, bool bForceSet); // Offset: 0x1053a47b8 // Return & Params: Num(4) Size(0x7)

	// Object Name: Function Skill.UTSkillManagerComponent.SetCurSkill
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetCurSkill(int SkillID, int SkillSlot); // Offset: 0x1053a469c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Skill.UTSkillManagerComponent.SetAutoSkillID
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAutoSkillID(int InSkillID); // Offset: 0x1053a45e0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillManagerComponent.ServerTriggerEvent_WithParams
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void ServerTriggerEvent_WithParams(int SkillID, enum class UTSkillEventType EventType, struct TArray<struct FUAEBlackboardKeySelector> KeySelectors, struct TArray<char> Content); // Offset: 0x1053a42ec // Return & Params: Num(4) Size(0x28)

	// Object Name: Function Skill.UTSkillManagerComponent.ServerTriggerEvent_WithID
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void ServerTriggerEvent_WithID(int SkillID, enum class UTSkillEventType EventType); // Offset: 0x1053a419c // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Skill.UTSkillManagerComponent.ServerTriggerEvent
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void ServerTriggerEvent(int SkillID, enum class UTSkillEventType EventType); // Offset: 0x1053a404c // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Skill.UTSkillManagerComponent.ServerStopAllSkill
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void ServerStopAllSkill(enum class UTSkillStopReason Reason); // Offset: 0x1053a3f60 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Skill.UTSkillManagerComponent.ServerStartSkill
	// Flags: [Native|Public|BlueprintCallable]
	bool ServerStartSkill(int SkillID, bool bAutoCast); // Offset: 0x1053a3e08 // Return & Params: Num(3) Size(0x6)

	// Object Name: Function Skill.UTSkillManagerComponent.ServerNotifyRandomSeed
	// Flags: [Net|Native|Event|Public|NetServer|NetValidate]
	void ServerNotifyRandomSeed(int Seed); // Offset: 0x1053a3d1c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillManagerComponent.ResetTeammateSkillCDData
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ResetTeammateSkillCDData(); // Offset: 0x1053a3cc8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillManagerComponent.ResetSkillCollDown
	// Flags: [Native|Public|BlueprintCallable]
	void ResetSkillCollDown(int SkillID); // Offset: 0x1053a3c04 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillManagerComponent.ResetAllSkillCollDown
	// Flags: [Native|Public|BlueprintCallable]
	void ResetAllSkillCollDown(); // Offset: 0x1053a3ba8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillManagerComponent.RequestSkillStates
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable|NetValidate]
	void RequestSkillStates(bool RepSkillCD, bool RepSkillActiveState, struct TArray<int> RequestIDs); // Offset: 0x1053a394c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Skill.UTSkillManagerComponent.RepSkillHitInfo
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RepSkillHitInfo(); // Offset: 0x1053a38f8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillManagerComponent.RepOneSkillSynData
	// Flags: [Final|Native|Public]
	void RepOneSkillSynData(int SkillSlot, int InLastSkillID); // Offset: 0x1053a37dc // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Skill.UTSkillManagerComponent.RepLastCastTime
	// Flags: [Final|Native|Public]
	void RepLastCastTime(); // Offset: 0x1053a3788 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillManagerComponent.ReplaceSkill
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ReplaceSkill(int OldSkillID, int NewSkillID); // Offset: 0x1053a366c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Skill.UTSkillManagerComponent.RemoveReplacedSkill
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RemoveReplacedSkill(int OldSkillID); // Offset: 0x1053a35b0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillManagerComponent.RemoveAllSkillUIWidget
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RemoveAllSkillUIWidget(); // Offset: 0x1053a355c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillManagerComponent.RegisterActorBlackBorad
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RegisterActorBlackBorad(struct AActor* InActor, struct UUAEBlackboard* RegisterBlackboard); // Offset: 0x1053a3440 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillManagerComponent.RandRangeSyn
	// Flags: [Final|Native|Public]
	int RandRangeSyn(int StartIndex, int EndIndex); // Offset: 0x1053a331c // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Skill.UTSkillManagerComponent.PlayHurtSkillEffect
	// Flags: [Native|Public]
	void PlayHurtSkillEffect(struct FUTSkillHitInfo TheSkillHitInfo); // Offset: 0x1053a3200 // Return & Params: Num(1) Size(0x30)

	// Object Name: Function Skill.UTSkillManagerComponent.OnStopSkill
	// Flags: [Native|Public]
	void OnStopSkill(struct AUTSkill* Skill, enum class UTSkillStopReason StopReason); // Offset: 0x1053a30dc // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Skill.UTSkillManagerComponent.OnSameTeam
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool OnSameTeam(struct AActor* A, struct AActor* B); // Offset: 0x1053a2fc0 // Return & Params: Num(3) Size(0x11)

	// Object Name: Function Skill.UTSkillManagerComponent.OnRespawned
	// Flags: [Native|Public]
	void OnRespawned(); // Offset: 0x1053a2f64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillManagerComponent.OnRep_SkillSynSinglePhaseData
	// Flags: [Native|Public]
	void OnRep_SkillSynSinglePhaseData(); // Offset: 0x1053a2f08 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillManagerComponent.OnRep_SkillSynData
	// Flags: [Native|Public]
	void OnRep_SkillSynData(); // Offset: 0x1053a2eac // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillManagerComponent.OnRep_SkillHitInfo
	// Flags: [Native|Public]
	void OnRep_SkillHitInfo(); // Offset: 0x1053a2e50 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillManagerComponent.OnRep_SkillCDDatas
	// Flags: [Final|Native|Public]
	void OnRep_SkillCDDatas(); // Offset: 0x1053a2dfc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillManagerComponent.OnRep_SkillActiveState
	// Flags: [Final|Native|Public]
	void OnRep_SkillActiveState(); // Offset: 0x1053a2da8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillManagerComponent.OnRep_ReplaceSkill
	// Flags: [Final|Native|Public]
	void OnRep_ReplaceSkill(); // Offset: 0x1053a2d54 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillManagerComponent.OnRep_DynamicRepData
	// Flags: [Final|Native|Public]
	void OnRep_DynamicRepData(); // Offset: 0x1053a2d00 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillManagerComponent.OnRecycled
	// Flags: [Native|Public]
	void OnRecycled(); // Offset: 0x1053a2ca4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillManagerComponent.OnInterruptSkill
	// Flags: [Native|Public]
	void OnInterruptSkill(struct AUTSkill* Skill, enum class UTSkillStopReason StopReason); // Offset: 0x1053a2b80 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Skill.UTSkillManagerComponent.IsUsingSkill
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsUsingSkill(int SkillID); // Offset: 0x1053a2ab8 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Skill.UTSkillManagerComponent.IsSkillCanUse
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	bool IsSkillCanUse(); // Offset: 0x1053a2a58 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Skill.UTSkillManagerComponent.IsSkillActived
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	bool IsSkillActived(int SkillID); // Offset: 0x1053a2990 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Skill.UTSkillManagerComponent.IsReadyToCastSkill
	// Flags: [Native|Public]
	bool IsReadyToCastSkill(int SkillID); // Offset: 0x1053a28c0 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Skill.UTSkillManagerComponent.IsEnableSkillCoolDown
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure]
	bool IsEnableSkillCoolDown(); // Offset: 0x1053a2858 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Skill.UTSkillManagerComponent.IsCurrentUseSkillID
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsCurrentUseSkillID(int InSkillID); // Offset: 0x1053a2790 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Skill.UTSkillManagerComponent.IsCastingSkillID
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsCastingSkillID(int InSkillID); // Offset: 0x1053a26c0 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Skill.UTSkillManagerComponent.IsCastingSkill
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsCastingSkill(); // Offset: 0x1053a2658 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Skill.UTSkillManagerComponent.HandleTriggerParamsEvent
	// Flags: [Event|Public|BlueprintEvent]
	bool HandleTriggerParamsEvent(int SkillID, enum class UTSkillEventType EventType); // Offset: 0x103df3e6c // Return & Params: Num(3) Size(0x6)

	// Object Name: Function Skill.UTSkillManagerComponent.HandleSkillStop
	// Flags: [Native|Public]
	void HandleSkillStop(int SkillID, enum class UTSkillStopReason StopReason); // Offset: 0x1053a2534 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Skill.UTSkillManagerComponent.HandleSkillStart
	// Flags: [Native|Public]
	void HandleSkillStart(int SkillID); // Offset: 0x1053a2470 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillManagerComponent.GetUAEBlackboardBySkillId
	// Flags: [Native|Public|BlueprintCallable]
	struct UUAEBlackboard* GetUAEBlackboardBySkillId(int SkillID); // Offset: 0x1053a23a4 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillManagerComponent.GetUAEBlackboard
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UUAEBlackboard* GetUAEBlackboard(struct AUTSkill* InSkill); // Offset: 0x1053a22e0 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillManagerComponent.GetSkillWidget
	// Flags: [Native|Public|BlueprintCallable]
	struct UUTSkillWidget* GetSkillWidget(int SkillID); // Offset: 0x1053a2214 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillManagerComponent.GetSkillState
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct TArray<struct FUTSkillStateSyncData> GetSkillState(); // Offset: 0x1053a2188 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Skill.UTSkillManagerComponent.GetSkillSlotBySkillID
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetSkillSlotBySkillID(int SkillID); // Offset: 0x1053a20c4 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Skill.UTSkillManagerComponent.GetSkillSlotBySkill
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetSkillSlotBySkill(struct AUTSkill* Skill); // Offset: 0x1053a2000 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Skill.UTSkillManagerComponent.GetSkillsByGroup
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct TArray<struct AUTSkill*> GetSkillsByGroup(struct FName SkillGroup); // Offset: 0x1053a1edc // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Skill.UTSkillManagerComponent.GetSkillLevel
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetSkillLevel(int SkillID); // Offset: 0x1053a1e18 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Skill.UTSkillManagerComponent.GetSkillLastPhase
	// Flags: [Final|Native|Public]
	int GetSkillLastPhase(struct AUTSkill* Skill); // Offset: 0x1053a1d54 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Skill.UTSkillManagerComponent.GetSkillIDFromSkillIndex
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetSkillIDFromSkillIndex(int InSkillIndex); // Offset: 0x1053a1c88 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Skill.UTSkillManagerComponent.GetSkillIDByClass
	// Flags: [Native|Public|BlueprintCallable]
	int GetSkillIDByClass(struct UObject* SkillClass); // Offset: 0x1053a1bbc // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Skill.UTSkillManagerComponent.GetSkillCurPhase
	// Flags: [Final|Native|Public]
	int GetSkillCurPhase(struct AUTSkill* Skill); // Offset: 0x1053a1af8 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Skill.UTSkillManagerComponent.GetSkillByName
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct AUTSkill* GetSkillByName(struct FString SkillName); // Offset: 0x1053a19bc // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Skill.UTSkillManagerComponent.GetSkillByClassName
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct AUTSkill* GetSkillByClassName(struct FString SkillClassName); // Offset: 0x1053a1880 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Skill.UTSkillManagerComponent.GetSkillBaseData
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FUTSkillCreateData GetSkillBaseData(int SkillID); // Offset: 0x1053a17b8 // Return & Params: Num(2) Size(0x78)

	// Object Name: Function Skill.UTSkillManagerComponent.GetSkill
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct AUTSkill* GetSkill(int SkillID); // Offset: 0x1053a16ec // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillManagerComponent.GetReplacedSkill
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetReplacedSkill(int OldSkillID); // Offset: 0x1053a1628 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Skill.UTSkillManagerComponent.GetRealOwnerRoleSafety
	// Flags: [Native|Public|BlueprintCallable]
	enum class ENetRole GetRealOwnerRoleSafety(); // Offset: 0x1053a15b4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Skill.UTSkillManagerComponent.GetLastCastTime
	// Flags: [Final|Native|Public]
	float GetLastCastTime(int SkillID); // Offset: 0x1053a14f0 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Skill.UTSkillManagerComponent.GetLastCastFinishTime
	// Flags: [Final|Native|Public]
	float GetLastCastFinishTime(int SkillID); // Offset: 0x1053a142c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Skill.UTSkillManagerComponent.GetCurUsingSkillIDS
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct TArray<int> GetCurUsingSkillIDS(); // Offset: 0x1053a13a0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Skill.UTSkillManagerComponent.GetCurSkills
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct TArray<struct AUTSkill*> GetCurSkills(); // Offset: 0x1053a1314 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Skill.UTSkillManagerComponent.GetCurSkillPhases
	// Flags: [Final|Native|Public]
	struct TArray<struct UUTSkillPhase*> GetCurSkillPhases(); // Offset: 0x1053a1288 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Skill.UTSkillManagerComponent.GetCurSkillPhase
	// Flags: [Final|Native|Public]
	struct UUTSkillPhase* GetCurSkillPhase(int InSkillSlot); // Offset: 0x1053a11c4 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillManagerComponent.GetCurSkillIDs
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct TArray<int> GetCurSkillIDs(); // Offset: 0x1053a1164 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Skill.UTSkillManagerComponent.GetCurSkillID
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	int GetCurSkillID(struct AUTSkill* Skill); // Offset: 0x1053a10a0 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Skill.UTSkillManagerComponent.GetCurSkill
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct AUTSkill* GetCurSkill(int InSkillSlot); // Offset: 0x1053a0fdc // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillManagerComponent.GetCurMonopolizeSkills
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct TArray<int> GetCurMonopolizeSkills(); // Offset: 0x1053a0f50 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Skill.UTSkillManagerComponent.FindRelatedCurSkillID
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	int FindRelatedCurSkillID(int SkillID, int& OutRelatedSkillSlot, bool bPeekSlotIndex); // Offset: 0x1053a0d7c // Return & Params: Num(4) Size(0x10)

	// Object Name: Function Skill.UTSkillManagerComponent.DynamicRemoveSkill
	// Flags: [Native|Public|BlueprintCallable]
	void DynamicRemoveSkill(int InSkillID); // Offset: 0x1053a0cb8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillManagerComponent.DynamicAddSkill
	// Flags: [Native|Public|BlueprintCallable]
	void DynamicAddSkill(int InSkillID); // Offset: 0x1053a0bf4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillManagerComponent.ClientStartSkill
	// Flags: [Native|Public|BlueprintCallable]
	void ClientStartSkill(int SkillID, bool bAutoCast); // Offset: 0x1053a0ab0 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Skill.UTSkillManagerComponent.ClearSkill
	// Flags: [Native|Public]
	void ClearSkill(); // Offset: 0x1053a0a54 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillManagerComponent.ClearRepParams
	// Flags: [Native|Public]
	void ClearRepParams(); // Offset: 0x1053a09f8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillManagerComponent.ClearInitParams
	// Flags: [Native|Public]
	void ClearInitParams(); // Offset: 0x1053a099c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillManagerComponent.CacheSkillWidget
	// Flags: [Native|Public|BlueprintCallable]
	void CacheSkillWidget(int SkillID, struct UUTSkillWidget* Widget); // Offset: 0x1053a0878 // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class Skill.UTSkillEventEffectMapForEditor
// Size: 0xa8 // Inherited bytes: 0x60
struct UUTSkillEventEffectMapForEditor : UUTSkillBaseWidget {
	// Fields
	enum class UTSkillEventType SkillEventType; // Offset: 0x60 // Size: 0x01
	char pad_0x61[0x7]; // Offset: 0x61 // Size: 0x07
	struct TArray<struct FName> InterestedOwnerTags; // Offset: 0x68 // Size: 0x10
	struct FName PreEventActionTag; // Offset: 0x78 // Size: 0x08
	struct UUTSkillEffect* SkillEffect; // Offset: 0x80 // Size: 0x08
	struct TArray<struct FSkillConditionWarpper> Conditions; // Offset: 0x88 // Size: 0x10
	struct TArray<struct FSkillConditionWarpper> TargetConditions; // Offset: 0x98 // Size: 0x10
};

// Object Name: Class Skill.UTSkillInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UUTSkillInterface : UInterface {
	// Functions

	// Object Name: Function Skill.UTSkillInterface.HasSkillToken
	// Flags: [Native|Public]
	bool HasSkillToken(int SkillID); // Offset: 0x10539f7dc // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Skill.UTSkillInterface.HandleSkillStart
	// Flags: [Native|Event|Public|BlueprintEvent]
	void HandleSkillStart(int SkillID); // Offset: 0x10539f718 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillInterface.HandleSkillEnd
	// Flags: [Native|Event|Public|BlueprintEvent]
	void HandleSkillEnd(int SkillID, enum class UTSkillStopReason Reason); // Offset: 0x10539f5f4 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Skill.UTSkillInterface.GetSkillManager
	// Flags: [Native|Public|Const]
	struct UUTSkillManagerComponent* GetSkillManager(); // Offset: 0x10539f590 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillInterface.ClearSkillToken
	// Flags: [Native|Public]
	void ClearSkillToken(int SkillID); // Offset: 0x10539f4cc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillInterface.ClearAllSkillToken
	// Flags: [Native|Public]
	void ClearAllSkillToken(); // Offset: 0x10539f470 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillInterface.AddSkillToken
	// Flags: [Native|Public]
	void AddSkillToken(int SkillID); // Offset: 0x10539f3ac // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class Skill.UTSkillPhase
// Size: 0x110 // Inherited bytes: 0x28
struct UUTSkillPhase : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
	struct FString PhaseName; // Offset: 0x30 // Size: 0x10
	struct FString PhaseDescription; // Offset: 0x40 // Size: 0x10
	bool bPhaseEnabled; // Offset: 0x50 // Size: 0x01
	char pad_0x51[0x3]; // Offset: 0x51 // Size: 0x03
	struct TWeakObjectPtr<struct AUTSkill> OwnerSkill; // Offset: 0x54 // Size: 0x08
	int PhaseIndex; // Offset: 0x5c // Size: 0x04
	char pad_0x60[0x18]; // Offset: 0x60 // Size: 0x18
	int ActionsTopHalfCount; // Offset: 0x78 // Size: 0x04
	char pad_0x7C[0x4]; // Offset: 0x7c // Size: 0x04
	struct FUTSkillPhaseCreateData BaseData; // Offset: 0x80 // Size: 0x88
	struct UUTSkillPicker* InEffectPickerOnAction; // Offset: 0x108 // Size: 0x08

	// Functions

	// Object Name: Function Skill.UTSkillPhase.TryJumpToPhase
	// Flags: [Final|Native|Public]
	bool TryJumpToPhase(struct UUTSkillManagerComponent* SkillManagerComponent, int PhaseId); // Offset: 0x1053b5098 // Return & Params: Num(3) Size(0xd)

	// Object Name: Function Skill.UTSkillPhase.StopPhase
	// Flags: [Native|Public]
	void StopPhase(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x1053b4fd4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillPhase.StartPhase
	// Flags: [Native|Public]
	void StartPhase(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x1053b4f10 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillPhase.RepeatPhase
	// Flags: [Native|Public]
	void RepeatPhase(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x1053b4e4c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillPhase.PlaySkillHurtEffect
	// Flags: [Native|Public]
	bool PlaySkillHurtEffect(struct UUTSkillManagerComponent* SkillManagerComponent, struct AActor* Victim); // Offset: 0x1053b4d1c // Return & Params: Num(3) Size(0x11)

	// Object Name: Function Skill.UTSkillPhase.PlaySkillHurtAppearances
	// Flags: [Native|Public]
	bool PlaySkillHurtAppearances(struct UUTSkillManagerComponent* SkillManagerComponent, struct AActor* Victim); // Offset: 0x1053b4bec // Return & Params: Num(3) Size(0x11)

	// Object Name: Function Skill.UTSkillPhase.PickTargets
	// Flags: [Native|Public]
	void PickTargets(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x1053b4b28 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillPhase.OnEvent
	// Flags: [Native|Public]
	bool OnEvent(struct UUTSkillManagerComponent* SkillManagerComponent, enum class UTSkillEventType TheEventType); // Offset: 0x1053b49f8 // Return & Params: Num(3) Size(0xa)

	// Object Name: Function Skill.UTSkillPhase.OnCustomEvent
	// Flags: [Native|Public]
	bool OnCustomEvent(struct UUTSkillManagerComponent* SkillManagerComponent, enum class UTSkillEventType TheEventType); // Offset: 0x1053b48c8 // Return & Params: Num(3) Size(0xa)

	// Object Name: Function Skill.UTSkillPhase.GetChargePhaseRate
	// Flags: [Final|Native|Public]
	float GetChargePhaseRate(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x1053b4804 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Skill.UTSkillPhase.ForceStopPhase
	// Flags: [Native|Public]
	bool ForceStopPhase(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x1053b4734 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Skill.UTSkillPhase.ClearAttachments
	// Flags: [Final|Native|Public]
	bool ClearAttachments(); // Offset: 0x1053b46d4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Skill.UTSkillPhase.AfterStartPhase
	// Flags: [Native|Public]
	void AfterStartPhase(struct UUTSkillManagerComponent* SkillManagerComponent); // Offset: 0x1053b4610 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillPhase.AddSkillConditionLua
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddSkillConditionLua(struct AUTSkill* InSkill, struct FString InLuaPath); // Offset: 0x1053b44bc // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Skill.UTSkillPhase.AddSkillActionLua
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddSkillActionLua(struct AUTSkill* InSkill, struct FString InLuaPath); // Offset: 0x1053b4368 // Return & Params: Num(2) Size(0x18)
};

// Object Name: Class Skill.UTSkillPicker
// Size: 0xb0 // Inherited bytes: 0x60
struct UUTSkillPicker : UUTSkillBaseWidget {
	// Fields
	struct FUTSkillPickerCreateData BaseData; // Offset: 0x60 // Size: 0x20
	char pad_0x80[0x10]; // Offset: 0x80 // Size: 0x10
	struct TArray<struct FUTSkillPickedTarget> PickedResultTargets; // Offset: 0x90 // Size: 0x10
	struct TArray<struct UUTSkillPickerFilter*> Filters; // Offset: 0xa0 // Size: 0x10

	// Functions

	// Object Name: Function Skill.UTSkillPicker.PickTargetsInner
	// Flags: [Native|Protected|HasDefaults|BlueprintCallable]
	bool PickTargetsInner(struct FVector OriginPoint); // Offset: 0x1053b62dc // Return & Params: Num(2) Size(0xd)

	// Object Name: Function Skill.UTSkillPicker.PickTargets
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	bool PickTargets(struct FVector OriginPoint); // Offset: 0x1053b61f4 // Return & Params: Num(2) Size(0xd)
};

// Object Name: Class Skill.UTSkillPickerFilter
// Size: 0x28 // Inherited bytes: 0x28
struct UUTSkillPickerFilter : UObject {
	// Functions

	// Object Name: Function Skill.UTSkillPickerFilter.HandleFilterArray
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent]
	void HandleFilterArray(struct TArray<struct FUTSkillPickedTarget>& inArray, struct AActor* Owner); // Offset: 0x1053b5e34 // Return & Params: Num(2) Size(0x18)
};

// Object Name: Class Skill.UTSkillWidget
// Size: 0x4a8 // Inherited bytes: 0x490
struct UUTSkillWidget : ULuaUAEUserWidget {
	// Fields
	struct UUTSkillManagerComponent* SkillManager; // Offset: 0x490 // Size: 0x08
	int SkillID; // Offset: 0x498 // Size: 0x04
	float TickInterval; // Offset: 0x49c // Size: 0x04
	bool bEnableTick; // Offset: 0x4a0 // Size: 0x01
	char pad_0x4A1[0x7]; // Offset: 0x4a1 // Size: 0x07

	// Functions

	// Object Name: Function Skill.UTSkillWidget.TriggerPassiveEvent
	// Flags: [Final|Native|Public|BlueprintCallable]
	void TriggerPassiveEvent(enum class UTSkillEventType SkillEvent); // Offset: 0x1053b7c54 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Skill.UTSkillWidget.TriggerEvent
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void TriggerEvent(enum class UTSkillEventType SkillEvent); // Offset: 0x1053b7b90 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Skill.UTSkillWidget.SetSkillManager
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSkillManager(struct UUTSkillManagerComponent* manager); // Offset: 0x1053b7ad4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillWidget.SetSkillID
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSkillID(int InSkillID); // Offset: 0x1053b7a18 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillWidget.RemoveSelf
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RemoveSelf(); // Offset: 0x1053b79c4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillWidget.GetSkillManager
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UUTSkillManagerComponent* GetSkillManager(); // Offset: 0x1053b7968 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillWidget.GetSkillID
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetSkillID(); // Offset: 0x1053b790c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillWidget.GetSkillCDBases
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct TArray<struct UUTSkillCDBase*> GetSkillCDBases(); // Offset: 0x1053b78ac // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Skill.UTSkillWidget.GetSkill
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct AUTSkill* GetSkill(); // Offset: 0x1053b7850 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Skill.UTSkillWidget.GetLocalPlayerController
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct APlayerController* GetLocalPlayerController(); // Offset: 0x1053b77f4 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class Skill.UTSkillLocationPicker
// Size: 0x60 // Inherited bytes: 0x60
struct UUTSkillLocationPicker : UUTSkillBaseWidget {
};

// Object Name: Class Skill.AddNewSkillToOwnerInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UAddNewSkillToOwnerInterface : UInterface {
	// Functions

	// Object Name: Function Skill.AddNewSkillToOwnerInterface.GetSkillTemplates
	// Flags: [Native|Event|Public|BlueprintEvent]
	struct TArray<struct FItemSkillsConfig> GetSkillTemplates(); // Offset: 0x1053888a0 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class Skill.SharedDelegate
// Size: 0x48 // Inherited bytes: 0x28
struct USharedDelegate : UObject {
	// Fields
	struct UObject* FunctionOuter; // Offset: 0x28 // Size: 0x08
	struct FName FunctionName; // Offset: 0x30 // Size: 0x08
	char pad_0x38[0x10]; // Offset: 0x38 // Size: 0x10

	// Functions

	// Object Name: Function Skill.SharedDelegate.EventTrigger
	// Flags: [Final|Native|Public|BlueprintCallable]
	void EventTrigger(); // Offset: 0x105388e04 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Skill.SharedDelegateManager
// Size: 0xd0 // Inherited bytes: 0x30
struct USharedDelegateManager : UWorldSubsystem {
	// Fields
	struct TMap<struct FSharedDelegateWrap, struct USharedDelegate*> DelegateMap; // Offset: 0x30 // Size: 0x50
	struct TMap<struct FMultiSharedDelegateWrap, struct USharedDelegate*> MultiDelegateMap; // Offset: 0x80 // Size: 0x50
};

// Object Name: Class Skill.UTSkillAction_Lua
// Size: 0x160 // Inherited bytes: 0xa0
struct UUTSkillAction_Lua : UUTSkillAction {
	// Fields
	char pad_0xA0[0x60]; // Offset: 0xa0 // Size: 0x60
	struct TMap<struct FName, struct FString> ActionParams; // Offset: 0x100 // Size: 0x50
	struct FString LuaFilePath; // Offset: 0x150 // Size: 0x10

	// Functions

	// Object Name: Function Skill.UTSkillAction_Lua.GetVectorValue
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|Const]
	struct FVector GetVectorValue(struct FName& Key); // Offset: 0x10538c288 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Skill.UTSkillAction_Lua.GetStringValue
	// Flags: [Final|Native|Public|HasOutParms|Const]
	struct FString GetStringValue(struct FName& Key); // Offset: 0x10538c144 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Skill.UTSkillAction_Lua.GetIntValue
	// Flags: [Final|Native|Public|HasOutParms|Const]
	int GetIntValue(struct FName& Key); // Offset: 0x10538c030 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Skill.UTSkillAction_Lua.GetFloatValue
	// Flags: [Final|Native|Public|HasOutParms|Const]
	float GetFloatValue(struct FName& Key); // Offset: 0x10538bf1c // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Skill.UTSkillAction_Lua.GetBoolValue
	// Flags: [Final|Native|Public|HasOutParms|Const]
	bool GetBoolValue(struct FName& Key); // Offset: 0x10538be04 // Return & Params: Num(2) Size(0x9)
};

// Object Name: Class Skill.UTSkillBlackboardInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UUTSkillBlackboardInterface : UInterface {
	// Functions

	// Object Name: Function Skill.UTSkillBlackboardInterface.SetValueAsWeakObject
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	void SetValueAsWeakObject(int SkillID, struct FUAEBlackboardKeySelector& Key, struct UObject* ObjectValue); // Offset: 0x10538f674 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Skill.UTSkillBlackboardInterface.SetValueAsVector
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void SetValueAsVector(int SkillID, struct FUAEBlackboardKeySelector& Key, struct FVector VectorValue); // Offset: 0x10538f498 // Return & Params: Num(3) Size(0x1c)

	// Object Name: Function Skill.UTSkillBlackboardInterface.SetValueAsString
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	void SetValueAsString(int SkillID, struct FUAEBlackboardKeySelector& Key, struct FString StringValue); // Offset: 0x10538f260 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Skill.UTSkillBlackboardInterface.SetValueAsRotator
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void SetValueAsRotator(int SkillID, struct FUAEBlackboardKeySelector& Key, struct FRotator VectorValue); // Offset: 0x10538f084 // Return & Params: Num(3) Size(0x1c)

	// Object Name: Function Skill.UTSkillBlackboardInterface.SetValueAsObject
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	void SetValueAsObject(int SkillID, struct FUAEBlackboardKeySelector& Key, struct UObject* ObjectValue); // Offset: 0x10538eec8 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Skill.UTSkillBlackboardInterface.SetValueAsName
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	void SetValueAsName(int SkillID, struct FUAEBlackboardKeySelector& Key, struct FName NameValue); // Offset: 0x10538ece4 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Skill.UTSkillBlackboardInterface.SetValueAsInt
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	void SetValueAsInt(int SkillID, struct FUAEBlackboardKeySelector& Key, int IntValue); // Offset: 0x10538eb28 // Return & Params: Num(3) Size(0x14)

	// Object Name: Function Skill.UTSkillBlackboardInterface.SetValueAsFloat
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	void SetValueAsFloat(int SkillID, struct FUAEBlackboardKeySelector& Key, float FloatValue); // Offset: 0x10538e96c // Return & Params: Num(3) Size(0x14)

	// Object Name: Function Skill.UTSkillBlackboardInterface.SetValueAsEnum
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	void SetValueAsEnum(int SkillID, struct FUAEBlackboardKeySelector& Key, char EnumValue); // Offset: 0x10538e7b0 // Return & Params: Num(3) Size(0x11)

	// Object Name: Function Skill.UTSkillBlackboardInterface.SetValueAsClass
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	void SetValueAsClass(int SkillID, struct FUAEBlackboardKeySelector& Key, struct UObject* ClassValue); // Offset: 0x10538e5f4 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Skill.UTSkillBlackboardInterface.SetValueAsBool
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	void SetValueAsBool(int SkillID, struct FUAEBlackboardKeySelector& Key, bool BoolValue); // Offset: 0x10538e418 // Return & Params: Num(3) Size(0x11)

	// Object Name: Function Skill.UTSkillBlackboardInterface.IsExistWeakObject
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	bool IsExistWeakObject(int SkillID, struct FUAEBlackboardKeySelector& Key); // Offset: 0x10538e2b0 // Return & Params: Num(3) Size(0x11)

	// Object Name: Function Skill.UTSkillBlackboardInterface.IsExistVector
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	bool IsExistVector(int SkillID, struct FUAEBlackboardKeySelector& Key); // Offset: 0x10538e148 // Return & Params: Num(3) Size(0x11)

	// Object Name: Function Skill.UTSkillBlackboardInterface.IsExistString
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	bool IsExistString(int SkillID, struct FUAEBlackboardKeySelector& Key); // Offset: 0x10538dfe0 // Return & Params: Num(3) Size(0x11)

	// Object Name: Function Skill.UTSkillBlackboardInterface.IsExistRotator
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	bool IsExistRotator(int SkillID, struct FUAEBlackboardKeySelector& Key); // Offset: 0x10538de78 // Return & Params: Num(3) Size(0x11)

	// Object Name: Function Skill.UTSkillBlackboardInterface.IsExistObject
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	bool IsExistObject(int SkillID, struct FUAEBlackboardKeySelector& Key); // Offset: 0x10538dd10 // Return & Params: Num(3) Size(0x11)

	// Object Name: Function Skill.UTSkillBlackboardInterface.IsExistName
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	bool IsExistName(int SkillID, struct FUAEBlackboardKeySelector& Key); // Offset: 0x10538dba8 // Return & Params: Num(3) Size(0x11)

	// Object Name: Function Skill.UTSkillBlackboardInterface.IsExistInt
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	bool IsExistInt(int SkillID, struct FUAEBlackboardKeySelector& Key); // Offset: 0x10538da40 // Return & Params: Num(3) Size(0x11)

	// Object Name: Function Skill.UTSkillBlackboardInterface.IsExistFloat
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	bool IsExistFloat(int SkillID, struct FUAEBlackboardKeySelector& Key); // Offset: 0x10538d8d8 // Return & Params: Num(3) Size(0x11)

	// Object Name: Function Skill.UTSkillBlackboardInterface.IsExistEnum
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	bool IsExistEnum(int SkillID, struct FUAEBlackboardKeySelector& Key); // Offset: 0x10538d770 // Return & Params: Num(3) Size(0x11)

	// Object Name: Function Skill.UTSkillBlackboardInterface.IsExistClass
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	bool IsExistClass(int SkillID, struct FUAEBlackboardKeySelector& Key); // Offset: 0x10538d608 // Return & Params: Num(3) Size(0x11)

	// Object Name: Function Skill.UTSkillBlackboardInterface.IsExistBool
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	bool IsExistBool(int SkillID, struct FUAEBlackboardKeySelector& Key); // Offset: 0x10538d4a0 // Return & Params: Num(3) Size(0x11)

	// Object Name: Function Skill.UTSkillBlackboardInterface.GetValueAsVector
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct FVector GetValueAsVector(int SkillID, struct FUAEBlackboardKeySelector& Key); // Offset: 0x10538d324 // Return & Params: Num(3) Size(0x1c)

	// Object Name: Function Skill.UTSkillBlackboardInterface.GetValueAsString
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	struct FString GetValueAsString(int SkillID, struct FUAEBlackboardKeySelector& Key); // Offset: 0x10538d190 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Skill.UTSkillBlackboardInterface.GetValueAsRotator
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct FRotator GetValueAsRotator(int SkillID, struct FUAEBlackboardKeySelector& Key); // Offset: 0x10538d014 // Return & Params: Num(3) Size(0x1c)

	// Object Name: Function Skill.UTSkillBlackboardInterface.GetValueAsName
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	struct FName GetValueAsName(int SkillID, struct FUAEBlackboardKeySelector& Key); // Offset: 0x10538cea8 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Skill.UTSkillBlackboardInterface.GetValueAsInt
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	int GetValueAsInt(int SkillID, struct FUAEBlackboardKeySelector& Key); // Offset: 0x10538cd44 // Return & Params: Num(3) Size(0x14)

	// Object Name: Function Skill.UTSkillBlackboardInterface.GetValueAsFloat
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	float GetValueAsFloat(int SkillID, struct FUAEBlackboardKeySelector& Key); // Offset: 0x10538cbe0 // Return & Params: Num(3) Size(0x14)

	// Object Name: Function Skill.UTSkillBlackboardInterface.GetValueAsEnum
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	char GetValueAsEnum(int SkillID, struct FUAEBlackboardKeySelector& Key); // Offset: 0x10538ca7c // Return & Params: Num(3) Size(0x11)

	// Object Name: Function Skill.UTSkillBlackboardInterface.GetValueAsClass
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	struct UObject* GetValueAsClass(int SkillID, struct FUAEBlackboardKeySelector& Key); // Offset: 0x10538c918 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Skill.UTSkillBlackboardInterface.GetValueAsBool
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	bool GetValueAsBool(int SkillID, struct FUAEBlackboardKeySelector& Key); // Offset: 0x10538c7b0 // Return & Params: Num(3) Size(0x11)

	// Object Name: Function Skill.UTSkillBlackboardInterface.GetUAEBlackboardBySkillId
	// Flags: [Native|Public|BlueprintCallable]
	struct UUAEBlackboard* GetUAEBlackboardBySkillId(int SkillID); // Offset: 0x10538c6e4 // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class Skill.UTSkillCDBase
// Size: 0xc8 // Inherited bytes: 0xa0
struct UUTSkillCDBase : ULuaObject {
	// Fields
	struct TWeakObjectPtr<struct UUTSkillManagerComponent> OwnerSkillManager; // Offset: 0xa0 // Size: 0x08
	struct TWeakObjectPtr<struct AUTSkill> OwnerSkill; // Offset: 0xa8 // Size: 0x08
	struct TArray<char> SyncContent; // Offset: 0xb0 // Size: 0x10
	bool bIgnoreCastSkillCheck; // Offset: 0xc0 // Size: 0x01
	char pad_0xC1[0x7]; // Offset: 0xc1 // Size: 0x07

	// Functions

	// Object Name: Function Skill.UTSkillCDBase.BindLua
	// Flags: [Final|Native|Public]
	void BindLua(struct FString luaPath); // Offset: 0x10539038c // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class Skill.UTSkillCondition_Lua
// Size: 0xd0 // Inherited bytes: 0x60
struct UUTSkillCondition_Lua : UUTSkillCondition {
	// Fields
	char pad_0x60[0x60]; // Offset: 0x60 // Size: 0x60
	struct FString LuaFilePath; // Offset: 0xc0 // Size: 0x10
};

// Object Name: Class Skill.UTSkillEvent
// Size: 0x30 // Inherited bytes: 0x28
struct UUTSkillEvent : UObject {
	// Fields
	enum class UTSkillEventType SkillEventType; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x7]; // Offset: 0x29 // Size: 0x07
};

// Object Name: Class Skill.UTSkillInstancedNodeContainerInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UUTSkillInstancedNodeContainerInterface : UInterface {
};

// Object Name: Class Skill.UTSkillInstancedNodeInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UUTSkillInstancedNodeInterface : UInterface {
};

// Object Name: Class Skill.UTSkillFunctionBase
// Size: 0x78 // Inherited bytes: 0x60
struct UUTSkillFunctionBase : UUTSkillBaseWidget {
	// Fields
	struct FSkillFuncNameSelector DoActionFuncKey; // Offset: 0x60 // Size: 0x08
	struct FSkillFuncNameSelector UndoActionFuncKey; // Offset: 0x68 // Size: 0x08
	struct FSkillFuncNameSelector ConditionFuncKey; // Offset: 0x70 // Size: 0x08
};

// Object Name: Class Skill.UTSkillSpecificAction
// Size: 0xb0 // Inherited bytes: 0xa0
struct UUTSkillSpecificAction : UUTSkillAction {
	// Fields
	struct FSkillFuncNameSelector DoActionFuncKey; // Offset: 0xa0 // Size: 0x08
	struct FSkillFuncNameSelector UndoActionFuncKey; // Offset: 0xa8 // Size: 0x08

	// Functions

	// Object Name: Function Skill.UTSkillSpecificAction.UpdateAction_Internal
	// Flags: [Native|Public|BlueprintCallable]
	void UpdateAction_Internal(float DeltaSeconds); // Offset: 0x1053b6dc4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Skill.UTSkillSpecificAction.UndoAction_Internal
	// Flags: [Native|Public|BlueprintCallable]
	void UndoAction_Internal(); // Offset: 0x1053b6d68 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillSpecificAction.Reset_Internal
	// Flags: [Native|Public|BlueprintCallable]
	void Reset_Internal(); // Offset: 0x1053b6d0c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Skill.UTSkillSpecificAction.RealDoAction_Internal
	// Flags: [Native|Public|BlueprintCallable]
	bool RealDoAction_Internal(); // Offset: 0x1053b6ca4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Skill.UTSkillSpecificAction.PreCloseSkill
	// Flags: [Native|Public]
	void PreCloseSkill(struct UUTSkillManagerComponent* SkillManagerComponent, struct AUTSkill* CurOwnerSkill); // Offset: 0x1053b6b80 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillSpecificAction.PostInitSkill
	// Flags: [Native|Public]
	void PostInitSkill(struct UUTSkillManagerComponent* SkillManagerComponent, struct AUTSkill* CurOwnerSkill); // Offset: 0x1053b6a5c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Skill.UTSkillSpecificAction.PostActiveSkill
	// Flags: [Native|Public]
	void PostActiveSkill(struct UUTSkillManagerComponent* SkillManagerComponent, struct AUTSkill* CurOwnerSkill); // Offset: 0x1053b6938 // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class Skill.UTSkillSpecificCondition
// Size: 0x68 // Inherited bytes: 0x60
struct UUTSkillSpecificCondition : UUTSkillCondition {
	// Fields
	struct FSkillFuncNameSelector ConditionFuncKey; // Offset: 0x60 // Size: 0x08
};

// Object Name: Class Skill.SkillUtil
// Size: 0x28 // Inherited bytes: 0x28
struct USkillUtil : UBlueprintFunctionLibrary {
};

