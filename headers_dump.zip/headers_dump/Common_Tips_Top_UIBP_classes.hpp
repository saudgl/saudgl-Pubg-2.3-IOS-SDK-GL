#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Common_Tips_Top_UIBP.Common_Tips_Top_UIBP_C
// Size: 0x270 // Inherited bytes: 0x260
struct UCommon_Tips_Top_UIBP_C : UUserWidget {
	// Fields
	struct UWidgetAnimation* Anima_In; // Offset: 0x260 // Size: 0x08
	struct UUTRichTextBlock* Text; // Offset: 0x268 // Size: 0x08
};

