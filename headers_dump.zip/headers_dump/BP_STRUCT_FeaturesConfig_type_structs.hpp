#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_FeaturesConfig_type.BP_STRUCT_FeaturesConfig_type
// Size: 0xe8 // Inherited bytes: 0x00
struct FBP_STRUCT_FeaturesConfig_type {
	// Fields
	int ExpressionID_0_00785A007C9D13EC165BDB12033C53D4; // Offset: 0x00 // Size: 0x04
	int ID_1_450A0E005D3EA5DA2CF450BC0B69C9B4; // Offset: 0x04 // Size: 0x04
	int FeatureType_2_051BE64069DB452541D6016D0010CE45; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct FString BtnIcon_3_559DD600627DCF682863307A0F2466CE; // Offset: 0x10 // Size: 0x10
	struct FString DeadBox_4_7EA4508064394B5A0D5DC10E0C0115F8; // Offset: 0x20 // Size: 0x10
	struct FString BtnDesc_5_67A8B3805F3218D42867819C0F243003; // Offset: 0x30 // Size: 0x10
	int ExpressionCD_6_665B188001C1BF52165BDBD5033C5374; // Offset: 0x40 // Size: 0x04
	int FightExpressionID_7_76F3D6801B83E68C1FA06CA40ECB7174; // Offset: 0x44 // Size: 0x04
	struct FString StoreClickAction_8_5B7D9F004E4A745E7EC377B60E2843CE; // Offset: 0x48 // Size: 0x10
	struct FString Sounds_9_5B11E9C002EEB1D9167D0CC4090DED73; // Offset: 0x58 // Size: 0x10
	struct FString Video_10_6D956880539823F61B937EA20C8A4C2F; // Offset: 0x68 // Size: 0x10
	struct FString SoundsTime_11_7BD26D804F9697F4599E67720D71A3D5; // Offset: 0x78 // Size: 0x10
	int ExcludeJPKR_12_78F30B002489EA202715F4C1073395A2; // Offset: 0x88 // Size: 0x04
	int DeadBoxScale_14_7E032A8065DB969442450ED70F198775; // Offset: 0x8c // Size: 0x04
	int EnterExpressionFrequency_15_6F8242C016F7432B75E1F2E00076E029; // Offset: 0x90 // Size: 0x04
	int EnterExpressionID_16_7411998036C40FC436054ADD00CFD644; // Offset: 0x94 // Size: 0x04
	bool HideUI_17_4E5630C01503A8DB564E54AB0984C359; // Offset: 0x98 // Size: 0x01
	char pad_0x99[0x7]; // Offset: 0x99 // Size: 0x07
	struct FString ActorVoiceList_18_3D19ED803608BDA6458D8F1C0E47A6E4; // Offset: 0xa0 // Size: 0x10
	int GPromptShow_19_43BE254029D83AFD53A68D0B08E352B7; // Offset: 0xb0 // Size: 0x04
	int EffectDuration_20_0AF44F8018255D021937804A0B2ACF3E; // Offset: 0xb4 // Size: 0x04
	struct FString HitEffect_21_56AA674053A788AB361266EA0E205214; // Offset: 0xb8 // Size: 0x10
	bool isEnterExpressionBottomOnSkip_22_42001F80507BBA34066DF3840E1FC8B0; // Offset: 0xc8 // Size: 0x01
	bool isVideoBottomOnClickShowUI_23_4927D540193426B117AFB5550A7C9D49; // Offset: 0xc9 // Size: 0x01
	char pad_0xCA[0x2]; // Offset: 0xca // Size: 0x02
	int VideoAutoBottomTimer_24_6EEE2C40341B88C3272B3D3D0BD67812; // Offset: 0xcc // Size: 0x04
	bool isEnterExpressionForceView_25_28DECFC001BF4EDB319ECE6101650E07; // Offset: 0xd0 // Size: 0x01
	bool isVideoForceView_26_771142003A11673E1F2C027A0EF2AF07; // Offset: 0xd1 // Size: 0x01
	char pad_0xD2[0x2]; // Offset: 0xd2 // Size: 0x02
	int DescID_27_1FDF0DC0447C095B13C3825E09C7FE14; // Offset: 0xd4 // Size: 0x04
	struct FString FeatureVoiceList_28_35826240443F31151ADFAE790D993D14; // Offset: 0xd8 // Size: 0x10
};

