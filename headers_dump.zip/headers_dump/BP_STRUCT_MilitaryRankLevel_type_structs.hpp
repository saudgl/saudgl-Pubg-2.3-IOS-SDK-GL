#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_MilitaryRankLevel_type.BP_STRUCT_MilitaryRankLevel_type
// Size: 0x64 // Inherited bytes: 0x00
struct FBP_STRUCT_MilitaryRankLevel_type {
	// Fields
	struct FString MilitaryRankName_0_6803185A4F44EE4389F6A3B24C13845F; // Offset: 0x00 // Size: 0x10
	int Exp_1_0727D7694F81C282360C298C96801A35; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct FString MilitaryRankType_2_F858884B40EBC459D56457B1741D963D; // Offset: 0x18 // Size: 0x10
	int Level_3_756F8DA14F48640682AFFFBD2A052F83; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct FString MilitaryRankBigIconPath_4_9A4E25B74B0B8657724BD1AD59F3CB7C; // Offset: 0x30 // Size: 0x10
	struct FString MilitaryRankSmallIconPath_5_F068C6BA4EB3CFAFA8CD159178EB8765; // Offset: 0x40 // Size: 0x10
	struct FString MilitaryRankTypeIconPath_6_9AE9634945BC5B59F5709EB9C63E9970; // Offset: 0x50 // Size: 0x10
	int NewExp_7_6999CF00319D98A86C1DE90507E74340; // Offset: 0x60 // Size: 0x04
};

