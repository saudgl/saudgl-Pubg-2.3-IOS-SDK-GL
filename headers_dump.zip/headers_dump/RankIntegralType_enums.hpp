#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedEnum RankIntegralType.RankIntegralType
enum class RankIntegralType : uint8 {
	NewEnumerator2 = 0,
	NewEnumerator3 = 1,
	NewEnumerator1 = 2,
	NewEnumerator0 = 3,
	NewEnumerator5 = 4,
	NewEnumerator6 = 5,
	NewEnumerator7 = 6,
	RankIntegralType_MAX = 7
};

