#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class UnrealArchExt.UAEUserWidget
// Size: 0x418 // Inherited bytes: 0x260
struct UUAEUserWidget : UUserWidget {
	// Fields
	struct UFrontendHUD* OwningFrontendHUD; // Offset: 0x260 // Size: 0x08
	struct ULogicManagerBase* OwningLogicManager; // Offset: 0x268 // Size: 0x08
	struct UUAEWidgetContainer* OwningWidgetContainer; // Offset: 0x270 // Size: 0x08
	struct UUAEUserWidget* ParentWidget; // Offset: 0x278 // Size: 0x08
	char pad_0x280[0xa0]; // Offset: 0x280 // Size: 0xa0
	struct TArray<struct UProperty*> Params; // Offset: 0x320 // Size: 0x10
	char pad_0x330[0x10]; // Offset: 0x330 // Size: 0x10
	struct FScriptMulticastDelegate widgetSizeNofity; // Offset: 0x340 // Size: 0x10
	struct FUserWidgetState DefaultUserWidgetState; // Offset: 0x350 // Size: 0x28
	struct FUserWidgetState CurrentUserWidgetState; // Offset: 0x378 // Size: 0x28
	float TickRate; // Offset: 0x3a0 // Size: 0x04
	bool bReceiveOnClickedEvent; // Offset: 0x3a4 // Size: 0x01
	bool bReceiveOnRightClickedEvent; // Offset: 0x3a5 // Size: 0x01
	bool bReceiveOnDoubleClickedEvent; // Offset: 0x3a6 // Size: 0x01
	bool bAutoSetScreenPosOnMouseEnter; // Offset: 0x3a7 // Size: 0x01
	struct FVector2D ScreenPos; // Offset: 0x3a8 // Size: 0x08
	struct FVector2D LastMouseEventScreenPos; // Offset: 0x3b0 // Size: 0x08
	char pad_0x3B8[0x8]; // Offset: 0x3b8 // Size: 0x08
	enum class EUserWidgetFadingStatus FadingStatus; // Offset: 0x3c0 // Size: 0x01
	char pad_0x3C1[0x3]; // Offset: 0x3c1 // Size: 0x03
	float CurrentOpacity; // Offset: 0x3c4 // Size: 0x04
	float FadingInTime; // Offset: 0x3c8 // Size: 0x04
	float FadingOutTime; // Offset: 0x3cc // Size: 0x04
	bool bNoFadeIn; // Offset: 0x3d0 // Size: 0x01
	bool bNoFadeOut; // Offset: 0x3d1 // Size: 0x01
	bool bShouldCollapse; // Offset: 0x3d2 // Size: 0x01
	bool bRegistUIMsg; // Offset: 0x3d3 // Size: 0x01
	char pad_0x3D4[0x4]; // Offset: 0x3d4 // Size: 0x04
	struct FString UIMsgPrefix; // Offset: 0x3d8 // Size: 0x10
	struct TArray<struct FString> UIMsgFunctionList; // Offset: 0x3e8 // Size: 0x10
	bool bRegistedUIMsgToMoudle; // Offset: 0x3f8 // Size: 0x01
	char pad_0x3F9[0x7]; // Offset: 0x3f9 // Size: 0x07
	struct FString MoudleToRegisted; // Offset: 0x400 // Size: 0x10
	char pad_0x410[0x8]; // Offset: 0x410 // Size: 0x08

	// Functions

	// Object Name: Function UnrealArchExt.UAEUserWidget.Visible
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool Visible(); // Offset: 0x10531c700 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UnrealArchExt.UAEUserWidget.UnRegistFromGameFrontendHUD
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UnRegistFromGameFrontendHUD(); // Offset: 0x10531c6ec // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UnrealArchExt.UAEUserWidget.SynchronizeBlueprintProperties
	// Flags: [Event|Public|BlueprintEvent]
	void SynchronizeBlueprintProperties(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UnrealArchExt.UAEUserWidget.Show
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Show(); // Offset: 0x10531c6d8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UnrealArchExt.UAEUserWidget.SetParentWidgetRecursive
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetParentWidgetRecursive(struct UUAEUserWidget* InParentWidget); // Offset: 0x10531c65c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UnrealArchExt.UAEUserWidget.SetParentWidget
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetParentWidget(struct UUAEUserWidget* InParentWidget); // Offset: 0x10531c5e0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UnrealArchExt.UAEUserWidget.SetOnWidgetShow
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetOnWidgetShow(DelegateProperty onShow); // Offset: 0x10531c558 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UnrealArchExt.UAEUserWidget.SetOnWidgetHide
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetOnWidgetHide(DelegateProperty OnHide); // Offset: 0x10531c4d0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UnrealArchExt.UAEUserWidget.SetOnClearUIStack
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetOnClearUIStack(DelegateProperty onClear); // Offset: 0x10531c448 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UnrealArchExt.UAEUserWidget.SetAdapation
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAdapation(float Left, float Top, float Right, float Bottom); // Offset: 0x10531c31c // Return & Params: Num(4) Size(0x10)

	// Object Name: Function UnrealArchExt.UAEUserWidget.RegistToGameFrontendHUD
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RegistToGameFrontendHUD(struct UFrontendHUD* GameFrontHUD); // Offset: 0x10531c2a0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UnrealArchExt.UAEUserWidget.Register
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Register(struct ULogicManagerBase* LogicManager, bool bAddToViewport); // Offset: 0x10531c1e0 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function UnrealArchExt.UAEUserWidget.ReceiveShow
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveShow(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UnrealArchExt.UAEUserWidget.ReceiveHide
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveHide(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UnrealArchExt.UAEUserWidget.ReceivedMountWidget
	// Flags: [Native|Event|Public|BlueprintEvent]
	void ReceivedMountWidget(); // Offset: 0x10531c1c4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UnrealArchExt.UAEUserWidget.ReceivedInitWidget
	// Flags: [Event|Public|BlueprintEvent]
	void ReceivedInitWidget(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UnrealArchExt.UAEUserWidget.ReCachedUIMsgFunction
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ReCachedUIMsgFunction(); // Offset: 0x10531c1b0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UnrealArchExt.UAEUserWidget.PushOpenedUIStack
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void PushOpenedUIStack(struct FString Name); // Offset: 0x10531c120 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UnrealArchExt.UAEUserWidget.PopOpenedUIStack
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void PopOpenedUIStack(struct FString curOpen); // Offset: 0x10531c090 // Return & Params: Num(1) Size(0x10)

	// Object Name: DelegateFunction UnrealArchExt.UAEUserWidget.OnWidgetShow__DelegateSignature
	// Flags: [Public|Delegate]
	void OnWidgetShow__DelegateSignature(struct FString ClassName); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x10)

	// Object Name: DelegateFunction UnrealArchExt.UAEUserWidget.OnWidgetHide__DelegateSignature
	// Flags: [Public|Delegate]
	void OnWidgetHide__DelegateSignature(struct FString ClassName); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UnrealArchExt.UAEUserWidget.OnRightClicked
	// Flags: [Event|Public|HasDefaults|BlueprintEvent]
	void OnRightClicked(struct FVector2D TempScreenPos); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UnrealArchExt.UAEUserWidget.OnFadeOutFinished
	// Flags: [Native|Event|Protected|BlueprintEvent]
	void OnFadeOutFinished(); // Offset: 0x10531c074 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UnrealArchExt.UAEUserWidget.OnFadeInFinished
	// Flags: [Native|Event|Protected|BlueprintEvent]
	void OnFadeInFinished(); // Offset: 0x10531c058 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UnrealArchExt.UAEUserWidget.OnDoubleClicked
	// Flags: [Event|Public|HasDefaults|BlueprintEvent]
	void OnDoubleClicked(struct FVector2D TempScreenPos); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UnrealArchExt.UAEUserWidget.OnClicked
	// Flags: [Event|Public|HasDefaults|BlueprintEvent]
	void OnClicked(struct FVector2D TempScreenPos); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x8)

	// Object Name: DelegateFunction UnrealArchExt.UAEUserWidget.OnClearUIStack__DelegateSignature
	// Flags: [Public|Delegate]
	void OnClearUIStack__DelegateSignature(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UnrealArchExt.UAEUserWidget.IntCompare
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	bool IntCompare(int A, int B, enum class EWidgetCompareType CompareType); // Offset: 0x10531bf58 // Return & Params: Num(4) Size(0xa)

	// Object Name: Function UnrealArchExt.UAEUserWidget.InitWidget
	// Flags: [Final|Native|Public|BlueprintCallable]
	void InitWidget(bool Recursive); // Offset: 0x10531bed4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UnrealArchExt.UAEUserWidget.InitCustomWidget
	// Flags: [Native|Public]
	void InitCustomWidget(struct AActor* OwnerActor, struct UWidgetComponent* WidgetComponent); // Offset: 0x10531be18 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UnrealArchExt.UAEUserWidget.Hide
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Hide(); // Offset: 0x10531be04 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UnrealArchExt.UAEUserWidget.HandleUIMessageBattle
	// Flags: [Final|Native|Public|BlueprintCallable]
	void HandleUIMessageBattle(struct FString UIMessage); // Offset: 0x10531bd6c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UnrealArchExt.UAEUserWidget.HandleUIMessage
	// Flags: [Final|Native|Public]
	void HandleUIMessage(struct FString UIMessage); // Offset: 0x10531bcd4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UnrealArchExt.UAEUserWidget.GetWidgetsByName
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UWidget* GetWidgetsByName(struct FString WidgetName, struct FString OuterName, bool bUseContains); // Offset: 0x10531bb90 // Return & Params: Num(4) Size(0x30)

	// Object Name: Function UnrealArchExt.UAEUserWidget.GetWidgetContainsName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UWidget* GetWidgetContainsName(struct FString Name); // Offset: 0x10531bae8 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function UnrealArchExt.UAEUserWidget.GetParentWidget
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UUAEUserWidget* GetParentWidget(); // Offset: 0x10531bab4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UnrealArchExt.UAEUserWidget.GetOwningPlayer
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct APlayerController* GetOwningPlayer(); // Offset: 0x10531ba78 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UnrealArchExt.UAEUserWidget.GetOwningLogicManager
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct ULogicManagerBase* GetOwningLogicManager(); // Offset: 0x10531ba44 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UnrealArchExt.UAEUserWidget.GetOwningFrontendHUD
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UFrontendHUD* GetOwningFrontendHUD(); // Offset: 0x10531ba10 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UnrealArchExt.UAEUserWidget.GetImgDynamicMaterial
	// Flags: [Final|Native|Protected|BlueprintCallable]
	struct UMaterialInstanceDynamic* GetImgDynamicMaterial(struct UImage* ImageMat); // Offset: 0x10531b984 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UnrealArchExt.UAEUserWidget.GetChildWidgetByEqualPolitics
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	struct UUserWidget* GetChildWidgetByEqualPolitics(struct FString ChildName, enum class EUserWidgetNameEqualPolitics EqualPolitics, int RecursiveDepth); // Offset: 0x10531b85c // Return & Params: Num(4) Size(0x20)

	// Object Name: Function UnrealArchExt.UAEUserWidget.GetChildWidget
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UUserWidget* GetChildWidget(struct FString WName); // Offset: 0x10531b7b4 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function UnrealArchExt.UAEUserWidget.GetAdapation
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FMargin GetAdapation(); // Offset: 0x10531b774 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UnrealArchExt.UAEUserWidget.FloatCompare
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	bool FloatCompare(float A, float B, enum class EWidgetCompareType CompareType); // Offset: 0x10531b674 // Return & Params: Num(4) Size(0xa)

	// Object Name: Function UnrealArchExt.UAEUserWidget.DynamicRegistUIMsgToCache
	// Flags: [Final|Native|Public|BlueprintCallable]
	void DynamicRegistUIMsgToCache(struct UUAEUserWidget* Widget); // Offset: 0x10531b5f8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UnrealArchExt.UAEUserWidget.DestroyWidget
	// Flags: [Final|Native|Public|BlueprintCallable]
	void DestroyWidget(); // Offset: 0x10531b5e4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UnrealArchExt.UAEUserWidget.ClearOpenedUIStack
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ClearOpenedUIStack(); // Offset: 0x10531b5d0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UnrealArchExt.UAEUserWidget.ClearFunctionCacheByMsgName
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearFunctionCacheByMsgName(struct FString InUIMsg); // Offset: 0x10531b538 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UnrealArchExt.UAEUserWidget.ClearFunctionCache
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearFunctionCache(); // Offset: 0x10531b524 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UnrealArchExt.UAEUserWidget.ClearClassWidgetTree
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearClassWidgetTree(); // Offset: 0x10531b510 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UnrealArchExt.UAEUserWidget.BindCustomUserEvent
	// Flags: [Native|Public]
	void BindCustomUserEvent(struct AActor* OwnerActor, struct UWidgetComponent* WidgetComponent); // Offset: 0x10531b454 // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class UnrealArchExt.LuaUAEUserWidget
// Size: 0x490 // Inherited bytes: 0x418
struct ULuaUAEUserWidget : UUAEUserWidget {
	// Fields
	char pad_0x418[0x60]; // Offset: 0x418 // Size: 0x60
	struct FString LuaFilePath; // Offset: 0x478 // Size: 0x10
	bool bEnableBlueprintTick; // Offset: 0x488 // Size: 0x01
	char pad_0x489[0x7]; // Offset: 0x489 // Size: 0x07
};

// Object Name: Class UnrealArchExt.UAECanvasPanel
// Size: 0x130 // Inherited bytes: 0x130
struct UUAECanvasPanel : UCanvasPanel {
	// Functions

	// Object Name: Function UnrealArchExt.UAECanvasPanel.ReceiveInitCanvasPanel
	// Flags: [Native|Event|Protected|BlueprintEvent]
	void ReceiveInitCanvasPanel(); // Offset: 0x105319988 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class UnrealArchExt.BackendUtils
// Size: 0x30 // Inherited bytes: 0x28
struct UBackendUtils : UObject {
	// Fields
	struct UBackendHUD* OwningBackendHUD; // Offset: 0x28 // Size: 0x08
};

// Object Name: Class UnrealArchExt.BackendHUD
// Size: 0xb0 // Inherited bytes: 0x28
struct UBackendHUD : UObject {
	// Fields
	struct UEngine* Engine; // Offset: 0x28 // Size: 0x08
	struct FString BackendUtilsClassName; // Offset: 0x30 // Size: 0x10
	struct UBackendUtils* Utils; // Offset: 0x40 // Size: 0x08
	struct TArray<struct UFrontendHUD*> FrontendHUDList; // Offset: 0x48 // Size: 0x10
	struct TMap<uint32_t, struct TWeakObjectPtr<struct UFrontendHUD>> FrontendHUDMap; // Offset: 0x58 // Size: 0x50
	char pad_0xA8[0x8]; // Offset: 0xa8 // Size: 0x08

	// Functions

	// Object Name: Function UnrealArchExt.BackendHUD.GetFrontendHUDByGameInstance
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UFrontendHUD* GetFrontendHUDByGameInstance(struct UGameInstance* GameInstance); // Offset: 0x1053153b4 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UnrealArchExt.BackendHUD.GetFrontendHUD
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UFrontendHUD* GetFrontendHUD(int FrontendHUDIndex); // Offset: 0x105315328 // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class UnrealArchExt.LogicManagerBase
// Size: 0xf8 // Inherited bytes: 0x28
struct ULogicManagerBase : UObject {
	// Fields
	char pad_0x28[0x10]; // Offset: 0x28 // Size: 0x10
	struct UFrontendHUD* OwningFrontendHUD; // Offset: 0x38 // Size: 0x08
	char pad_0x40[0x10]; // Offset: 0x40 // Size: 0x10
	bool bPersistentUI; // Offset: 0x50 // Size: 0x01
	bool bDynamicWidget; // Offset: 0x51 // Size: 0x01
	bool bKeepDynamicWidget; // Offset: 0x52 // Size: 0x01
	bool bUseNewHandleUIMessage; // Offset: 0x53 // Size: 0x01
	int iUIControlState; // Offset: 0x54 // Size: 0x04
	int DefaultSceneCameraIndex; // Offset: 0x58 // Size: 0x04
	char pad_0x5C[0x14]; // Offset: 0x5c // Size: 0x14
	struct TArray<struct FName> GameStatusList; // Offset: 0x70 // Size: 0x10
	char pad_0x80[0x30]; // Offset: 0x80 // Size: 0x30
	struct TArray<struct UObject*> WidgetUClassList; // Offset: 0xb0 // Size: 0x10
	struct TArray<struct UUAEUserWidget*> WidgetList; // Offset: 0xc0 // Size: 0x10
	char pad_0xD0[0x18]; // Offset: 0xd0 // Size: 0x18
	struct TArray<struct UObject*> DelayMessage_Obj; // Offset: 0xe8 // Size: 0x10

	// Functions

	// Object Name: Function UnrealArchExt.LogicManagerBase.SetEnableRemoveDynamicWidgets
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetEnableRemoveDynamicWidgets(bool bEnable); // Offset: 0x105318e7c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UnrealArchExt.LogicManagerBase.IsEnableRemoveDynamicWidgets
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	bool IsEnableRemoveDynamicWidgets(); // Offset: 0x105318e48 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UnrealArchExt.LogicManagerBase.GetWidgetList
	// Flags: [Final|Native|Public]
	struct TArray<struct UUAEUserWidget*> GetWidgetList(); // Offset: 0x105318de4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UnrealArchExt.LogicManagerBase.GetWidgetByName
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UUAEUserWidget* GetWidgetByName(struct FString InName); // Offset: 0x105318d3c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function UnrealArchExt.LogicManagerBase.GetWidgetByClass
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UUAEUserWidget* GetWidgetByClass(struct UObject* InClass); // Offset: 0x105318cb0 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UnrealArchExt.LogicManagerBase.GetOwningFrontendHUD
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UFrontendHUD* GetOwningFrontendHUD(); // Offset: 0x105318c7c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UnrealArchExt.LogicManagerBase.GetDefaultSceneCamera
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetDefaultSceneCamera(); // Offset: 0x105318c48 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UnrealArchExt.LogicManagerBase.DispatchUIMessage
	// Flags: [Final|Native|Public|BlueprintCallable]
	void DispatchUIMessage(struct FString UIMessage, struct UObject* Source, struct UUAEUserWidget* Target); // Offset: 0x105318b10 // Return & Params: Num(3) Size(0x20)
};

// Object Name: Class UnrealArchExt.FrontendHUD
// Size: 0x1d0 // Inherited bytes: 0x28
struct UFrontendHUD : UObject {
	// Fields
	char pad_0x28[0x18]; // Offset: 0x28 // Size: 0x18
	struct UGameInstance* GameInstance; // Offset: 0x40 // Size: 0x08
	char pad_0x48[0x8]; // Offset: 0x48 // Size: 0x08
	struct FString FrontendUtilsClassName; // Offset: 0x50 // Size: 0x10
	struct UFrontendUtils* Utils; // Offset: 0x60 // Size: 0x08
	struct TArray<struct ULogicManagerBase*> LogicManagerList; // Offset: 0x68 // Size: 0x10
	struct TMap<struct FString, struct TWeakObjectPtr<struct ULogicManagerBase>> LogicManagerMap; // Offset: 0x78 // Size: 0x50
	char pad_0xC8[0x10]; // Offset: 0xc8 // Size: 0x10
	int UnusedWidgetMinCount; // Offset: 0xd8 // Size: 0x04
	int UnusedWidgetMaxCount; // Offset: 0xdc // Size: 0x04
	int UnusedWidgetKeepTime; // Offset: 0xe0 // Size: 0x04
	float MaxLowLevelMemoryLimit; // Offset: 0xe4 // Size: 0x04
	float MaxMiddleMemoryLimit; // Offset: 0xe8 // Size: 0x04
	float MaxGCArrayObjectSize; // Offset: 0xec // Size: 0x04
	struct FName CurrentGameStatus; // Offset: 0xf0 // Size: 0x08
	struct FName LastGameStatus; // Offset: 0xf8 // Size: 0x08
	bool InComBatStatus; // Offset: 0x100 // Size: 0x01
	char pad_0x101[0x7]; // Offset: 0x101 // Size: 0x07
	struct FName PendingGameStatus; // Offset: 0x108 // Size: 0x08
	struct FString LatestGameStatusURL; // Offset: 0x110 // Size: 0x10
	struct FScriptMulticastDelegate OnPostSwitchGameStatusStartEvent; // Offset: 0x120 // Size: 0x10
	struct FScriptMulticastDelegate OnPostSwitchGameStatusEvent; // Offset: 0x130 // Size: 0x10
	struct FScriptMulticastDelegate OnPreSwitchGameStatusEvent; // Offset: 0x140 // Size: 0x10
	char pad_0x150[0x10]; // Offset: 0x150 // Size: 0x10
	struct FScriptMulticastDelegate OnGameStatusSwitchTerminate; // Offset: 0x160 // Size: 0x10
	struct FScriptMulticastDelegate OnPreSwitchGameStatusEndEvent; // Offset: 0x170 // Size: 0x10
	struct FScriptMulticastDelegate OnCreateLogicManagerListEvent; // Offset: 0x180 // Size: 0x10
	struct FScriptMulticastDelegate OnSetGameStatusEvent; // Offset: 0x190 // Size: 0x10
	struct FScriptMulticastDelegate OnAddLuaLogicManagerEvent; // Offset: 0x1a0 // Size: 0x10
	struct FScriptMulticastDelegate OnRemoveLuaLogicManagerEvent; // Offset: 0x1b0 // Size: 0x10
	struct UWorld* CurrentGameStatusWorld; // Offset: 0x1c0 // Size: 0x08
	char pad_0x1C8[0x8]; // Offset: 0x1c8 // Size: 0x08

	// Functions

	// Object Name: Function UnrealArchExt.FrontendHUD.SwitchGameStatus
	// Flags: [Native|Public|BlueprintCallable]
	void SwitchGameStatus(struct FName GameStatus, struct FString Options); // Offset: 0x10531651c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function UnrealArchExt.FrontendHUD.StandAloneSwitchGameStatus
	// Flags: [Native|Public|BlueprintCallable]
	void StandAloneSwitchGameStatus(struct FName InGameStatus, struct FString Options); // Offset: 0x105316418 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function UnrealArchExt.FrontendHUD.OnPreLoadMap
	// Flags: [Native|Protected]
	void OnPreLoadMap(struct FString MapName); // Offset: 0x105316378 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UnrealArchExt.FrontendHUD.OnPostLoadMapWithWorld
	// Flags: [Native|Protected]
	void OnPostLoadMapWithWorld(struct UWorld* World); // Offset: 0x1053162f4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UnrealArchExt.FrontendHUD.OnGameViewportClientCreated
	// Flags: [Final|Native|Protected]
	void OnGameViewportClientCreated(); // Offset: 0x1053162e0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UnrealArchExt.FrontendHUD.GetWorld
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UWorld* GetWorld(); // Offset: 0x1053162a4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UnrealArchExt.FrontendHUD.GetUtils
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UFrontendUtils* GetUtils(); // Offset: 0x105316270 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UnrealArchExt.FrontendHUD.GetPlayerController
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct APlayerController* GetPlayerController(); // Offset: 0x10531623c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UnrealArchExt.FrontendHUD.GetLogicManagerByName
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct ULogicManagerBase* GetLogicManagerByName(struct FString LogicManagerTagName); // Offset: 0x105316170 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function UnrealArchExt.FrontendHUD.GetLogicManager
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct ULogicManagerBase* GetLogicManager(int LogicManagerIndex); // Offset: 0x1053160e4 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UnrealArchExt.FrontendHUD.GetGameViewportClient
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UGameViewportClient* GetGameViewportClient(); // Offset: 0x1053160b0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UnrealArchExt.FrontendHUD.GetGameMode
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct AGameMode* GetGameMode(); // Offset: 0x10531607c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UnrealArchExt.FrontendHUD.GetGameInstance
	// Flags: [Final|Native|Public|Const]
	struct UGameInstance* GetGameInstance(); // Offset: 0x105316048 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UnrealArchExt.FrontendHUD.FindRegistedUIFunctionList
	// Flags: [Final|Native|Public]
	struct TArray<struct TWeakObjectPtr<struct UObject>> FindRegistedUIFunctionList(struct FString strMsg, struct FString moduleMsg); // Offset: 0x105315f24 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function UnrealArchExt.FrontendHUD.EnableGuiTest
	// Flags: [Final|Native|Public|BlueprintCallable]
	void EnableGuiTest(bool bEnable); // Offset: 0x105315ea0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UnrealArchExt.FrontendHUD.DynamicRegistUIMsgToCache
	// Flags: [Final|Native|Public|BlueprintCallable]
	void DynamicRegistUIMsgToCache(struct UUAEUserWidget* Widget, struct FString module); // Offset: 0x105315dcc // Return & Params: Num(2) Size(0x18)

	// Object Name: Function UnrealArchExt.FrontendHUD.ClearLogicManagerByName
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearLogicManagerByName(struct FString managerName); // Offset: 0x105315d10 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class UnrealArchExt.FrontendUtils
// Size: 0x398 // Inherited bytes: 0x28
struct UFrontendUtils : UObject {
	// Fields
	struct UFrontendHUD* OwningFrontendHUD; // Offset: 0x28 // Size: 0x08
	struct FScriptMulticastDelegate SceneCameraSwitchedDelegate; // Offset: 0x30 // Size: 0x10
	struct FName CurrentSceneCameraName; // Offset: 0x40 // Size: 0x08
	struct TArray<struct ACameraActor*> SceneCameraList; // Offset: 0x48 // Size: 0x10
	struct TMap<struct FName, struct TWeakObjectPtr<struct ACameraActor>> SceneCameraMap; // Offset: 0x58 // Size: 0x50
	struct TArray<struct ADirectionalLight*> SceneDirectionalLightList; // Offset: 0xa8 // Size: 0x10
	struct TMap<struct FName, struct TWeakObjectPtr<struct ADirectionalLight>> SceneDirectionalLightMap; // Offset: 0xb8 // Size: 0x50
	struct TArray<struct APointLight*> ScenePointLightList; // Offset: 0x108 // Size: 0x10
	struct TMap<struct FName, struct TWeakObjectPtr<struct APointLight>> ScenePointLightMap; // Offset: 0x118 // Size: 0x50
	struct TMap<struct FName, struct TWeakObjectPtr<struct ASkyLight>> SceneSkyLightMap; // Offset: 0x168 // Size: 0x50
	char pad_0x1B8[0x68]; // Offset: 0x1b8 // Size: 0x68
	struct FString GlobalUIEventDispatcherClassName; // Offset: 0x220 // Size: 0x10
	struct UObject* GlobalUIEventDispatcherClass; // Offset: 0x230 // Size: 0x08
	struct UObject* GlobalUIEventDispatcher; // Offset: 0x238 // Size: 0x08
	struct FString GlobalUIContainerClassName; // Offset: 0x240 // Size: 0x10
	struct TArray<struct FName> GlobalUIContainerNames; // Offset: 0x250 // Size: 0x10
	struct TMap<struct FName, struct UUAEWidgetContainer*> GlobalUIContainers; // Offset: 0x260 // Size: 0x50
	struct TArray<struct UUAEWidgetContainer*> GlobalPushUIContainers; // Offset: 0x2b0 // Size: 0x10
	struct TMap<struct FName, struct UUAEWidgetContainer*> GlobalPushUIRelations; // Offset: 0x2c0 // Size: 0x50
	char pad_0x310[0x38]; // Offset: 0x310 // Size: 0x38
	struct TMap<struct UUAEWidgetContainer*, bool> UIShowStatusMap; // Offset: 0x348 // Size: 0x50

	// Functions

	// Object Name: Function UnrealArchExt.FrontendUtils.SwitchSceneCameraToTransform
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SwitchSceneCameraToTransform(struct FTransform targetTrans, enum class ECameraProjectionMode ProjectionMode, float FOV, float blendTime, bool bForce, bool bAutoFixAspect); // Offset: 0x105317990 // Return & Params: Num(6) Size(0x3e)

	// Object Name: Function UnrealArchExt.FrontendUtils.SwitchSceneCamera
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SwitchSceneCamera(struct FName SceneCameraName, float blendTime, bool bForce); // Offset: 0x105317894 // Return & Params: Num(3) Size(0xd)

	// Object Name: Function UnrealArchExt.FrontendUtils.SetSceneSkyLightProperty
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetSceneSkyLightProperty(struct FName sceneLightName, struct FTransform targetTrans, float Intensity, struct FLinearColor Color); // Offset: 0x10531773c // Return & Params: Num(4) Size(0x54)

	// Object Name: Function UnrealArchExt.FrontendUtils.SetScenePointLightProperty
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetScenePointLightProperty(struct FName sceneLightName, struct FTransform targetTrans, float Intensity, struct FLinearColor Color, int inverseSquareFalloff, float Radius); // Offset: 0x10531756c // Return & Params: Num(6) Size(0x5c)

	// Object Name: Function UnrealArchExt.FrontendUtils.SetSceneDirectionalLightProperty
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetSceneDirectionalLightProperty(struct FName sceneLightName, struct FTransform targetTrans, float Intensity, struct FLinearColor Color, struct FLightingChannels Channel); // Offset: 0x1053173d4 // Return & Params: Num(5) Size(0x55)

	// Object Name: Function UnrealArchExt.FrontendUtils.SetAutoFixFovByAspectRatio
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAutoFixFovByAspectRatio(struct ACameraActor* CameraActor, bool bInAutoFixFov); // Offset: 0x105317314 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function UnrealArchExt.FrontendUtils.RegisterSceneSkyLight
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RegisterSceneSkyLight(struct FName sceneLightName, struct ASkyLight* Light); // Offset: 0x105317260 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UnrealArchExt.FrontendUtils.RegisterScenePointLight
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RegisterScenePointLight(struct FName sceneLightName, struct APointLight* Light); // Offset: 0x1053171ac // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UnrealArchExt.FrontendUtils.RegisterSceneDirectionalLight
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RegisterSceneDirectionalLight(struct FName sceneLightName, struct ADirectionalLight* Light); // Offset: 0x1053170f8 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UnrealArchExt.FrontendUtils.RegisterSceneCamera
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RegisterSceneCamera(struct FName SceneCameraName, struct ACameraActor* SceneCamera); // Offset: 0x105317044 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UnrealArchExt.FrontendUtils.PopAllPushedUI
	// Flags: [Final|Native|Public|BlueprintCallable]
	void PopAllPushedUI(); // Offset: 0x105317030 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UnrealArchExt.FrontendUtils.OnAllSceneCamerasRegistered
	// Flags: [Native|Public|BlueprintCallable]
	void OnAllSceneCamerasRegistered(); // Offset: 0x105317014 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UnrealArchExt.FrontendUtils.IsPushedPanel
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	bool IsPushedPanel(struct FName& managerName); // Offset: 0x105316f78 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function UnrealArchExt.FrontendUtils.IsNoRenderClient
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsNoRenderClient(); // Offset: 0x105316f44 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UnrealArchExt.FrontendUtils.GlobalUIEventDispatcher_GetDelegateIsBound
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool GlobalUIEventDispatcher_GetDelegateIsBound(struct FString DelegateNum); // Offset: 0x105316e78 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function UnrealArchExt.FrontendUtils.GetUIStackTopSrcTag
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetUIStackTopSrcTag(); // Offset: 0x105316e14 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UnrealArchExt.FrontendUtils.GetUIStackTopDstTag
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetUIStackTopDstTag(); // Offset: 0x105316db0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UnrealArchExt.FrontendUtils.GetUIStackTop
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetUIStackTop(); // Offset: 0x105316d4c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UnrealArchExt.FrontendUtils.GetSceneCamera
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct ACameraActor* GetSceneCamera(); // Offset: 0x105316d18 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UnrealArchExt.FrontendUtils.GetOwningFrontendHUD
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UFrontendHUD* GetOwningFrontendHUD(); // Offset: 0x105316ce4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UnrealArchExt.FrontendUtils.GetGlobalUIEventDispatcher
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UObject* GetGlobalUIEventDispatcher(); // Offset: 0x105316cb0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UnrealArchExt.FrontendUtils.GetGlobalUIContainer
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UUAEWidgetContainer* GetGlobalUIContainer(struct FName ContainerName); // Offset: 0x105316c24 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UnrealArchExt.FrontendUtils.EnableLobbyMainLight
	// Flags: [Final|Native|Public|BlueprintCallable]
	void EnableLobbyMainLight(bool NewEnable); // Offset: 0x105316ba0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UnrealArchExt.FrontendUtils.ClearAllSceneCameras
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearAllSceneCameras(); // Offset: 0x105316b8c // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class UnrealArchExt.TableTraver
// Size: 0x28 // Inherited bytes: 0x28
struct UTableTraver : UObject {
};

// Object Name: Class UnrealArchExt.UAEDataTable
// Size: 0x110 // Inherited bytes: 0x80
struct UUAEDataTable : UDataTable {
	// Fields
	char pad_0x80[0x30]; // Offset: 0x80 // Size: 0x30
	struct TMap<struct FString, struct UProperty*> NameToProperty; // Offset: 0xb0 // Size: 0x50
	char pad_0x100[0x10]; // Offset: 0x100 // Size: 0x10

	// Functions

	// Object Name: Function UnrealArchExt.UAEDataTable.SetTableData_String
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetTableData_String(struct FString KeyValue, struct FString TagName, struct FString Value); // Offset: 0x10531a2e4 // Return & Params: Num(4) Size(0x31)

	// Object Name: Function UnrealArchExt.UAEDataTable.SetTableData_Int32
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetTableData_Int32(struct FString KeyValue, struct FString TagName, int Value); // Offset: 0x10531a1a8 // Return & Params: Num(4) Size(0x25)

	// Object Name: Function UnrealArchExt.UAEDataTable.SetTableData_Float
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetTableData_Float(struct FString KeyValue, struct FString TagName, float Value); // Offset: 0x10531a06c // Return & Params: Num(4) Size(0x25)

	// Object Name: Function UnrealArchExt.UAEDataTable.GetTableName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetTableName(); // Offset: 0x10531a008 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UnrealArchExt.UAEDataTable.GetRealTableName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetRealTableName(struct FString tableName); // Offset: 0x105319f38 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function UnrealArchExt.UAEDataTable.ConditionAddEmptyRow
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	bool ConditionAddEmptyRow(struct FName& RowName); // Offset: 0x105319e9c // Return & Params: Num(2) Size(0x9)
};

// Object Name: Class UnrealArchExt.UAEDataTableInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UUAEDataTableInterface : UInterface {
};

// Object Name: Class UnrealArchExt.UAEWidgetContainer
// Size: 0x428 // Inherited bytes: 0x418
struct UUAEWidgetContainer : UUAEUserWidget {
	// Fields
	struct TArray<struct UUserWidget*> WidgetList; // Offset: 0x418 // Size: 0x10

	// Functions

	// Object Name: Function UnrealArchExt.UAEWidgetContainer.RemoveWidgetInternal
	// Flags: [Native|Event|Protected|BlueprintEvent]
	void RemoveWidgetInternal(struct UUserWidget* Widget); // Offset: 0x10531ded0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UnrealArchExt.UAEWidgetContainer.RemoveWidget
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RemoveWidget(struct UUserWidget* Widget); // Offset: 0x10531de54 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UnrealArchExt.UAEWidgetContainer.AddWidgetWithZOrderInternal
	// Flags: [Native|Event|Protected|BlueprintEvent]
	void AddWidgetWithZOrderInternal(struct UUserWidget* Widget, int ZOrder); // Offset: 0x10531dd94 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function UnrealArchExt.UAEWidgetContainer.AddWidgetWithZOrder
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddWidgetWithZOrder(struct UUserWidget* Widget, int ZOrder); // Offset: 0x10531dcdc // Return & Params: Num(2) Size(0xc)

	// Object Name: Function UnrealArchExt.UAEWidgetContainer.AddWidgetInternal
	// Flags: [Native|Event|Protected|BlueprintEvent]
	void AddWidgetInternal(struct UUserWidget* Widget); // Offset: 0x10531dc58 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UnrealArchExt.UAEWidgetContainer.AddWidget
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddWidget(struct UUserWidget* Widget); // Offset: 0x10531dbdc // Return & Params: Num(1) Size(0x8)
};

