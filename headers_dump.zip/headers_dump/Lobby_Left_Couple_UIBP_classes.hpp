#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Lobby_Left_Couple_UIBP.Lobby_Left_Couple_UIBP_C
// Size: 0x2a8 // Inherited bytes: 0x260
struct ULobby_Left_Couple_UIBP_C : UUserWidget {
	// Fields
	struct UCommon_Avatar_BP_C* Common_Avatar_BP; // Offset: 0x260 // Size: 0x08
	struct UCanvasPanel* FriendInfo; // Offset: 0x268 // Size: 0x08
	struct UImage* RelationIcon_2; // Offset: 0x270 // Size: 0x08
	struct UImage* RelationIcon_3; // Offset: 0x278 // Size: 0x08
	struct UImage* RelationIcon_4; // Offset: 0x280 // Size: 0x08
	struct UImage* RelationIcon_5; // Offset: 0x288 // Size: 0x08
	struct UTextBlock* TextBlock_1; // Offset: 0x290 // Size: 0x08
	struct UTextBlock* TextBlock_PlayerName02; // Offset: 0x298 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_RelationIcon; // Offset: 0x2a0 // Size: 0x08
};

