#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum ShadowTrackerExtra.EAutoAimLockState
enum class EAutoAimLockState : uint8 {
	NotLock = 0,
	LockNoTarget = 1,
	Locking = 2,
	Locked = 3,
	EAutoAimLockState_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.ESTExtraVehicleSeatType
enum class ESTExtraVehicleSeatType : uint8 {
	ESeatType_DriversSeat = 0,
	ESeatType_PassengersSeat = 1,
	ESeatType_FreeFiringLeftSeat = 2,
	ESeatType_FreeFiringRightSeat = 3,
	ESeatType_GunnerSeat = 4,
	ESeatType_VirtualDriverSeat = 5,
	ESeatType_AssistantSeat = 6,
	ESeatType_Max = 7
};

// Object Name: Enum ShadowTrackerExtra.EVHSeatSideType
enum class EVHSeatSideType : uint8 {
	EVHSeatSideType_Center = 0,
	EVHSeatSideType_Left = 1,
	EVHSeatSideType_Right = 2,
	EVHSeatSideType_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EVHSeatSpecialType
enum class EVHSeatSpecialType : uint8 {
	EVHSeatSpecial_Common = 0,
	EVHSeatSpecial_Narrow = 1,
	EVHSeatSpecial_OutLeft = 2,
	EVHSeatSpecial_OutRight = 3,
	EVHSeatSpecial_Max = 4
};

// Object Name: Enum ShadowTrackerExtra.EVHSeatWeaponHoldType
enum class EVHSeatWeaponHoldType : uint8 {
	ESeatWeapon_None = 0,
	ESeatWeapon_ShortOnly = 1,
	ESeatWeapon_RifleOnly = 2,
	ESeatWeapon_SeatWeapon = 3,
	ESeatWeapon_All = 3,
	ESeatWeapon_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EVHSeatGUIType
enum class EVHSeatGUIType : uint8 {
	EVHSeatGUIType_NoSeat = 0,
	EVHSeatGUIType_Empty = 1,
	EVHSeatGUIType_Other = 2,
	EVHSeatGUIType_Self = 3,
	EVHSeatGUIType_Max = 4
};

// Object Name: Enum ShadowTrackerExtra.EShotFlag
enum class EShotFlag : uint8 {
	CLIENTNOCONNECT = 1,
	GUN_ADS = 2,
	RECENTLY_GUN_ADS_OR_PRONE = 4,
	EShotFlag_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.EAvatarDamagePosition
enum class EAvatarDamagePosition : uint8 {
	Non = 0,
	BigHead = 1,
	BigLimbs = 2,
	BigBody = 3,
	BigHand = 4,
	BigFoot = 5,
	Wheel0 = 6,
	Wheel1 = 7,
	Wheel2 = 8,
	Wheel3 = 9,
	BigLimb_LeftLowerArm = 10,
	BigLimb_LeftUpperArm = 11,
	BigLimb_RightLowerArm = 12,
	BigLimb_RightUpperArm = 13,
	BigLimb_LeftThigh = 14,
	BigLimb_LeftShank = 15,
	BigLimb_RightThigh = 16,
	BigLimb_RightShank = 17,
	BodyZone0 = 20,
	BodyZone1 = 21,
	BodyZone2 = 22,
	BodyZone3 = 23,
	EAvatarDamagePosition_MAX = 24
};

// Object Name: Enum ShadowTrackerExtra.EUAESkillEvent
enum class EUAESkillEvent : uint8 {
	UAESkillEvent_None = 0,
	GrenadeModeChange = 1,
	ThrowGrenade = 2,
	SkillCancel = 3,
	GrenadeTimeOut = 4,
	SwitchWeapon = 5,
	SwitchWeaponInterrupt = 6,
	SwitchWeaponFinish = 7,
	UnequipWeapon = 8,
	UnequipWeaponFinish = 9,
	SkillInterrupt = 10,
	SkillPlayerDieInterrupt = 11,
	PickItem = 12,
	StartFire = 13,
	LevelSequenceFinish = 14,
	EUAESkillEvent_MAX = 15
};

// Object Name: Enum ShadowTrackerExtra.ESeekAndLockStage
enum class ESeekAndLockStage : uint8 {
	ESeekAndLockStage_None = 0,
	ESeekAndLockStage_2 = 1,
	ESeekAndLockStage_3 = 2,
	ESeekAndLockStage_4 = 3,
	ESeekAndLockStage_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.ESurviveWeaponPropSlot
enum class ESurviveWeaponPropSlot : uint8 {
	SWPS_None = 0,
	SWPS_MainShootWeapon1 = 1,
	SWPS_MainShootWeapon2 = 2,
	SWPS_SubShootWeapon = 3,
	SWPS_MeleeWeapon = 4,
	SWPS_HandProp = 5,
	SWPS_TempSpecialWeapon = 6,
	SWPS_ShiftGrenadeWeapon = 7,
	SWPS_VehicleWeapon = 8,
	SWPS_Max = 9
};

// Object Name: Enum ShadowTrackerExtra.EWeaponChangeInvenroryDataType
enum class EWeaponChangeInvenroryDataType : uint8 {
	EWCIDT_Init = 0,
	EWCIDT_PickUp = 1,
	EWCIDT_PutDown = 2,
	EWCIDT_Swap = 3,
	EWCIDT_GrenadeLaunch = 4,
	EWCIDT_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.EPawnState
enum class EPawnState : uint8 {
	Move = 0,
	Sprint = 1,
	ProneMove = 2,
	Stand = 3,
	Crouch = 4,
	Prone = 5,
	Jump = 6,
	GunFire = 7,
	GunReload = 8,
	GunADS = 9,
	Picth = 10,
	SwitchWeapon = 11,
	Pick = 12,
	MeleeAttack = 13,
	HoldGrenade = 14,
	Save = 15,
	UseConsumables = 16,
	Dying = 17,
	Dead = 18,
	DriveVehicle = 19,
	InVehicle = 20,
	LeanOutVehicle = 21,
	Swim = 22,
	InParachute = 23,
	Vault = 24,
	InPlane = 25,
	GunOBOReload = 26,
	SwitchPP = 27,
	PlayEmote = 28,
	HoldShield = 29,
	Imprisonment = 30,
	StunBurnNag = 31,
	Skill = 32,
	DetectPaintDecal = 33,
	Revival = 34,
	AirAttackLocator = 35,
	ControlUnmannedVehicle = 36,
	Shoveling = 37,
	RemoteControlVehicle = 38,
	Build = 39,
	GunFillGas = 40,
	Shoulder = 41,
	Variation = 42,
	CarryBack = 43,
	BeCarriedBack = 44,
	Dizziness = 45,
	Knock = 46,
	InZipline = 47,
	StairsMove = 48,
	InEmergencyCall = 49,
	DriveMovePlatForm = 50,
	Slide = 51,
	__MAX = 52,
	EPawnState_MAX = 53
};

// Object Name: Enum ShadowTrackerExtra.EWeaponTriggerEvent
enum class EWeaponTriggerEvent : uint8 {
	EWeaponTriggerEvent_None = 0,
	EWeaponTriggerEvent_PressFuncBtn = 1,
	EWeaponTriggerEvent_ReleaseFuncBtn = 2,
	EWeaponTriggerEvent_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.ESTEPoseState
enum class ESTEPoseState : uint8 {
	Stand = 0,
	Crouch = 1,
	Prone = 2,
	Sprint = 3,
	CrouchSprint = 4,
	Crawl = 5,
	Swim = 6,
	SwimSprint = 7,
	Dying = 8,
	DyingBeCarried = 9,
	DyingSwim = 10,
	ESTEPoseState_MAX = 11
};

// Object Name: Enum ShadowTrackerExtra.EPlayerCameraMode
enum class EPlayerCameraMode : uint8 {
	PCM_None = 0,
	PCM_Normal = 1,
	PCM_Near = 2,
	PCM_Aim = 3,
	PCM_Plane = 4,
	PCM_FPP = 5,
	PCM_MAX = 6
};

// Object Name: Enum ShadowTrackerExtra.ESTExtraVehicleHealthState
enum class ESTExtraVehicleHealthState : uint8 {
	VHS_Good = 0,
	VHS_Smoking = 1,
	VHS_Burning = 2,
	VHS_Destroyed = 3,
	VHS_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EMeshType
enum class EMeshType : uint8 {
	None = 0,
	Skeletal = 1,
	Static = 2,
	SkeletalWithSocket = 3,
	EMeshType_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EOpticalSightType
enum class EOpticalSightType : uint8 {
	NoneSight = 0,
	UpperLarge = 1,
	UpperSmall = 2,
	UpperDefault = 3,
	EOpticalSightType_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EWeaponSubSlotType
enum class EWeaponSubSlotType : uint8 {
	None = 0,
	UpperLarge = 1,
	UpperSmall = 2,
	UpperDefault = 3,
	Laser = 4,
	EWeaponSubSlotType_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.EWeaponAttachmentSocketType
enum class EWeaponAttachmentSocketType : uint8 {
	GunPoint = 0,
	Grip = 1,
	Magazine = 2,
	Gunstock = 3,
	OpticalSight = 4,
	MasterGun = 7,
	Ammo = 8,
	Pendant = 9,
	AngledOpticalSight = 10,
	ACCore = 11,
	EWeaponAttachmentSocketType_MAX = 12
};

// Object Name: Enum ShadowTrackerExtra.EWeaponPendantSocketType
enum class EWeaponPendantSocketType : uint8 {
	First = 0,
	Third = 1,
	Lobby = 2,
	ArmamentBank = 3,
	Store = 4,
	Max_Auto = 5,
	EWeaponPendantSocketType_MAX = 6
};

// Object Name: Enum ShadowTrackerExtra.EPutDownDetachMethod
enum class EPutDownDetachMethod : uint8 {
	Unkown = 0,
	Skill_Front = 1,
	Skill_Back = 2,
	StateInterrupted_SelfDying = 3,
	StateInterrupted_SelfDead = 4,
	StateInterrupted_SelfInParachute = 5,
	StateInterrupted_SelfSwim = 6,
	StateInterrupted_SelfInVehicle = 7,
	StateInterrupted_OtherDead = 8,
	StateInterrupted_RescueFinish = 9,
	SkillInterrupted = 10,
	NoConnectOutOfTime = 11,
	OtherReason = 12,
	PreReason1 = 13,
	PreReason2 = 14,
	PreReason3 = 15,
	EPutDownDetachMethod_MAX = 16
};

// Object Name: Enum ShadowTrackerExtra.ECarryBackState
enum class ECarryBackState : uint8 {
	None = 0,
	InCarryBack = 1,
	CarryBackDone = 2,
	InPutDown = 3,
	InBeCarriedBack = 4,
	BeCarriedBackDone = 5,
	InBePutDown = 6,
	ECarryBackState_MAX = 7
};

// Object Name: Enum ShadowTrackerExtra.EFreshWeaponStateType
enum class EFreshWeaponStateType : uint8 {
	FreshWeaponStateType_None = 0,
	FreshWeaponStateType_Inactive = 1,
	FreshWeaponStateType_Idle = 2,
	FreshWeaponStateType_IdleToBackpack = 3,
	FreshWeaponStateType_Backpack = 4,
	FreshWeaponStateType_BackpackToIdle = 5,
	FreshWeaponStateType_Fire = 6,
	FreshWeaponStateType_Reload = 7,
	FreshWeaponStateType_NoBullet = 8,
	FreshWeaponStateType_PreFire = 9,
	FreshWeaponStateType_PostFire = 10,
	FreshWeaponStateType_PostReload = 11,
	FreshWeaponStateType_WarmUp = 12,
	FreshWeaponStateType_FillGas = 13,
	FreshWeaponStateType_PostFillGas = 14,
	FreshWeaponStateType_Drop = 15,
	FreshWeaponStateType_MAX = 16
};

// Object Name: Enum ShadowTrackerExtra.ELaserTraceUIStage
enum class ELaserTraceUIStage : uint8 {
	LaserTraceUIStage_2 = 0,
	LaserTraceUIStage_3 = 1,
	LaserTraceUIStage_4 = 2,
	LaserTraceUIStage_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EDamageableGameObjectType
enum class EDamageableGameObjectType : uint8 {
	EDamageableGameObjectType_Player = 0,
	EDamageableGameObjectType_Monster = 1,
	EDamageableGameObjectType_Vehicle = 2,
	EDamageableGameObjectType_Boss = 3,
	EDamageableGameObjectType_Building = 4,
	EDamageableGameObjectType_Building_A = 5,
	EDamageableGameObjectType_Building_B = 6,
	EDamageableGameObjectType_Building_C = 7,
	EDamageableGameObjectType_Flammable = 8,
	EDamageableGameObjectType_AI = 9,
	EDamageableGameObjectType_MAX = 10
};

// Object Name: Enum ShadowTrackerExtra.EObserverType
enum class EObserverType : uint8 {
	EObserverType_None = 0,
	EObserverType_InSpectating = 1,
	EObserverType_GlobalObserver = 2,
	EObserverType_FriendObserver = 3,
	EObserverType_Spectator = 4,
	EObserverType_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.ETeamNumber
enum class ETeamNumber : uint8 {
	POLICE = 0,
	TERRORIST = 1,
	CIVILIAN = 2,
	UNKNOWN = 3,
	ETeamNumber_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EUAVUseType
enum class EUAVUseType : uint8 {
	UAV_None = 0,
	UAV_Init = 1,
	UAV_Using = 2,
	UAV_Standby = 3,
	UAV_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EAvatarEnum
enum class EAvatarEnum : uint8 {
	NONE = 0,
	CharacterAvatar = 1,
	WeaponAvatar = 2,
	VehicleAvatar = 3,
	VehicleAdAvatar = 4,
	PetAvatar = 5,
	PlaneAvatar = 6,
	GrenadeAvatar = 7,
	ConsumableAvatar = 8,
	EAvatarEnum_MAX = 9
};

// Object Name: Enum ShadowTrackerExtra.EDisplayQuality
enum class EDisplayQuality : uint8 {
	Low = 0,
	Middle = 1,
	High = 2,
	Invalid = 3,
	EDisplayQuality_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.ESyncOperation
enum class ESyncOperation : uint8 {
	PutOn = 0,
	PutOff = 1,
	ApplyHead = 2,
	MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EAvatarActionType
enum class EAvatarActionType : uint8 {
	NONE = 0,
	ApplyMesh = 1,
	ApplyMaterial = 2,
	ApplyMatConfig = 3,
	ApplyParticle = 4,
	ApplyDIYPattern = 5,
	ApplyItemHandle = 6,
	ApplyWeaponHandle = 7,
	ApplyDIYMatParam = 8,
	ApplyDIYMirroParam = 9,
	ApplyMatParamModify = 10,
	EAvatarActionType_MAX = 11
};

// Object Name: Enum ShadowTrackerExtra.EMeshAssetType
enum class EMeshAssetType : uint8 {
	None = 0,
	Attach_StaticMesh = 1,
	Attach_SkeletalMesh = 2,
	SetMaster_SkeletalMesh = 3,
	ReplaceMaster_StaitciMesh = 4,
	ReplaceMaster_SkeletalMesh = 5,
	EMeshAssetType_MAX = 6
};

// Object Name: Enum ShadowTrackerExtra.EWeaponFuncFlag
enum class EWeaponFuncFlag : uint8 {
	SoundDisable = 1,
	MaxFuncFlag = 2,
	EWeaponFuncFlag_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EWeaponComponentType
enum class EWeaponComponentType : uint8 {
	WCT_None = 0,
	WCT_Scope = 1,
	WCT_Max = 2
};

// Object Name: Enum ShadowTrackerExtra.ESurvivePickUpGlobalCategory
enum class ESurvivePickUpGlobalCategory : uint8 {
	SurvivePickUpItemGlobalCategory_None = 0,
	SurvivePickUpItemGlobalCategory_Weapon = 1,
	SurvivePickUpItemGlobalCategory_PlayerEquipment = 2,
	SurvivePickUpItemGlobalCategory_WeaponComponent = 3,
	SurvivePickUpItemGlobalCategory_ConsumeItem = 4,
	SurvivePickUpItemGlobalCategory_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.ESightType
enum class ESightType : uint8 {
	SightX1 = 0,
	SightX2 = 1,
	SightX4 = 2,
	SightX8 = 3,
	SightDefault = 4,
	SightX3 = 5,
	SightX6 = 6,
	SightTeleScope = 7,
	ESightType_MAX = 8
};

// Object Name: Enum ShadowTrackerExtra.EWeaponFireMode
enum class EWeaponFireMode : uint8 {
	WeaponFireMode_Single = 0,
	WeaponFireMode_Burst = 1,
	WeaponFireMode_Auto = 2,
	WeaponFireMode_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EWeaponHoldType
enum class EWeaponHoldType : uint8 {
	EWHT_None = 0,
	EWHT_SingleHand = 1,
	EWHT_TwoHand = 2,
	EWHT_Max = 3
};

// Object Name: Enum ShadowTrackerExtra.EWeaponType
enum class EWeaponType : uint8 {
	AWT_None = 0,
	AWT_Pistol = 1,
	AWT_PistolSilencer = 2,
	AWT_ShotGun = 3,
	AWT_SubmachineGun = 4,
	AWT_RPG = 5,
	AWT_ChargeGun = 6,
	AWT_Knife = 7,
	AWT_EnegyCaptureWhip = 8,
	AWT_RifleGun = 9,
	AWT_RPG7 = 10,
	AWT_MAX = 11
};

// Object Name: Enum ShadowTrackerExtra.EWeaponTypeNew
enum class EWeaponTypeNew : uint8 {
	EWeaponTypeNew_Other = 0,
	EWeaponTypeNew_Rifle = 1,
	EWeaponTypeNew_SingleShotSniper = 2,
	EWeaponTypeNew_BurstShotSniper = 3,
	EWeaponTypeNew_Submachine = 4,
	EWeaponTypeNew_ShotGun = 5,
	EWeaponTypeNew_MachineGun = 6,
	EWeaponTypeNew_Pistol = 7,
	EWeaponTypeNew_Melee = 8,
	EWeaponTypeNew_Crossbow = 9,
	EWeaponTypeNew_ThrownObj = 10,
	EWeaponTypeNew_MAX = 11
};

// Object Name: Enum ShadowTrackerExtra.EWeaponAction
enum class EWeaponAction : uint8 {
	WA_None = 0,
	WA_EquipWeapon = 1,
	WA_UnEquipWeapon = 2,
	WA_Shoot = 3,
	WA_IdleToNoneIdle = 4,
	WA_NoneShoot = 5,
	WA_Reload = 6,
	WA_AutoShoot = 7,
	WA_DropWeapon = 8,
	WA_MAX = 9
};

// Object Name: Enum ShadowTrackerExtra.EExtraWeaponUIType
enum class EExtraWeaponUIType : uint8 {
	EWUT_None = 0,
	EWUT_MeleeWeapon = 1,
	EWUT_ShootWeapon = 2,
	EWUT_Greanade = 3,
	EWUT_KeroseneFurnace = 4,
	EWUT_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.EWeaponState
enum class EWeaponState : uint8 {
	WS_Unavailable = 0,
	WS_UnEquiped = 1,
	WS_Equiped = 2,
	WS_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.ESTEWeaponShootType
enum class ESTEWeaponShootType : uint8 {
	OneBulletBursting = 1,
	MultiBulletsBursting = 2,
	Auto = 4,
	Volley = 8,
	ESTEWeaponShootType_MAX = 9
};

// Object Name: Enum ShadowTrackerExtra.EWeaponReloadMethod
enum class EWeaponReloadMethod : uint8 {
	All = 0,
	Tactical = 1,
	EWeaponReloadMethod_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EMoveBaseSpeedType
enum class EMoveBaseSpeedType : uint8 {
	MBST_Normal = 0,
	MBST_Fast = 1,
	MBST_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EShootVertifySubRes
enum class EShootVertifySubRes : uint8 {
	OK = 0,
	BulletIDAndShootIDError1_2 = 1,
	BulletIDAndShootIDError1_3 = 2,
	BulletIDAndShootIDError1_4 = 3,
	BulletIDAndShootIDError1_5 = 4,
	BulletIDAndShootIDError1_6 = 5,
	BulletIDAndShootIDError1_7 = 6,
	BulletIDAndShootIDError2_2 = 7,
	BulletIDAndShootIDError2_3 = 8,
	BulletIDAndShootIDError2_4 = 9,
	BulletIDAndShootIDError2_5 = 10,
	BulletIDAndShootIDError2_6 = 11,
	BulletIDAndShootIDError2_7 = 12,
	EShootVertifySubRes_MAX = 13
};

// Object Name: Enum ShadowTrackerExtra.EShootVertifyRes
enum class EShootVertifyRes : uint8 {
	OK = 0,
	ShootBigHead = 1,
	ShootPointBigDeviation = 2,
	ShootBigBoxNull = 3,
	ShootOtherBlock = 4,
	ShootOtherBlockRev = 5,
	NoLagCompensation = 6,
	ShootTimeTooDelay = 7,
	MuzzleBigDeviation = 8,
	ShootHitHeadError = 9,
	ShootHitRotationError = 10,
	ShootRangeError = 11,
	ShootHitInVehicle = 12,
	ShootHitAITarget = 13,
	ShootHitVehicleTarget = 14,
	BulletFlyTimeError = 15,
	BulletDirError = 16,
	BulletImpactOffsetError = 17,
	CharacterImpactOffsetError = 18,
	ImpactTargetPassWall = 19,
	GunPoseError = 20,
	HisotryLocusError = 21,
	Client_HitImpactPassWall = 22,
	Client_ShootMuzzleHeight = 23,
	Client_BoneMissMatch = 24,
	ErrorShooterWeaponRange = 25,
	MuzzleDirError = 26,
	ShooterPosError = 27,
	ClientVerifyError = 28,
	VictmPosError = 29,
	ShooterInDamageFreeze = 30,
	WeaponScopePosError = 31,
	OwnerHeadAndMuzzlePassWall = 32,
	MuzzleImpactDirError1 = 33,
	MuzzleImpactDirError2 = 34,
	ShootPosHistoryLocusError1 = 35,
	ShootPosHistoryLocusError2 = 36,
	MuzzleLocusError = 37,
	MuzzleLocusErrorX = 38,
	MuzzleLocusErrorY = 39,
	MuzzleLocusErrorZ = 40,
	FiringRateAndShootIDError = 41,
	BulletIDAndShootIDError = 42,
	VehicleShootFarInMidAir = 43,
	PawnShootFarInMidAir = 44,
	MuzzleLocusErrorLength = 45,
	FarShootInHighTangentMoveSpeed = 46,
	ParachuteSpeedHack = 47,
	NonGunADSFarShootFromClientBulletData = 48,
	Non = 49,
	EShootVertifyRes_MAX = 50
};

// Object Name: Enum ShadowTrackerExtra.EWeaponShootIntervalMode
enum class EWeaponShootIntervalMode : uint8 {
	EWeaponShootIntervalMode_A = 0,
	EWeaponShootIntervalMode_B = 1,
	EWeaponShootIntervalMode_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.ESightVisionType
enum class ESightVisionType : uint8 {
	NoneSightVision = 0,
	NightVision = 1,
	ThermalImaging = 2,
	ESightVisionType_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.ECrossHairSpreadType
enum class ECrossHairSpreadType : uint8 {
	ECHST_Offset = 0,
	ECHST_Scale = 1,
	ECHST_Damage = 2,
	ECHST_Rotate = 3,
	ECHST_SingleCircle = 4,
	ECHST_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.EWeaponReloadType
enum class EWeaponReloadType : uint8 {
	Magzine = 0,
	OneByOne = 1,
	OneByOneAndClip = 2,
	EWeaponReloadType_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EReuqestFireRet
enum class EReuqestFireRet : uint8 {
	OK = 0,
	InvalidRequestBulletNum1 = 1,
	InvalidRequestBulletNum2 = 2,
	InvalidStartShootID = 3,
	InvalidClipInfo1 = 4,
	InvalidClipInfo2 = 5,
	InvalidAntiCheatComp = 6,
	EReuqestFireRet_MAX = 7
};

// Object Name: Enum ShadowTrackerExtra.EShootWeaponState
enum class EShootWeaponState : uint8 {
	SWS_Idle = 0,
	SWS_NoneIdle = 1,
	SWS_Shooting = 2,
	SWS_Reloading = 3,
	SWS_ReloadDone = 4,
	SWS_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.EShootWeaponShootMode
enum class EShootWeaponShootMode : uint8 {
	SWST_MuzzleDirection = 0,
	SWST_TargetDirection = 1,
	SWST_TraceTarget = 2,
	SWST_VehicleShoot = 3,
	SWST_AIControllerRotation = 4,
	SWST_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.ESyncTicketStatus
enum class ESyncTicketStatus : uint8 {
	EMatch = 0,
	ETimeOut = 1,
	EFuture = 2,
	ESyncTicketStatus_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EFatalDamageCharacterType
enum class EFatalDamageCharacterType : uint8 {
	EUnknown = 0,
	EPlayer = 1,
	ERobot = 2,
	EMonster = 3,
	EBoss = 4,
	EInfecZombie = 5,
	EInfecRevenger = 6,
	EWalkingDead = 7,
	EWalkingDeadAI = 8,
	EFatalDamageCharacterType_MAX = 9
};

// Object Name: Enum ShadowTrackerExtra.EFatalDamageRelationShip
enum class EFatalDamageRelationShip : uint8 {
	MyTeamateIsCauser = 0,
	NotRelated = 1,
	MyTeammateIsVictim = 2,
	MyTeammateIsCauserAndVictim = 3,
	EFatalDamageRelationShip_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EAvatarSlotType
enum class EAvatarSlotType : uint8 {
	EAvatarSlotType_NONE = 0,
	EAvatarSlotType_HeadEquipemtSlot = 1,
	EAvatarSlotType_HairEquipemtSlot = 2,
	EAvatarSlotType_HatEquipemtSlot = 3,
	EAvatarSlotType_FaceEquipemtSlot = 4,
	EAvatarSlotType_ClothesEquipemtSlot = 5,
	EAvatarSlotType_PantsEquipemtSlot = 6,
	EAvatarSlotType_ShoesEquipemtSlot = 7,
	EAvatarSlotType_BackpackEquipemtSlot = 8,
	EAvatarSlotType_HelmetEquipemtSlot = 9,
	EAvatarSlotType_ArmorEquipemtSlot = 10,
	EAvatarSlotType_ParachuteEquipemtSlot = 11,
	EAvatarSlotType_GlassEquipemtSlot = 12,
	EAvatarSlotType_NightVisionEquipemtSlot = 13,
	EAvatarSlotType_BeardEquipemtSlot = 14,
	EAvatarSlotType_GlideEquipemtSlot = 15,
	EAvatarSlotType_HandEffectEquipemtSlot = 16,
	EAvatarSlotType_BackPack_PendantSlot = 17,
	EAvatarSlotType_MechaChestSlot = 18,
	EAvatarSlotType_MechaArmSlot = 19,
	EAvatarSlotType_MechaLegSlot = 20,
	EAvatarSlotType_MechaInnerSuitSlot = 21,
	EAvatarSlotType_FootEffectEquipemtSlot = 22,
	EAvatarSlotType_MaxSlotNum = 23,
	EAvatarSlotType_MAX = 24
};

// Object Name: Enum ShadowTrackerExtra.EInviteResponceType
enum class EInviteResponceType : uint8 {
	ETimeout = 0,
	EAgree = 1,
	ERefuse = 2,
	EBeInviting = 3,
	EInvalidInvitation = 4,
	ENotAllowedInvite = 5,
	ENotAllowedFollow = 6,
	EDuringTransferLeader = 7,
	EInviteResponceType_MAX = 8
};

// Object Name: Enum ShadowTrackerExtra.EParachuteInvitationType
enum class EParachuteInvitationType : uint8 {
	EInviteFollow = 0,
	EInviteTransferLeader = 1,
	EParachuteInvitationType_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EDeltaRotationTest
enum class EDeltaRotationTest : uint8 {
	Prone = 0,
	KnockedDown = 1,
	EDeltaRotationTest_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.ECharacterMainType
enum class ECharacterMainType : uint8 {
	NormalPlayer = 1,
	Zombie = 2,
	WalkingDead = 3,
	WalkingDeadAI = 4,
	_MAX = 255,
	ECharacterMainType_MAX = 256
};

// Object Name: Enum ShadowTrackerExtra.ECharacterSubType
enum class ECharacterSubType : uint8 {
	InvalidPawnType = 0,
	NormalPlayer = 11,
	RevengerPlayer = 12,
	MotherZombie = 21,
	NormalZombie = 22,
	InvisibleZombie = 23,
	ThrowerZombie = 24,
	WalkingDeadMale = 31,
	WalkingDeadFemale = 32,
	_MAX = 255,
	ECharacterSubType_MAX = 256
};

// Object Name: Enum ShadowTrackerExtra.EParachuteState
enum class EParachuteState : uint8 {
	PS_None = 0,
	PS_FreeFall = 1,
	PS_Opening = 2,
	PS_Landing = 3,
	PS_Launch = 4,
	PS_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.ECustomMovmentMode
enum class ECustomMovmentMode : uint8 {
	CUSTOM_MOVE_None = 0,
	CUSTOM_MOVE_CrowdMove = 1,
	CUSTOM_MOVE_Shovel = 2,
	CUSTOM_MOVE_Climb = 3,
	CUSTOM_SKILL_DirectMove = 4,
	CUSTOM_SKILL_AirJump = 5,
	CUSTOM_MOVE_SLIDE = 6,
	CUSTOM_MOVE_Vault = 7,
	CUSTOM_MOVE_DriveFireBalloon = 8,
	CUSTOM_MOVE_Max = 9,
	CUSTOM_MAX = 10
};

// Object Name: Enum ShadowTrackerExtra.ESTExtraVehicleType
enum class ESTExtraVehicleType : uint8 {
	VT_Unknown = 0,
	VT_Motorbike_1 = 1,
	VT_Motorbike_2 = 2,
	VT_Motorbike_SideCart_1 = 3,
	VT_Motorbike_SideCart_2 = 4,
	VT_Dacia_1 = 5,
	VT_Dacia_2 = 6,
	VT_Dacia_3 = 7,
	VT_Dacia_4 = 8,
	VT_UAZ_1 = 9,
	VT_UAZ_2 = 10,
	VT_UAZ_3 = 11,
	VT_Buggy_1 = 12,
	VT_Buggy_2 = 13,
	VT_Buggy_3 = 14,
	VT_PG117 = 15,
	VT_Aquarail = 16,
	VT_MiniBus_2 = 17,
	VT_MiniBus_3 = 18,
	VT_MiniBus_4 = 19,
	VT_PickUp_2 = 20,
	VT_PickUp_3 = 21,
	VT_PickUp_4 = 22,
	VT_PickUp_5 = 23,
	VT_PickUp_6 = 24,
	VT_PickUp_7 = 25,
	VT_PickUp_8 = 26,
	VT_PickUp_9 = 27,
	VT_PickUp_10 = 28,
	VT_PickUp_11 = 29,
	VT_Buggy_5 = 30,
	VT_Buggy_6 = 31,
	VT_Buggy_7 = 32,
	VT_Mirado_Close_2 = 33,
	VT_Mirado_Close_3 = 34,
	VT_Mirado_Close_4 = 35,
	VT_Mirado_Close_5 = 36,
	VT_Mirado_Open_2 = 37,
	VT_Mirado_Open_3 = 38,
	VT_Mirado_Open_4 = 39,
	VT_Mirado_Open_5 = 40,
	VT_UAZ04 = 41,
	VT_Rony_2 = 42,
	VT_Rony_3 = 43,
	VT_Rony_4 = 44,
	VT_Scooter = 45,
	VT_Surfboard = 46,
	VT_UH60 = 47,
	VT_Amphibious = 48,
	VT_TUK = 49,
	VT_Snowboard = 50,
	VT_UAV = 51,
	VT_Telecar = 52,
	VT_UCAV = 53,
	VT_DragonBoat = 55,
	VT_Tesla = 56,
	VT_ExtraMount = 57,
	VT_Motorglider = 58,
	VT_LootTruck = 60,
	VT_ATGMotorCycle = 63,
	VT_ModelY = 64,
	VT_ATV = 65,
	VT_SciFi = 66,
	VT_Lamborghini = 100,
	VT_Lamborghini_2 = 101,
	VT_MegaDrop = 102,
	VT_BigFoot = 103,
	VT_TrackVehicle = 104,
	VT_CoupeRB = 105,
	VT_CatapultMachine = 107,
	VT_UTV = 108,
	VT_Bike = 109,
	VT_Tank = 110,
	VT_MAX = 111
};

// Object Name: Enum ShadowTrackerExtra.EThrowGrenadeMode
enum class EThrowGrenadeMode : uint8 {
	HighThrowMode = 0,
	LowThrowMode = 1,
	LeftThrowMode = 2,
	RightThrowMode = 3,
	EThrowGrenadeMode_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.ESightVisionMask
enum class ESightVisionMask : uint8 {
	NightVisionEquip = 1,
	NightVisionHelmet = 2,
	NightVisionScope = 4,
	NightVisionEnv = 8,
	ThermalImagingScope = 16,
	NightVision = 15,
	NightVisionFrame = 7,
	ESightVisionMask_MAX = 17
};

// Object Name: Enum ShadowTrackerExtra.ESightVisionCondition
enum class ESightVisionCondition : uint8 {
	NightVisionUnderGround = 1,
	ESightVisionCondition_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EPaintDecalTargetValidationType
enum class EPaintDecalTargetValidationType : uint8 {
	ValidTarget = 0,
	InvalidTarget = 1,
	OutrangeTarget = 2,
	EPaintDecalTargetValidationType_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EFollowState
enum class EFollowState : uint8 {
	None = 0,
	Leader = 1,
	Follower = 2,
	EFollowState_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.ECharacterHealthStatus
enum class ECharacterHealthStatus : uint8 {
	HealthyAlive = 0,
	HasLastBreath = 1,
	FinishedLastBreath = 2,
	WaitingForRevival = 3,
	Max = 4
};

// Object Name: Enum ShadowTrackerExtra.EUAVCharacterMsgType
enum class EUAVCharacterMsgType : uint8 {
	UAV_None = 0,
	UAV_VehicleSound = 1,
	UAV_CharacterMoveSound = 2,
	UAV_BulletSound = 3,
	UAV_HurtSoud = 4,
	UAV_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.EFootStepState
enum class EFootStepState : uint8 {
	Run = 0,
	Squat = 1,
	Walk = 2,
	Crawl = 3,
	Fall = 4,
	EFootStepState_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.ESTEScopeType
enum class ESTEScopeType : uint8 {
	Normal = 0,
	ProneMove = 1,
	InFold = 2,
	AutoCollapsed = 3,
	BoltAction = 4,
	ESTEScopeType_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.EIdeaDecalParentType
enum class EIdeaDecalParentType : uint8 {
	NoParent = 0,
	MovableStaticMesh = 1,
	SkeletalMesh = 2,
	DestroyableStaticMesh = 3,
	EIdeaDecalParentType_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.ERecoveryReasonType
enum class ERecoveryReasonType : uint8 {
	ERecoveryReason_Medicine = 0,
	ERecoveryReason_Energy = 1,
	ERecoveryReason_RescueByTeammate = 2,
	ERecoveryReason_Type3 = 3,
	ERecoveryReason_Type4 = 4,
	ERecoveryReason_Type5 = 5,
	ERecoveryReason_Type6 = 6,
	ERecoveryReason_Type7 = 7,
	ERecoveryReason_Max = 8
};

// Object Name: Enum ShadowTrackerExtra.EFootprintType
enum class EFootprintType : uint8 {
	Invalid = 0,
	Left = 1,
	Right = 2,
	EFootprintType_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EMeleeAutoAimType
enum class EMeleeAutoAimType : uint8 {
	NoAutoAim = 0,
	AllTime = 1,
	EMeleeAutoAimType_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EHealthPredictShowType
enum class EHealthPredictShowType : uint8 {
	EHealthPredict_Add = 0,
	EHealthPredict_Set = 1,
	EHealthPredict_Max = 2
};

// Object Name: Enum ShadowTrackerExtra.EHitPartJugementType
enum class EHitPartJugementType : uint8 {
	HitPos = 0,
	HitBone = 1,
	EHitPartJugementType_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EGameModeType
enum class EGameModeType : uint8 {
	EUnknownGameMode = 0,
	ETypicalGameMode = 1,
	EEntertainmentGameMode = 2,
	EGameModeGroup = 3,
	EBattleRoyalCorpsWarMode = 4,
	EWarGameMode = 5,
	EWarGameMode_SuperPower = 6,
	EWarGameMode_GrandTheft = 7,
	EPVEGameMode = 8,
	EPVECollectionGameMode = 9,
	EActivityGameMode = 10,
	EDeathMatchGameMode = 11,
	EPVEInfectionGameMode = 12,
	EHeavyWeaponGameMode = 13,
	EVehicleWar = 15,
	EVehicleWar_CAMP = 16,
	EBattleRoyal_SuperCold = 17,
	ESocialIsland = 18,
	ETraining = 19,
	EFourInOneGameMode = 20,
	EBigEventGameMode = 21,
	EXAndT = 22,
	EBountyHunter = 23,
	EGameModeType_MAX = 24
};

// Object Name: Enum ShadowTrackerExtra.EScreenParticleEffectType
enum class EScreenParticleEffectType : uint8 {
	ESPET_None = 0,
	ESPET_Rainy = 1,
	ESPET_Snowy = 2,
	ESPET_Blizzard = 3,
	ESPET_DustStorm = 4,
	ESPET_MicroRegion = 5,
	ESPET_Max = 6
};

// Object Name: Enum ShadowTrackerExtra.EAngledSightType
enum class EAngledSightType : uint8 {
	Switch = 0,
	AngledSight = 1,
	NormalSight = 2,
	EAngledSightType_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EAIAttackType
enum class EAIAttackType : uint8 {
	AttackType_None = 0,
	AttackType_Melee = 1,
	AttackType_Remotely = 2,
	AttackType_Flight = 3,
	AttackType_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EAIShootingPose
enum class EAIShootingPose : uint8 {
	ShootingPose_Stand = 0,
	ShootingPose_Stand_Peek_Left = 1,
	ShootingPose_Stand_Peek_Right = 2,
	ShootingPose_Crouch_Peek_Left = 3,
	ShootingPose_Crouch_Peek_Right = 4,
	ShootingPose_Crouch = 5,
	ShootingPose_Prone = 6,
	ShootingPose_Normal = 255,
	ShootingPose_MAX = 256
};

// Object Name: Enum ShadowTrackerExtra.EAICharacterRotateInterpType
enum class EAICharacterRotateInterpType : uint8 {
	UseRotateRateOfCharacterMovementComponent = 0,
	UseControlRotationInterp = 1,
	EAICharacterRotateInterpType_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EAIEquipSpawnItemType
enum class EAIEquipSpawnItemType : uint8 {
	Shoot_Weap = 0,
	Backpack = 1,
	other = 2,
	EAIEquipSpawnItemType_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EAIActionType
enum class EAIActionType : uint8 {
	AIActionType_Normal = 0,
	AIActionType_SpecialAction = 1,
	AIActionType_FinalCircle = 2,
	AIActionType_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EFakePlayerBornType
enum class EFakePlayerBornType : uint8 {
	FromLobby = 0,
	FromSpawner = 1,
	EFakePlayerBornType_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EWeatherStatusType
enum class EWeatherStatusType : uint8 {
	EWeatherStatusType_None = 0,
	EWeatherStatusType_SunnyDay = 1,
	EWeatherStatusType_Night = 2,
	EWeatherStatusType_Fog = 3,
	EWeatherStatusType_Rain = 4,
	EWeatherStatusType_Snow = 5,
	EWeatherStatusType_Blizzard = 6,
	EWeatherStatusType_PVEDaytime = 7,
	EWeatherStatusType_PVEEvening = 8,
	EWeatherStatusType_PVENight = 9,
	EWeatherStatusType_MidAutumnDaytime = 10,
	EWeatherStatusType_MidAutumnEve = 11,
	EWeatherStatusType_MidAutumnNight = 12,
	EWeatherStatusType_Aurora = 13,
	EWeatherStatusType_SpringFestivalNight = 14,
	EWeatherStatusType_DesertSunny = 15,
	EWeatherStatusType_DustStorm = 16,
	EWeatherStatusType_MAX = 17
};

// Object Name: Enum ShadowTrackerExtra.EPlayerEnegyStage
enum class EPlayerEnegyStage : uint8 {
	PES_None = 0,
	PES_Stage1 = 1,
	PES_Stage2 = 2,
	PES_Stage3 = 3,
	PES_Stage4 = 4,
	PES_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.EMarkStatus
enum class EMarkStatus : uint8 {
	EMAS_HIDE = 0,
	EMAS_SHOW = 1,
	EMAS_CUSTOMEVENT = 2,
	EMAS_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EAddMarkFlag
enum class EAddMarkFlag : uint8 {
	EAMF_None = 0,
	EAMF_MiniMapOnly = 1,
	EAMF_EntireMapOnly = 2,
	EAMF_Both = 3,
	EAMF_Screen = 4,
	EAMF_ScreenRot = 8,
	EAMF_MAX = 9
};

// Object Name: Enum ShadowTrackerExtra.EMarkGetAllType
enum class EMarkGetAllType : uint8 {
	EMAGET_ALL = 0,
	EMAGET_REP = 1,
	EMAGET_LOCAL = 2,
	EMAGET_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EDriveCar
enum class EDriveCar : uint8 {
	None = 0,
	Buggy = 1,
	EDriveCar_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.ExtraPlayerLiveState
enum class ExtraPlayerLiveState : uint8 {
	InDefault = 0,
	InPlane = 1,
	InParachute = 2,
	InVehicle = 3,
	InDying = 4,
	InDied = 5,
	Offline = 6,
	ExtraPlayerLiveState_MAX = 7
};

// Object Name: Enum ShadowTrackerExtra.EWeatherChangeEvent
enum class EWeatherChangeEvent : uint8 {
	EWeatherChangeEvent_StartEnter = 0,
	EWeatherChangeEvent_Staturated = 1,
	EWeatherChangeEvent_StartQuit = 2,
	EWeatherChangeEvent_Quit = 3,
	EWeatherChangeEvent_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.WeatherUICountDownType
enum class WeatherUICountDownType : uint8 {
	UINone = 0,
	UISuperCold = 1,
	UILiveMode = 2,
	UIMidAutu = 3,
	WeatherUICountDownType_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.ESTEAIState
enum class ESTEAIState : int32 {
	ZS_Spawn = 1,
	ZS_Idle = 2,
	ZS_Battle = 4,
	ZS_Move = 8,
	ZS_Run = 16,
	ZS_Inspect = 32,
	ZS_Jump = 64,
	ZS_Land_Light = 128,
	ZS_Land_Hard = 256,
	ZS_Suffer = 512,
	ZS_SufferFreez = 1024,
	ZS_Fall = 2048,
	ZS_ClimbingWall = 4096,
	ZS_CrossingWindow = 8192,
	ZS_Dead = 16384,
	ZS_LockTarget = 32768,
	ZS_SpawnOnCeiling = 65536,
	ZS_NearDeath = 131072,
	ZS_Stun = 262144,
	ZS_Frozen = 524288,
	ZS_Charge = 1048576,
	ZS_Active = 2097152,
	ZS_MAX = 2097153
};

// Object Name: Enum ShadowTrackerExtra.EBPAIState
enum class EBPAIState : uint8 {
	ZS_Spawn = 0,
	ZS_Idle = 1,
	ZS_Battle = 2,
	ZS_Move = 3,
	ZS_Run = 4,
	ZS_Inspect = 5,
	ZS_Jump = 6,
	ZS_Land_Light = 7,
	ZS_Land_Hard = 8,
	ZS_Suffer = 9,
	ZS_SufferFreez = 10,
	ZS_Fall = 11,
	ZS_ClimbingWall = 12,
	ZS_CrossingWindow = 13,
	ZS_Dead = 14,
	ZS_LockTarget = 15,
	ZS_SpawnOnCeiling = 16,
	ZS_NearDeath = 17,
	ZS_Stun = 18,
	ZS_Frozen = 19,
	ZS_Charge = 20,
	ZS_Active = 21,
	ZS_Max = 22
};

// Object Name: Enum ShadowTrackerExtra.EItemReplaceType
enum class EItemReplaceType : uint8 {
	AIDrop = 0,
	Chest = 1,
	ItemGenerate = 2,
	EItemReplaceType_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EMonsterTreasureBoxState
enum class EMonsterTreasureBoxState : uint8 {
	None = 0,
	Spawned = 1,
	Standby = 2,
	Started = 3,
	Broken = 4,
	CountdownFinished = 5,
	AnimationFinished = 6,
	Stopped = 7,
	EMonsterTreasureBoxState_MAX = 8
};

// Object Name: Enum ShadowTrackerExtra.EPickUpBoxType
enum class EPickUpBoxType : uint8 {
	EPickUpBoxType_TombBox = 0,
	EPickUpBoxType_AirDropBox = 1,
	EPickUpBoxType_TreasureBox = 2,
	EPickUpBoxType_MonsterTombBox = 3,
	EPickUpBoxType_VehicleBox = 4,
	EPickUpBoxType_DeadRemainBox = 5,
	EPickUpBoxType_ResourceBox = 6,
	EPickUpBoxType_LootBox = 7,
	EPickUpBoxType_MAX = 8
};

// Object Name: Enum ShadowTrackerExtra.EAirAttackInfo
enum class EAirAttackInfo : uint8 {
	AttackWarningTips = 0,
	AttackStarted = 1,
	Attacking = 2,
	AttackOver = 3,
	NoAirAttack = 4,
	EAirAttackInfo_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.ECircleInfo
enum class ECircleInfo : uint8 {
	SafeZoneTips = 0,
	BlueCirclePreWarning = 1,
	BlueCircleRun = 2,
	NoCircleInfo = 3,
	ECircleInfo_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.InCircleState
enum class InCircleState : uint8 {
	Both = 0,
	InCircle = 1,
	OutCircle = 2,
	InCircleState_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EWeatherDayState
enum class EWeatherDayState : uint8 {
	Day = 1,
	Dusk = 2,
	Night = 3,
	EWeatherDayState_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.ESubSystemType
enum class ESubSystemType : uint8 {
	ESS_None = 0,
	ESS_DeferredExit = 1,
	ESS_RecallTeammate = 2,
	ESS_RescueHelicopter = 3,
	ESS_HeavyWeapon = 4,
	ESS_TDMHardPoint = 5,
	ESS_VisualField = 6,
	ESS_WorldActorFlag = 7,
	ESS_SuperCold = 8,
	ESS_DynamicSpawn = 9,
	ESS_ARWeaponManager = 10,
	ESS_MAX = 11
};

// Object Name: Enum ShadowTrackerExtra.EGameModeSubType
enum class EGameModeSubType : uint8 {
	ENoneGameMode = 0,
	EjungleGameMode = 1,
	EZombieStandard = 2,
	EZombieSurvive = 3,
	EEgyptGameMode = 4,
	EFiremanGameMode = 5,
	EAceMode = 6,
	ETPlan = 7,
	EEsportsGameMode = 8,
	EIceWorldGameMode = 9,
	EMetroGameMode = 10,
	ERuneGameMode = 11,
	EValentineGameMode = 12,
	EMusicFestivalGameMode = 13,
	EGodzilla = 14,
	EKingKong = 15,
	EMGodzilla = 16,
	ETraverse = 17,
	EPlanDGameMode = 18,
	EPlanETGameMode = 19,
	ESinkGameMode = 20,
	EPlanAGameMode = 21,
	EPlanSGameMode = 22,
	EPlanZNQ4thGameMode = 23,
	ELivik = 24,
	EBorderland = 25,
	EGameModeSubType_MAX = 26
};

// Object Name: Enum ShadowTrackerExtra.EStateType
enum class EStateType : uint8 {
	State_None = 0,
	State_Initial = 1,
	State_Fight = 2,
	State_InPlane = 3,
	State_InExPlane = 4,
	State_Launch = 5,
	State_ParachuteJump = 6,
	State_ParachuteOpen = 7,
	State_Dead = 8,
	State_Finish = 9,
	State_MAX = 10
};

// Object Name: Enum ShadowTrackerExtra.ETaskConditionType
enum class ETaskConditionType : uint8 {
	ETCT_Operator_And = 0,
	ETCT_Operator_Or = 1,
	ETCT_GameMode = 2,
	ETCT_SpecifiedItemID = 3,
	ETCT_SpecifiedArea = 4,
	ETCT_SpecifiedPlace = 5,
	ETCT_TouchDownLocType = 6,
	ETCT_Duration = 7,
	ETCT_TakeDamage = 8,
	ETCT_KillPlayer = 9,
	ETCT_CollectItem = 10,
	ETCT_TeamAction = 11,
	ETCT_MAX = 12
};

// Object Name: Enum ShadowTrackerExtra.ECharacterAnimOverrideType
enum class ECharacterAnimOverrideType : uint8 {
	ECAOT_Default = 0,
	ECAOT_FlySuit = 1,
	ECAOT_FlyDevice = 2,
	ECAOT_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EWeaponOperationMode
enum class EWeaponOperationMode : uint8 {
	None = 0,
	Shoot = 1,
	Skill = 2,
	Throw = 3,
	EWeaponOperationMode_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EMsgType
enum class EMsgType : uint8 {
	EMsg_GMEnterActive = 0,
	EMsg_GMExitActive = 1,
	EMsg_GMEnterReady = 2,
	EMsg_GMExitReady = 3,
	EMsg_GMEnterFight = 4,
	EMsg_GMExitFight = 5,
	EMsg_GMEnterFinish = 6,
	EMsg_GMExit = 7,
	EMsg_PCGotoFight = 8,
	EMsg_PCGotoPlane = 9,
	EMsg_PCGotoParachuteJump = 10,
	EMsg_PCGotoParachuteOpen = 11,
	EMsg_PCDie = 12,
	EMsg_PCRespawn = 13,
	EMsg_PCGotoExPlane = 14,
	EMsg_PCGotoLaunch = 15,
	EMsg_MAX = 16
};

// Object Name: Enum ShadowTrackerExtra.EAIType
enum class EAIType : uint8 {
	None = 0,
	DeliverByBT = 1,
	NormalByBT = 2,
	DeliverByML = 3,
	NormalByML = 4,
	EAIType_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.EChangeCharacterState
enum class EChangeCharacterState : uint8 {
	ECCS_None = 0,
	ECCS_RecvChange = 1,
	ECCS_RecvPosses = 2,
	ECCS_RecvUnposses = 3,
	ECCS_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.ETopMostUIPanelType
enum class ETopMostUIPanelType : uint8 {
	ETopUIPanelType_MainInputPanel = 0,
	ETopUIPanelType_BackpackPanel = 1,
	ETopUIPanelType_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EWarScoreChangeReason
enum class EWarScoreChangeReason : uint8 {
	WarScoreChangeReason_NONE = 0,
	WarScoreChangeReason_WHOLETEAMKILLED = 1,
	WarScoreChangeReason_SAVETEAMMATE = 2,
	WarScoreChangeReason_KNOCKDOWNENEMY = 3,
	WarScoreChangeReason_KILLENEMY = 4,
	WarScoreChangeReason_PICKUPSCOREITEM = 5,
	WarScoreChangeReason_GRABSCORE = 6,
	WarScoreChangeReason_MAX = 7
};

// Object Name: Enum ShadowTrackerExtra.EReportLogType
enum class EReportLogType : uint8 {
	AntiDataClientEmpty = 0,
	AntiDataClientFilter = 1,
	AntiDataClientCRC = 2,
	AntiDataSDkNull = 3,
	AntiDataSDKZero = 4,
	AntiDataSDKLong = 5,
	AntiDataSDkEmpty = 6,
	AntiDataDSEmpty = 7,
	AntiDataClientOK = 8,
	AntiDataPlatformInvaild = 9,
	EReportLogType_MAX = 10
};

// Object Name: Enum ShadowTrackerExtra.EPhotographerOptype
enum class EPhotographerOptype : uint8 {
	Open = 0,
	TakePhoto = 1,
	Template = 2,
	EPhotographerOptype_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.ESTEPoseStateFailReason
enum class ESTEPoseStateFailReason : uint8 {
	None = 0,
	SamePose = 1,
	ESTEPoseStateFailReason_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EPressType
enum class EPressType : uint8 {
	PressNone = 0,
	PressFireBtn = 1,
	PressMax = 2,
	EPressType_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EForceHideState
enum class EForceHideState : uint8 {
	None = 0,
	All = 1,
	Team = 2,
	Self = 3,
	EForceHideState_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EPhysicalSurfaceDescription
enum class EPhysicalSurfaceDescription : uint8 {
	Default = 0,
	Concrete = 1,
	Dirt = 2,
	Water = 3,
	Metal = 4,
	Wood = 5,
	Grass = 6,
	Glass = 7,
	Flesh = 8,
	Steel = 9,
	Sandbag = 10,
	Sand = 11,
	Cloth = 12,
	Plastic = 13,
	Leather = 14,
	Ceramics = 15,
	Paper = 16,
	Stone = 17,
	Snow = 18,
	PopCan = 19,
	Pyrefly = 20,
	Leaf = 21,
	Car = 22,
	Asphalt = 23,
	ConcreteTDM = 24,
	Ice = 25,
	Food = 28,
	EPhysicalSurfaceDescription_MAX = 29
};

// Object Name: Enum ShadowTrackerExtra.ERenderQuality
enum class ERenderQuality : uint8 {
	Default = 0,
	SMOOTH = 1,
	BALANCE = 2,
	HIGHDEFINITION = 3,
	HIGHDEFINITIONPLUS = 4,
	ULTRAHIGHDEFINITION = 5,
	VERYSMOOTH = 6,
	ERenderQuality_MAX = 7
};

// Object Name: Enum ShadowTrackerExtra.ETouchFireType
enum class ETouchFireType : uint8 {
	NotFire = 0,
	ButtonFire = 1,
	TouchForceFire = 2,
	DoubleClickFire = 3,
	ETouchFireType_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EnmSprintOptType
enum class EnmSprintOptType : uint8 {
	NoneOpt = 0,
	TimeToSprint = 1,
	DistToSprint = 2,
	EnmSprintOptType_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EKillOrPutDownMessageType
enum class EKillOrPutDownMessageType : uint8 {
	EKillOrPutDownMessageType_YouPutDownPlayer = 0,
	EKillOrPutDownMessageType_YouKilledPlayer = 1,
	EKillOrPutDownMessageType_YouHaveBeenPutDown = 2,
	EKillOrPutDownMessageType_YouHaveBeenKilled = 3,
	EKillOrPutDownMessageType_YourTeammatePutDownPlayer = 4,
	EKillOrPutDownMessageType_YourTeammateKilledPlayer = 5,
	EKillOrPutDownMessageType_YourTeammateHaveBeenPutDown = 6,
	EKillOrPutDownMessageType_YourTeammateHaveBeenKilled = 7,
	EKillOrPutDownMessageType_YouHaveBeenKilledByPoison = 8,
	EKillOrPutDownMessageType_YourTeammateHaveBeenKilledByPoison = 9,
	EKillOrPutDownMessageType_YouHaveBeenPutDownByPoison = 10,
	EKillOrPutDownMessageType_YourTeammateHaveBeenPutDownByPoison = 11,
	EKillOrPutDownMessageType_YouHaveBeenPutDownByFallingDown = 12,
	EKillOrPutDownMessageType_YourTeammateHaveBeenPutDownByFallingDown = 13,
	EKillOrPutDownMessageType_YouHaveBeenKilledByFallingDown = 14,
	EKillOrPutDownMessageType_YourTeammateHaveBeenKilledByFallingDown = 15,
	EKillOrPutDownMessageType_YouHaveBeenPutDownByDrowing = 16,
	EKillOrPutDownMessageType_YourTeammateHaveBeenPutDownByDrowing = 17,
	EKillOrPutDownMessageType_YouHaveBeenKilledByDrowing = 18,
	EKillOrPutDownMessageType_YourTeammateHaveBeenKilledByDrowing = 19,
	EKillOrPutDownMessageType_YouHaveBeenKilledFinally = 20,
	EKillOrPutDownMessageType_YourTeammateHaveBeenKilledFinally = 21,
	EKillOrPutDownMessageType_YouHaveBeenPutDownByAirAttack = 22,
	EKillOrPutDownMessageType_YourTeammateHaveBeenPutDownByAirAttack = 23,
	EKillOrPutDownMessageType_YouHaveBeenKilledByAirAttack = 24,
	EKillOrPutDownMessageType_YourTeammateHaveBeenKilledByAirAttack = 25,
	EKillOrPutDownMessageType_YouHaveBeenPutDownByPoisonWater = 26,
	EKillOrPutDownMessageType_YourTeammateHaveBeenPutDownByPoisonWater = 27,
	EKillOrPutDownMessageType_YouHaveBeenKilledByPoisonWater = 28,
	EKillOrPutDownMessageType_YourTeammateHaveBeenKilledByPoisonWater = 29,
	EKillOrPutDownMessageType_YouHaveBeenKilledByLowTemperature = 30,
	EKillOrPutDownMessageType_YourTeammateHaveBeenKilledByLowTemperature = 31,
	EKillOrPutDownMessageType_YouHaveBeenPutDownByLowTemperature = 32,
	EKillOrPutDownMessageType_YourTeammateHaveBeenPutDownByLowTemperature = 33,
	EKillOrPutDownMessageType_MAX = 34
};

// Object Name: Enum ShadowTrackerExtra.EAutoAimType
enum class EAutoAimType : uint8 {
	FullTime = 0,
	OnlyFire = 1,
	OnlyTouch = 2,
	OnlyNotTouch = 3,
	TouchOrFire = 4,
	ScopeOrFire = 5,
	EAutoAimType_MAX = 6
};

// Object Name: Enum ShadowTrackerExtra.EMonsterPoseType
enum class EMonsterPoseType : uint8 {
	EMonsterPose_Birth01 = 0,
	EMonsterPose_Birth02 = 1,
	EMonsterPose_Idle = 2,
	EMonsterPose_Combat_Idle = 3,
	EMonsterPose_Run = 4,
	EMonsterPose_Combat_Run = 5,
	EMonsterPose_Attack_01 = 6,
	EMonsterPose_Attack_02 = 7,
	EMonsterPose_Attack_03 = 8,
	EMonsterPose_Hit = 9,
	EMonsterPose_Hit_Hard = 10,
	EMonsterPose_Stiff = 11,
	EMonsterPose_Jump_Start = 12,
	EMonsterPose_Fall = 13,
	EMonsterPose_Fall_Stand = 14,
	EMonsterPose_Fall_Hard_Stand = 15,
	EMonsterPose_Death_Front = 16,
	EMonsterPose_Death_HeadShot = 17,
	EMonsterPose_Death_VehicleHit = 18,
	EMonsterPose_Death_Explosion = 19,
	EMonsterPose_Death_Stand = 20,
	EMonsterPose_Climb = 21,
	EMonsterPose_Climb_Window = 22,
	EMonsterPose_Climbing = 23,
	EMonsterPose_Stun = 24,
	EMonsterPose_Stride = 25,
	EMonsterPose_Active = 26,
	EMonsterPose_Turn = 27,
	EMonsterPose_StopLeftLeg = 28,
	EMonsterPose_StopRightLeg = 29,
	EMonsterPose_StopLeftLeg_Front = 30,
	EMonsterPose_StopRightLeg_Front = 31,
	EMonsterPose_RunStopLeftLeg = 32,
	EMonsterPose_RunStopRightLeg = 33,
	EMonsterPose_RunStopLeftLeg_Front = 34,
	EMonsterPose_RunStopRightLeg_Front = 35,
	EMonsterPose_Max = 36
};

// Object Name: Enum ShadowTrackerExtra.EAvatarCustomType
enum class EAvatarCustomType : uint8 {
	AvatarCustomNone = 0,
	AvatarCustomCharacter = 1,
	AvatarCustomWeapon = 2,
	AvatarCustomVehicle = 3,
	AvatarCustomPet = 4,
	EAvatarCustomType_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.ESlotDescDiff
enum class ESlotDescDiff : uint8 {
	NONE = 0,
	VisibleDiff = 1,
	MeshDiff = 2,
	MatDiff = 3,
	ESlotDescDiff_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EVehicleStyleType
enum class EVehicleStyleType : uint8 {
	EVehicleStyleType_NONE = 0,
	EVehicleStyleType_Model = 1,
	EVehicleStyleType_Color = 2,
	EVehicleStyleType_Pattern = 3,
	EVehicleStyleType_Particle = 4,
	EVehicleStyleType_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.EVehicleSlotType
enum class EVehicleSlotType : uint8 {
	EVehicleSlotType_NONE = 0,
	EVehicleSlotType_Body = 1,
	EVehicleSlotType_Bonnet = 2,
	EVehicleSlotType_Wheel = 3,
	EVehicleSlotType_FrontBumper = 4,
	EVehicleSlotType_TailBumper = 5,
	EVehicleSlotType_Empennage = 6,
	EVehicleSlotType_Skirt = 7,
	EVehicleSlotType_Interior = 8,
	EVehicleSlotType_Roof = 9,
	EVehicleSlotType_Exhaust = 10,
	EVehicleSlotType_Attach1 = 11,
	EVehicleSlotType_Attach2 = 12,
	EVehicleSlotType_Attach3 = 13,
	EVehicleSlotType_Attach4 = 14,
	EVehicleSlotType_MaxSlotNum = 15,
	EVehicleSlotType_MAX = 16
};

// Object Name: Enum ShadowTrackerExtra.ESTExtraVehicleUserState
enum class ESTExtraVehicleUserState : uint8 {
	EVUS_OutOfVehicle = 0,
	EVUS_AsDriver = 1,
	EVUS_ASPassenger = 2,
	EVUS_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.ESTExtraUAVVehicleState
enum class ESTExtraUAVVehicleState : uint8 {
	UAVS_Init = 0,
	UAVS_Using = 1,
	UAVS_StandBy = 2,
	UAVS_PowerOff = 3,
	UAVS_Recalling = 4,
	UAVS_Disappearing = 5,
	UAVS_Destroy = 6,
	UAVS_SelfDestruct = 7,
	UAVS_InWater = 8,
	UAVS_Max = 9
};

// Object Name: Enum ShadowTrackerExtra.ERetargetAvatarAdaptSpace
enum class ERetargetAvatarAdaptSpace : uint8 {
	RAAS_None = 0,
	RAAS_MasterComponent_RootBoneSpace = 1,
	RAAS_MasterComponent_ParentSpace = 2,
	RAAS_RetargetComponent_RootBoneSpace = 4,
	RAAS_RetargetComponent_ParentSpace = 8,
	RAAS_MAX = 9
};

// Object Name: Enum ShadowTrackerExtra.EAvatarSlotNameConfig
enum class EAvatarSlotNameConfig : uint8 {
	EAvatarSlotNameConfig_None = 0,
	EAvatarSlotNameConfig_Swim_Suit = 1,
	EAvatarSlotNameConfig_Swim_Pants = 2,
	EAvatarSlotNameConfig_Female_Default_Bra = 3,
	EAvatarSlotNameConfig_SanJiaoKu = 4,
	EAvatarSlotNameConfig_Black_Pants = 5,
	EAvatarSlotNameConfig_Female_White_Bra = 6,
	EAvatarSlotNameConfig_Female_Black_Bra = 7,
	EAvatarSlotNameConfig_MAX = 8
};

// Object Name: Enum ShadowTrackerExtra.EEffectValidDevice
enum class EEffectValidDevice : uint8 {
	LowDevice = 1,
	MidDevice = 2,
	HighDevice = 4,
	LowAndMidDevice = 3,
	LowAndHighDevice = 5,
	MidAndHighDevice = 6,
	All = 15,
	EEffectValidDevice_MAX = 16
};

// Object Name: Enum ShadowTrackerExtra.EEffectValidTarget
enum class EEffectValidTarget : uint8 {
	Self = 1,
	Teammate = 2,
	Enemy = 4,
	SelfAndTeammate = 3,
	SelfAndEnemy = 5,
	EnemyAndTeammate = 6,
	All = 7,
	EEffectValidTarget_MAX = 8
};

// Object Name: Enum ShadowTrackerExtra.EEffectCreateType
enum class EEffectCreateType : uint8 {
	All = 0,
	RandomOne = 1,
	RandomGroup = 2,
	RandomSocket = 3,
	EEffectCreateType_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EAvatarSubSlot
enum class EAvatarSubSlot : uint8 {
	ESubSlot_None = 0,
	ESubSlot_PonyTailHairSlot = 60,
	ESubSlot_AnimHair = 61,
	ESubSlot_HatPre1 = 65,
	ESubSlot_HatPre2 = 66,
	ESubSlot_AnimHat = 67,
	ESubSlot_VeilSlot = 70,
	ESubSlot_GhostFace = 71,
	ESubSlot_FacePre1 = 72,
	ESubSlot_FacePre2 = 73,
	ESubSlot_AnimBeard = 74,
	ESubSlot_HoodSlot = 75,
	ESubSlot_ClothPre1 = 76,
	ESubSlot_ClothPre2 = 77,
	ESubSlot_StockingSlot = 85,
	ESubSlot_BootsSlot = 86,
	ESubSlot_MAX = 87
};

// Object Name: Enum ShadowTrackerExtra.ENewbieGuidePlayerCategory
enum class ENewbieGuidePlayerCategory : uint8 {
	Low = 0,
	Middle = 1,
	High = 2,
	ENewbieGuidePlayerCategory_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.ENewbieGuideType
enum class ENewbieGuideType : uint8 {
	Op = 0,
	Rule = 1,
	ENewbieGuideType_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EAirDropType
enum class EAirDropType : uint8 {
	AirDrop_None = 0,
	AirDrop_NormalAirDrop = 1,
	AirDrop_SuperAirDrop = 2,
	AirDrop_VehicleAirDrop = 3,
	AirDrop_ZombieAirDrop = 4,
	AirDrop_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.EMaxFlyHeightType
enum class EMaxFlyHeightType : uint8 {
	RelativeToInitialHeight = 0,
	WorldAbsoluteHeight = 1,
	EMaxFlyHeightType_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EEmergencyCallStateType
enum class EEmergencyCallStateType : uint8 {
	ECState_None = 0,
	ECState_Building = 1,
	ECState_FirstStage = 2,
	ECState_SecondStage = 3,
	ECState_Idle = 4,
	ECState_Flying = 5,
	ECState_MAX = 6
};

// Object Name: Enum ShadowTrackerExtra.EHardPointOccupyState
enum class EHardPointOccupyState : uint8 {
	Neutral = 0,
	Occupied = 1,
	Contending = 2,
	EHardPointOccupyState_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EActorStatus
enum class EActorStatus : uint8 {
	None = 0,
	Born = 1,
	Normal = 2,
	Broken = 3,
	Dead = 4,
	Backup4 = 5,
	Backup5 = 6,
	Backup6 = 7,
	Backup7 = 8,
	Backup8 = 9,
	Backup9 = 10,
	Max = 99
};

// Object Name: Enum ShadowTrackerExtra.EDamageableMeshState
enum class EDamageableMeshState : uint8 {
	EDMS_Normal = 0,
	EDMS_HealthEvent = 1,
	EDMS_NearDeath = 2,
	EDMS_Die = 3,
	EDMS_DieByInitiative = 4,
	EDMS_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.ERandomRocketExplosionType
enum class ERandomRocketExplosionType : uint8 {
	ERRET_COLLIDE = 0,
	ERRET_BOMBARMENT = 1,
	ERRET_DESTRUCTED = 2,
	ERRET_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.ECaptiveStatus
enum class ECaptiveStatus : uint8 {
	CaptiveNone = 0,
	PrepareCaptive = 1,
	DoCaptiving = 2,
	Captiving = 3,
	Captived = 4,
	Rollbacking = 5,
	ECaptiveStatus_MAX = 6
};

// Object Name: Enum ShadowTrackerExtra.EEnterAreaFlyStateType
enum class EEnterAreaFlyStateType : uint8 {
	EAFState_None = 0,
	EAFState_TakeOff = 1,
	EAFState_Rush = 2,
	EAFState_Rush2 = 3,
	EAFState_Launch = 4,
	EAFState_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.EGamePawnEvent
enum class EGamePawnEvent : uint8 {
	None = 0,
	Birth = 1,
	ViewPlane = 2,
	Plane = 3,
	Jump = 4,
	Parachute = 5,
	Land = 6,
	Die = 7,
	ReBirth = 8,
	HeightCheck_High = 9,
	HeightCheck_Mid = 10,
	HeightCheck_Low = 11,
	Fighting = 12,
	EGamePawnEvent_MAX = 13
};

// Object Name: Enum ShadowTrackerExtra.EZiplineMovementMode
enum class EZiplineMovementMode : uint8 {
	Duration = 0,
	SpeedCurve = 1,
	EZiplineMovementMode_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.ObjectMovingType
enum class ObjectMovingType : uint8 {
	OMT_Uniform = 0,
	OMT_Acceleration = 1,
	OMT_Deceleration = 2,
	OMT_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EAllowThrowMode
enum class EAllowThrowMode : uint8 {
	Any = 0,
	High = 1,
	Low = 2,
	EAllowThrowMode_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EThrowState
enum class EThrowState : uint8 {
	Idle = 0,
	Prepare = 1,
	Aim = 2,
	Release = 3,
	Drop = 4,
	EThrowState_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.ERenderDynamicStyle
enum class ERenderDynamicStyle : uint8 {
	Default = 0,
	GuidedMissile = 1,
	SceneToGrayOnDeath = 2,
	ThermalImagingStyle = 3,
	ERenderDynamicStyle_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.ERenderStyle
enum class ERenderStyle : uint8 {
	Default = 0,
	CLASSIC = 1,
	COLOURFUL = 2,
	REALISTIC = 3,
	SOFT = 4,
	NightVision = 5,
	MOVIE = 6,
	DynamicStyle = 7,
	ERenderStyle_MAX = 8
};

// Object Name: Enum ShadowTrackerExtra.ESoundEffect
enum class ESoundEffect : uint8 {
	LOW = 0,
	HIGH = 1,
	SUPERHIGH = 2,
	ESoundEffect_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EGamePlayMode
enum class EGamePlayMode : uint8 {
	None = 1,
	TeamPVE = 2,
	EGamePlayMode_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.ERoleMainSkillID
enum class ERoleMainSkillID : int32 {
	INVISIBLE = 110007,
	ERoleMainSkillID_MAX = 110008
};

// Object Name: Enum ShadowTrackerExtra.EInfectionRoundStateType
enum class EInfectionRoundStateType : uint8 {
	RoundBefore = 0,
	RoundReady = 1,
	RoundFight = 2,
	RoundEnd = 3,
	EInfectionRoundStateType_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EInfectionBGMStateType
enum class EInfectionBGMStateType : uint8 {
	RoundBefore = 0,
	RoundReady = 1,
	RoundFight_Zombie = 2,
	RoundFight_Revenger = 3,
	RoundEnd = 4,
	EInfectionBGMStateType_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.EIslandStateType
enum class EIslandStateType : uint8 {
	IST_Init = 0,
	IST_Opening = 1,
	IST_Close = 2,
	IST_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EVehicleWarGemMatchState
enum class EVehicleWarGemMatchState : uint8 {
	EVM_Ready = 0,
	EVM_Normal = 1,
	EVM_MatchPoint = 2,
	EVM_MatchPointFight = 3,
	EVM_MatchEnd = 4,
	EVM_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.EPetState
enum class EPetState : uint8 {
	PetStateNone = 0,
	PetIdle = 1,
	PetDisappear = 2,
	PetParachute = 3,
	PetFollow = 4,
	PetFlyAround = 5,
	PetSwimming = 6,
	PetSleeping = 7,
	EPetState_MAX = 8
};

// Object Name: Enum ShadowTrackerExtra.EPlayerAutoNavMode
enum class EPlayerAutoNavMode : uint8 {
	StaticLocation = 0,
	Character = 1,
	EPlayerAutoNavMode_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EPlayerAutoNavFindResult
enum class EPlayerAutoNavFindResult : uint8 {
	HasPath = 0,
	NoPath = 1,
	NoCharacter = 2,
	EPlayerAutoNavFindResult_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EPlayerAutoNavResult
enum class EPlayerAutoNavResult : uint8 {
	Succeed = 0,
	Failed = 1,
	UserCancel = 2,
	NoCharacter = 3,
	EPlayerAutoNavResult_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.ESIslandActiveType
enum class ESIslandActiveType : uint8 {
	SAT_Active = 0,
	SAT_PandingKickOut = 1,
	SAT_kickedOut = 2,
	SAT_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EFieldOfViewNotificationStatus
enum class EFieldOfViewNotificationStatus : uint8 {
	None = 0,
	Rendered = 1,
	Traced = 2,
	EnumMax = 3,
	EFieldOfViewNotificationStatus_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EDeathMatchPersonalNotifyReason
enum class EDeathMatchPersonalNotifyReason : uint8 {
	Kill = 0,
	HeadShoot = 1,
	EDeathMatchPersonalNotifyReason_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EDeathMatchDamageResult
enum class EDeathMatchDamageResult : uint8 {
	None = 0,
	Assist = 1,
	Kill = 2,
	EDeathMatchDamageResult_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EDeathMatchGlobalNotifyReason
enum class EDeathMatchGlobalNotifyReason : uint8 {
	FirstKill = 0,
	SuperGod = 1,
	LastStraw = 2,
	Slaughter = 3,
	GameComingEnd_KillNum = 4,
	GameComingEnd_RemainTime = 5,
	HardPointHalfTime = 6,
	HardPointComingEnd_Score = 7,
	HardPointComingEnd_RemainTime = 8,
	ArmsRace_Pan = 9,
	EDeathMatchGlobalNotifyReason_MAX = 10
};

// Object Name: Enum ShadowTrackerExtra.EDeathMatchGameEndType
enum class EDeathMatchGameEndType : uint8 {
	None = 0,
	ScoreWin = 1,
	Timeout = 2,
	EnemyEscape = 3,
	EDeathMatchGameEndType_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EDeathMatchGlobalAudioType
enum class EDeathMatchGlobalAudioType : uint8 {
	FirstKill = 0,
	SuperGod = 1,
	SuperGodEnd = 2,
	Rampage = 3,
	GameComingHalfScore = 4,
	GameComingEnd_KillNum = 5,
	GameComingHalfTime = 6,
	GameComingEnd_RemainTime = 7,
	HardPointHalfTime = 8,
	HardPointComingEnd_Score = 9,
	HardPointComingEnd_RemainTime = 10,
	EDeathMatchGlobalAudioType_MAX = 11
};

// Object Name: Enum ShadowTrackerExtra.EAutoLockSignType
enum class EAutoLockSignType : uint8 {
	ALS_Normal = 0,
	ALS_Locking = 1,
	ALS_Locked = 2,
	ALS_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EDamageType
enum class EDamageType : int32 {
	InvalidDamageType = 0,
	ShootDamage = 1,
	STPointDamage = 3,
	CustomRadiusDamage = 4,
	PoisonDamage = 13,
	DrowningDamage = 14,
	FallingDamage = 15,
	MeleeDamage = 16,
	GrenadeRadiusDamage = 17,
	BurningDamage = 18,
	AirAttackDamage = 19,
	VehicleDamage = 20,
	VehicleExplodeRadiusDamage = 21,
	LastBreathWithoutRescue = 22,
	WinnerFakeDeath = 23,
	SkillDamage = 24,
	PoisonFogDamage = 25,
	GasolineCanExplosion = 26,
	ZombieDamage = 27,
	LowTemperatureDamage = 28,
	TopFiveGaveUpDamage = 29,
	Resurrection = 30,
	TyrantMonsterStonedDamage = 31,
	RPGExplosionDamage = 32,
	CartridgeExplosionDamage = 33,
	DotDamage = 34,
	RadialDamage = 9999,
	CustomRadialDamage = 1231231,
	EDamageType_MAX = 1231232
};

// Object Name: Enum ShadowTrackerExtra.EBallVehicleMotionState
enum class EBallVehicleMotionState : uint8 {
	ENormalState = 0,
	EReadyForKick = 1,
	EInJumpState = 2,
	EInSecondJumpState = 3,
	EBallVehicleMotionState_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.ECatapultMachineStateType
enum class ECatapultMachineStateType : uint8 {
	CMState_Initial = 0,
	CMState_ChargeReady = 1,
	CMState_Charge = 2,
	CMState_Launch = 3,
	CMState_Cooldown = 4,
	CMState_Supplement = 5,
	CMState_MAX = 6
};

// Object Name: Enum ShadowTrackerExtra.EOutlineType
enum class EOutlineType : uint8 {
	NONE = 0,
	Self = 1,
	SameTeam = 2,
	SameCamp = 3,
	Enemy = 4,
	EOutlineType_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.ESTExtraUAVVehicleOperateState
enum class ESTExtraUAVVehicleOperateState : uint8 {
	Operate_Normal = 0,
	Operate_WithUp = 1,
	Operate_WithDown = 2,
	Operate_Clear = 3,
	Operate_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.ECameraDataType
enum class ECameraDataType : uint8 {
	ECameraDataType_Stand = 0,
	ECameraDataType_Crouch = 1,
	ECameraDataType_Prone = 2,
	ECameraDataType_Indoor = 3,
	ECameraDataType_LeanLeft = 4,
	ECameraDataType_LeanRight = 5,
	ECameraDataType_Vehicle = 6,
	ECameraDataType_NearDeath = 7,
	ECameraDataType_PeekLeft = 8,
	ECameraDataType_PeekRight = 9,
	ECameraDataType_IndoorLowerCameraStand = 10,
	ECameraDataType_IndoorLowerCameraCrouch = 11,
	ECameraDataType_IndoorLowerCameraProne = 12,
	ECameraDataType_Vault = 13,
	ECameraDataType_Shoveling = 14,
	ECameraDataType_Helicopter = 15,
	ECameraDataType_FireBalloon = 16,
	ECameraDataType_ShoulderLeft = 17,
	ECameraDataType_ShoulderRight = 18,
	ECameraDataType_Insect = 19,
	ECameraDataType_Skill = 20,
	ECameraDataType_Max = 21
};

// Object Name: Enum ShadowTrackerExtra.ESTAINoiseType
enum class ESTAINoiseType : uint8 {
	PlayerShootSound = 0,
	VehicleRunSound = 1,
	VehicleHornSound = 2,
	ESTAINoiseType_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.ESTExtraVehicleSyncState
enum class ESTExtraVehicleSyncState : uint8 {
	VSS_None = 0,
	VSS_Client = 1,
	VSS_ServerAuthorize = 2,
	VSS_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.ESTExtraVehicleShapeType
enum class ESTExtraVehicleShapeType : uint8 {
	VST_Unknown = 0,
	VST_Motorbike = 1,
	VST_Motorbike_SideCart = 2,
	VST_Dacia = 3,
	VST_MiniBus = 4,
	VST_PickUp = 5,
	VST_PickUp_2 = 6,
	VST_Buggy_1 = 7,
	VST_UAZ_1 = 8,
	VST_UAZ_2 = 9,
	VST_UAZ_3 = 10,
	VST_PG117 = 11,
	VST_Aquarail = 12,
	VST_UAZ_4 = 13,
	VST_Mirado = 14,
	VST_Mirado_2 = 15,
	VST_Rony = 16,
	VST_Scooter = 17,
	VST_SnowMobile = 18,
	VST_TukTukTuk = 19,
	VST_SnowBike = 20,
	VST_Surfboard = 21,
	VST_Snowboard = 22,
	VST_UH60 = 23,
	VST_Amphibious = 24,
	VST_LadaNiva = 25,
	VST_UAV = 26,
	VST_LootTruck = 27,
	VST_ATGMotorCycle = 28,
	VST_ModelY = 29,
	VST_ATV = 30,
	VST_SciFi = 31,
	VST_MegaDrop = 49,
	VST_Lamborghini = 50,
	VST_Lamborghini_2 = 51,
	VST_GoldMirado = 52,
	VST_BigFoot = 53,
	VST_HeavyDacia = 54,
	VST_HeavyPickup = 55,
	VST_HeavyBuggy = 56,
	VST_HeavyUAZ = 57,
	VST_HeavyUH60 = 58,
	VST_TrackVehicle = 59,
	VST_Motorglider = 60,
	VST_CoupeRB = 61,
	VST_CatapultMachine = 62,
	VST_MBT = 63,
	VST_UTV = 64,
	VST_Bike = 65,
	VST_WingMan = 66,
	VST_PreparedVeh1 = 101,
	VST_PreparedVeh2 = 102,
	VST_MAX = 103
};

// Object Name: Enum ShadowTrackerExtra.EVehWeaponCameraSpace
enum class EVehWeaponCameraSpace : uint8 {
	WorldSpace = 0,
	VehicleSpace = 1,
	EVehWeaponCameraSpace_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EVehicleWarBeLockedState
enum class EVehicleWarBeLockedState : uint8 {
	BLS_NotLock = 0,
	BLS_Locking = 1,
	BLS_Locked = 2,
	BLS_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EProjectilePassThroughType
enum class EProjectilePassThroughType : uint8 {
	Ignore = 0,
	PassThrough = 1,
	Block = 2,
	EProjectilePassThroughType_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EActorHiddenMask
enum class EActorHiddenMask : uint8 {
	ActorHiddenMask0 = 0,
	ActorHiddenMask1 = 1,
	ActorHiddenMask2 = 2,
	ActorHiddenMask3 = 3,
	ActorHiddenMask4 = 4,
	ActorHiddenMask5 = 5,
	ActorHiddenMask6 = 6,
	ActorHiddenMask7 = 7,
	EActorHiddenMask_MAX = 8
};

// Object Name: Enum ShadowTrackerExtra.EEnemyType
enum class EEnemyType : uint8 {
	ERealPlayer = 0,
	EZombie = 1,
	EBuildings = 2,
	ETreasureBox = 3,
	EProjectile = 4,
	EEnemyType_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.EFlyTargetLocHeightSetType
enum class EFlyTargetLocHeightSetType : uint8 {
	FlyHeightSet_RelativeGround = 1,
	FlyHeightSet_RelativeCenter = 2,
	FlyHeightSet_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EAI_BlockType
enum class EAI_BlockType : uint8 {
	NoneBlock = 0,
	HaveNoNavMesh = 1,
	HaveNavMesh = 2,
	EAI_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EAnimalMovePose
enum class EAnimalMovePose : uint8 {
	Walk = 0,
	Trot = 1,
	Run = 2,
	KeepCurrentPose = 3,
	EAnimalMovePose_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EAIMoveType
enum class EAIMoveType : uint8 {
	StraightMove = 0,
	CurveMove = 1,
	EAIMoveType_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EAIWeaponShootType
enum class EAIWeaponShootType : uint8 {
	SingleShot = 0,
	Auto = 1,
	EAIWeaponShootType_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EAINewFocusPriority
enum class EAINewFocusPriority : uint8 {
	Default = 0,
	Move = 1,
	Gameplay = 2,
	EAINewFocusPriority_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EAIMovePose
enum class EAIMovePose : uint8 {
	Walk = 0,
	Run = 1,
	CrouchSprint = 2,
	KeepCurrentPose = 3,
	Prone = 4,
	Crouch = 5,
	EAIMovePose_MAX = 6
};

// Object Name: Enum ShadowTrackerExtra.EAIPoseState
enum class EAIPoseState : uint8 {
	Stand = 0,
	Crouch = 1,
	Prone = 2,
	Jump = 3,
	EAIPoseState_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EAITriggerAttrType
enum class EAITriggerAttrType : uint8 {
	None = 0,
	Health = 1,
	Energy = 2,
	EAITriggerAttrType_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EAIAttrCompareType
enum class EAIAttrCompareType : uint8 {
	None = 0,
	Great = 1,
	Less = 2,
	EAIAttrCompareType_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EAIOrderType
enum class EAIOrderType : uint8 {
	Invalid = 0,
	MoveTo = 1,
	MoveAttack = 2,
	AttackMove = 3,
	MoveToTarget = 4,
	AttackTarget = 5,
	GuardTarget = 6,
	GuardArea = 7,
	CastSkillNoneTarget = 8,
	CastSkillOnTarget = 9,
	CastSkillOnLocation = 10,
	IdleShow = 11,
	RotateTo = 12,
	Stop = 99,
	EAIOrderType_MAX = 100
};

// Object Name: Enum ShadowTrackerExtra.EJumpStrategy
enum class EJumpStrategy : uint8 {
	Default = 0,
	Lean = 1,
	Direct = 2,
	Glide = 3,
	Horizontal = 4,
	DirectGlide = 5,
	VerticalLean = 6,
	HorizontalLean = 7,
	EJumpStrategy_MAX = 8
};

// Object Name: Enum ShadowTrackerExtra.EAirAttackGenerateType
enum class EAirAttackGenerateType : uint8 {
	None = 0,
	Ringtaw = 1,
	Outsider = 2,
	RandomExcludeNone = 3,
	NotSet = 4,
	EAirAttackGenerateType_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.EExecuteAirDropOrderResult
enum class EExecuteAirDropOrderResult : uint8 {
	MakeAirDropOrderDone = 0,
	UndefinedADFReason = 1,
	RandomDropFailure = 2,
	NothingToDrop = 3,
	GameNotStart = 4,
	GameEnded = 5,
	GameStateInvalid = 6,
	DroppingLocationOutSideLandscape = 7,
	LandscapeExtentInvalid = 8,
	FlyingDirectionInValid = 9,
	AirPlaneClassInvalid = 10,
	NoLandscapeToDrop = 11,
	UseCustomStrategy = 12,
	EExecuteAirDropOrderResult_MAX = 13
};

// Object Name: Enum ShadowTrackerExtra.EAIWayPointEventResult
enum class EAIWayPointEventResult : uint8 {
	Succeeded = 0,
	Failed = 1,
	Aborted = 2,
	InProgress = 3,
	None = 4,
	EAIWayPointEventResult_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.EHearSoundCharacterType
enum class EHearSoundCharacterType : uint8 {
	CharacterType_Zombie = 0,
	CharacterType_Animal = 1,
	CharacterType_AIPlayer = 2,
	CharacterType_MlAIPlayer = 3,
	CharacterType_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.ESoundType
enum class ESoundType : uint8 {
	SoundType_FootStep_Default = 0,
	SoundType_FootStep_Walk = 1,
	SoundType_FootStep_Run = 2,
	SoundType_FootStep_Crouch = 3,
	SoundType_FootStep_Prone = 4,
	SoundType_Weapon_L_WithSilencer = 5,
	SoundType_Weapon_L_WithoutSilencer = 6,
	SoundType_Weapon_M_WithSilencer = 7,
	SoundType_Weapon_M_WithoutSilencer = 8,
	SoundType_Weapon_S_WithSilencer = 9,
	SoundType_Weapon_S_WithoutSilencer = 10,
	SoundType_Weapon_BulletImpact = 11,
	SoundType_Glass = 12,
	SoundType_Grenade = 13,
	SoundType_FlashBomb = 14,
	SoundType_SmokeBomb = 15,
	SoundType_BurningBottle = 16,
	SoundType_Vehicle = 17,
	SoundType_OpenTreasureBox = 18,
	SoundType_MAX = 19
};

// Object Name: Enum ShadowTrackerExtra.AnimalAnimListType
enum class AnimalAnimListType : uint8 {
	Idle = 0,
	Idle_Arder = 1,
	Walk = 2,
	Trot = 9,
	Run = 3,
	Watch = 5,
	Dead = 6,
	BeHit = 7,
	Fear = 10,
	Cute = 11,
	Max = 12
};

// Object Name: Enum ShadowTrackerExtra.EAnimalDeliverStrategy
enum class EAnimalDeliverStrategy : uint8 {
	EAnimalDeliverStrategy_Team = 0,
	EAnimalDeliverStrategy_Individual = 1,
	EAnimalDeliverStrategy_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.ESelectStrategy
enum class ESelectStrategy : uint8 {
	ESelectStrategy_Forward = 0,
	ESelectStrategy_Reverse = 1,
	ESelectStrategy_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.ESortStrategy
enum class ESortStrategy : uint8 {
	ESortStrategy_Max = 0,
	ESortStrategy_Min = 1,
	ESortStrategy_Average = 2,
	ESortStrategy_Total = 3
};

// Object Name: Enum ShadowTrackerExtra.EAudioRegionEventType
enum class EAudioRegionEventType : uint8 {
	Enter = 0,
	Exit = 1,
	EAudioRegionEventType_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.AudioRegionProcessorType
enum class AudioRegionProcessorType : uint8 {
	AudioRegion = 1,
	AudioRegionEnemy = 2,
	RiverAmbient = 3,
	MagmaAmbient = 4,
	AudioRegionProcessorType_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.AUTO_SCROLL_TYPE
enum class AUTO_SCROLL_TYPE : uint8 {
	LEFT_RIGHT = 0,
	PING_PONG = 1,
	AUTO_SCROLL_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EAvatarActionLifeType
enum class EAvatarActionLifeType : uint8 {
	NONE = 0,
	NormalAction = 1,
	MainAction = 2,
	UniqueAction = 3,
	EAvatarActionLifeType_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EDIYEnableLevel
enum class EDIYEnableLevel : uint8 {
	None = 0,
	Self = 1,
	Team = 2,
	All = 3,
	EDIYEnableLevel_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EDIYMatPart
enum class EDIYMatPart : uint8 {
	EDIYMatPart_Red = 1,
	EDIYMatPart_Green = 2,
	EDIYMatPart_Blue = 3,
	EDIYMatPart_Alpha = 4,
	EDIYMatPart_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.EDIYDecalBakingType
enum class EDIYDecalBakingType : uint8 {
	Character = 0,
	Weapon = 1,
	Vehicle = 2,
	EDIYDecalBakingType_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EAvatarVisiblityType
enum class EAvatarVisiblityType : uint8 {
	EAllVisible = 0,
	ETeammateOnly = 1,
	EAvatarVisiblityType_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EWeaponReuseCfgType
enum class EWeaponReuseCfgType : uint8 {
	ReuseFov = 0,
	ReuseSupportBullet = 1,
	ReuseSupportAttach = 2,
	ReuseAttachMesh = 3,
	ReuseDefaultAttach = 4,
	ReuseAvatar = 5,
	ReuseNone = 6,
	EWeaponReuseCfgType_MAX = 7
};

// Object Name: Enum ShadowTrackerExtra.EHideBoneType
enum class EHideBoneType : uint8 {
	AlwaysValid = 0,
	InvalidWhenReplaced = 1,
	InvalidWhenHidden = 2,
	InvalidWhenHiddenOrReplaced = 3,
	EHideBoneType_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EPostOperationType
enum class EPostOperationType : uint8 {
	Name_None = 0,
	KeepHidden = 1,
	RecoverHidden = 2,
	KeepReplace = 3,
	RecoverReplace = 4,
	EPostOperationType_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.EAvatarAttachmentSlot
enum class EAvatarAttachmentSlot : uint8 {
	NONE = 0,
	Magazine = 1,
	MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EReplaceSlot
enum class EReplaceSlot : uint8 {
	EReplaceType_NONE = 0,
	EReplaceType_HeadEquipemtSlot = 1,
	EReplaceType_HairEquipemtSlot = 2,
	EReplaceType_HatEquipemtSlot = 3,
	EReplaceType_FaceEquipemtSlot = 4,
	EReplaceType_ClothesEquipemtSlot = 5,
	EReplaceType_PantsEquipemtSlot = 6,
	EReplaceType_ShoesEquipemtSlot = 7,
	EReplaceType_BackpackEquipemtSlot = 8,
	EReplaceType_HelmetEquipemtSlot = 9,
	EReplaceType_ArmorEquipemtSlot = 10,
	EReplaceType_ParachuteEquipemtSlot = 11,
	EReplaceType_GlassEquipemtSlot = 12,
	EReplaceType_NightVisionEquipemtSlot = 13,
	EReplaceType_BeardEquipemtSlot = 14,
	EReplaceType_PonyTailHairSlot = 60,
	EReplaceType_VeilSlot = 70,
	EReplaceType_GhostFace = 71,
	EReplaceType_HoodSlot = 75,
	EReplaceType_StockingSlot = 85,
	EReplaceType_BootsSlot = 86,
	EReplaceType_MAX = 87
};

// Object Name: Enum ShadowTrackerExtra.EAvatarSpecialType
enum class EAvatarSpecialType : uint8 {
	EAvatarSpecialType_None = 0,
	EAvatarSpecialType_FlexibleCloth = 1,
	EAvatarSpecialType_CustomCloth = 2,
	EAvatarSpecialType_Bareheaded = 3,
	EAvatarSpecialType_2PassHair = 4,
	EAvatarSpecialType_MoreBoneCloth = 5,
	EAvatarSpecialType_MAX = 6
};

// Object Name: Enum ShadowTrackerExtra.EBackpackItemSortType
enum class EBackpackItemSortType : uint8 {
	EIS_Default = 0,
	EIS_Worth = 1,
	ECT_Type = 2,
	EBackpackItemSortType_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EClipsType
enum class EClipsType : uint8 {
	ECT_EXPANSION = 1,
	ECT_QUICK = 2,
	ECT_QUICK_EXPANSION = 3,
	ECT_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EAvatarDownloadType
enum class EAvatarDownloadType : uint8 {
	EAvatarDownloadType_Character = 0,
	EAvatarDownloadType_Vehicle = 1,
	EAvatarDownloadType_Weapon = 2,
	EAvatarDownloadType_AdvanceVehicle = 3,
	EAvatarDownloadType_Other1 = 4,
	EAvatarDownloadType_Other2 = 5,
	EAvatarDownloadType_Max = 10
};

// Object Name: Enum ShadowTrackerExtra.EBackpackItemType
enum class EBackpackItemType : uint8 {
	UnknownBackpackItemType = 0,
	BackpackItemType_Weapon = 1,
	BackpackItemType_WeaponAttachment = 2,
	BackpackItemType_Ammo = 3,
	BackpackItemType_Clothing = 4,
	BackpackItemType_Armor = 5,
	BackpackItemType_Consumable = 6,
	BackpackItemType_Emote = 7,
	BackpackItemType_SkillProps = 8,
	BackpackItemType_VehicleProps = 9,
	BackpackItemType_Chip = 10,
	EBackpackItemType_MAX = 11
};

// Object Name: Enum ShadowTrackerExtra.EVehicleModifyMatTargetType
enum class EVehicleModifyMatTargetType : uint8 {
	EVehicleModifyMatTargetType_MeshSkin = 0,
	EVehicleModifyMatTargetType_Particle = 1,
	EVehicleModifyMatTargetType_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EVehicleModifyMatParamUsage
enum class EVehicleModifyMatParamUsage : uint8 {
	EVehicleModifyMatParamUsage_SpeedUp = 0,
	EVehicleModifyMatParamUsage_MAX = 1
};

// Object Name: Enum ShadowTrackerExtra.EVehicleModifyMatParamType
enum class EVehicleModifyMatParamType : uint8 {
	EVehicleModifyMatParamType_Float = 0,
	EVehicleModifyMatParamType_Vector = 1,
	EVehicleModifyMatParamType_Tex = 2,
	EVehicleModifyMatParamType_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EAllAttachmentSet
enum class EAllAttachmentSet : uint8 {
	GunPoint = 0,
	Grip = 1,
	Magazine = 2,
	Gunstock = 3,
	IronSight = 4,
	RedPointScope = 5,
	QXScope = 6,
	X2Scope = 7,
	X4Scope = 8,
	X8Scope = 9,
	EAllAttachmentSet_MAX = 10
};

// Object Name: Enum ShadowTrackerExtra.EObstacleDetectionSpace
enum class EObstacleDetectionSpace : uint8 {
	ObstacleDetection_Box = 0,
	ObstacleDetection_CapsuleSweep = 1,
	ObstacleDetection_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EAICheckFlyingStatusType
enum class EAICheckFlyingStatusType : uint8 {
	FlyingStatus_HasNavigationSystem = 0,
	FlyingStatus_NavigationVoxelDataDone = 1,
	FlyingStatus_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EAICheckShootingPoseType
enum class EAICheckShootingPoseType : uint8 {
	ShootingPose_Normal = 0,
	ShootingPose_Stand = 1,
	ShootingPose_Peek = 2,
	ShootingPose_WaitVisibilityCheck = 254,
	ShootingPose_MAX = 255
};

// Object Name: Enum ShadowTrackerExtra.ECompareLengthType
enum class ECompareLengthType : uint8 {
	ELengthGreater = 0,
	ELengthLess = 1,
	ELengthEequal = 2,
	ECompareLengthType_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EAIDecoratorGeneralLineTraceType
enum class EAIDecoratorGeneralLineTraceType : uint8 {
	LineTraceType_Forward = 0,
	LineTraceType_MAX = 1
};

// Object Name: Enum ShadowTrackerExtra.EInSafetyCircleType
enum class EInSafetyCircleType : uint8 {
	EInSafetyCircleType_None = 0,
	EInSafetyCircleType_BlueCircle = 1,
	EInSafetyCircleType_WhiteCircle = 2,
	EInSafetyCircleType_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EItemNumCheckType
enum class EItemNumCheckType : uint8 {
	ItemNumGreater = 0,
	ItemNumLess = 1,
	ItemNumEequal = 2,
	EItemNumCheckType_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EChooseEnemySearchMethod
enum class EChooseEnemySearchMethod : uint8 {
	SearchMethod_Nearest = 0,
	SearchMethod_MostHP = 1,
	SearchMethod_LeastHP = 2,
	SearchMethod_ByBlackboardValue = 255,
	SearchMethod_MAX = 256
};

// Object Name: Enum ShadowTrackerExtra.EChooseEnemyType
enum class EChooseEnemyType : uint8 {
	EnemyType_Player = 0,
	EnemyType_Animal = 1,
	EnemyType_Zombie = 2,
	EnemyType_UAV = 3,
	EnemyType_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EMobAddHPServiceType
enum class EMobAddHPServiceType : uint8 {
	LoseTarget = 0,
	EMobAddHPServiceType_MAX = 1
};

// Object Name: Enum ShadowTrackerExtra.EAISearchEnemyType
enum class EAISearchEnemyType : uint8 {
	Nearest = 1,
	Random = 2,
	EAISearchEnemyType_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EAISearchEnemySingleRule
enum class EAISearchEnemySingleRule : uint8 {
	SingleRule_Hatred = 1,
	SingleRule_Random = 2,
	SingleRule_Nearest = 3,
	SingleRule_MostHP = 4,
	SingleRule_PoorHP = 5,
	SingleRule_BlackboardValue = 255,
	SingleRule_MAX = 256
};

// Object Name: Enum ShadowTrackerExtra.EAISenseGrenadeType
enum class EAISenseGrenadeType : uint8 {
	ExplosionGrenade = 0,
	BurningGrenade = 1,
	SmokingGrenade = 2,
	FlashBomb = 3,
	Grenade_MaxNum = 4,
	EAISenseGrenadeType_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.ETargetAngleCheck
enum class ETargetAngleCheck : uint8 {
	TargetAngleCheckFocus = 0,
	TargetAngleCheckFocusFail = 1,
	TargetAngleCheckFocusSuccess = 2,
	ETargetAngleCheck_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EAIAdvFindOcclusionPointSearchBestOcclusionMethod
enum class EAIAdvFindOcclusionPointSearchBestOcclusionMethod : uint8 {
	Method_Normal = 0,
	Method_NearToTarget = 2,
	Method_FarToTarget = 3,
	Method_NearToSelf = 4,
	Method_RandomOfSelf = 5,
	Method_MAX = 6
};

// Object Name: Enum ShadowTrackerExtra.EAIAdvFindOcclusionPointPoseType
enum class EAIAdvFindOcclusionPointPoseType : uint8 {
	Occlusion_PoseProne = 1,
	Occlusion_PoseCrouch = 2,
	Occlusion_PoseStand = 4,
	Occlusion_PoseBush = 8,
	Occlusion_MAX = 9
};

// Object Name: Enum ShadowTrackerExtra.EFindFlyingHoverPointOneSideShapeOType
enum class EFindFlyingHoverPointOneSideShapeOType : uint8 {
	OT_RandomSide = 0,
	OT_LeftSide = 1,
	OT_RightSide = 2,
	OT_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EFindFlyingHoverPointHoverType
enum class EFindFlyingHoverPointHoverType : uint8 {
	HT_OneSideShapeO = 0,
	HT_MAX = 1
};

// Object Name: Enum ShadowTrackerExtra.EFlyToPathfindingThread
enum class EFlyToPathfindingThread : uint8 {
	Sync = 0,
	ASync = 1,
	EFlyToPathfindingThread_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EMobFindAttackablePositionLineTraceType
enum class EMobFindAttackablePositionLineTraceType : uint8 {
	Normal = 0,
	HalfHeightOffset = 1,
	CustomHeightOffset = 2,
	EMobFindAttackablePositionLineTraceType_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.ESearchType
enum class ESearchType : uint8 {
	CenterInSelfLocation = 0,
	CenterInSpecificLocation = 1,
	ESearchType_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EModifyBlackboardDataValueType
enum class EModifyBlackboardDataValueType : uint8 {
	Int = 0,
	Float = 1,
	Bool = 2,
	String = 3,
	Name = 4,
	Object = 5,
	Vector3 = 6,
	EModifyBlackboardDataValueType_MAX = 7
};

// Object Name: Enum ShadowTrackerExtra.EAIMoveToOcclusionFinishMovePoseType
enum class EAIMoveToOcclusionFinishMovePoseType : uint8 {
	FinishMovePoseType_Normal = 0,
	FinishMovePoseType_CrouchIfACrouchOcclusion = 1,
	FinishMovePoseType_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EAIMoveToOcclusionMovingPoseType
enum class EAIMoveToOcclusionMovingPoseType : uint8 {
	MovingPoseType_Normal = 0,
	MovingPoseType_CrouchSprintIfAlreadyCrouched = 1,
	MovingPoseType_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EAIMoveToOcclusionSearchBestOcclusionMethod
enum class EAIMoveToOcclusionSearchBestOcclusionMethod : uint8 {
	Normal = 0,
	NearToTarget = 2,
	FarToTarget = 3,
	NearToSelf = 4,
	RandomOfSelf = 5,
	EAIMoveToOcclusionSearchBestOcclusionMethod_MAX = 6
};

// Object Name: Enum ShadowTrackerExtra.EAIMoveToOcclusionPoseType
enum class EAIMoveToOcclusionPoseType : uint8 {
	PoseProne = 1,
	PoseCrouch = 2,
	PoseStand = 4,
	PoseBush = 8,
	EAIMoveToOcclusionPoseType_MAX = 9
};

// Object Name: Enum ShadowTrackerExtra.ESeekFlyPointHorizontalAngleType
enum class ESeekFlyPointHorizontalAngleType : uint8 {
	TargetView = 0,
	TargetToSelf = 1,
	BornLocationView = 2,
	ESeekFlyPointHorizontalAngleType_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.ESeekFlyPointCenterLocType
enum class ESeekFlyPointCenterLocType : uint8 {
	Target = 0,
	Self = 1,
	BornLocation = 2,
	ESeekFlyPointCenterLocType_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EAITaskNodeThrowGrenadeMethod
enum class EAITaskNodeThrowGrenadeMethod : uint8 {
	ThrowGrenadeMethod_Normal = 0,
	ThrowGrenadeMethod_Advanced = 1,
	ThrowGrenadeMethod_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.ESmartPhotographerMode
enum class ESmartPhotographerMode : uint8 {
	Photo = 0,
	Video = 1,
	ESmartPhotographerMode_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.ChatFlagType
enum class ChatFlagType : uint8 {
	DanagerForward = 0,
	SaveMe = 1,
	Congregation = 2,
	SuppliesHere = 3,
	GetOnCar = 4,
	NeedSupplies = 5,
	ChatFlagType_MAX = 6
};

// Object Name: Enum ShadowTrackerExtra.EMovementState
enum class EMovementState : uint8 {
	MS_None = 0,
	MS_StartUp = 1,
	MS_Flying = 2,
	MS_ArriveSmallPoint = 3,
	MS_ArriveBigPoint = 4,
	MS_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.EWidgetTouchState
enum class EWidgetTouchState : uint8 {
	None = 0,
	Up = 1,
	Down = 2,
	Dragging = 3,
	EWidgetTouchState_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EClimbingProxyGenerationLineTraceType
enum class EClimbingProxyGenerationLineTraceType : uint8 {
	UsingLineTraceDown = 0,
	WithoutLineTracing = 1,
	EClimbingProxyGenerationLineTraceType_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EClimbingProxyGenerationDirection
enum class EClimbingProxyGenerationDirection : uint8 {
	Default = 0,
	BothWays = 1,
	LeftToRight = 2,
	RightToLeft = 3,
	EClimbingProxyGenerationDirection_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EClimbingProxyGenerationType
enum class EClimbingProxyGenerationType : uint8 {
	Climbing = 0,
	Striding = 1,
	EClimbingProxyGenerationType_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.ECollectedEventDataEventId
enum class ECollectedEventDataEventId : uint8 {
	GameStatus = 0,
	StartMatching = 2,
	PlaneCarrying = 6,
	PuttingDownCakeFireWorks = 11,
	RankingScore = 12,
	TakeDropItem = 13,
	UsingItem = 15,
	Falling = 17,
	Climbing = 18,
	InFieldOfView = 20,
	UnderEnermyAttack = 21,
	TakingDamage = 22,
	ReducingSignalValue = 23,
	CircleReducing = 24,
	CircleChange = 25,
	Rescue = 26,
	DrivingVehicle = 27,
	ReloadingBullet = 29,
	AirDrop = 30,
	PlayerPos = 32,
	WeaponUsage = 33,
	ItemPackageCreate = 34,
	ItemAttach = 35,
	ItemDetach = 36,
	PlayerInfo = 37,
	MiniMapShowInfo = 38,
	Following = 39,
	MiniMapPinning = 40,
	Blocking = 41,
	Dancing = 43,
	PickingupTombBox = 44,
	AirAttacking = 45,
	CurrentWeapon = 46,
	SceneInfo = 47,
	TeamInfo = 48,
	EnteringLeavingTeam = 49,
	OnOffline = 50,
	RankList = 51,
	TextMessage = 52,
	PawnState = 53,
	OpenCloseDoor = 54,
	MicSpeakerState = 55,
	VehicleState = 56,
	BattleResult = 102,
	VersionEvent = 103,
	EnumMax = 104,
	ECollectedEventDataEventId_MAX = 105
};

// Object Name: Enum ShadowTrackerExtra.EFireResetType
enum class EFireResetType : uint8 {
	EFireResetType_None = 0,
	EFireResetType_Single = 1,
	EFireResetType_Loop = 2,
	EFireResetType_SingleAndLoop = 3,
	EFireResetType_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.ECustomCndEventType
enum class ECustomCndEventType : uint8 {
	OnStartFire = 0,
	OnStopFire = 1,
	OnFireHitServer = 2,
	OnFireWeaponStateEnd = 3,
	MaxType = 4,
	ECustomCndEventType_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.EConditionHeathType
enum class EConditionHeathType : uint8 {
	EQUAL = 0,
	MORE_THAN = 1,
	LESS_THAN = 2,
	EConditionHeathType_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EDDMCFindType
enum class EDDMCFindType : uint8 {
	DDMCFT_ALL = 0,
	DDMCFT_RPC = 1,
	DDMCFT_REP = 2,
	DDMCFT_NONE = 3,
	DDMCFT_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EDeathMatchPersonalMedalType
enum class EDeathMatchPersonalMedalType : uint8 {
	SuperGod = 1,
	ContinuouKill = 2,
	SuperGodEnd = 3,
	TopSpotEnd = 4,
	ContinuouKillEnd = 5,
	FirstKill = 6,
	Revenge = 7,
	HeadShot = 8,
	Hunter = 9,
	Rally = 10,
	Cheer = 11,
	Sharpshooter = 12,
	GorgeousExplosion = 13,
	Slaughter = 14,
	AntiKill = 15,
	SunderArmorExperts = 16,
	RPG = 17,
	Guard = 18,
	Raiders = 19,
	Keeper = 20,
	EDeathMatchPersonalMedalType_MAX = 21
};

// Object Name: Enum ShadowTrackerExtra.EDeathMatchWWISENotifyReason
enum class EDeathMatchWWISENotifyReason : uint8 {
	None = 0,
	Reload = 1,
	NormalKill = 2,
	RedTeamFirstKill = 3,
	BlueTeamFirstKill = 4,
	RedTeamLeading = 5,
	BlueTeamLeading = 6,
	RedTeamAlmostWin = 7,
	BlueTeamAlmostWin = 8,
	RedTeamAlmostCompletelyWin = 9,
	BlueTeamAlmostCompoletelyWin = 10,
	RedTeamHalfTimeLeading = 11,
	BlueTeamHalfTimeLeading = 12,
	RedTeamTimeEndLeading = 13,
	BlueTeamTimeEndLeading = 14,
	RedTeamHasSuperGod = 15,
	BlueTeamHasSuperGod = 16,
	RedTeamEndSuperGod = 17,
	BlueTeamEndSuperGod = 18,
	RedTeamRampage = 19,
	BlueTeamRampage = 20,
	RedTeamWillOccupyHardPoint = 21,
	BlueTeamWillOccupyHardPoint = 22,
	RedTeamWillOccupyHardPoint_Time = 23,
	BlueTeamWillOccupyHardPoint_Time = 24,
	RedTeamWillHardPointHalfTime = 25,
	BlueTeamWillHardPointHalfTime = 26,
	EDeathMatchWWISENotifyReason_MAX = 27
};

// Object Name: Enum ShadowTrackerExtra.EScanPhase
enum class EScanPhase : uint8 {
	ScanPhaseNone = 0,
	ScanPhase1 = 1,
	ScanPhase2 = 2,
	ScanPhase3 = 3,
	ScanPhase4 = 4,
	ScanPhase5 = 5,
	ScanPhase6 = 6,
	ScanPhase7 = 7,
	ScanPhase8 = 8,
	ScanPhase9 = 9,
	EScanPhase_MAX = 10
};

// Object Name: Enum ShadowTrackerExtra.EItemCurveAnimState
enum class EItemCurveAnimState : uint8 {
	DelayStart = 0,
	Anim = 1,
	DelayDestroy = 2,
	End = 3,
	EItemCurveAnimState_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EComponentDormantType
enum class EComponentDormantType : uint8 {
	DormantFull = 0,
	DormantTick = 1,
	EComponentDormantType_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EDynamicWeatherExMgrActivityStatus
enum class EDynamicWeatherExMgrActivityStatus : uint8 {
	Begin = 0,
	End = 1,
	EDynamicWeatherExMgrActivityStatus_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.ENightStatus
enum class ENightStatus : uint8 {
	ENightStatus_Other = 0,
	ENightStatus_Night1 = 1,
	ENightStatus_Night2 = 2,
	ENightStatus_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EWeatherChangeStatus
enum class EWeatherChangeStatus : uint8 {
	EWeatherChangeStatus_StartEnter = 0,
	EWeatherChangeStatus_Duration = 1,
	EWeatherChangeStatus_StartQuit = 2,
	EWeatherChangeStatus_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EEffectAdjustType
enum class EEffectAdjustType : uint8 {
	EAT_MinShowDistanceAndLerp = 0,
	EAT_MinShowDistanceAndHide = 1,
	EAT_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.ESpikeDeploymentState
enum class ESpikeDeploymentState : uint8 {
	PreDeploy = 0,
	Deploying = 1,
	PostDeploy = 2,
	Popped = 3,
	Idle = 4,
	ESpikeDeploymentState_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.EProjectileEventType
enum class EProjectileEventType : uint8 {
	None = 0,
	Activate = 1,
	Bounce = 2,
	Stop = 3,
	Exploded = 4,
	Damaged = 5,
	EProjectileEventType_MAX = 6
};

// Object Name: Enum ShadowTrackerExtra.EProjectileExplosionStartType
enum class EProjectileExplosionStartType : uint8 {
	Never = 0,
	Impact = 1,
	Timer = 2,
	ImpactAndTimer = 3,
	EProjectileExplosionStartType_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EEnhancerSpotState
enum class EEnhancerSpotState : uint8 {
	DeActive = 0,
	Ready = 1,
	Active = 2,
	EEnhancerSpotState_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EEventDataCollectionValues_MicSpeakerState_Speaker
enum class EEventDataCollectionValues_MicSpeakerState_Speaker : uint8 {
	None = 0,
	Lbs = 1,
	Team = 2,
	EEventDataCollectionValues_MicSpeakerState_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EEventDataCollectionValues_MicSpeakerState_Mic
enum class EEventDataCollectionValues_MicSpeakerState_Mic : uint8 {
	None = 0,
	Lbs = 1,
	Team = 2,
	KeyLbs = 1,
	KeyTeam = 2,
	EEventDataCollectionValues_MicSpeakerState_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EEventDataCollectionValues_RankList_Type
enum class EEventDataCollectionValues_RankList_Type : uint8 {
	None = 0,
	Hot = 1,
	Lucky = 2,
	EEventDataCollectionValues_RankList_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EFinderShape
enum class EFinderShape : uint8 {
	Line = 0,
	Box = 1,
	Sphere = 2,
	Capsule = 3,
	Cone = 4,
	Fan = 5,
	Complex = 6,
	EFinderShape_MAX = 7
};

// Object Name: Enum ShadowTrackerExtra.EFPPCameraDataType
enum class EFPPCameraDataType : uint8 {
	EFPPCameraType_InVehicle = 0,
	EFPPCameraType_Shoveling = 1,
	EFPPCameraType_Max = 2
};

// Object Name: Enum ShadowTrackerExtra.EBotSourceType
enum class EBotSourceType : uint8 {
	BotSourceType_First = 0,
	BotSourceType_Spawner = 1,
	BotSourceType_API = 2,
	BotSourceType_TriggerAction = 3,
	BotSourceType_AIActing = 4,
	BotSourceType_PlaceOnLevel = 5,
	BotSourceType_MAX = 6
};

// Object Name: Enum ShadowTrackerExtra.EBotType
enum class EBotType : uint8 {
	BotType_First = 0,
	BotType_Default = 0,
	BotType_Boss = 1,
	BotType_NormalActor = 2,
	BotType_Vehicle = 3,
	BotType_PickUpWrapper = 4,
	BotType_All = 15,
	BotType_MAX = 16
};

// Object Name: Enum ShadowTrackerExtra.EBotCategray
enum class EBotCategray : uint8 {
	BotCategory_First = 0,
	BotCategory_Monster = 0,
	BotCategory_Decorator = 1,
	BotCategory_NormalActor = 2,
	BotCategory_Vehicle = 3,
	BotCategory_PickUpWrapper = 4,
	BotCategory_FakePlayer = 5,
	BotCategory_All = 15,
	BotCategory_MAX = 16
};

// Object Name: Enum ShadowTrackerExtra.ELevelChapterType
enum class ELevelChapterType : int32 {
	NormalChapter = 1000,
	PoliceChapter = 2000,
	EliteMonsterGroupChapter = 3000,
	ELevelChapterType_MAX = 3001
};

// Object Name: Enum ShadowTrackerExtra.EConstructType
enum class EConstructType : uint8 {
	ECT_Static = 0,
	ECT_Dynamic = 1,
	ECT_BlueprintAttach = 2,
	ECT_GlobalOverride = 3,
	ECT_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EGameReplayType
enum class EGameReplayType : uint8 {
	EGameReplayType_None = 0,
	EGameReplayType_DeathPlayback = 1,
	EGameReplayType_CompletePlayback = 2,
	EGameReplayType_ObservingReplay = 3,
	EGameReplayType_WonderfulPlayback = 4,
	EGameReplayType_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.EGPCompareType
enum class EGPCompareType : uint8 {
	CMP_Equal = 0,
	CMP_Less = 1,
	CMP_LessEqual = 2,
	CMP_Greater = 3,
	CMP_GreaterEqual = 4,
	CMP_NotEqual = 5,
	CMP_Regex = 6,
	CMP_Mask = 7,
	CMP_MAX = 8
};

// Object Name: Enum ShadowTrackerExtra.EGPSourceType
enum class EGPSourceType : uint8 {
	SRC_PreviousRegexMatch = 0,
	SRC_GpuFamily = 1,
	SRC_GlVersion = 2,
	SRC_OSVersion = 3,
	SRC_DeviceMake = 4,
	SRC_DeviceModel = 5,
	SRC_VulkanVersion = 6,
	SRC_TotalPhysicalGB = 7,
	SRC_ProfileName = 8,
	SRC_OpenID = 9,
	SRC_MapName = 10,
	SRC_GameModeName = 11,
	SRC_MAX = 12
};

// Object Name: Enum ShadowTrackerExtra.EGroupBackpackScheme
enum class EGroupBackpackScheme : uint8 {
	NoneScheme = 0,
	VehicleScheme = 1,
	EGroupBackpackScheme_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EHardPointManagerState
enum class EHardPointManagerState : uint8 {
	None = 0,
	WaitActivate = 1,
	HardPointActivating = 2,
	EHardPointManagerState_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EIdeaFenceSelector
enum class EIdeaFenceSelector : uint8 {
	None = 0,
	Use_2 = 1,
	Use_3 = 2,
	Use_4 = 3,
	Use_5 = 4,
	EIdeaFenceSelector_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.EImpactMask
enum class EImpactMask : uint8 {
	EImpactNone = 0,
	EImpactEffect = 1,
	EImpactAll = 255,
	EImpactMask_MAX = 256
};

// Object Name: Enum ShadowTrackerExtra.AllowFailedReason
enum class AllowFailedReason : uint8 {
	None = 0,
	CppFailed = 1,
	Occupied = 2,
	Cooling = 3,
	BlueprintFailed = 4,
	Blocked = 5,
	InVehicle = 6,
	AllowFailedReason_MAX = 7
};

// Object Name: Enum ShadowTrackerExtra.EInteractiveMoveType
enum class EInteractiveMoveType : uint8 {
	InteractiveMoveType_Stairs = 0,
	InteractiveMoveType_Max = 1
};

// Object Name: Enum ShadowTrackerExtra.EInterp3Method
enum class EInterp3Method : uint8 {
	PositionFirst = 0,
	RoationFirst = 1,
	PositionForced = 2,
	RoationForced = 3,
	EInterp3Method_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.ELobbyBgMatType
enum class ELobbyBgMatType : uint8 {
	ELBS = 0,
	EMarketAppearance = 1,
	EMarketParachute = 2,
	EMarketWeapon = 3,
	ESeasonPass = 4,
	ELobbyBgMat_Max = 5,
	ELobbyBgMatType_MAX = 6
};

// Object Name: Enum ShadowTrackerExtra.EXTaskSrcType
enum class EXTaskSrcType : uint8 {
	BySelf = 0,
	ByTeammate = 1,
	EXTaskSrcType_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EXTaskType
enum class EXTaskType : uint8 {
	TaskTypeDefault = 0,
	TaskTypeMain = 1,
	TaskTypeBranch = 2,
	TaskTypeDaily = 3,
	TaskTypeBounty = 4,
	TaskTypeBattle = 5,
	TaskTypeWishing = 6,
	TaskTypeLobby = 7,
	TaskTypeAward = 8,
	TaskTypeMilitary = 9,
	EXTaskType_MAX = 10
};

// Object Name: Enum ShadowTrackerExtra.FXTaskStateType
enum class FXTaskStateType : uint8 {
	StateNone = 0,
	StateGot = 1,
	StateProgress = 2,
	StateDone = 3,
	StateComplete = 4,
	StateFail = 5,
	FXTaskStateType_MAX = 6
};

// Object Name: Enum ShadowTrackerExtra.KilledReason
enum class KilledReason : uint8 {
	None = 0,
	KillBySun = 1,
	KillByLeave = 2,
	KillBySleep = 3,
	KillByFightingState = 4,
	KilledReason_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.EMarkTypeIDClearType
enum class EMarkTypeIDClearType : uint8 {
	ETC_OWNER_ONLY = 0,
	ETC_TEAMMATE = 1,
	ETC_Global = 2,
	ETC_ALL = 3,
	ETC_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EMarkDispatchRange
enum class EMarkDispatchRange : uint8 {
	EMAMDT_OWNER_ONLY = 0,
	EMAMDT_TEAMMATE = 1,
	EMAMDT_ENEMIES = 2,
	EMAMDT_TEAMMATE_RANGED = 3,
	EMAMDT_ENEMIES_RANGED = 4,
	EMAMDT_ALL_RANGED = 5,
	EMAMDT_ALL = 6,
	EMAMDT_MAX = 7
};

// Object Name: Enum ShadowTrackerExtra.EMarkDispatchActionType
enum class EMarkDispatchActionType : uint8 {
	EMAMAT_INSTANT = 0,
	EMAMAT_DELAYED = 1,
	EMAMAT_DELAYED_WITHCALLBACK = 2,
	EMAMAT_BATCH = 3,
	EMAMAT_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EMarkParentWidget
enum class EMarkParentWidget : uint8 {
	EMPW_None = 0,
	EMPW_MiniMap = 1,
	EMPW_EntireMap = 2,
	EMPW_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EUIMarkState
enum class EUIMarkState : uint8 {
	EUMS_None = 0,
	EUMS_Show = 1,
	EUMS_Hide = 2,
	EUMS_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EMapWidgetType
enum class EMapWidgetType : uint8 {
	EMWT_None = 0,
	EMWT_Fighting_MiniMap = 1,
	EMWT_Fighting_EntireMap = 2,
	EMWT_Observe_MiniMap = 3,
	EMWT_Observe_EntireMap = 4,
	EMWT_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.EMetorPolygonAreaType
enum class EMetorPolygonAreaType : uint8 {
	PAT_Normal = 0,
	PAT_OuterBound = 1,
	PAT_Radiation = 2,
	PAT_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EMissileState
enum class EMissileState : uint8 {
	Ready = 0,
	Flying = 1,
	Bomb = 2,
	EMissileState_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EMobClimbingProxyType
enum class EMobClimbingProxyType : uint8 {
	Climbing = 0,
	Striding = 1,
	ClimbWindow = 2,
	EMobClimbingProxyType_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.ENoiseSearchType
enum class ENoiseSearchType : uint8 {
	Loudest = 0,
	Nearest = 1,
	ENoiseSearchType_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.ENoiseAttenuationModel
enum class ENoiseAttenuationModel : uint8 {
	LinearSquard = 0,
	Logarithmic = 1,
	LogSquard = 2,
	ENoiseAttenuationModel_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.ELogicAreaType
enum class ELogicAreaType : uint8 {
	BreakableWall = 0,
	BreakableHouse = 1,
	ELogicAreaType_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.ENetProfileMonitorArg
enum class ENetProfileMonitorArg : uint8 {
	NumClients = 0,
	OutRate = 1,
	InRate = 2,
	OutLoss = 3,
	InLoss = 4,
	OutSaturation = 5,
	NumConsideredActors = 6,
	NumNetWorkActors = 7,
	FPS = 8,
	ENetProfileMonitorArg_MAX = 9
};

// Object Name: Enum ShadowTrackerExtra.ENetProfileCondition
enum class ENetProfileCondition : uint8 {
	PLANE = 0,
	ENetProfileCondition_MAX = 1
};

// Object Name: Enum ShadowTrackerExtra.EBulletImpactDir
enum class EBulletImpactDir : uint8 {
	ImpactNormal = 1,
	ImpactShootDir = 2,
	EBulletImpactDir_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.ECurrencyType
enum class ECurrencyType : uint8 {
	PlayerStateVar = 0,
	Item = 1,
	ECurrencyType_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.ECreateType
enum class ECreateType : uint8 {
	ECreateTypeRefuse = 0,
	ECreateTypeFree = 1,
	ECreateTypeAddToPool = 2,
	ECreateType_Max = 3
};

// Object Name: Enum ShadowTrackerExtra.EDisplayPolicy
enum class EDisplayPolicy : uint8 {
	Visibility = 0,
	Activity = 1,
	EDisplayPolicy_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EPetSlotType
enum class EPetSlotType : uint8 {
	EPetSlotType_NONE = 0,
	EPetSlotType_Body = 1,
	EPetSlotType_Suit = 2,
	EPetSlotType_Hat = 3,
	EPetSlotType_Glasses = 4,
	EPetSlotType_Jacket = 5,
	EPetSlotType_Bag = 6,
	EPetSlotType_Trousers = 7,
	EPetSlotType_Shoes = 8,
	EPetSlotType_MaxSlotNum = 9,
	EPetSlotType_MAX = 10
};

// Object Name: Enum ShadowTrackerExtra.EPetFallingTimeCnd
enum class EPetFallingTimeCnd : uint8 {
	Equal = 0,
	MoreThan = 1,
	LessThan = 2,
	EPetFallingTimeCnd_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EPetActionPattern
enum class EPetActionPattern : uint8 {
	None = 0,
	Idle = 1,
	Walk = 2,
	Run = 3,
	Parachute = 4,
	Swimming = 5,
	Normal = 6,
	WithSubAnimations = 7,
	Max = 8
};

// Object Name: Enum ShadowTrackerExtra.EPetRelevantType
enum class EPetRelevantType : uint8 {
	PetRelevant_OnlySelf = 0,
	PetRelevant_Team = 1,
	PetRelevant_All = 2,
	PetRelevant_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EPawnStateChangeType
enum class EPawnStateChangeType : uint8 {
	Enter = 0,
	Leave = 1,
	EPawnStateChangeType_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EPetEventType
enum class EPetEventType : uint8 {
	PetEventNone = 0,
	PlayEmotionEvent = 1,
	PlayerStateEvent = 2,
	PetRandomMontageEvent = 3,
	PlayerPlayEmotionEvent = 4,
	PlayerWin = 5,
	PlayerKillSomeone = 6,
	PlayerAssistKill = 7,
	EnemyStep = 8,
	EnemyShoot = 9,
	AirAttack = 10,
	EPetEventType_MAX = 11
};

// Object Name: Enum ShadowTrackerExtra.EPetFollowOwnerType
enum class EPetFollowOwnerType : uint8 {
	Attach = 0,
	Follow = 1,
	EPetFollowOwnerType_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EAsianGamesTeamColor
enum class EAsianGamesTeamColor : uint8 {
	None = 0,
	Blue = 1,
	Green = 2,
	Yellow = 3,
	Pink = 4,
	EAsianGamesTeamColor_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.EPVEDeadAttacker
enum class EPVEDeadAttacker : uint8 {
	Nothing = 0,
	Zombie = 1,
	EPVEDeadAttacker_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EMeleeDamageSubType
enum class EMeleeDamageSubType : uint8 {
	Fist = 1,
	Cowbar = 3,
	Pan = 4,
	Machete = 5,
	Sickle = 6,
	Dagger = 7,
	PlanAFist = 8,
	EMeleeDamageSubType_MAX = 9
};

// Object Name: Enum ShadowTrackerExtra.EAdditionDamageSubType
enum class EAdditionDamageSubType : uint8 {
	AdditionDamageToVehicle = 0,
	AdditionDamageToZombie = 1,
	AdditionDamageToDoor = 2,
	EAdditionDamageSubType_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EPlayerEquipmentLevel
enum class EPlayerEquipmentLevel : uint8 {
	PEL_2 = 0,
	PEL_3 = 1,
	PEL_4 = 2,
	PEL_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.ERespawnPointType
enum class ERespawnPointType : uint8 {
	Plane = 0,
	BornPoint = 1,
	ERespawnPointType_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.ESlideState
enum class ESlideState : uint8 {
	ESS_NONE = 0,
	ESS_LAUNCH = 1,
	ESS_SLIDE = 2,
	ESS_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EAnimPlayFlag
enum class EAnimPlayFlag : uint8 {
	None = 0,
	DisableLeftHandIK = 1,
	EAnimPlayFlag_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.FSoundType
enum class FSoundType : uint8 {
	ESoundMove = 0,
	ESoundFire = 1,
	ESoundVehicle = 2,
	FSoundType_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EScopeMeshAnimType
enum class EScopeMeshAnimType : uint8 {
	ScopeMeshAnimType_Normal = 0,
	ScopeMeshAnimType_Translate = 1,
	ScopeMeshAnimType_Scope = 2,
	ScopeMeshAnimType_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EBattleTextType
enum class EBattleTextType : uint8 {
	EBattleTextType_Fist = 0,
	EBattleTextType_BurningBomb = 1,
	EBattleTextType_Use = 2,
	EBattleTextType_ShotAndExplode = 3,
	EBattleTextType_Vehicle = 4,
	EBattleTextType_You = 5,
	EBattleTextType_YourTeammate = 6,
	EBattleTextType_By = 7,
	EBattleTextType_HeadShot = 8,
	EBattleTextType_PutDown = 9,
	EBattleTextType_Kill = 10,
	EBattleTextType_Killed = 11,
	EBattleTextType_Le = 12,
	EBattleTextType_Because = 13,
	EBattleTextType_CriticalWounded = 14,
	EBattleTextType_HighFallingDown = 15,
	EBattleTextType_FallToGround = 16,
	EBattleTextType_InPosionArea = 17,
	EBattleTextType_TooMuchTime = 18,
	EBattleTextType_UnderWeater = 19,
	EBattleTextType_Finally = 20,
	EBattleTextType_AirAttackHit = 21,
	EBattleTextType_AccidentalDamage = 22,
	EBattleTextType_Myself = 23,
	EBattleTextType_Explosion = 24,
	EBattleTextType_PoisonWater = 25,
	EBattleTextType_Dot = 26,
	EBattleTextType_MAX = 27
};

// Object Name: Enum ShadowTrackerExtra.EHandlePickUpActionReplicatedDataActionType
enum class EHandlePickUpActionReplicatedDataActionType : uint8 {
	EHandlePickUpActionReplicatedDataActionType_None = 0,
	EHandlePickUpActionReplicatedDataActionType_PickUpWeapon = 1,
	EHandlePickUpActionReplicatedDataActionType_PickUpPlayerEquipment = 2,
	EHandlePickUpActionReplicatedDataActionType_PutDownlayerEquipment = 3,
	EHandlePickUpActionReplicatedDataActionType_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EPlayerEquipmentSlotType
enum class EPlayerEquipmentSlotType : uint8 {
	EPlayerEquipmentSlotType_None = 0,
	EPlayerEquipmentSlotType_HeadEquipemtSlot = 1,
	EPlayerEquipmentSlotType_ChestEquipemtSlot = 2,
	EPlayerEquipmentSlotType_JacketEquipemtSlot = 3,
	EPlayerEquipmentSlotType_BackEquipemtSlot = 4,
	EPlayerEquipmentSlotType_LegsEquipemtSlot = 5,
	EPlayerEquipmentSlotType_FeetEquipemtSlot = 6,
	EPlayerEquipmentSlotType_MAX = 7
};

// Object Name: Enum ShadowTrackerExtra.EDataTableType
enum class EDataTableType : uint8 {
	EDataTableType_None = 0,
	EDataTableType_PickUpGlobalDataTable = 1,
	EDataTableType_PickUpGlobalIDAndWrapperDataTable = 2,
	EDataTableType_WeaponDataTable = 3,
	EDataTableType_PlayerEquipmentDataTable = 4,
	EDataTableType_WeaponComponentDataTable = 5,
	EDataTableType_ConsumeItemDataTable = 6,
	EDataTableType_AkEventDataTable = 7,
	EDataTableType_MAX = 8
};

// Object Name: Enum ShadowTrackerExtra.ESurvivePickUpType
enum class ESurvivePickUpType : uint8 {
	SPUT_RifileGun = 0,
	SPUT_SubmachineGun = 1,
	SPUT_SniperGun = 2,
	SPUT_Shotgun = 3,
	SPUT_Pistol = 4,
	SPUT_Helmet = 5,
	SPUT_Chest = 6,
	SPUT_Scop = 7,
	SPUT_Bandage = 8,
	SPUT_MedicalBag = 9,
	SPUT_MedicalBox = 10,
	SPUT_EnegyDrink = 11,
	SPUT_PainKillerPills = 12,
	SPUT_Adrenaline = 13,
	SPUT_MAX = 14
};

// Object Name: Enum ShadowTrackerExtra.ESurvivePickUpCategory
enum class ESurvivePickUpCategory : uint8 {
	SPUC_MainShootWeapon = 0,
	SPUC_SubShootWeapon = 1,
	SPUC_MeleWeapon = 2,
	SPUC_Prop = 3,
	SPUC_PlayerEquipment = 4,
	SPUC_WeaponComponent = 5,
	SPUC_ConsumeItem = 6,
	SPUC_Other = 7,
	SPUC_MAX = 8
};

// Object Name: Enum ShadowTrackerExtra.EPostEffectBlendType
enum class EPostEffectBlendType : uint8 {
	PEBT_ScanBomb = 0,
	PEBT_DeadGray = 1,
	PEBT_PropOutline = 2,
	PEBT_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EPlayerBodyPartType
enum class EPlayerBodyPartType : uint8 {
	PBPT_Head = 0,
	PBPT_LeftArm = 1,
	PBPT_RightArm = 2,
	PBPT_LeftLeg = 3,
	PBPT_RightLeg = 4,
	PBPT_Body = 5,
	PBPT_MAX = 6
};

// Object Name: Enum ShadowTrackerExtra.EWeaponSlot
enum class EWeaponSlot : uint8 {
	Primary = 0,
	Secondary = 1,
	Pistol = 2,
	EWeaponSlot_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EInfectionChgReason
enum class EInfectionChgReason : uint8 {
	None = 0,
	SelectChgToZombie = 1,
	InfectionChgToZombie = 2,
	ZombieRespawn = 3,
	HumanChgToRevenger = 4,
	RoundChgToNormalPlayer = 5,
	EInfectionChgReason_MAX = 6
};

// Object Name: Enum ShadowTrackerExtra.EPVEProjectileDamageTiming
enum class EPVEProjectileDamageTiming : uint8 {
	DamageWhenExplode = 0,
	DamageWhenImpact = 1,
	EPVEProjectileDamageTiming_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EQuickSignSubType
enum class EQuickSignSubType : uint8 {
	Invalid = 0,
	SomebodyCame = 1,
	AttackPos = 2,
	DefencePos = 3,
	AssemblePos = 4,
	NeedAmmo = 5,
	NeedAttachment = 6,
	ComeInVehicle = 7,
	NeedMedicine = 8,
	MarkVehicle = 9,
	MarkOpenDoor = 10,
	MarkAirDrop = 11,
	MarkDeadBox = 12,
	MarkSupply = 13,
	MarkPos = 14,
	Dangerous = 15,
	MarkPosSafeZone = 16,
	NeedMuzzle = 17,
	NeedGrip = 18,
	NeedMag = 19,
	NeedStock = 20,
	NeedScope = 21,
	NeedSideScope = 22,
	NeedWeapon = 23,
	NeedHelmet = 24,
	NeedArmor = 25,
	NeedBackpack = 26,
	NeedNightVision = 27,
	ResRoger = 28,
	ResComing = 29,
	ResIWant = 30,
	MarkClassicStore = 31,
	MarkReviveTower = 32,
	MarkZipline = 33,
	ScannedActorTest = 34,
	M_PlayerPawn = 35,
	M_DollAirBalloon = 36,
	MarkClosedDoor = 37,
	M_EnergyChest = 38,
	EQuickSignSubType_MAX = 39
};

// Object Name: Enum ShadowTrackerExtra.EQuickSignType
enum class EQuickSignType : uint8 {
	Cancle = 255,
	Attack = 7,
	Defence = 0,
	Assemble = 1,
	NeedAmmo = 2,
	NeedAttachment = 3,
	ComeInVehicle = 4,
	NeedMedicine = 5,
	SomebodyCame = 6,
	Attention = 8,
	MarkPos = 9,
	MarkPosSafeZone = 10,
	NeedSlot = 11,
	ResRoger = 50,
	ResComing = 51,
	ResIWant = 52,
	EQuickSignType_MAX = 256
};

// Object Name: Enum ShadowTrackerExtra.EMarkItemType
enum class EMarkItemType : uint8 {
	EIT_Hide = 0,
	EIT_InScreen = 1,
	EIT_OutScreen = 2,
	EIT_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.ERelationshipWithTarget
enum class ERelationshipWithTarget : uint8 {
	ERelationshipWithTarget_Default = 0,
	ERelationshipWithTarget_Self = 1,
	ERelationshipWithTarget_Teammate = 2,
	ERelationshipWithTarget_Enemy = 3,
	ERelationshipWithTarget_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EWonderfulKeepState
enum class EWonderfulKeepState : uint8 {
	EWonderfulKeepState_None = 0,
	EWonderfulKeepState_WaitFor = 1,
	EWonderfulKeepState_Failed = 2,
	EWonderfulKeepState_Success = 3,
	EWonderfulKeepState_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EWonderfulType
enum class EWonderfulType : uint8 {
	EWonderfulType_None = 0,
	EWonderfulType_MultiKill = 1,
	EWonderfulType_MovingVehicleKill = 2,
	EWonderfulType_AntiKill = 3,
	EWonderfulType_LongDistance = 4,
	EWonderfulType_MovingKill = 5,
	EWonderfulType_OnVehicleKill = 6,
	EWonderfulType_GrenadeKill = 7,
	EWonderfulType_HeadshotKill = 8,
	EWonderfulType_MeleeWeaponKill = 9,
	EWonderfulType_MAX = 10
};

// Object Name: Enum ShadowTrackerExtra.EWonderfulErrorCode
enum class EWonderfulErrorCode : uint8 {
	EWonderfulErrorCode_None = 0,
	EWonderfulErrorCode_FileNameError = 1,
	EWonderfulErrorCode_FileNotExist = 2,
	EWonderfulErrorCode_LoadFileError = 3,
	EWonderfulErrorCode_SerializeError = 4,
	EWonderfulErrorCode_InPlayState = 5,
	EWonderfulErrorCode_NullPtr = 6,
	EWonderfulErrorCode_UncompressError = 7,
	EWonderfulErrorCode_MAX = 8
};

// Object Name: Enum ShadowTrackerExtra.EDemoType
enum class EDemoType : uint8 {
	EDemoType_None = 0,
	EDemoType_Server = 1,
	EDemoType_Client = 2,
	EDemoType_Wonderful = 3,
	EDemoType_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.ERevivalPointState
enum class ERevivalPointState : uint8 {
	None = 0,
	Start = 1,
	Revivaling = 2,
	RevivalFinish = 3,
	RevivalCD = 4,
	Destroy = 5,
	ERevivalPointState_MAX = 6
};

// Object Name: Enum ShadowTrackerExtra.ERollState
enum class ERollState : uint8 {
	None = 0,
	Rolling = 1,
	Picking = 2,
	ERollState_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.ERuneElemixType
enum class ERuneElemixType : uint8 {
	RET_None = 0,
	RET_Wind = 1,
	RET_Fire = 2,
	RET_Ice = 3,
	RET_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EShootTimeDataTransType
enum class EShootTimeDataTransType : uint8 {
	ESTDT_None = 0,
	ESTDT_DynamicFloor = 1,
	ESTDT_VehicleWeapon = 2,
	ESTDT_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.ETraceShootType
enum class ETraceShootType : uint8 {
	EST_NONE = 0,
	EST_CAMERA = 1,
	EST_AIM = 2,
	EST_FOLD = 3,
	EST_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.ERemoveFromScanningType
enum class ERemoveFromScanningType : uint8 {
	Timeout = 1,
	Complete = 2,
	Quit = 3,
	SkippedBeforeScan = 4,
	ERemoveFromScanningType_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.EScreenRotationMarkValueStatue
enum class EScreenRotationMarkValueStatue : uint8 {
	ESRMVS_Close = 0,
	ESRMVS_Show = 1,
	ESRMVS_Hide = 2,
	ESRMVS_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.ETargetBodyType
enum class ETargetBodyType : uint8 {
	Head1 = 31,
	Head2 = 32,
	Body1 = 33,
	Body2 = 34,
	Body3 = 35,
	ETargetBodyType_MAX = 36
};

// Object Name: Enum ShadowTrackerExtra.EWeaponVeiryIgnore
enum class EWeaponVeiryIgnore : uint8 {
	None = 0,
	WVI_HitCheck = 1,
	EWeaponVeiryIgnore_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EHelicopterState
enum class EHelicopterState : uint8 {
	EHelicopterState_Idle = 0,
	EHelicopterState_FlyInReady = 1,
	EHelicopterState_FlyInFight = 2,
	EHelicopterState_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.ESnowBoardState
enum class ESnowBoardState : uint8 {
	ESBS_InLand = 0,
	ESBS_FLYING0 = 1,
	ESBS_FLYING1 = 2,
	ESBS_FLYING2 = 3,
	ESBS_FLYING3 = 4,
	ESBS_FALLING = 5,
	ESBS_MAX = 6
};

// Object Name: Enum ShadowTrackerExtra.EOverrideAutoPickUp
enum class EOverrideAutoPickUp : uint8 {
	Invalid = 0,
	Enable = 1,
	Disable = 2,
	EOverrideAutoPickUp_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.ESkirtPoseType
enum class ESkirtPoseType : uint8 {
	ESkirtPose_Lobby = 0,
	ESkirtPose_Stand = 1,
	ESkirtPose_Crouch = 2,
	ESkirtPose_Prone = 3,
	ESkirtPose_InVehicle = 4,
	ESkirtPose_Swim = 5,
	ESkirtPose_Parachute = 6,
	ESkirtPose_NoSim = 7,
	ESkirtPose_LobbyCorrectSkMesh = 8,
	ESkirtPose_MAX = 9
};

// Object Name: Enum ShadowTrackerExtra.ELoopMoveMode
enum class ELoopMoveMode : uint8 {
	ELoopMoveMode_None = 0,
	ELoopMoveMode_NoLoop = 1,
	ELoopMoveMode_Forward = 2,
	ELoopMoveMode_Back = 3,
	ELoopMoveMode_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EIslandDuelResult
enum class EIslandDuelResult : uint8 {
	State_Win = 0,
	State_Fail = 1,
	State_Tie = 2,
	State_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EIslandDuelReqResponse
enum class EIslandDuelReqResponse : uint8 {
	IDF_Access = 0,
	IDF_Refuse = 1,
	IDF_SettingNotAllow = 2,
	IDS_SelfStateNotAllow = 3,
	IDS_TargetStateNoAllow = 4,
	EIslandDuelReqResponse_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.EIslandBattleState
enum class EIslandBattleState : uint8 {
	BattleState_NONE = 0,
	BattleState_PreEnter = 1,
	BattleState_ENTER = 2,
	BattleState_Ready = 3,
	BattleState_Fight = 4,
	BattleState_Settle = 5,
	BattleState_Arrive = 6,
	BattleState_MAX = 7
};

// Object Name: Enum ShadowTrackerExtra.EIslandDuelState
enum class EIslandDuelState : uint8 {
	State_NONE = 0,
	State_Ready = 1,
	State_Fight = 2,
	State_OutArea = 3,
	State_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EIslandInteractiveStateType
enum class EIslandInteractiveStateType : uint8 {
	IST_None = 0,
	IST_Seat = 1,
	IST_Duel = 2,
	IST_Emote = 3,
	IST_Duck = 4,
	IST_ShootPractice = 5,
	IST_Battle = 6,
	IST_Swing = 7,
	IST_MusicGame = 8,
	IST_Racing = 9,
	IST_MAX = 10
};

// Object Name: Enum ShadowTrackerExtra.EST3DNavigationQueryStatus
enum class EST3DNavigationQueryStatus : uint8 {
	Unscheduled = 0,
	InProgress = 1,
	Succeeded = 2,
	Failed = 3,
	EST3DNavigationQueryStatus_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EST3DNavigationCookFlag
enum class EST3DNavigationCookFlag : uint8 {
	CookedJPSPreTable = 0,
	CookedJPSForcedNeighbors = 1,
	EST3DNavigationCookFlag_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EST3DNavigationGenerationType
enum class EST3DNavigationGenerationType : uint8 {
	Static = 0,
	Dynamic = 1,
	EST3DNavigationGenerationType_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EST3DNavigationSearchAlgorithm
enum class EST3DNavigationSearchAlgorithm : uint8 {
	AStar = 0,
	JPS = 1,
	JPSPlus = 2,
	EST3DNavigationSearchAlgorithm_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EST3DNavigationLocProjectStrategy
enum class EST3DNavigationLocProjectStrategy : uint8 {
	AdjustLocByMoveUp = 0,
	EST3DNavigationLocProjectStrategy_MAX = 1
};

// Object Name: Enum ShadowTrackerExtra.EST3DNavigationPathfindingPartialStrategy
enum class EST3DNavigationPathfindingPartialStrategy : uint8 {
	AdjustTargetByMoveUp = 0,
	EST3DNavigationPathfindingPartialStrategy_MAX = 1
};

// Object Name: Enum ShadowTrackerExtra.EStairsMoveType
enum class EStairsMoveType : uint8 {
	EStairsMove_Idle = 0,
	EStairsMove_Up = 1,
	EStairsMove_Down = 2,
	EStairsMove_Enter = 3,
	EStairsMove_Exit = 4,
	EStairsMove_TopHoldOn = 5,
	EStairsMove_JumpToTop = 6,
	EStairsMove_JumpOff = 7,
	EStairsMove_None = 8,
	EStairsMove_MAX = 9
};

// Object Name: Enum ShadowTrackerExtra.EAnimalState
enum class EAnimalState : uint8 {
	Idle = 0,
	Idle_Arder = 1,
	Walk = 2,
	Trot = 9,
	Run = 3,
	Jump = 4,
	Watch = 5,
	Dead = 6,
	Scare = 7,
	Fighting = 8,
	Fear = 10,
	Cute = 11,
	Max = 12
};

// Object Name: Enum ShadowTrackerExtra.EAnimalType
enum class EAnimalType : uint8 {
	NONE = 0,
	CHICKEN = 1,
	DEER = 2,
	ROE_DEER = 3,
	RABBIT = 4,
	GOBLIN = 5,
	ICE = 6,
	EAnimalType_MAX = 7
};

// Object Name: Enum ShadowTrackerExtra.EHitFilterType
enum class EHitFilterType : uint8 {
	EFilterByGun = 0,
	EFilterByBullet = 1,
	EHitFilterType_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EBuffDotValueType
enum class EBuffDotValueType : uint8 {
	BurningDamage = 0,
	ShootWeaponDamage = 1,
	AddHealth = 2,
	AddBulletNum = 3,
	AddArmor = 4,
	AddHelmet = 5,
	PoisonFogDamage = 6,
	AddEnergy = 7,
	AddWeaponDurability = 8,
	DotDamage = 9,
	SkillBlackboardInt = 10,
	SkillBlackboardFloat = 11,
	EBuffDotValueType_MAX = 12
};

// Object Name: Enum ShadowTrackerExtra.EBuffSenseTargetState
enum class EBuffSenseTargetState : uint8 {
	Sensing = 0,
	HasEnemy = 1,
	WaitSense = 2,
	EBuffSenseTargetState_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.ELaunchDirectionType
enum class ELaunchDirectionType : uint8 {
	UseLaunchCenter = 0,
	UseSelfRotation = 1,
	UseCauserRotation = 2,
	FarAwayFromCauser = 3,
	ELaunchDirectionType_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EBuffMofifyDurationType
enum class EBuffMofifyDurationType : uint8 {
	RefCauserDistance = 0,
	RefMonsterType = 1,
	RefOneAndTwo = 2,
	EBuffMofifyDurationType_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EBuffModifyPropertyType
enum class EBuffModifyPropertyType : uint8 {
	EBMPT_Bool = 0,
	EBMPT_Int = 1,
	EBMPT_Float = 2,
	EBMPT_String = 3,
	EBMPT_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EBuffAirDropShowType
enum class EBuffAirDropShowType : uint8 {
	ExceptNone = 0,
	ExceptSelfOpened = 1,
	ExceptTeamOpened = 2,
	EBuffAirDropShowType_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EEffectSpreadState
enum class EEffectSpreadState : uint8 {
	ESS_InitialTrace = 0,
	ESS_InitialProcess = 1,
	ESS_Spreading = 2,
	ESS_SpreadDone = 3,
	ESS_Ending = 4,
	ESS_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.EBuffHitFaceType
enum class EBuffHitFaceType : uint8 {
	All = 0,
	Forward = 1,
	Back = 2,
	EBuffHitFaceType_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EBuffBeHitSpaceType
enum class EBuffBeHitSpaceType : uint8 {
	All = 0,
	Stand = 1,
	Air = 2,
	EBuffBeHitSpaceType_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EBuffKeepInStateType
enum class EBuffKeepInStateType : uint8 {
	MinUnion = 0,
	ContainOne = 1,
	EBuffKeepInStateType_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EBuffConditionRescueType
enum class EBuffConditionRescueType : uint8 {
	EBCRT_RescueOther = 0,
	EBCRT_BeRescued = 1,
	EBCRT_RescueSelf = 2,
	EBCRT_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EnumPoisonFogStage
enum class EnumPoisonFogStage : uint8 {
	None = 0,
	Stage_One = 1,
	Stage_Two = 2,
	Stage_Three = 3,
	EnumPoisonFogStage_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EPlayShovelSoundType
enum class EPlayShovelSoundType : uint8 {
	Shovel_Enter = 0,
	Shovel_Exit = 1,
	Shovel_Interrupt = 2,
	Shovel_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EClothAnimBPType
enum class EClothAnimBPType : uint8 {
	EClothAnimBP_None = 0,
	EClothAnimBP_Lobby = 1,
	EClothAnimBP_Max = 2
};

// Object Name: Enum ShadowTrackerExtra.ESTCrowdSimulationState
enum class ESTCrowdSimulationState : uint8 {
	Enabled = 0,
	ObstacleOnly = 1,
	Disabled = 2,
	ESTCrowdSimulationState_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EActorCacheID
enum class EActorCacheID : uint8 {
	ACID_Bullet = 0,
	ACID_BulletImpactEffect = 1,
	ACID_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.ESTCharacterType
enum class ESTCharacterType : uint8 {
	MLAI1 = 1,
	MLAI2 = 2,
	NormalAI = 3,
	RearPlayer = 4,
	SimpleCharacter = 5,
	None = 6,
	ESTCharacterType_MAX = 7
};

// Object Name: Enum ShadowTrackerExtra.ESTEScopeState
enum class ESTEScopeState : uint8 {
	ScopeOut = 0,
	ScopeIn = 1,
	ESTEScopeState_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EReleaseToFireType
enum class EReleaseToFireType : uint8 {
	RELEASEFIRE_NONE = 0,
	RELEASEFIRE_SHOTGUN = 1,
	RELEASEFIRE_SNIPER = 2,
	RELEASEFIRE_BRUST = 3,
	RELEASEFIRE_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.ShootWeaponAnimType
enum class ShootWeaponAnimType : uint8 {
	SWAT_Shoot = 0,
	SWAT_NoneShoot = 1,
	SWAT_Reload = 2,
	SWAT_IdleToNoneIdle = 3,
	SWAT_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.ESTEWeaponHoldType
enum class ESTEWeaponHoldType : uint8 {
	Hand = 0,
	Rifle = 1,
	Pistol = 2,
	Melee = 3,
	ESTEWeaponHoldType_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EAirborne2
enum class EAirborne2 : uint8 {
	Airborne = 0,
	FreeFall = 1,
	Opening = 2,
	Landing = 3,
	EAirborne2_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EAnimBPType
enum class EAnimBPType : uint8 {
	EAnimBP_None = 0,
	EAnimBP_Vehicle = 1,
	EAnimBP_TPP = 2,
	EAnimBP_FPP = 3,
	EAnimBP_Max = 4
};

// Object Name: Enum ShadowTrackerExtra.EMainCharMontagePlayType
enum class EMainCharMontagePlayType : uint8 {
	EMainCharMontagePlay_All = 0,
	EMainCharMontagePlay_TPP = 1,
	EMainCharMontagePlay_FPP = 2,
	EMainCharMontagePlay_TPPVeh = 3,
	EMainCharMontagePlay_FPPVeh = 4,
	EMainCharMontagePlay_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.ELeftUIInfoRecordType
enum class ELeftUIInfoRecordType : uint8 {
	FatalDamage = 0,
	PhaseInformation = 1,
	KillKingInfo = 2,
	ELeftUIInfoRecordType_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EPlayEmoteSubState
enum class EPlayEmoteSubState : uint8 {
	EPlayEmoteSubState_None = 0,
	EPlayEmoteSubState_RealEmote = 1,
	EPlayEmoteSubState_ChangeWearing = 2,
	EPlayEmoteSubState_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.ECustomMoveModeType
enum class ECustomMoveModeType : uint8 {
	ECustomMoveMode_None = 0,
	ECustomMoveMode_Hang = 1,
	ECustomMoveMode_Vault = 2,
	ECustomMoveMode_Shovel = 3,
	ECustomMoveMode_SkillAttach = 4,
	ECustomMoveMode_Max = 5
};

// Object Name: Enum ShadowTrackerExtra.EPlayerHurtAnimType
enum class EPlayerHurtAnimType : uint8 {
	EPlayerHurtAnim_None = 0,
	EPlayerHurtAnim_Point = 1,
	EPlayerHurtAnim_Melee = 2,
	EPlayerHurtAnim_Max = 3
};

// Object Name: Enum ShadowTrackerExtra.EGetAllPlayerCharacterFlag
enum class EGetAllPlayerCharacterFlag : uint8 {
	Non = 0,
	Alive = 1,
	EGetAllPlayerCharacterFlag_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EBuffSkillSpellerType
enum class EBuffSkillSpellerType : uint8 {
	OnSelf = 0,
	OnTarget = 1,
	EBuffSkillSpellerType_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EBuffSpellerSourceType
enum class EBuffSpellerSourceType : uint8 {
	SourceNone = 0,
	SourceEvent = 1,
	EBuffSpellerSourceType_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EBuffApplierCondition
enum class EBuffApplierCondition : uint8 {
	BuffAppConditio_Ignore = 0,
	BuffAppCondition_IsZombie = 1,
	BuffAppCondition_InSight = 2,
	BuffAppCondition_InnerRange = 3,
	BuffAppConditio_Default = 4,
	EBuffApplierCondition_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.EBodyPosition
enum class EBodyPosition : uint8 {
	Non = 0,
	BodyHead = 1,
	BodyBody = 2,
	BodyFoot = 3,
	BodyTPPSpringArm = 4,
	BodyTPPCamera = 5,
	EBodyPosition_MAX = 6
};

// Object Name: Enum ShadowTrackerExtra.EDollAirBalloonState
enum class EDollAirBalloonState : uint8 {
	EDollAirBalloon_EmptyAir = 0,
	EDollAirBalloon_Blowing = 1,
	EDollAirBalloon_Idle = 2,
	EDollAirBalloon_Flying = 3,
	EDollAirBalloon_Falling = 4,
	EDollAirBalloon_None = 5,
	EDollAirBalloon_MAX = 6
};

// Object Name: Enum ShadowTrackerExtra.EGameMap
enum class EGameMap : uint8 {
	NoMap = 0,
	SurviveRoot = 1,
	SurviveTestRoot = 2,
	SurviveRCity = 3,
	EGameMap_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EInfectionAnimBPType
enum class EInfectionAnimBPType : uint8 {
	EInfectionAnimBP_None = 0,
	EInfectionAnimBP_TPP = 1,
	EInfectionAnimBP_FPP = 2,
	EInfectionAnimBP_Lobby = 3,
	EInfectionAnimBP_Max = 4
};

// Object Name: Enum ShadowTrackerExtra.EPlayerOperation
enum class EPlayerOperation : uint8 {
	None = 0,
	Parachute = 1,
	Shooting = 2,
	Driving = 3,
	EPlayerOperation_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EMapType
enum class EMapType : uint8 {
	ENTIREMAP = 0,
	MINIMAP = 1,
	EMapType_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EMonsterFuncType
enum class EMonsterFuncType : int32 {
	AutoExit = 1,
	BigBody = 2,
	MaxFuncType = 1024,
	EMonsterFuncType_MAX = 1025
};

// Object Name: Enum ShadowTrackerExtra.ENewBuffApplierCondition
enum class ENewBuffApplierCondition : uint8 {
	NewBuffAppCondition_IsZombie = 0,
	NewBuffAppCondition_InSight = 1,
	NewBuffAppCondition_InnerRange = 2,
	NewBuffAppConditio_Default = 3,
	ENewBuffApplierCondition_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EObserveFailedReason
enum class EObserveFailedReason : uint8 {
	EObserveFailedReason_Default = 0,
	EObserveFailedReason_CanSelfRevival = 1,
	EObserveFailedReason_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EVehicleControlType
enum class EVehicleControlType : uint8 {
	EVCType_Buttons = 3,
	EVCType_SingleJoystick = 2,
	EVCType_FullJoystick = 1,
	EVCType_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EVirtualJoystickState
enum class EVirtualJoystickState : uint8 {
	EVJS_None = 0,
	EVJS_Left = 1,
	EVJS_Right = 2,
	EVJS_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EApplyStatus
enum class EApplyStatus : int32 {
	REVERT = -1,
	NO_APPLY = 0,
	Apply = 1,
	EApplyStatus_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.ELoadMode
enum class ELoadMode : uint8 {
	LOW_LOAD = 1,
	MEDIUM_LOAD = 2,
	HIGH_LOAD = 3,
	ELoadMode_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EMobWalkType
enum class EMobWalkType : uint8 {
	Normal = 0,
	IdleWalk = 1,
	AttackWalk = 2,
	SprintRun = 3,
	Sideways = 4,
	MaxSpeed = 5,
	EMobWalkType_MAX = 6
};

// Object Name: Enum ShadowTrackerExtra.EMonsterType
enum class EMonsterType : uint8 {
	EMonsterType_All = 0,
	EMonsterType_Normal = 1,
	EMonsterType_Elite = 2,
	EMonsterType_Boss = 3,
	EMonsterType_BigBoss = 4,
	EMonsterType_Behemoth = 5,
	EMonsterType_MAX = 6
};

// Object Name: Enum ShadowTrackerExtra.EMonsterAnimGroupMask
enum class EMonsterAnimGroupMask : uint8 {
	EMonsterAnimGroupMask_Null = 0,
	EMonsterAnimGroupMask_Base = 1,
	EMonsterAnimGroupMask_Child = 2,
	EMonsterAnimGroupMask_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.ENetRelevantType
enum class ENetRelevantType : uint8 {
	ENetRelevantType_All = 0,
	ENetRelevantType_Teammates = 1,
	ENetRelevantType_OwnerOnly = 2,
	ENetRelevantType_None = 3,
	ENetRelevantType_Max = 4
};

// Object Name: Enum ShadowTrackerExtra.SnowManStatus
enum class SnowManStatus : uint8 {
	Born = 1,
	Broken = 2,
	Dead = 3,
	SnowManStatus_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EVehicleAIAvoidanceMode
enum class EVehicleAIAvoidanceMode : uint8 {
	Off = 0,
	SingleTrace = 1,
	MultiTrace = 2,
	EVehicleAIAvoidanceMode_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.ESpawnType
enum class ESpawnType : uint8 {
	Single = 0,
	ContinuousOnTimer = 1,
	ContinuousOnDeath = 2,
	ESpawnType_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.ESyncBuildState
enum class ESyncBuildState : uint8 {
	SyncBuild_None = 0,
	SyncBuild_Building = 1,
	SyncBuild_Finish = 2,
	SyncBuild_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EVehAnimAssetType
enum class EVehAnimAssetType : uint8 {
	EVehAssetType_Sequence = 0,
	EVehAssetType_BlendSpace = 1,
	EVehAssetType_Max = 2
};

// Object Name: Enum ShadowTrackerExtra.EVehicleWeaponParentType
enum class EVehicleWeaponParentType : uint8 {
	MainWeapon = 0,
	Hull = 255,
	EVehicleWeaponParentType_MAX = 256
};

// Object Name: Enum ShadowTrackerExtra.EVehicleWeaponType
enum class EVehicleWeaponType : uint8 {
	MainWeapon = 0,
	SecondaryWeapon = 1,
	EVehicleWeaponType_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EWeaponHiddenMask
enum class EWeaponHiddenMask : uint8 {
	WeaponHiddenMask0 = 0,
	WeaponHiddenMask1 = 1,
	WeaponHiddenMask2 = 2,
	WeaponHiddenMask3 = 3,
	WeaponHiddenMask4 = 4,
	WeaponHiddenMask5 = 5,
	WeaponHiddenMask6 = 6,
	WeaponHiddenMask7 = 7,
	EWeaponHiddenMask_MAX = 8
};

// Object Name: Enum ShadowTrackerExtra.EHiarAnimBPType
enum class EHiarAnimBPType : uint8 {
	EHairAnimBP_None = 0,
	EHairAnimBP_Lobby = 1,
	EHairAnimBP_Max = 2
};

// Object Name: Enum ShadowTrackerExtra.EPlatformDeviceLevel
enum class EPlatformDeviceLevel : uint8 {
	PlatformDeviceLevel_Low = 0,
	PlatformDeviceLevel_Middle = 1,
	PlatformDeviceLevel_Hight = 2,
	PlatformDeviceLevel_None = 3,
	PlatformDeviceLevel_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.ESurfBoardState
enum class ESurfBoardState : uint8 {
	ESBS_InWater = 0,
	ESBS_FLYING0 = 1,
	ESBS_FLYING1 = 2,
	ESBS_FLYING2 = 3,
	ESBS_FALLING = 4,
	ESBS_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.ETextVertPos
enum class ETextVertPos : uint8 {
	Top = 0,
	Center = 1,
	Bottom = 2,
	MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.ETextHorzPos
enum class ETextHorzPos : uint8 {
	Left = 0,
	Center = 1,
	Right = 2,
	MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.ECharOperationType
enum class ECharOperationType : uint8 {
	OpMove = 0,
	OpSprint = 1,
	OpJump = 2,
	OpInvalidEnum = 3,
	ECharOperationType_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EOperationRunResult
enum class EOperationRunResult : uint8 {
	OpRunning = 0,
	OpSuccess = 1,
	OpAutoFinish = 2,
	OpFail = 3,
	OpNotStarted = 4,
	EOperationRunResult_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.ETaskTeamActionConditionType
enum class ETaskTeamActionConditionType : uint8 {
	ETTACT_SameArea = 1,
	ETTACT_SameEmote = 2,
	ETTACT_SameEmoteInSameTime = 3,
	ETTACT_SameEmoteInSameTimeAndArea = 4,
	ETTACT_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.ETaskActionType
enum class ETaskActionType : uint8 {
	ETAT_Common = 0,
	ETAT_CollectItem = 1,
	ETAT_RedoCollectItem = 2,
	ETAT_KillPlayer = 3,
	ETAT_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.ETaskEventType
enum class ETaskEventType : uint8 {
	ETET_TakeDamage = 0,
	ETET_KillPlayer = 1,
	ETET_TouchDown = 2,
	ETET_DoEmote = 3,
	ETET_EnterArea = 4,
	ETET_PickupItem = 5,
	ETET_DropItem = 6,
	ETET_MAX = 7
};

// Object Name: Enum ShadowTrackerExtra.ETaskTriggerAreaType
enum class ETaskTriggerAreaType : uint8 {
	ETTAT_City_Unknown = 0,
	ETTAT_City_P = 1,
	ETTAT_MilitaryBase = 2,
	ETTAT_School = 3,
	ETTAT_StMartin = 4,
	ETTAT_City_Ebo = 5,
	ETTAT_City_Lion = 6,
	ETTAT_City_River = 7,
	ETTAT_Quarry = 8,
	ETTAT_Shami = 9,
	ETTAT_MAX = 10
};

// Object Name: Enum ShadowTrackerExtra.ETaskTriggerItemType
enum class ETaskTriggerItemType : uint8 {
	ETTIT_DoEmote = 0,
	ETTIT_DeathBox = 1,
	ETTIT_PicnicMat = 2,
	ETTIT_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.ETaskSubType
enum class ETaskSubType : uint8 {
	ETST_Specific_area_kill_task = 3,
	ETST_Dancing_around_box_task = 8,
	ETST_Dancing_in_area_task = 9,
	ETST_Dancing_in_position_task = 10,
	ETST_MAX = 11
};

// Object Name: Enum ShadowTrackerExtra.ETaskType
enum class ETaskType : uint8 {
	ETT_Common = 0,
	ETT_PureCollection = 1,
	ETT_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.ECustomTickRoleType
enum class ECustomTickRoleType : uint8 {
	ECTR_All = 0,
	ECTR_Simulated = 1,
	ECTR_Autonomous = 2,
	ECTR_Authority = 4,
	ECTR_SimulatedAndAutonomous = 3,
	ECTR_SimulatedAndAuthority = 5,
	ECTR_AutonomousAndAuthority = 6,
	ECTR_MAX = 7
};

// Object Name: Enum ShadowTrackerExtra.ECustomTickType
enum class ECustomTickType : uint8 {
	ComponentTick = 1,
	OwnerTick = 2,
	ECustomTickType_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.ETrailMarkType
enum class ETrailMarkType : uint8 {
	Normal = 0,
	Slipping = 1,
	Broken = 2,
	ETrailMarkType_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.ESpawnItemFunction
enum class ESpawnItemFunction : uint8 {
	ESpawnItemFunction_GenerateMonster = 1,
	ESpawnItemFunction_GeneratePickup = 2,
	ESpawnItemFunction_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EExpressType
enum class EExpressType : uint8 {
	EExpressType_Invalid = 0,
	EExpressType_Werewolf = 1,
	EExpressType_Drone = 2,
	EExpressType_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EDrivingCheckPointState
enum class EDrivingCheckPointState : uint8 {
	DCPS_Invalid = 0,
	DCPS_Unpass = 1,
	DCPS_Pass = 2,
	DCPS_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EMultiButtonType
enum class EMultiButtonType : uint8 {
	None = 0,
	Click = 1,
	Hold = 2,
	Multi = 3,
	EMultiButtonType_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.ETagVolumeWorkableNetRole
enum class ETagVolumeWorkableNetRole : uint8 {
	NR_DSOnly = 0,
	NR_ClientOnly = 1,
	NR_Both = 2,
	NR_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.ETagVolumeSubType
enum class ETagVolumeSubType : uint8 {
	ST_City = 0,
	ST_Unknown = 254,
	ST_Invalid = 255,
	ST_MAX = 256
};

// Object Name: Enum ShadowTrackerExtra.EInfectionJumpPhase
enum class EInfectionJumpPhase : uint8 {
	EEInfectionJumpPhase_PreJump = 0,
	EEInfectionJumpPhase_FallLoop = 1,
	EEInfectionJumpPhase_Land = 2,
	EEInfectionJumpPhase_LandHard = 3,
	EEInfectionJumpPhase_Max = 4
};

// Object Name: Enum ShadowTrackerExtra.EInfectionJumpType
enum class EInfectionJumpType : uint8 {
	EInfectionJump_InPlace = 0,
	EInfectionJump_Forward = 1,
	EInfectionJump_Max = 2
};

// Object Name: Enum ShadowTrackerExtra.EInfectionAnimType
enum class EInfectionAnimType : uint8 {
	EInfectionAnim_Move = 0,
	EInfectionAnim_Melee = 1,
	EInfectionAnim_Hurt = 2,
	EInfectionAnim_Dead = 3,
	EInfectionAnim_Turn_L = 4,
	EInfectionAnim_Turn_R = 5,
	EInfectionAnim_OpenDoor = 6,
	EInfectionAnim_ToCrouch = 7,
	EInfectionAnim_ToStand = 8,
	EInfectionAnim_Max = 9
};

// Object Name: Enum ShadowTrackerExtra.EInfectionPoseType
enum class EInfectionPoseType : uint8 {
	EInfectionPose_Stand = 0,
	EInfectionPose_Crouch = 1,
	EInfectionPose_Max = 2
};

// Object Name: Enum ShadowTrackerExtra.EInfectionAnimListType
enum class EInfectionAnimListType : uint8 {
	EInfectionAnimList_TPP = 1,
	EInfectionAnimList_FPP = 2,
	EInfectionAnimList_Max = 3
};

// Object Name: Enum ShadowTrackerExtra.EVehicleWeaponBoardDataType
enum class EVehicleWeaponBoardDataType : uint8 {
	EVehicleWeaponBoardDataType_None = 0,
	EVehicleWeaponBoardDataType_MuzzlePos = 1,
	EVehicleWeaponBoardDataType_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EDelegateBindType
enum class EDelegateBindType : uint8 {
	BINDTYPE_NONE = 0,
	BINDTYPE_DYNAMIC = 1,
	BINDTYPE_DYNAMIC_MULTICAST = 2,
	BINDTYPE_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.ECarryBackDirection
enum class ECarryBackDirection : uint8 {
	ECarryBackDirection_NONE = 0,
	ECarryBackDirection_Front = 1,
	ECarryBackDirection_Back = 2,
	ECarryBackDirection_Left = 3,
	ECarryBackDirection_Right = 4,
	ECarryBackDirection_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.ECarryBackSkillActionType
enum class ECarryBackSkillActionType : uint8 {
	ECBSAT_START = 0,
	ECBSAT_CARRYBACK = 1,
	ECBSAT_END = 2,
	ECBSAT_FAILED = 3,
	ECBSAT_NONE = 4,
	ECBSAT_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.EBSSkillActionType
enum class EBSSkillActionType : uint8 {
	EBSSAT_START = 0,
	EBSSAT_PLACE = 1,
	EBSSAT_END = 2,
	EBSSAT_CHECK = 3,
	EBSSAT_NONE = 4,
	EBSSAT_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.ESkillActionFireType
enum class ESkillActionFireType : uint8 {
	AFT_STOP = 0,
	AFT_START = 1,
	AFT_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EJumpStage
enum class EJumpStage : uint8 {
	EJumpStage_Rising = 0,
	EJumpStage_Hovering = 1,
	EJumpStage_Diving = 2,
	EJumpStage_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EPVEProjectileInitLocationType
enum class EPVEProjectileInitLocationType : uint8 {
	UseOwnerLocation = 0,
	UseTargetLocation = 1,
	UseSocketLocation = 2,
	EPVEProjectileInitLocationType_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.ELockPPType
enum class ELockPPType : uint8 {
	ELPPT_FPP = 0,
	ELPPT_TPP = 1,
	ELPPT_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.ESkillModifyPropertyType
enum class ESkillModifyPropertyType : uint8 {
	ESMPT_Bool = 0,
	ESMPT_Int = 1,
	ESMPT_Float = 2,
	ESMPT_String = 3,
	ESMPT_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.AnimMontageTypeAndPosture
enum class AnimMontageTypeAndPosture : uint8 {
	FPS_Stand = 0,
	FPS_Crouch = 1,
	FPS_Prone = 2,
	FPS_Vehicle = 3,
	FPS_Max = 4,
	TPS_Stand = 5,
	TPS_Crouch = 6,
	TPS_Prone = 7,
	TPS_Vehicle = 8,
	TPS_Max = 9,
	AnimMontageTypeAndPosture_MAX = 10
};

// Object Name: Enum ShadowTrackerExtra.EPutDownDirection
enum class EPutDownDirection : uint8 {
	EPutDownDirection_NONE = 0,
	EPutDownDirection_Front = 1,
	EPutDownDirection_Back = 2,
	EPutDownDirection_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EPutDownSkillActionType
enum class EPutDownSkillActionType : uint8 {
	EPDSAT_START = 0,
	EPDSAT_PUTDOWN = 1,
	EPDSAT_END = 2,
	EPDSAT_FAILED = 3,
	EPDSAT_NONE = 4,
	EPDSAT_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.ESkillTouchEvent
enum class ESkillTouchEvent : uint8 {
	ESkillTouchEvent_KEY_DOWN = 0,
	ESkillTouchEvent_KEY_UP = 1,
	ESkillTouchEvent_KEY_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EBeamEffectDataFromType
enum class EBeamEffectDataFromType : uint8 {
	FixedPoint = 0,
	BlackBoard = 1,
	AttachPoint = 2,
	EBeamEffectDataFromType_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.ESkillConditionRole
enum class ESkillConditionRole : uint8 {
	ESCR_All = 0,
	ESCR_Authority = 1,
	ESCR_Autonomous = 2,
	ESCR_Simulated = 3,
	ESCR_AutonomousSimulated = 4,
	ESCR_AutonomousAuthority = 5,
	ESCR_MAX = 6
};

// Object Name: Enum ShadowTrackerExtra.EUAESkillCondition_BlackboardValueComparison
enum class EUAESkillCondition_BlackboardValueComparison : uint8 {
	Equal = 0,
	NotEqual = 1,
	Less = 2,
	Greater = 3,
	LessEqual = 4,
	GreaterEqual = 5,
	EUAESkillCondition_MAX = 6
};

// Object Name: Enum ShadowTrackerExtra.ESkillConditionIsInHouseCheckType
enum class ESkillConditionIsInHouseCheckType : uint8 {
	In = 0,
	NotIn = 1,
	ESkillConditionIsInHouseCheckType_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.ESkillConditionIsInHouseCheckTarget
enum class ESkillConditionIsInHouseCheckTarget : uint8 {
	Self = 0,
	SelfForward = 1,
	ESkillConditionIsInHouseCheckTarget_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EAxisType
enum class EAxisType : uint8 {
	EAxis_X = 0,
	EAxis_Y = 1,
	EAxis_Z = 2,
	EAxis_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.ESettingConfigType
enum class ESettingConfigType : uint8 {
	SCT_Int = 0,
	SCT_UInt = 1,
	SCT_Float = 2,
	SCT_Bool = 3,
	SCT_String = 4,
	SCT_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.EPickerFromBlackboard_DataType
enum class EPickerFromBlackboard_DataType : uint8 {
	Actor = 0,
	Circle = 1,
	ActorCircle = 2,
	EPickerFromBlackboard_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.ESkillPickerQueryType
enum class ESkillPickerQueryType : uint8 {
	SPQT_AllCharacter = 0,
	SPQT_BaseCharacter = 1,
	SPQT_SimpleCharacter = 2,
	SPQT_Vehicle = 3,
	SPQT_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EMovementDirection
enum class EMovementDirection : uint8 {
	EForward = 0,
	EBackward = 1,
	ELeft = 2,
	ERight = 3,
	EMovementDirection_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EVelocityChangeType
enum class EVelocityChangeType : uint8 {
	ESpeed_Up = 0,
	ESpeed_Down = 1,
	ESpeed_Both = 2,
	ESpeed_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.ESkillConditionCheckType
enum class ESkillConditionCheckType : uint8 {
	ECheck_Once = 0,
	ECheck_Continuous = 1,
	ECheck_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.ERecoveryType
enum class ERecoveryType : uint8 {
	ERecovery_AddDirectly = 0,
	ERecovery_AddTo = 1,
	ERecovery_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EValueType
enum class EValueType : uint8 {
	EValueType_Percentage = 0,
	EValueType_Absolute = 1,
	EValueType_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EOperatorType
enum class EOperatorType : uint8 {
	EOperator_Equal = 0,
	EOperator_Greater = 1,
	EOperator_Less = 2,
	EOperator_GreaterEqual = 3,
	EOperator_LessEqual = 4,
	EOperator_NotEqual = 5,
	EOperator_MAX = 6
};

// Object Name: Enum ShadowTrackerExtra.EUAVStaySubState
enum class EUAVStaySubState : uint8 {
	UAVStaySubType_Stay = 0,
	UAVStaySubType_Move = 1,
	UAVStaySubType_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EUAVFlyType
enum class EUAVFlyType : uint8 {
	UAVFly_KeepRelativeLocAndRot = 0,
	UAVFly_RelativeBaseLoc = 1,
	UAVFly_WorldLocAndRot = 2,
	UAVFly_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EUAVStateType
enum class EUAVStateType : uint8 {
	UAVState_Initial = 0,
	UAVState_BornFly = 1,
	UAVState_MoveIn = 2,
	UAVState_Stay = 3,
	UAVState_MoveAway = 4,
	UAVState_Finish = 5,
	UAVState_MAX = 6
};

// Object Name: Enum ShadowTrackerExtra.EUAVAirDropCallType
enum class EUAVAirDropCallType : uint8 {
	BT_Normal = 0,
	BT_EventCall = 1,
	BT_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EUAVCharacterFlyingPhase
enum class EUAVCharacterFlyingPhase : uint8 {
	FlyingDescending = 0,
	FlyingHorizontal = 1,
	AirDropping = 2,
	FlyingDisappear = 3,
	Finished = 255,
	EUAVCharacterFlyingPhase_MAX = 256
};

// Object Name: Enum ShadowTrackerExtra.EAnimHurtingTarget
enum class EAnimHurtingTarget : uint8 {
	PlayerCharacter = 0,
	SimpleCharacter = 1,
	AllCharacter = 2,
	EAnimHurtingTarget_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EHurtApperanceRotateType
enum class EHurtApperanceRotateType : uint8 {
	ERotateToCaster = 0,
	EHurtApperanceRotateType_MAX = 1
};

// Object Name: Enum ShadowTrackerExtra.UTSkill_SoundCue_ListenType
enum class UTSkill_SoundCue_ListenType : uint8 {
	Listen_SelfOnly = 0,
	Listen_Teammate = 1,
	Listen_Target = 2,
	Listen_AllTarget = 3,
	Listen_All = 4,
	Listen_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.ESLP_CrossHair_TraceType
enum class ESLP_CrossHair_TraceType : uint8 {
	ESLP_CrossHair_Line = 0,
	ESLP_CrossHair_Sphere = 1,
	ESLP_CrossHair_Box = 2,
	ESLP_CrossHair_Capsule = 3,
	ESLP_CrossHair_Fan = 4,
	ESLP_CrossHair_MAX = 5
};

// Object Name: Enum ShadowTrackerExtra.EAirdropDampingState
enum class EAirdropDampingState : uint8 {
	NotDamping = 0,
	Damping = 1,
	DampComplete = 2,
	EAirdropDampingState_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.ECustomDamageEventReactionType
enum class ECustomDamageEventReactionType : uint8 {
	SpawnActor = 0,
	ActiveParticles = 1,
	DetactiveParticles = 2,
	HideMesh = 3,
	HideMeshInstance = 4,
	HideBone = 5,
	ApplyPhysicalAnimationProfile = 6,
	SetCollisionEnabled = 7,
	ECustomDamageEventReactionType_MAX = 8
};

// Object Name: Enum ShadowTrackerExtra.ECustomDamageEventTriggerType
enum class ECustomDamageEventTriggerType : uint8 {
	OnPassedDamageThreshold = 0,
	OnAnyDamage = 1,
	ECustomDamageEventTriggerType_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EVehicleLogDebugType
enum class EVehicleLogDebugType : uint8 {
	Disable = 0,
	Basic = 1,
	Server = 2,
	AutomomousProxy = 4,
	SimulatedProxy = 8,
	ReplicatedMovement = 16,
	ResolveStuck = 32,
	AvoidPene = 64,
	Underground = 128,
	EVehicleLogDebugType_MAX = 129
};

// Object Name: Enum ShadowTrackerExtra.EVehicleChangeAvatarStatus
enum class EVehicleChangeAvatarStatus : uint8 {
	SUCCESS = 0,
	FAIL = 1,
	EVehicleChangeAvatarStatus_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EVFNetSide
enum class EVFNetSide : uint8 {
	Server = 0,
	Client = 1,
	EVFNetSide_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EVFComponentOpType
enum class EVFComponentOpType : uint8 {
	Add = 0,
	Remove = 1,
	EVFComponentOpType_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EVehicleDriveTankControlMode
enum class EVehicleDriveTankControlMode : uint8 {
	STANDARD = 0,
	SPECIAL = 1,
	EVehicleDriveTankControlMode_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.SpringArmState
enum class SpringArmState : uint8 {
	SASDefault = 0,
	SASLeave = 1,
	SASStay = 2,
	SASApproach = 3,
	SpringArmState_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.ESTExtraVehicleStates
enum class ESTExtraVehicleStates : uint8 {
	EVS_NONE = 0,
	EVS_SPEED = 1,
	EVS_ELECTRONIC_FAILURE = 2,
	EVS_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.TrackState
enum class TrackState : uint8 {
	TSNone = 0,
	TSLeave = 1,
	TSStay = 2,
	TSApproach = 3,
	TrackState_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EVehicleUserState
enum class EVehicleUserState : uint8 {
	EVUS_OutOfVehicle = 0,
	EVUS_AsDriver = 1,
	EVUS_ASPassenger = 2,
	EVUS_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EViewMaskType
enum class EViewMaskType : uint8 {
	EAuto = 0,
	EEachPlayer = 1,
	EEachTeam = 2,
	EViewMaskType_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EShowVoiceDistanceType
enum class EShowVoiceDistanceType : uint8 {
	ESD_Walk = 0,
	ESD_Shot = 1,
	ESD_Vehicle = 2,
	ESD_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.FFixedDropOffLocationType
enum class FFixedDropOffLocationType : uint8 {
	World = 0,
	Relative = 1,
	FFixedDropOffLocationType_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.FDropOffLocationType
enum class FDropOffLocationType : uint8 {
	World = 0,
	Relative = 1,
	FDropOffLocationType_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EWeaponEffectMatParamType
enum class EWeaponEffectMatParamType : uint8 {
	EWeaponEffectMatParamType_Scalar = 0,
	EWeaponEffectMatParamType_Color = 1,
	EWeaponEffectMatParamType_Texture = 2,
	EWeaponEffectMatParamType_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EWeaponFxParamType
enum class EWeaponFxParamType : uint8 {
	EWeaponFxParamType_Float = 0,
	EWeaponFxParamType_Vector = 1,
	EWeaponFxParamType_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EWeaponEffectValidSceneType
enum class EWeaponEffectValidSceneType : uint8 {
	LobbyOnly = 0,
	InGameOnly = 1,
	All = 2,
	EWeaponEffectValidSceneType_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EWeaponEffectTriggerCondition
enum class EWeaponEffectTriggerCondition : uint8 {
	None = 0,
	Kill = 1,
	LobbyUserTrigger = 2,
	EquipSpecifyAvatar = 3,
	EWeaponEffectTriggerCondition_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EFlameEmitterType
enum class EFlameEmitterType : uint8 {
	ESingleShot = 0,
	EContinuous = 1,
	EFlameEmitterType_MAX = 2
};

// Object Name: Enum ShadowTrackerExtra.EHandleHitType
enum class EHandleHitType : uint8 {
	None = 0,
	HandleFly = 1,
	HandleStuck = 2,
	EHandleHitType_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EWonderfulPlayType
enum class EWonderfulPlayType : uint8 {
	EWonderfulPlayType_None = 0,
	EWonderfulPlayType_FromLobby = 1,
	EWonderfulPlayType_FromBattle = 2,
	EWonderfulPlayType_MAX = 3
};

// Object Name: Enum ShadowTrackerExtra.EWonderfulPlayState
enum class EWonderfulPlayState : uint8 {
	EWonderfulPlayState_Initial = 0,
	EWonderfulPlayState_WaitJumpTimeDone = 1,
	EWonderfulPlayState_Playing = 2,
	EWonderfulPlayState_Finished = 3,
	EWonderfulPlayState_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EWonderfulCutOutputType
enum class EWonderfulCutOutputType : uint8 {
	WonderfulCutOutputType_None = 0,
	WonderfulCutOutputType_ChickenDinner = 1,
	WonderfulCutOutputType_ShootKill = 2,
	WonderfulCutOutputType_ShootLastBreath = 3,
	WonderfulCutOutputType_ShootDamage = 4,
	WonderfulCutOutputType_MeleeKill = 5,
	WonderfulCutOutputType_MeleeLastBreath = 6,
	WonderfulCutOutputType_GrenadeKill = 7,
	WonderfulCutOutputType_GrenadeLastBreath = 8,
	WonderfulCutOutputType_VehicleKill = 9,
	WonderfulCutOutputType_VehicleLastBreath = 10,
	WonderfulCutOutputType_MAX = 11
};

// Object Name: Enum ShadowTrackerExtra.EWonderfulCutShootDamageType
enum class EWonderfulCutShootDamageType : uint8 {
	WonderfulCutHurtType_None = 0,
	WonderfulCutHurtType_Kill = 1,
	WonderfulCutHurtType_LastBreath = 2,
	WonderfulCutHurtType_Hurt = 3,
	WonderfulCutHurtType_MAX = 4
};

// Object Name: Enum ShadowTrackerExtra.EWonderfulCutCaptureType
enum class EWonderfulCutCaptureType : uint8 {
	WonderfulCutCaptureType_None = 0,
	WonderfulCutCaptureType_ChickenDinner = 1,
	WonderfulCutCaptureType_Circle = 2,
	WonderfulCutCaptureType_Vehicle = 3,
	WonderfulCutCaptureType_Grenade = 4,
	WonderfulCutCaptureType_Melee = 5,
	WonderfulCutCaptureType_ShootDamage = 6,
	WonderfulCutCaptureType_MAX = 7
};

// Object Name: Enum ShadowTrackerExtra.EWeatherPhaseIndex
enum class EWeatherPhaseIndex : uint8 {
	FirstDay = 0,
	FirstDusk = 1,
	FirstNight = 2,
	SecondDay = 3,
	SecondDusk = 4,
	SecondNight = 5,
	ThirdDay = 6,
	EWeatherPhaseIndex_MAX = 7
};

