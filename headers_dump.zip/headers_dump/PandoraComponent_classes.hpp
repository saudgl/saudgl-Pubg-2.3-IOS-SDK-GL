#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class PandoraComponent.PandoraBpFunctionLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UPandoraBpFunctionLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function PandoraComponent.PandoraBpFunctionLibrary.Tnm2Test
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void Tnm2Test(struct FString errMsg, int iId, int iType, bool bSend); // Offset: 0x102119efc // Return & Params: Num(4) Size(0x19)

	// Object Name: Function PandoraComponent.PandoraBpFunctionLibrary.SetGameInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetGameInstance(struct UGameInstance* Instance); // Offset: 0x102119e88 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function PandoraComponent.PandoraBpFunctionLibrary.OnClickOpenPop
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString OnClickOpenPop(); // Offset: 0x102119e24 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function PandoraComponent.PandoraBpFunctionLibrary.OnClickInit
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString OnClickInit(); // Offset: 0x102119dc0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function PandoraComponent.PandoraBpFunctionLibrary.OnClickClose
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString OnClickClose(); // Offset: 0x102119d5c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function PandoraComponent.PandoraBpFunctionLibrary.LogoutPandora
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void LogoutPandora(); // Offset: 0x102119d48 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function PandoraComponent.PandoraBpFunctionLibrary.InitPandora
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool InitPandora(struct FString InOpenId, struct FString InRoleId, struct FString InAppId, struct FString InPlatId, struct FString InAccType, struct FString InArea, struct FString InPartion, struct FString InCloudTest, struct FString InAccessToken, struct FString InSdkVersion, struct FString InGameVersion); // Offset: 0x1021197cc // Return & Params: Num(12) Size(0xb1)

	// Object Name: Function PandoraComponent.PandoraBpFunctionLibrary.GetHappyMessage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetHappyMessage(); // Offset: 0x102119768 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class PandoraComponent.PandoraInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UPandoraInterface : UObject {
};

// Object Name: Class PandoraComponent.PandoraRichTextBox
// Size: 0x420 // Inherited bytes: 0x100
struct UPandoraRichTextBox : UWidget {
	// Fields
	struct FText Text; // Offset: 0x100 // Size: 0x18
	DelegateProperty TextDelegate; // Offset: 0x118 // Size: 0x10
	struct FSlateFontInfo Font; // Offset: 0x128 // Size: 0x58
	struct FLinearColor Color; // Offset: 0x180 // Size: 0x10
	enum class ETextJustify Justification; // Offset: 0x190 // Size: 0x01
	bool AutoWrapText; // Offset: 0x191 // Size: 0x01
	char pad_0x192[0x2]; // Offset: 0x192 // Size: 0x02
	float WrapTextAt; // Offset: 0x194 // Size: 0x04
	struct FMargin Margin; // Offset: 0x198 // Size: 0x10
	float LineHeightPercentage; // Offset: 0x1a8 // Size: 0x04
	char pad_0x1AC[0x4]; // Offset: 0x1ac // Size: 0x04
	struct TArray<struct URichTextBlockDecorator*> Decorators; // Offset: 0x1b0 // Size: 0x10
	char pad_0x1C0[0x260]; // Offset: 0x1c0 // Size: 0x260

	// Functions

	// Object Name: Function PandoraComponent.PandoraRichTextBox.SetText
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetText(struct FText InText); // Offset: 0x10211a510 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function PandoraComponent.PandoraRichTextBox.GetText
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	struct FText GetText(); // Offset: 0x10211a4ac // Return & Params: Num(1) Size(0x18)
};

// Object Name: Class PandoraComponent.PandoraSceneComponent
// Size: 0x2d0 // Inherited bytes: 0x2d0
struct UPandoraSceneComponent : USceneComponent {
};

// Object Name: Class PandoraComponent.PandoraLuaActor
// Size: 0x450 // Inherited bytes: 0x3d8
struct APandoraLuaActor : AActor {
	// Fields
	char pad_0x3D8[0x58]; // Offset: 0x3d8 // Size: 0x58
	struct FString LuaFilePath; // Offset: 0x430 // Size: 0x10
	struct FString LuaStateName; // Offset: 0x440 // Size: 0x10

	// Functions

	// Object Name: Function PandoraComponent.PandoraLuaActor.CallLuaMember
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct FPandoraLuaBPVar CallLuaMember(struct FString FunctionName, struct TArray<struct FPandoraLuaBPVar>& Args); // Offset: 0x10211a868 // Return & Params: Num(3) Size(0x40)
};

// Object Name: Class PandoraComponent.PandoraLuaPawn
// Size: 0x4b0 // Inherited bytes: 0x438
struct APandoraLuaPawn : APawn {
	// Fields
	char pad_0x438[0x58]; // Offset: 0x438 // Size: 0x58
	struct FString LuaFilePath; // Offset: 0x490 // Size: 0x10
	struct FString LuaStateName; // Offset: 0x4a0 // Size: 0x10

	// Functions

	// Object Name: Function PandoraComponent.PandoraLuaPawn.CallLuaMember
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct FPandoraLuaBPVar CallLuaMember(struct FString FunctionName, struct TArray<struct FPandoraLuaBPVar>& Args); // Offset: 0x10211abfc // Return & Params: Num(3) Size(0x40)
};

// Object Name: Class PandoraComponent.PandoraLuaCharacter
// Size: 0x890 // Inherited bytes: 0x810
struct APandoraLuaCharacter : ACharacter {
	// Fields
	char pad_0x810[0x58]; // Offset: 0x810 // Size: 0x58
	struct FString LuaFilePath; // Offset: 0x868 // Size: 0x10
	struct FString LuaStateName; // Offset: 0x878 // Size: 0x10
	char pad_0x888[0x8]; // Offset: 0x888 // Size: 0x08

	// Functions

	// Object Name: Function PandoraComponent.PandoraLuaCharacter.CallLuaMember
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct FPandoraLuaBPVar CallLuaMember(struct FString FunctionName, struct TArray<struct FPandoraLuaBPVar>& Args); // Offset: 0x10211aea8 // Return & Params: Num(3) Size(0x40)
};

// Object Name: Class PandoraComponent.PandoraLuaController
// Size: 0x4b8 // Inherited bytes: 0x440
struct APandoraLuaController : AController {
	// Fields
	char pad_0x440[0x58]; // Offset: 0x440 // Size: 0x58
	struct FString LuaFilePath; // Offset: 0x498 // Size: 0x10
	struct FString LuaStateName; // Offset: 0x4a8 // Size: 0x10

	// Functions

	// Object Name: Function PandoraComponent.PandoraLuaController.CallLuaMember
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct FPandoraLuaBPVar CallLuaMember(struct FString FunctionName, struct TArray<struct FPandoraLuaBPVar>& Args); // Offset: 0x10211b154 // Return & Params: Num(3) Size(0x40)
};

// Object Name: Class PandoraComponent.PandoraLuaPlayerController
// Size: 0x7b8 // Inherited bytes: 0x740
struct APandoraLuaPlayerController : APlayerController {
	// Fields
	char pad_0x740[0x58]; // Offset: 0x740 // Size: 0x58
	struct FString LuaFilePath; // Offset: 0x798 // Size: 0x10
	struct FString LuaStateName; // Offset: 0x7a8 // Size: 0x10

	// Functions

	// Object Name: Function PandoraComponent.PandoraLuaPlayerController.CallLuaMember
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct FPandoraLuaBPVar CallLuaMember(struct FString FunctionName, struct TArray<struct FPandoraLuaBPVar>& Args); // Offset: 0x10211b400 // Return & Params: Num(3) Size(0x40)
};

// Object Name: Class PandoraComponent.PandoraLuaGameModeBase
// Size: 0x4e0 // Inherited bytes: 0x468
struct APandoraLuaGameModeBase : AGameModeBase {
	// Fields
	char pad_0x468[0x58]; // Offset: 0x468 // Size: 0x58
	struct FString LuaFilePath; // Offset: 0x4c0 // Size: 0x10
	struct FString LuaStateName; // Offset: 0x4d0 // Size: 0x10

	// Functions

	// Object Name: Function PandoraComponent.PandoraLuaGameModeBase.CallLuaMember
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct FPandoraLuaBPVar CallLuaMember(struct FString FunctionName, struct TArray<struct FPandoraLuaBPVar>& Args); // Offset: 0x10211b6b0 // Return & Params: Num(3) Size(0x40)
};

// Object Name: Class PandoraComponent.PandoraLuaHUD
// Size: 0x538 // Inherited bytes: 0x4c0
struct APandoraLuaHUD : AHUD {
	// Fields
	char pad_0x4C0[0x58]; // Offset: 0x4c0 // Size: 0x58
	struct FString LuaFilePath; // Offset: 0x518 // Size: 0x10
	struct FString LuaStateName; // Offset: 0x528 // Size: 0x10

	// Functions

	// Object Name: Function PandoraComponent.PandoraLuaHUD.CallLuaMember
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct FPandoraLuaBPVar CallLuaMember(struct FString FunctionName, struct TArray<struct FPandoraLuaBPVar>& Args); // Offset: 0x10211b960 // Return & Params: Num(3) Size(0x40)
};

// Object Name: Class PandoraComponent.PandoraLuaBlueprintLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UPandoraLuaBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function PandoraComponent.PandoraLuaBlueprintLibrary.GetStringFromVar
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetStringFromVar(struct FPandoraLuaBPVar Value, int Index); // Offset: 0x10211c734 // Return & Params: Num(3) Size(0x38)

	// Object Name: Function PandoraComponent.PandoraLuaBlueprintLibrary.GetObjectFromVar
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UObject* GetObjectFromVar(struct FPandoraLuaBPVar Value, int Index); // Offset: 0x10211c634 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function PandoraComponent.PandoraLuaBlueprintLibrary.GetNumberFromVar
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	float GetNumberFromVar(struct FPandoraLuaBPVar Value, int Index); // Offset: 0x10211c534 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function PandoraComponent.PandoraLuaBlueprintLibrary.GetIntFromVar
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetIntFromVar(struct FPandoraLuaBPVar Value, int Index); // Offset: 0x10211c434 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function PandoraComponent.PandoraLuaBlueprintLibrary.GetBoolFromVar
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool GetBoolFromVar(struct FPandoraLuaBPVar Value, int Index); // Offset: 0x10211c334 // Return & Params: Num(3) Size(0x25)

	// Object Name: Function PandoraComponent.PandoraLuaBlueprintLibrary.CreateVarFromString
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FPandoraLuaBPVar CreateVarFromString(struct FString Value); // Offset: 0x10211c250 // Return & Params: Num(2) Size(0x30)

	// Object Name: Function PandoraComponent.PandoraLuaBlueprintLibrary.CreateVarFromObject
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FPandoraLuaBPVar CreateVarFromObject(struct UObject* Value); // Offset: 0x10211c1ac // Return & Params: Num(2) Size(0x28)

	// Object Name: Function PandoraComponent.PandoraLuaBlueprintLibrary.CreateVarFromNumber
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FPandoraLuaBPVar CreateVarFromNumber(float Value); // Offset: 0x10211c108 // Return & Params: Num(2) Size(0x28)

	// Object Name: Function PandoraComponent.PandoraLuaBlueprintLibrary.CreateVarFromInt
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FPandoraLuaBPVar CreateVarFromInt(int Value); // Offset: 0x10211c064 // Return & Params: Num(2) Size(0x28)

	// Object Name: Function PandoraComponent.PandoraLuaBlueprintLibrary.CreateVarFromBool
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FPandoraLuaBPVar CreateVarFromBool(bool Value); // Offset: 0x10211bfb8 // Return & Params: Num(2) Size(0x28)

	// Object Name: Function PandoraComponent.PandoraLuaBlueprintLibrary.CallToLuaWithArgs
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FPandoraLuaBPVar CallToLuaWithArgs(struct FString FunctionName, struct TArray<struct FPandoraLuaBPVar>& Args, struct FString StateName); // Offset: 0x10211bdec // Return & Params: Num(4) Size(0x50)

	// Object Name: Function PandoraComponent.PandoraLuaBlueprintLibrary.CallToLua
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FPandoraLuaBPVar CallToLua(struct FString FunctionName, struct FString StateName); // Offset: 0x10211bc90 // Return & Params: Num(3) Size(0x40)
};

// Object Name: Class PandoraComponent.PandoraLuaDelegate
// Size: 0x38 // Inherited bytes: 0x28
struct UPandoraLuaDelegate : UObject {
	// Fields
	char pad_0x28[0x10]; // Offset: 0x28 // Size: 0x10

	// Functions

	// Object Name: Function PandoraComponent.PandoraLuaDelegate.EventTrigger
	// Flags: [Final|Native|Public|BlueprintCallable]
	void EventTrigger(); // Offset: 0x10211cc88 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class PandoraComponent.PandoraLuaUserWidget
// Size: 0x310 // Inherited bytes: 0x260
struct UPandoraLuaUserWidget : UUserWidget {
	// Fields
	char pad_0x260[0x58]; // Offset: 0x260 // Size: 0x58
	struct FString LuaFilePath; // Offset: 0x2b8 // Size: 0x10
	struct FString LuaStateName; // Offset: 0x2c8 // Size: 0x10
	char pad_0x2D8[0x38]; // Offset: 0x2d8 // Size: 0x38

	// Functions

	// Object Name: Function PandoraComponent.PandoraLuaUserWidget.CallLuaMember
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct FPandoraLuaBPVar CallLuaMember(struct FString FunctionName, struct TArray<struct FPandoraLuaBPVar>& Args); // Offset: 0x10211cde8 // Return & Params: Num(3) Size(0x40)
};

