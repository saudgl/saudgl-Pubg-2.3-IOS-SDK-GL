#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BattleItemHandle_HeadBP.BattleItemHandle_HeadBP_C
// Size: 0xb38 // Inherited bytes: 0xb22
struct UBattleItemHandle_HeadBP_C : UBattleItemHandle_AvatarBP_C {
	// Fields
	char pad_0xB22[0x6]; // Offset: 0xb22 // Size: 0x06
	struct TArray<int> BodyResIDList; // Offset: 0xb28 // Size: 0x10
};

