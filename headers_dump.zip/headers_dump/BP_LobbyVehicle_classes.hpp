#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_LobbyVehicle.BP_LobbyVehicle_C
// Size: 0x5c0 // Inherited bytes: 0x4c0
struct ABP_LobbyVehicle_C : ASTExtraLobbyVehicle {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x4c0 // Size: 0x08
	struct UVehicleAdvanceAvatarComp_BP_C* VehicleAdvanceAvatarComp_BP; // Offset: 0x4c8 // Size: 0x08
	struct UVehicleAvatarComponent_BP_C* VehicleAvatarComponent_BP; // Offset: 0x4d0 // Size: 0x08
	struct UMaterialInstanceDynamic* DMI; // Offset: 0x4d8 // Size: 0x08
	struct UMaterialInstanceDynamic* FPPDynamicMat; // Offset: 0x4e0 // Size: 0x08
	struct FName TailLightParamName; // Offset: 0x4e8 // Size: 0x08
	struct FName FrontLightParamName; // Offset: 0x4f0 // Size: 0x08
	struct FName FPPBoostLightParamName; // Offset: 0x4f8 // Size: 0x08
	int vehicleResId; // Offset: 0x500 // Size: 0x04
	char pad_0x504[0x4]; // Offset: 0x504 // Size: 0x04
	struct UMaterialInstanceDynamic* DMI_TailLight; // Offset: 0x508 // Size: 0x08
	struct UMaterialInstanceDynamic* DMI_AdvanceVehicle; // Offset: 0x510 // Size: 0x08
	int HighlightTryTime; // Offset: 0x518 // Size: 0x04
	char pad_0x51C[0x4]; // Offset: 0x51c // Size: 0x04
	struct TSet<int> SkyMotors; // Offset: 0x520 // Size: 0x50
	struct TSet<int> SpecialMotors; // Offset: 0x570 // Size: 0x50

	// Functions

	// Object Name: Function BP_LobbyVehicle.BP_LobbyVehicle_C.SetHighLight
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetHighLight(float invincible, float FreExp, float Speed); // Offset: 0x103df3e6c // Return & Params: Num(3) Size(0xc)

	// Object Name: Function BP_LobbyVehicle.BP_LobbyVehicle_C.GetDefaultAvatarID
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	int GetDefaultAvatarID(int InAvatarID); // Offset: 0x103df3e6c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function BP_LobbyVehicle.BP_LobbyVehicle_C.SetDMIParam
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetDMIParam(struct UMaterialInstanceDynamic* Target, struct FName Name, float Value); // Offset: 0x103df3e6c // Return & Params: Num(3) Size(0x14)

	// Object Name: Function BP_LobbyVehicle.BP_LobbyVehicle_C.GetVehicleMasterPath
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetVehicleMasterPath(int VehicleSkinID, struct FString& MeshBasePath); // Offset: 0x103df3e6c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function BP_LobbyVehicle.BP_LobbyVehicle_C.ClearAllVehicleItems
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	bool ClearAllVehicleItems(); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BP_LobbyVehicle.BP_LobbyVehicle_C.PreChangeVehicleAvatar_Old
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	bool PreChangeVehicleAvatar_Old(int InAvatarID, int InAdvanceAvatarID); // Offset: 0x103df3e6c // Return & Params: Num(3) Size(0x9)

	// Object Name: Function BP_LobbyVehicle.BP_LobbyVehicle_C.PutOffVehicleSlot
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	bool PutOffVehicleSlot(enum class EVehicleSlotType InSlotType); // Offset: 0x103df3e6c // Return & Params: Num(2) Size(0x2)

	// Object Name: Function BP_LobbyVehicle.BP_LobbyVehicle_C.PutOffVehicleItem
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	bool PutOffVehicleItem(int InModelID); // Offset: 0x103df3e6c // Return & Params: Num(2) Size(0x5)

	// Object Name: Function BP_LobbyVehicle.BP_LobbyVehicle_C.PutOnVehicleItem
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	bool PutOnVehicleItem(int InModelID, int ColorID, int PatternID, int ParticleID); // Offset: 0x103df3e6c // Return & Params: Num(5) Size(0x11)

	// Object Name: Function BP_LobbyVehicle.BP_LobbyVehicle_C.GetNewVehicleMasterAnimBPPath
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetNewVehicleMasterAnimBPPath(int InSkinID, struct FString& AnimBpPath); // Offset: 0x103df3e6c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function BP_LobbyVehicle.BP_LobbyVehicle_C.GetNewVehilceMasterPath
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetNewVehilceMasterPath(int VehicleSkinID, struct FString& MeshBasePath); // Offset: 0x103df3e6c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function BP_LobbyVehicle.BP_LobbyVehicle_C.PreChangeVehicleAvatar
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	bool PreChangeVehicleAvatar(int InAvatarID, int InAdvanceAvatarID); // Offset: 0x103df3e6c // Return & Params: Num(3) Size(0x9)

	// Object Name: Function BP_LobbyVehicle.BP_LobbyVehicle_C.ClearAllVehicleStyleID
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	bool ClearAllVehicleStyleID(); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BP_LobbyVehicle.BP_LobbyVehicle_C.PutOffVehicleStyleID
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	bool PutOffVehicleStyleID(int InStyleID); // Offset: 0x103df3e6c // Return & Params: Num(2) Size(0x5)

	// Object Name: Function BP_LobbyVehicle.BP_LobbyVehicle_C.PutOnVehicleStyleID
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	bool PutOnVehicleStyleID(int InStyleID); // Offset: 0x103df3e6c // Return & Params: Num(2) Size(0x5)

	// Object Name: Function BP_LobbyVehicle.BP_LobbyVehicle_C.UserConstructionScript
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void UserConstructionScript(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_LobbyVehicle.BP_LobbyVehicle_C.TrySetHighlight
	// Flags: [BlueprintCallable|BlueprintEvent]
	void TrySetHighlight(float invincible, float Freq, float Speed); // Offset: 0x103df3e6c // Return & Params: Num(3) Size(0xc)

	// Object Name: Function BP_LobbyVehicle.BP_LobbyVehicle_C.ExecuteUbergraph_BP_LobbyVehicle
	// Flags: [HasDefaults]
	void ExecuteUbergraph_BP_LobbyVehicle(int EntryPoint); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x4)
};

