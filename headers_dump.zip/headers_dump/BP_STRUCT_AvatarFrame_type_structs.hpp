#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_AvatarFrame_type.BP_STRUCT_AvatarFrame_type
// Size: 0x98 // Inherited bytes: 0x00
struct FBP_STRUCT_AvatarFrame_type {
	// Fields
	int Type_0_1A0A9F0743331BBE49AADB988DC87C90; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString Desc_1_AC45D7034D7DDDC90D52E19BF6D66EF9; // Offset: 0x08 // Size: 0x10
	struct FString Name_2_401DF90F47F3FF259DF5AD890925B071; // Offset: 0x18 // Size: 0x10
	int ID_3_831225F64111B05931B2D0B74884A6BD; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct FString DescGet_4_E78748484096828FA71D5E85901FD57B; // Offset: 0x30 // Size: 0x10
	struct FString IconBig_5_82F9A60A40DA032B376321A0896F07F2; // Offset: 0x40 // Size: 0x10
	struct FString Icon_6_7C7ADBE24A1E2C45A54BC7BD91D84759; // Offset: 0x50 // Size: 0x10
	struct FString DescTime_7_684743074A1D090755252DAA2F6832B5; // Offset: 0x60 // Size: 0x10
	int AppleAuditHide_8_C3DCAE874E4C89FB670303A48501283C; // Offset: 0x70 // Size: 0x04
	int DefaultDisplay_9_43871EC03BAE8EB1607A95390AB61819; // Offset: 0x74 // Size: 0x04
	struct FString ShowTime_10_6F3484001A56164C305DF94C07184815; // Offset: 0x78 // Size: 0x10
	struct FString JumpUrl_11_6CA1ABC05B25AE9F2E15463A0A43122C; // Offset: 0x88 // Size: 0x10
};

