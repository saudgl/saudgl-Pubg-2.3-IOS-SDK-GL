#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass WeaponAvatarComp_BP.WeaponAvatarComp_BP_C
// Size: 0x898 // Inherited bytes: 0x898
struct UWeaponAvatarComp_BP_C : UWeaponAvatarComponent {
};

