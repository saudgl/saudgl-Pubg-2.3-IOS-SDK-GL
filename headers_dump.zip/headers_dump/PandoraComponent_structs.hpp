#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct PandoraComponent.PandoraLuaBPVar
// Size: 0x20 // Inherited bytes: 0x00
struct FPandoraLuaBPVar {
	// Fields
	char pad_0x0[0x20]; // Offset: 0x00 // Size: 0x20
};

