#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_VehicleRefitParticleTable_type.BP_STRUCT_VehicleRefitParticleTable_type
// Size: 0x18 // Inherited bytes: 0x00
struct FBP_STRUCT_VehicleRefitParticleTable_type {
	// Fields
	struct FString PartileBPPath_0_5E40F7001EF760FC74A533720BB8A4F8; // Offset: 0x00 // Size: 0x10
	int ID_1_7D8FDE406414C5ED44FDA70204464694; // Offset: 0x10 // Size: 0x04
	int StyleID_2_4BC8E2804CB29D6C7BC616430EFC4DA4; // Offset: 0x14 // Size: 0x04
};

