#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass RankSmall_Interface.RankSmall_Interface_C
// Size: 0x28 // Inherited bytes: 0x28
struct URankSmall_Interface_C : UInterface {
	// Functions

	// Object Name: Function RankSmall_Interface.RankSmall_Interface_C.SetRankText
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetRankText(struct FSlateColor Color, struct FSlateColor ShadowColor, struct FSlateFontInfo FontInfo); // Offset: 0x103df3e6c // Return & Params: Num(3) Size(0xa8)

	// Object Name: Function RankSmall_Interface.RankSmall_Interface_C.SetRankIntegral
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetRankIntegral(struct FBP_STRUCT_RankIntegralLevel_type RankIntegralLevel_Info, bool isStarOpen); // Offset: 0x103df3e6c // Return & Params: Num(2) Size(0xe9)
};

