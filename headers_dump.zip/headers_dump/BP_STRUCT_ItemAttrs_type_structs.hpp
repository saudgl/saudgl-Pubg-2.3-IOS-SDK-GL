#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_ItemAttrs_type.BP_STRUCT_ItemAttrs_type
// Size: 0x0a // Inherited bytes: 0x00
struct FBP_STRUCT_ItemAttrs_type {
	// Fields
	bool CannotManualDrop_0_0E61A2402E96D7E519F01EB60A948770; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int Id_1_3F8638004A8D0C9628CCDB940E749B64; // Offset: 0x04 // Size: 0x04
	bool NotAddInTombBox_2_089BB7C052749B513D7FACBB06702BD8; // Offset: 0x08 // Size: 0x01
	bool RespawnNotDrop_3_715016400C714305540785CB07BAA120; // Offset: 0x09 // Size: 0x01
};

