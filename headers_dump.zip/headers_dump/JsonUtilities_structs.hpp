#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct JsonUtilities.JsonObjectWrapper
// Size: 0x20 // Inherited bytes: 0x00
struct FJsonObjectWrapper {
	// Fields
	struct FString jsonString; // Offset: 0x00 // Size: 0x10
	char pad_0x10[0x10]; // Offset: 0x10 // Size: 0x10
};

