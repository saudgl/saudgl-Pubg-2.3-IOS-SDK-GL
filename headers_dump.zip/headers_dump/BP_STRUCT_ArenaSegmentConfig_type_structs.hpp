#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_ArenaSegmentConfig_type.BP_STRUCT_ArenaSegmentConfig_type
// Size: 0x50 // Inherited bytes: 0x00
struct FBP_STRUCT_ArenaSegmentConfig_type {
	// Fields
	struct FString BigIcon_0_1B62704077A956854669C5D80A6A736E; // Offset: 0x00 // Size: 0x10
	int SegmentID_1_267821806A43506E11B3ED190DB173F4; // Offset: 0x10 // Size: 0x04
	int SegmentMinScore_2_2FDEA6400078E87F534C29050388F295; // Offset: 0x14 // Size: 0x04
	struct FString SegmentName_3_355C1E805B1679D25EA4543001746B85; // Offset: 0x18 // Size: 0x10
	int SegmentType_4_0C2886C06B91302F5EA0CFBE0172ADD5; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct FString SubIcon_6_2130B64038DD15F3291609280827737E; // Offset: 0x30 // Size: 0x10
	struct FString SmallIcon_7_44822A007BC7BC583E83C77F07BBD6FE; // Offset: 0x40 // Size: 0x10
};

