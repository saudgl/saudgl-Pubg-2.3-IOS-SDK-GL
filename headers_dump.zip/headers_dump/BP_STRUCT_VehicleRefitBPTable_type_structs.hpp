#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_VehicleRefitBPTable_type.BP_STRUCT_VehicleRefitBPTable_type
// Size: 0x30 // Inherited bytes: 0x00
struct FBP_STRUCT_VehicleRefitBPTable_type {
	// Fields
	struct FString Path_0_367735C04445450711936E2507D65338; // Offset: 0x00 // Size: 0x10
	int SkinID_1_178D3B00586DF4A03398AF2E06BA7504; // Offset: 0x10 // Size: 0x04
	int TemplateID_2_188844C035CA84B912116AE102FE3804; // Offset: 0x14 // Size: 0x04
	int ID_3_7E5115C05AFA7931402A62180B97D7E4; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct FString LobbyPath_6_1DD513C07D99921F4DE3874A01E3EA48; // Offset: 0x20 // Size: 0x10
};

