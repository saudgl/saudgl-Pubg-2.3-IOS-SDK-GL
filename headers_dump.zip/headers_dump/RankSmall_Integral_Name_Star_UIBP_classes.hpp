#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass RankSmall_Integral_Name_Star_UIBP.RankSmall_Integral_Name_Star_UIBP_C
// Size: 0x2a0 // Inherited bytes: 0x260
struct URankSmall_Integral_Name_Star_UIBP_C : UUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x260 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_Star; // Offset: 0x268 // Size: 0x08
	struct UImage* Image_Icon; // Offset: 0x270 // Size: 0x08
	struct UImage* Image_Quality; // Offset: 0x278 // Size: 0x08
	struct UImage* Image_Star; // Offset: 0x280 // Size: 0x08
	struct UTextBlock* TextBlock_Rank; // Offset: 0x288 // Size: 0x08
	struct UTextBlock* TextBlock_Star; // Offset: 0x290 // Size: 0x08
	struct UImage* vx_Image_Quality; // Offset: 0x298 // Size: 0x08

	// Functions

	// Object Name: Function RankSmall_Integral_Name_Star_UIBP.RankSmall_Integral_Name_Star_UIBP_C.SetRankText
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetRankText(struct FSlateColor Color, struct FSlateColor ShadowColor, struct FSlateFontInfo FontInfo); // Offset: 0x103df3e6c // Return & Params: Num(3) Size(0xa8)

	// Object Name: Function RankSmall_Integral_Name_Star_UIBP.RankSmall_Integral_Name_Star_UIBP_C.SetRankIntegral
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetRankIntegral(struct FBP_STRUCT_RankIntegralLevel_type RankIntegralLevel_Info, bool isStarOpen); // Offset: 0x103df3e6c // Return & Params: Num(2) Size(0xe9)

	// Object Name: Function RankSmall_Integral_Name_Star_UIBP.RankSmall_Integral_Name_Star_UIBP_C.ExecuteUbergraph_RankSmall_Integral_Name_Star_UIBP
	// Flags: [HasDefaults]
	void ExecuteUbergraph_RankSmall_Integral_Name_Star_UIBP(int EntryPoint); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x4)
};

