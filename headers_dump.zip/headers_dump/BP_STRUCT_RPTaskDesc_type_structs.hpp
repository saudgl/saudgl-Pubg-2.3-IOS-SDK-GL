#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_RPTaskDesc_type.BP_STRUCT_RPTaskDesc_type
// Size: 0x28 // Inherited bytes: 0x00
struct FBP_STRUCT_RPTaskDesc_type {
	// Fields
	struct FString Content_0_567889405931B67D3FC560CC09D170E4; // Offset: 0x00 // Size: 0x10
	int Desc_7_179FF240751420B53F51EA930C4BB5D3; // Offset: 0x10 // Size: 0x04
	int Recommand_2_335AF80028F60D606457CF530EA89F64; // Offset: 0x14 // Size: 0x04
	int TaskID_3_6877BA807B1789522DBC3F2E0AB1D394; // Offset: 0x18 // Size: 0x04
	int Title_6_2FEF1300013F605643FD62B604AC9FE5; // Offset: 0x1c // Size: 0x04
	int WeekIconType_5_307F20400B733E531956D0D504A153D5; // Offset: 0x20 // Size: 0x04
	int LocalizeContent_8_7817960060D1FF247336F71005A28004; // Offset: 0x24 // Size: 0x04
};

