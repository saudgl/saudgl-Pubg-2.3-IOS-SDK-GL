#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Reddot_Anchor_Item02.Reddot_Anchor_Item02_C
// Size: 0x2e4 // Inherited bytes: 0x2d0
struct UReddot_Anchor_Item02_C : ULuaUserWidget {
	// Fields
	struct UWidgetAnimation* Breathing; // Offset: 0x2d0 // Size: 0x08
	struct UTextBlock* TextBlock_Num; // Offset: 0x2d8 // Size: 0x08
	int PosTemplate; // Offset: 0x2e0 // Size: 0x04
};

