#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Lobby_Social_Attach_UIBP.Lobby_Social_Attach_UIBP_C
// Size: 0x2e8 // Inherited bytes: 0x260
struct ULobby_Social_Attach_UIBP_C : UUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x260 // Size: 0x08
	struct UWidgetAnimation* huadong; // Offset: 0x268 // Size: 0x08
	struct UCanvasPanel* Animation; // Offset: 0x270 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_56; // Offset: 0x278 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_Avatar; // Offset: 0x280 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_Bag; // Offset: 0x288 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_Download1; // Offset: 0x290 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_Download2; // Offset: 0x298 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_Download3; // Offset: 0x2a0 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_Edit_Car; // Offset: 0x2a8 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_IPX; // Offset: 0x2b0 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_Vehicle_Show; // Offset: 0x2b8 // Size: 0x08
	struct UCanvasPanel* HideRoleInfoPanel; // Offset: 0x2c0 // Size: 0x08
	struct UImage* Image_15; // Offset: 0x2c8 // Size: 0x08
	struct UTextBlock* TextBlock_1; // Offset: 0x2d0 // Size: 0x08
	struct UTitle_UIBP_C* Title_UIBP; // Offset: 0x2d8 // Size: 0x08
	struct UWrapBox* WrapBox_Edit_Car; // Offset: 0x2e0 // Size: 0x08

	// Functions

	// Object Name: Function Lobby_Social_Attach_UIBP.Lobby_Social_Attach_UIBP_C.ExecuteUbergraph_Lobby_Social_Attach_UIBP
	// Flags: [None]
	void ExecuteUbergraph_Lobby_Social_Attach_UIBP(int EntryPoint); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x4)
};

