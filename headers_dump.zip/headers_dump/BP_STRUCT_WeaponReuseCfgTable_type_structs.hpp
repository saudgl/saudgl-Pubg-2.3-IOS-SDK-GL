#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_WeaponReuseCfgTable_type.BP_STRUCT_WeaponReuseCfgTable_type
// Size: 0x20 // Inherited bytes: 0x00
struct FBP_STRUCT_WeaponReuseCfgTable_type {
	// Fields
	int ReuseAttachMeshID_0_5434FBC01C8BEB516724520609513054; // Offset: 0x00 // Size: 0x04
	int ReuseAvatarID_1_4546FB007C83124E1571E69B0A8192B4; // Offset: 0x04 // Size: 0x04
	int ReuseDefaultAttachID_2_7C7649C07EECDDC5161C8EEB079CE084; // Offset: 0x08 // Size: 0x04
	int ReuseFovID_3_4A896E0025C515CC35B3061B01430A64; // Offset: 0x0c // Size: 0x04
	int ReuseSupportAttachID_4_52FB37C0468A0A5532B875EE0C4070F4; // Offset: 0x10 // Size: 0x04
	int ReuseSupportBulletID_5_2F445C800F9CE3205C956C620DD524E4; // Offset: 0x14 // Size: 0x04
	int WeaponBPID_6_133CA14062C42FFD677CE3FD0F9C4324; // Offset: 0x18 // Size: 0x04
	int WeaponID_7_4308BCC073680B1B09069F6E07FF9CE4; // Offset: 0x1c // Size: 0x04
};

