#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_DefaultIconCfg_type.BP_STRUCT_DefaultIconCfg_type
// Size: 0x14 // Inherited bytes: 0x00
struct FBP_STRUCT_DefaultIconCfg_type {
	// Fields
	struct FString IconPath_0_3F9C22802280FE4E64E9102A0A2480E8; // Offset: 0x00 // Size: 0x10
	int ItemTypeOrSubType_1_6BA78C804B9BB4041C236DE40C2A9645; // Offset: 0x10 // Size: 0x04
};

