#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Team_Main_UIBP.Team_Main_UIBP_C
// Size: 0x278 // Inherited bytes: 0x260
struct UTeam_Main_UIBP_C : UUserWidget {
	// Fields
	struct UCanvasPanel* CanvasPanel_IPX; // Offset: 0x260 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_Menus; // Offset: 0x268 // Size: 0x08
	struct UTeamcode_C* Teamcode; // Offset: 0x270 // Size: 0x08
};

