#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_AvatarReplaceBlackTable_type.BP_STRUCT_AvatarReplaceBlackTable_type
// Size: 0x14 // Inherited bytes: 0x00
struct FBP_STRUCT_AvatarReplaceBlackTable_type {
	// Fields
	struct TArray<int> BreakItemIDArray_a_0_41BE8D800689F05464EA1B35089A9FB1; // Offset: 0x00 // Size: 0x10
	int ItemID_4_0ABFA4806936BA387754110A01381B74; // Offset: 0x10 // Size: 0x04
};

