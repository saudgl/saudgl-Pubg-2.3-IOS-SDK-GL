#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class ScriptPlugin.LuaContext
// Size: 0x3f0 // Inherited bytes: 0x3d8
struct ALuaContext : AActor {
	// Fields
	struct ULuaStateWrapper* OwningLuaStateWrapper; // Offset: 0x3d8 // Size: 0x08
	struct UObject* OwningObject; // Offset: 0x3e0 // Size: 0x08
	struct UScriptContextComponent* ScriptContextComponent; // Offset: 0x3e8 // Size: 0x08
};

// Object Name: Class ScriptPlugin.ScriptProfiler
// Size: 0x48 // Inherited bytes: 0x28
struct UScriptProfiler : UObject {
	// Fields
	char pad_0x28[0x20]; // Offset: 0x28 // Size: 0x20
};

// Object Name: Class ScriptPlugin.LuaStateWrapper
// Size: 0xf8 // Inherited bytes: 0x28
struct ULuaStateWrapper : UObject {
	// Fields
	char pad_0x28[0xd0]; // Offset: 0x28 // Size: 0xd0
};

// Object Name: Class ScriptPlugin.NetInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UNetInterface : UInterface {
};

// Object Name: Class ScriptPlugin.ScriptBlueprint
// Size: 0xf8 // Inherited bytes: 0xd8
struct UScriptBlueprint : UBlueprint {
	// Fields
	struct TArray<char> ByteCode; // Offset: 0xd8 // Size: 0x10
	struct FString SourceCode; // Offset: 0xe8 // Size: 0x10
};

// Object Name: Class ScriptPlugin.ScriptBlueprintGeneratedClass
// Size: 0x400 // Inherited bytes: 0x3d0
struct UScriptBlueprintGeneratedClass : UBlueprintGeneratedClass {
	// Fields
	struct TArray<char> ByteCode; // Offset: 0x3d0 // Size: 0x10
	struct FString SourceCode; // Offset: 0x3e0 // Size: 0x10
	struct TArray<struct UProperty*> ScriptProperties; // Offset: 0x3f0 // Size: 0x10
};

// Object Name: Class ScriptPlugin.ScriptContext
// Size: 0x30 // Inherited bytes: 0x28
struct UScriptContext : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08

	// Functions

	// Object Name: Function ScriptPlugin.ScriptContext.CallScriptFunction
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CallScriptFunction(struct FString FunctionName); // Offset: 0x102024c18 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class ScriptPlugin.ScriptContextComponent
// Size: 0x120 // Inherited bytes: 0x110
struct UScriptContextComponent : UActorComponent {
	// Fields
	char pad_0x110[0x8]; // Offset: 0x110 // Size: 0x08
	struct ULuaStateWrapper* OwningLuaStateWrapper; // Offset: 0x118 // Size: 0x08

	// Functions

	// Object Name: Function ScriptPlugin.ScriptContextComponent.PushScriptArrayIndexData
	// Flags: [Final|Native|Public|BlueprintCallable]
	void PushScriptArrayIndexData(struct FString ParamName, int Index); // Offset: 0x102025254 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function ScriptPlugin.ScriptContextComponent.PushOneScriptPropertyValues
	// Flags: [Native|Public|BlueprintCallable]
	void PushOneScriptPropertyValues(struct FString ParamName); // Offset: 0x102025190 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function ScriptPlugin.ScriptContextComponent.PushAllScriptPropertyValues
	// Flags: [Native|Public|BlueprintCallable]
	void PushAllScriptPropertyValues(); // Offset: 0x102025174 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ScriptPlugin.ScriptContextComponent.FetchScriptArrayIndexData
	// Flags: [Final|Native|Public|BlueprintCallable]
	void FetchScriptArrayIndexData(struct FString ParamName, int Index); // Offset: 0x102025078 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function ScriptPlugin.ScriptContextComponent.FetchOneScriptPropertyValues
	// Flags: [Native|Public|BlueprintCallable]
	void FetchOneScriptPropertyValues(struct FString ParamName); // Offset: 0x102024fb4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function ScriptPlugin.ScriptContextComponent.FetchAllScriptPropertyValues
	// Flags: [Native|Public|BlueprintCallable]
	void FetchAllScriptPropertyValues(); // Offset: 0x102024f98 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ScriptPlugin.ScriptContextComponent.CallScriptFunctionWithoutFetch
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CallScriptFunctionWithoutFetch(struct FString FunctionName); // Offset: 0x102024edc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function ScriptPlugin.ScriptContextComponent.CallScriptFunction
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CallScriptFunction(struct FString FunctionName); // Offset: 0x102024e20 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class ScriptPlugin.ScriptHelperNetInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UScriptHelperNetInterface : UObject {
	// Functions

	// Object Name: Function ScriptPlugin.ScriptHelperNetInterface.SendPacket_LuaState
	// Flags: [Final|Native|Static|Public]
	int SendPacket_LuaState(); // Offset: 0x1020257a8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function ScriptPlugin.ScriptHelperNetInterface.Disconnect
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void Disconnect(struct TScriptInterface<Class>& NetInterface); // Offset: 0x102025724 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function ScriptPlugin.ScriptHelperNetInterface.Connect
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void Connect(struct TScriptInterface<Class>& NetInterface, int Timeout); // Offset: 0x102025664 // Return & Params: Num(2) Size(0x14)
};

// Object Name: Class ScriptPlugin.ScriptPluginComponent
// Size: 0x30 // Inherited bytes: 0x28
struct UScriptPluginComponent : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08

	// Functions

	// Object Name: Function ScriptPlugin.ScriptPluginComponent.CallScriptFunction
	// Flags: [Native|Public|BlueprintCallable]
	bool CallScriptFunction(struct FString FunctionName); // Offset: 0x1020259a8 // Return & Params: Num(2) Size(0x11)
};

// Object Name: Class ScriptPlugin.ScriptTestActor
// Size: 0x3f0 // Inherited bytes: 0x3d8
struct AScriptTestActor : AActor {
	// Fields
	struct FString TestString; // Offset: 0x3d8 // Size: 0x10
	float TestValue; // Offset: 0x3e8 // Size: 0x04
	bool TestBool; // Offset: 0x3ec // Size: 0x01
	char pad_0x3ED[0x3]; // Offset: 0x3ed // Size: 0x03

	// Functions

	// Object Name: Function ScriptPlugin.ScriptTestActor.TestFunction
	// Flags: [Final|Native|Public]
	float TestFunction(float InValue, float InFactor, bool bMultiply); // Offset: 0x102025d54 // Return & Params: Num(4) Size(0x10)
};

// Object Name: Class ScriptPlugin.LuaClassBaseObj
// Size: 0x3d8 // Inherited bytes: 0x3d8
struct ALuaClassBaseObj : AActor {
	// Functions

	// Object Name: Function ScriptPlugin.LuaClassBaseObj.ItsATest
	// Flags: [Native|Public]
	struct FString ItsATest(struct FPlayerInfo Player1, struct TArray<int> nums, int X, struct FString Q, struct TArray<struct FPlayerInfo> Player2); // Offset: 0x1020260d4 // Return & Params: Num(6) Size(0x80)

	// Object Name: Function ScriptPlugin.LuaClassBaseObj.HandleUIMessage
	// Flags: [Native|Public|BlueprintCallable]
	void HandleUIMessage(struct FString UIMessage); // Offset: 0x102026034 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function ScriptPlugin.LuaClassBaseObj.GetGameStatus
	// Flags: [Native|Public|BlueprintCallable]
	struct FString GetGameStatus(); // Offset: 0x102025fc8 // Return & Params: Num(1) Size(0x10)
};

