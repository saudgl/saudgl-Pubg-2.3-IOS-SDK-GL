#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_NewbieSmallRankReward_type.BP_STRUCT_NewbieSmallRankReward_type
// Size: 0xa4 // Inherited bytes: 0x00
struct FBP_STRUCT_NewbieSmallRankReward_type {
	// Fields
	struct FString Condition1_Desc_0_1160A4007285B5D2358F0C5F06FB9153; // Offset: 0x00 // Size: 0x10
	int Condition1_Param_1_3BECC080766E21160BB616A40FC5541D; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct FString Condition1_Type_2_220D0CC0799F46D335800B7606FC9DA5; // Offset: 0x18 // Size: 0x10
	int ID_3_0C1D39C05F629F7D234199BB083D8964; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct FString ImageUrl_blue_1_4_3EDB81C0292671BB0CEEA48C0191E591; // Offset: 0x30 // Size: 0x10
	struct FString ImageUrl_blue_2_5_3EDC8200292671BC0CEEA48F0191E592; // Offset: 0x40 // Size: 0x10
	struct FString ImageUrl_global_1_6_4EC07400433DC08E747499F40106D1C1; // Offset: 0x50 // Size: 0x10
	struct FString ImageUrl_global_2_7_4EC17440433DC08F747499EB0106D1C2; // Offset: 0x60 // Size: 0x10
	int IsJK_8_03CAAAC059616ED9669367150D8ABFDB; // Offset: 0x70 // Size: 0x04
	int RelateID_9_5E2311007CC34CEA019D6534041521E4; // Offset: 0x74 // Size: 0x04
	int RewardItem_Num1_10_054FE380771ED5724A2303C7068449E1; // Offset: 0x78 // Size: 0x04
	int RewardItem_Num2_11_0550E3C0771ED5734A2303C6068449E2; // Offset: 0x7c // Size: 0x04
	int RewardItem_Num3_12_0551E400771ED5744A2303C5068449E3; // Offset: 0x80 // Size: 0x04
	int RewardItem_Time1_13_4D903B4050C72CF93DC90AD1084BDDE1; // Offset: 0x84 // Size: 0x04
	int RewardItem_Time2_14_4D913B8050C72CFA3DC90AD2084BDDE2; // Offset: 0x88 // Size: 0x04
	int RewardItem_Time3_15_4D923BC050C72CFB3DC90AD3084BDDE3; // Offset: 0x8c // Size: 0x04
	int RewardItemID1_16_405203001EA8E1CE5C98F76F03E64D61; // Offset: 0x90 // Size: 0x04
	int RewardItemID2_17_405303401EA8E1CF5C98F76003E64D62; // Offset: 0x94 // Size: 0x04
	int RewardItemID3_18_405403801EA8E1D05C98F76103E64D63; // Offset: 0x98 // Size: 0x04
	int SeasonID_19_6067B4004F446F4C5D595F4303B5EAF4; // Offset: 0x9c // Size: 0x04
	int SortID_20_1D8983C014E417016F223824083EA554; // Offset: 0xa0 // Size: 0x04
};

