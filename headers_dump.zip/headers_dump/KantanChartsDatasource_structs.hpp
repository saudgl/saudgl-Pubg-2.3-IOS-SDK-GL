#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct KantanChartsDatasource.KantanCartesianDatapoint
// Size: 0x08 // Inherited bytes: 0x00
struct FKantanCartesianDatapoint {
	// Fields
	struct FVector2D Coords; // Offset: 0x00 // Size: 0x08
};

