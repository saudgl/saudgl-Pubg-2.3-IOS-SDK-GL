#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: AnimBlueprintGeneratedClass SK_WEP_SCAR_AnimBP.SK_WEP_SCAR_AnimBP_C
// Size: 0x8a0 // Inherited bytes: 0x4c0
struct USK_WEP_SCAR_AnimBP_C : UWeaponAnimInstanceBase {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x4c0 // Size: 0x08
	struct FAnimNode_Root AnimGraphNode_Root_E0B90AD14ED6B7EC52E645A370C3E9D6; // Offset: 0x4c8 // Size: 0x50
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_C89DFC5847056D779E16F58B2B65C861; // Offset: 0x518 // Size: 0xd0
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_0FC4C7994FF75BBBC7DA1E8F8A28D1D1; // Offset: 0x5e8 // Size: 0x70
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_42DBF73F4D1B13CD4B302EB7F90A76E9; // Offset: 0x658 // Size: 0x70
	struct FAnimNode_Slot AnimGraphNode_Slot_D116339E424B254CA282DE8A8C5CBE65; // Offset: 0x6c8 // Size: 0x70
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend_BA19168644BB52369E637290CC89E913; // Offset: 0x738 // Size: 0xe8
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_E00B452142980F5B03492B99D420779E; // Offset: 0x820 // Size: 0x70
	bool EquipScope; // Offset: 0x890 // Size: 0x01
	char pad_0x891[0x7]; // Offset: 0x891 // Size: 0x07
	struct UWeaponAvatarComponent* WeaponAvatarComp; // Offset: 0x898 // Size: 0x08

	// Functions

	// Object Name: Function SK_WEP_SCAR_AnimBP.SK_WEP_SCAR_AnimBP_C.HandleWeaponStateChanged
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void HandleWeaponStateChanged(enum class EFreshWeaponStateType Selection); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function SK_WEP_SCAR_AnimBP.SK_WEP_SCAR_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_SK_WEP_SCAR_AnimBP_AnimGraphNode_BlendListByBool_C89DFC5847056D779E16F58B2B65C861
	// Flags: [BlueprintEvent]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_SK_WEP_SCAR_AnimBP_AnimGraphNode_BlendListByBool_C89DFC5847056D779E16F58B2B65C861(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SK_WEP_SCAR_AnimBP.SK_WEP_SCAR_AnimBP_C.OnWeaponChangeState
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnWeaponChangeState(enum class EFreshWeaponStateType CurState); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function SK_WEP_SCAR_AnimBP.SK_WEP_SCAR_AnimBP_C.OnScopeEquip
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnScopeEquip(enum class EWeaponAttachmentSocketType AttachmentSocketTypeD); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function SK_WEP_SCAR_AnimBP.SK_WEP_SCAR_AnimBP_C.OnScopeUnequip
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnScopeUnequip(enum class EWeaponAttachmentSocketType AttachmentSocketType); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function SK_WEP_SCAR_AnimBP.SK_WEP_SCAR_AnimBP_C.BlueprintInitializeAnimation
	// Flags: [Event|Public|BlueprintEvent]
	void BlueprintInitializeAnimation(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SK_WEP_SCAR_AnimBP.SK_WEP_SCAR_AnimBP_C.ExecuteUbergraph_SK_WEP_SCAR_AnimBP
	// Flags: [None]
	void ExecuteUbergraph_SK_WEP_SCAR_AnimBP(int EntryPoint); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x4)
};

