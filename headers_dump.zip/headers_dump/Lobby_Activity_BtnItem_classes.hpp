#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Lobby_Activity_BtnItem.Lobby_Activity_BtnItem_C
// Size: 0x538 // Inherited bytes: 0x418
struct ULobby_Activity_BtnItem_C : UUAEUserWidget {
	// Fields
	struct UWidgetAnimation* Anim_loading_loop; // Offset: 0x418 // Size: 0x08
	struct UWidgetAnimation* AwardPickAnimation; // Offset: 0x420 // Size: 0x08
	struct UCanvasPanel* Activity; // Offset: 0x428 // Size: 0x08
	struct UImage* awardBg; // Offset: 0x430 // Size: 0x08
	struct UImage* awardFX; // Offset: 0x438 // Size: 0x08
	struct UImage* awardIcon; // Offset: 0x440 // Size: 0x08
	struct UButton* Button_Activity; // Offset: 0x448 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_CountDown; // Offset: 0x450 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_Icon; // Offset: 0x458 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_name; // Offset: 0x460 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_OnlineActivityCountDown; // Offset: 0x468 // Size: 0x08
	struct UHorizontalBox* HorizontalBox_loading; // Offset: 0x470 // Size: 0x08
	struct UImage* Image_Activity; // Offset: 0x478 // Size: 0x08
	struct UImage* Image_CountDown; // Offset: 0x480 // Size: 0x08
	struct UReddot_Anchor_C* Image_RedPoint; // Offset: 0x488 // Size: 0x08
	struct UImage* Image_RedPoint_Old; // Offset: 0x490 // Size: 0x08
	struct UImage* Image_TimeCountDownBcakgroundPic; // Offset: 0x498 // Size: 0x08
	struct UCanvasPanel* Panel_Download; // Offset: 0x4a0 // Size: 0x08
	struct UTextBlock* T; // Offset: 0x4a8 // Size: 0x08
	struct UTextBlock* TextBlock_10; // Offset: 0x4b0 // Size: 0x08
	struct UTextBlock* TextBlock_11; // Offset: 0x4b8 // Size: 0x08
	struct UTextBlock* TextBlock_12; // Offset: 0x4c0 // Size: 0x08
	struct UTextBlock* TextBlock_13; // Offset: 0x4c8 // Size: 0x08
	struct UTextBlock* TextBlock_ActivityName; // Offset: 0x4d0 // Size: 0x08
	struct FVector2D PressedPosition; // Offset: 0x4d8 // Size: 0x08
	struct FScriptMulticastDelegate ItemMoveLeftDispatcher; // Offset: 0x4e0 // Size: 0x10
	struct FScriptMulticastDelegate ItemMoveRightDispatcher; // Offset: 0x4f0 // Size: 0x10
	struct FScriptMulticastDelegate ItemClickDispatcher; // Offset: 0x500 // Size: 0x10
	float ClickRange; // Offset: 0x510 // Size: 0x04
	int _onlineActivityType; // Offset: 0x514 // Size: 0x04
	int _onlineMinutes; // Offset: 0x518 // Size: 0x04
	int _onlineSeconds; // Offset: 0x51c // Size: 0x04
	int _ActId; // Offset: 0x520 // Size: 0x04
	int _CreatedUtc; // Offset: 0x524 // Size: 0x04
	struct FString JumpLink; // Offset: 0x528 // Size: 0x10

	// Functions

	// Object Name: Function Lobby_Activity_BtnItem.Lobby_Activity_BtnItem_C.SetOnlineActivityData
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetOnlineActivityData(int Status, struct FString strText); // Offset: 0x103df3e6c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Lobby_Activity_BtnItem.Lobby_Activity_BtnItem_C.SetBtnData
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetBtnData(struct FString ActivityName, struct FString IconPath, struct FString JumpUrl, bool IsShowCountDownIcon, bool isNew, struct FString DependItems, int ActID, int CreatedUtc); // Offset: 0x103df3e6c // Return & Params: Num(8) Size(0x50)

	// Object Name: Function Lobby_Activity_BtnItem.Lobby_Activity_BtnItem_C.ItemClickDispatcher__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void ItemClickDispatcher__DelegateSignature(struct ULobby_Activity_BtnItem_C* Item); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Lobby_Activity_BtnItem.Lobby_Activity_BtnItem_C.ItemMoveRightDispatcher__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void ItemMoveRightDispatcher__DelegateSignature(struct ULobby_Activity_BtnItem_C* Item); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Lobby_Activity_BtnItem.Lobby_Activity_BtnItem_C.ItemMoveLeftDispatcher__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void ItemMoveLeftDispatcher__DelegateSignature(struct ULobby_Activity_BtnItem_C* Item); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x8)
};

