#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class AI.AIActionExecutionComponent
// Size: 0x1f0 // Inherited bytes: 0x1d8
struct UAIActionExecutionComponent : ULuaActorComponent {
	// Fields
	struct ANewFakePlayerAIController* MyController; // Offset: 0x1d8 // Size: 0x08
	struct ASTExtraBaseCharacter* MyPlayerPawn; // Offset: 0x1e0 // Size: 0x08
	struct UMLAIControllerComponent* MyMLAIControllerComp; // Offset: 0x1e8 // Size: 0x08

	// Functions

	// Object Name: Function AI.AIActionExecutionComponent.SetFocusRotation
	// Flags: [Final|Native|Public]
	void SetFocusRotation(float InPitch, float InYaw, float InRoll); // Offset: 0x103b1a238 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function AI.AIActionExecutionComponent.IsFreeCamera
	// Flags: [Final|Native|Public]
	bool IsFreeCamera(); // Offset: 0x103b1a204 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AI.AIActionExecutionComponent.GetPickActorWithID
	// Flags: [Final|Native|Public]
	struct APickUpWrapperActor* GetPickActorWithID(int UId); // Offset: 0x103b1a178 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function AI.AIActionExecutionComponent.DoActionMove
	// Flags: [Final|Native|Public]
	void DoActionMove(bool IsRun, float DirectionX, float DirectionY, float DirectionZ); // Offset: 0x103b1a03c // Return & Params: Num(4) Size(0x10)

	// Object Name: Function AI.AIActionExecutionComponent.DoActionFreeCamera
	// Flags: [Final|Native|Public]
	void DoActionFreeCamera(bool IsEnter, float InPitch, float InYaw, float InRoll); // Offset: 0x103b19f00 // Return & Params: Num(4) Size(0x10)
};

// Object Name: Class AI.AISoundCollectionComponent
// Size: 0x2f0 // Inherited bytes: 0x1d8
struct UAISoundCollectionComponent : ULuaActorComponent {
	// Fields
	struct TMap<uint32_t, struct FCacheSoundState> CacheStepSounds; // Offset: 0x1d8 // Size: 0x50
	struct TMap<uint32_t, struct FCacheSoundState> CacheWeaponSounds; // Offset: 0x228 // Size: 0x50
	struct TMap<uint32_t, struct FCacheSoundState> CacheVehicleSounds; // Offset: 0x278 // Size: 0x50
	char pad_0x2C8[0x18]; // Offset: 0x2c8 // Size: 0x18
	float ClearStepSoundTime; // Offset: 0x2e0 // Size: 0x04
	float ClearWeaponSoundTime; // Offset: 0x2e4 // Size: 0x04
	float ClearVehicleSoundTime; // Offset: 0x2e8 // Size: 0x04
	char pad_0x2EC[0x4]; // Offset: 0x2ec // Size: 0x04

	// Functions

	// Object Name: Function AI.AISoundCollectionComponent.OnCollectionHearSound
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	void OnCollectionHearSound(enum class ESoundType soundType, struct FVector& InPos, struct AActor* InSourceActor); // Offset: 0x103b1aa24 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function AI.AISoundCollectionComponent.GetCollectSoundInfo
	// Flags: [Final|Native|Public]
	struct TArray<struct FSoundState> GetCollectSoundInfo(); // Offset: 0x103b1a9c0 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class AI.AIStateInfoComponent
// Size: 0xa80 // Inherited bytes: 0x110
struct UAIStateInfoComponent : UActorComponent {
	// Fields
	struct TMap<int, int> ProgressSkillConfig; // Offset: 0x110 // Size: 0x50
	struct TMap<int, bool> AvailableBackpacItemTypes; // Offset: 0x160 // Size: 0x50
	struct TMap<int, int> GrenadeTypeConfig; // Offset: 0x1b0 // Size: 0x50
	float VisibleAngle; // Offset: 0x200 // Size: 0x04
	float NearByEnemyRange; // Offset: 0x204 // Size: 0x04
	float FogWeatherRangeScale; // Offset: 0x208 // Size: 0x04
	int NearByEnemyMaxNum; // Offset: 0x20c // Size: 0x04
	bool IsSearchNearItem; // Offset: 0x210 // Size: 0x01
	char pad_0x211[0x3]; // Offset: 0x211 // Size: 0x03
	int NearbyItemMaxNum; // Offset: 0x214 // Size: 0x04
	int NearbyMaxBoxNum; // Offset: 0x218 // Size: 0x04
	float NearbyAirDropBoxRangeInner; // Offset: 0x21c // Size: 0x04
	float NearbyAirDropBoxRangeOuter; // Offset: 0x220 // Size: 0x04
	float NearbyDeathBoxRange; // Offset: 0x224 // Size: 0x04
	float NearbyPickUpWrapperRange; // Offset: 0x228 // Size: 0x04
	float CacheNearbyItemRangeCoefficient; // Offset: 0x22c // Size: 0x04
	float NearbyFindBuildingRange; // Offset: 0x230 // Size: 0x04
	float ItemStateChangedRange; // Offset: 0x234 // Size: 0x04
	bool IsItemVisiable; // Offset: 0x238 // Size: 0x01
	bool IsUseItemSpotLoc; // Offset: 0x239 // Size: 0x01
	char pad_0x23A[0x2]; // Offset: 0x23a // Size: 0x02
	float NearbyObstacleRange; // Offset: 0x23c // Size: 0x04
	float NearbyThrownRange; // Offset: 0x240 // Size: 0x04
	int NearbyThrownMaxNum; // Offset: 0x244 // Size: 0x04
	char pad_0x248[0x4]; // Offset: 0x248 // Size: 0x04
	int NearbyDoorMaxNum; // Offset: 0x24c // Size: 0x04
	int NearbyVehicleRange; // Offset: 0x250 // Size: 0x04
	int NearbyVehicleMaxNum; // Offset: 0x254 // Size: 0x04
	float NearbyBulletHoleRange; // Offset: 0x258 // Size: 0x04
	char pad_0x25C[0x4]; // Offset: 0x25c // Size: 0x04
	struct FAIStateInfo CacheAIStateInfo; // Offset: 0x260 // Size: 0x2e0
	struct FDiffAIStateInfo CacheDiffAIStateInfo; // Offset: 0x540 // Size: 0x418
	struct FRedZoneState CacheRedZoneInfo; // Offset: 0x958 // Size: 0x18
	float AirAttackTotalTime; // Offset: 0x970 // Size: 0x04
	bool IsTouchedPlayer; // Offset: 0x974 // Size: 0x01
	bool bIgnoreTreeAIWhenNoPlayerAround; // Offset: 0x975 // Size: 0x01
	char pad_0x976[0x2]; // Offset: 0x976 // Size: 0x02
	float IgnoreTreeAIRadius; // Offset: 0x978 // Size: 0x04
	uint32_t FrameNo; // Offset: 0x97c // Size: 0x04
	struct UAirAttackComponent* AirAttackComp; // Offset: 0x980 // Size: 0x08
	struct APawn* MyOwnerPawn; // Offset: 0x988 // Size: 0x08
	struct ABattleRoyaleGameModeBase* MyGameMode; // Offset: 0x990 // Size: 0x08
	char pad_0x998[0x60]; // Offset: 0x998 // Size: 0x60
	struct TMap<int, struct APickUpWrapperActor*> CacheAINearByItem; // Offset: 0x9f8 // Size: 0x50
	struct FCacheNearbyItemState CacheNearbyItemState; // Offset: 0xa48 // Size: 0x20
	struct UMLAIControllerComponent* MyMLAIControllerComp; // Offset: 0xa68 // Size: 0x08
	uint32_t CacheModeMapId; // Offset: 0xa70 // Size: 0x04
	char pad_0xA74[0xc]; // Offset: 0xa74 // Size: 0x0c

	// Functions

	// Object Name: Function AI.AIStateInfoComponent.QueryItemStates
	// Flags: [Final|Native|Public]
	struct TArray<struct FItemStateData> QueryItemStates(int MaxBoxNum, int MaxItemNum, float AirDropBoxRangeInner, float AirDropBoxRangeOuter, float DeathBoxRange, float PickUpWrapperRange, float FindBuildingRange, bool InIsUseItemSpotLoc); // Offset: 0x103b1c9bc // Return & Params: Num(9) Size(0x30)

	// Object Name: Function AI.AIStateInfoComponent.OnItemStateChanged
	// Flags: [Final|Native|Public|HasDefaults]
	void OnItemStateChanged(struct FVector Location); // Offset: 0x103b1c940 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function AI.AIStateInfoComponent.OnAirAttackInfo
	// Flags: [Final|Native|Private|HasOutParms|HasDefaults]
	void OnAirAttackInfo(enum class EAirAttackInfo airattacktype, int waveIndex, struct FAirAttackOrder& InAirAttackOrder, struct FVector& InAirAttackArea); // Offset: 0x103b1c7ac // Return & Params: Num(4) Size(0x5c)

	// Object Name: Function AI.AIStateInfoComponent.IsAvailableBackpacItemType
	// Flags: [Final|Native|Public|Const]
	bool IsAvailableBackpacItemType(struct FItemDefineID DefineID); // Offset: 0x103b1c710 // Return & Params: Num(2) Size(0x19)

	// Object Name: Function AI.AIStateInfoComponent.HasPlayerAround
	// Flags: [Final|Native|Private]
	bool HasPlayerAround(); // Offset: 0x103b1c6dc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AI.AIStateInfoComponent.GetViewForwardVector
	// Flags: [Final|Native|Private|HasDefaults]
	struct FVector GetViewForwardVector(struct ACharacter* InCharacter); // Offset: 0x103b1c64c // Return & Params: Num(2) Size(0x14)

	// Object Name: Function AI.AIStateInfoComponent.GetVehicleStatus
	// Flags: [Final|Native|Public]
	struct FVehicleState GetVehicleStatus(struct ASTExtraVehicleBase* InVehicle, struct ASTExtraBaseCharacter* PawnInCar); // Offset: 0x103b1c578 // Return & Params: Num(3) Size(0x74)

	// Object Name: Function AI.AIStateInfoComponent.GetTLogAIShootInfo
	// Flags: [Final|Native|Public]
	struct FTLogAIShootInfo GetTLogAIShootInfo(); // Offset: 0x103b1c540 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function AI.AIStateInfoComponent.GetSoundInfo
	// Flags: [Final|Native|Public]
	struct TArray<struct FSoundState> GetSoundInfo(); // Offset: 0x103b1c4dc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AI.AIStateInfoComponent.GetProgressBarState
	// Flags: [Final|Native|Public]
	struct FProgressBarState GetProgressBarState(); // Offset: 0x103b1c478 // Return & Params: Num(1) Size(0x20)

	// Object Name: Function AI.AIStateInfoComponent.GetPlayerInteractInfo
	// Flags: [Final|Native|Public]
	struct FAIPlayerInteractInfo GetPlayerInteractInfo(); // Offset: 0x103b1c414 // Return & Params: Num(1) Size(0x30)

	// Object Name: Function AI.AIStateInfoComponent.GetPickActorWithID
	// Flags: [Final|Native|Public]
	struct APickUpWrapperActor* GetPickActorWithID(int UId); // Offset: 0x103b1c388 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function AI.AIStateInfoComponent.GetObstaclesState
	// Flags: [Final|Native|Public]
	struct TArray<struct FObstacleState> GetObstaclesState(float Range); // Offset: 0x103b1c2d4 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function AI.AIStateInfoComponent.GetNearbyVehicles
	// Flags: [Final|Native|Public]
	struct TArray<struct FVehicleState> GetNearbyVehicles(struct ASTExtraBaseCharacter* InPawn); // Offset: 0x103b1c220 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function AI.AIStateInfoComponent.GetFrameNo
	// Flags: [Final|Native|Private]
	uint32_t GetFrameNo(); // Offset: 0x103b1c204 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AI.AIStateInfoComponent.GetDoorsState
	// Flags: [Final|Native|Public]
	struct TArray<struct FDoorState> GetDoorsState(float Range, int MaxNum); // Offset: 0x103b1c114 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function AI.AIStateInfoComponent.GetDiffAIStateInfo
	// Flags: [Final|Native|Public]
	struct FDiffAIStateInfo GetDiffAIStateInfo(); // Offset: 0x103b1c0b0 // Return & Params: Num(1) Size(0x418)

	// Object Name: Function AI.AIStateInfoComponent.GetDamageSources
	// Flags: [Final|Native|Public]
	struct FAIDamageSources GetDamageSources(); // Offset: 0x103b1c04c // Return & Params: Num(1) Size(0x30)

	// Object Name: Function AI.AIStateInfoComponent.GetCameraState
	// Flags: [Final|Native|Public]
	struct FCameraState GetCameraState(struct ASTExtraBaseCharacter* InCharacter); // Offset: 0x103b1bfb0 // Return & Params: Num(2) Size(0x2c)

	// Object Name: Function AI.AIStateInfoComponent.GetAllPlayerStateInfo
	// Flags: [Final|Native|Public]
	struct TArray<struct FAIStateInfo> GetAllPlayerStateInfo(); // Offset: 0x103b1bf4c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AI.AIStateInfoComponent.GetAIStateInfoInternal
	// Flags: [Final|Native|Public]
	struct FAIStateInfo GetAIStateInfoInternal(); // Offset: 0x103b1bee8 // Return & Params: Num(1) Size(0x2e0)

	// Object Name: Function AI.AIStateInfoComponent.GetAIStateInfo
	// Flags: [Final|Native|Public]
	struct FAIStateInfo GetAIStateInfo(); // Offset: 0x103b1be84 // Return & Params: Num(1) Size(0x2e0)

	// Object Name: Function AI.AIStateInfoComponent.GetAIPlayerBackpackItems
	// Flags: [Final|Native|Public]
	struct TArray<struct FAIBackpackItem> GetAIPlayerBackpackItems(struct ABaseAIController* InController); // Offset: 0x103b1bdd0 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function AI.AIStateInfoComponent.GetAINearbyThrownState
	// Flags: [Final|Native|Public]
	struct TArray<struct FAINearbyThrown> GetAINearbyThrownState(struct ASTExtraBaseCharacter* InCharacter, float InRange, float InCheckAngle, int MaxNum); // Offset: 0x103b1bc6c // Return & Params: Num(5) Size(0x28)

	// Object Name: Function AI.AIStateInfoComponent.ClearPlayerInteractInfo
	// Flags: [Final|Native|Public]
	void ClearPlayerInteractInfo(); // Offset: 0x103b1bc58 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AI.AIStateInfoComponent.ClearDamageSources
	// Flags: [Final|Native|Public]
	void ClearDamageSources(); // Offset: 0x103b1bc44 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class AI.MLAIControllerComponent
// Size: 0x258 // Inherited bytes: 0x110
struct UMLAIControllerComponent : UActorComponent {
	// Fields
	struct UActorComponent* AIActionExcutionCompClass; // Offset: 0x110 // Size: 0x08
	struct UActorComponent* AISoundCollectCompClass; // Offset: 0x118 // Size: 0x08
	struct UActorComponent* AIStateInfoCompClass; // Offset: 0x120 // Size: 0x08
	struct UAIActionExecutionComponent* AIActionExecutionComp; // Offset: 0x128 // Size: 0x08
	struct UAIStateInfoComponent* AIStateInfoComp; // Offset: 0x130 // Size: 0x08
	struct UAISoundCollectionComponent* AISoundCollectComp; // Offset: 0x138 // Size: 0x08
	float HearRadius; // Offset: 0x140 // Size: 0x04
	char pad_0x144[0x4]; // Offset: 0x144 // Size: 0x04
	struct TMap<enum class ESTEPoseState, struct FCameraViewPitchLimitData> CameraViewPitchLimitDataMap; // Offset: 0x148 // Size: 0x50
	struct FVector PrePos; // Offset: 0x198 // Size: 0x0c
	float PreTickTime; // Offset: 0x1a4 // Size: 0x04
	struct ANewFakePlayerAIController* MyController; // Offset: 0x1a8 // Size: 0x08
	char pad_0x1B0[0x14]; // Offset: 0x1b0 // Size: 0x14
	float FindNavLocationRadius; // Offset: 0x1c4 // Size: 0x04
	int MaxNavLocationFindTimes; // Offset: 0x1c8 // Size: 0x04
	bool bUseLerpRotation; // Offset: 0x1cc // Size: 0x01
	char pad_0x1CD[0x3]; // Offset: 0x1cd // Size: 0x03
	float LerpRotationThreshold; // Offset: 0x1d0 // Size: 0x04
	bool IsForceTargetRotation; // Offset: 0x1d4 // Size: 0x01
	char pad_0x1D5[0x3]; // Offset: 0x1d5 // Size: 0x03
	float FirstLerpRotationDeltaTime; // Offset: 0x1d8 // Size: 0x04
	float FreeCameraTurnVelocity; // Offset: 0x1dc // Size: 0x04
	char pad_0x1E0[0x4]; // Offset: 0x1e0 // Size: 0x04
	bool IsModifyDamageLuaOverride; // Offset: 0x1e4 // Size: 0x01
	char pad_0x1E5[0x3]; // Offset: 0x1e5 // Size: 0x03
	float RatingDamageScaleLuaOverride; // Offset: 0x1e8 // Size: 0x04
	bool bShouldSendVehicleInfo; // Offset: 0x1ec // Size: 0x01
	char pad_0x1ED[0x6b]; // Offset: 0x1ed // Size: 0x6b

	// Functions

	// Object Name: Function AI.MLAIControllerComponent.UnBindDelegates
	// Flags: [Final|Native|Public]
	void UnBindDelegates(bool IsEndPlay); // Offset: 0x103b1ec94 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AI.MLAIControllerComponent.SetLuaAIParamConfigString
	// Flags: [Final|Native|Public]
	void SetLuaAIParamConfigString(struct FString InAIParamConfigString); // Offset: 0x103b1ebd8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AI.MLAIControllerComponent.RestartFightBehaviorTree
	// Flags: [Final|Native|Public]
	void RestartFightBehaviorTree(); // Offset: 0x103b1ebc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AI.MLAIControllerComponent.IsFreeCamera
	// Flags: [Final|Native|Public]
	bool IsFreeCamera(); // Offset: 0x103b1eb90 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AI.MLAIControllerComponent.GetViewRotation
	// Flags: [Final|Native|Public|HasDefaults]
	struct FRotator GetViewRotation(); // Offset: 0x103b1eb58 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function AI.MLAIControllerComponent.GetViewForwardVector
	// Flags: [Final|Native|Public|HasDefaults]
	struct FVector GetViewForwardVector(); // Offset: 0x103b1eb20 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function AI.MLAIControllerComponent.GetAIStateInfoComp
	// Flags: [Final|Native|Public|Const]
	struct UAIStateInfoComponent* GetAIStateInfoComp(); // Offset: 0x103b1eb04 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function AI.MLAIControllerComponent.GetAIActionExecutionComp
	// Flags: [Final|Native|Public|Const]
	struct UAIActionExecutionComponent* GetAIActionExecutionComp(); // Offset: 0x103b1eae8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function AI.MLAIControllerComponent.DoActionFreeCamera
	// Flags: [Final|Native|Public]
	void DoActionFreeCamera(bool IsEnter, float InPitch, float InYaw, float InRoll); // Offset: 0x103b1e9ac // Return & Params: Num(4) Size(0x10)

	// Object Name: Function AI.MLAIControllerComponent.CheckCameraViewPitchLimit
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	bool CheckCameraViewPitchLimit(struct FRotator& InOutTargetRot); // Offset: 0x103b1e914 // Return & Params: Num(2) Size(0xd)

	// Object Name: Function AI.MLAIControllerComponent.BindDelegates
	// Flags: [Final|Native|Public]
	void BindDelegates(); // Offset: 0x103b1e900 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class AI.MLAISubSystem
// Size: 0x158 // Inherited bytes: 0x30
struct UMLAISubSystem : UWorldSubsystem {
	// Fields
	struct TMap<uint32_t, struct FAIPlayerState> CacheAIPlayerStates; // Offset: 0x30 // Size: 0x50
	struct TMap<uint32_t, struct FAIPlayerWeapon> CacheAIPlayerWeapons; // Offset: 0x80 // Size: 0x50
	struct TMap<uint32_t, struct FAIPlayerEquipment> CacheAIPlayerEquipments; // Offset: 0xd0 // Size: 0x50
	struct TArray<struct UAIStateInfoComponent*> AIStateInfoComps; // Offset: 0x120 // Size: 0x10
	struct TArray<struct FBulletHole> CacheBulletHoles; // Offset: 0x130 // Size: 0x10
	struct TArray<struct FSpecialZoneState> CacheSpecialZones; // Offset: 0x140 // Size: 0x10
	char pad_0x150[0x8]; // Offset: 0x150 // Size: 0x08

	// Functions

	// Object Name: Function AI.MLAISubSystem.StartRequestCache
	// Flags: [Final|Native|Public]
	void StartRequestCache(); // Offset: 0x103b2b618 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AI.MLAISubSystem.OnItemStateChanged
	// Flags: [Final|Native|Public|HasDefaults]
	void OnItemStateChanged(struct FVector Location); // Offset: 0x103b2b59c // Return & Params: Num(1) Size(0xc)

	// Object Name: Function AI.MLAISubSystem.EndRequestCache
	// Flags: [Final|Native|Public]
	void EndRequestCache(); // Offset: 0x103b2b588 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class AI.MLAITrainingComponent
// Size: 0x138 // Inherited bytes: 0x110
struct UMLAITrainingComponent : UActorComponent {
	// Fields
	bool IsBeginRequestAIState; // Offset: 0x110 // Size: 0x01
	bool IsEndRequestAIState; // Offset: 0x111 // Size: 0x01
	char pad_0x112[0x26]; // Offset: 0x112 // Size: 0x26

	// Functions

	// Object Name: Function AI.MLAITrainingComponent.StopRunnable
	// Flags: [Final|Native|Public]
	void StopRunnable(); // Offset: 0x103b2c5a8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AI.MLAITrainingComponent.SendAIStateRequest
	// Flags: [Final|Native|Public]
	void SendAIStateRequest(struct TArray<char> Packet); // Offset: 0x103b2c4c4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AI.MLAITrainingComponent.IsRequestAIState
	// Flags: [Final|Native|Public]
	bool IsRequestAIState(); // Offset: 0x103b2c490 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AI.MLAITrainingComponent.InitRunnable
	// Flags: [Final|Native|Public]
	void InitRunnable(float InStartCollectingInterval, float InSendInterval, float InTimeOutInterval); // Offset: 0x103b2c3a0 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function AI.MLAITrainingComponent.EndRequestAIState
	// Flags: [Final|Native|Public]
	void EndRequestAIState(); // Offset: 0x103b2c38c // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class AI.SpecialZoneShapeComponent
// Size: 0x710 // Inherited bytes: 0x700
struct USpecialZoneShapeComponent : UPrimitiveComponent {
	// Fields
	float SphereRadius; // Offset: 0x700 // Size: 0x04
	char pad_0x704[0xc]; // Offset: 0x704 // Size: 0x0c
};

// Object Name: Class AI.SpecialZoneActor
// Size: 0x3f0 // Inherited bytes: 0x3d8
struct ASpecialZoneActor : AActor {
	// Fields
	int ZoneID; // Offset: 0x3d8 // Size: 0x04
	float Radius; // Offset: 0x3dc // Size: 0x04
	int Type; // Offset: 0x3e0 // Size: 0x04
	char pad_0x3E4[0x4]; // Offset: 0x3e4 // Size: 0x04
	struct USpecialZoneShapeComponent* SpecialZoneShapeComponent; // Offset: 0x3e8 // Size: 0x08

	// Functions

	// Object Name: Function AI.SpecialZoneActor.GetSpecialZoneState
	// Flags: [Final|Native|Public]
	struct FSpecialZoneState GetSpecialZoneState(); // Offset: 0x103b2cb9c // Return & Params: Num(1) Size(0x30)
};

// Object Name: Class AI.VehicleAIUserComponent
// Size: 0x208 // Inherited bytes: 0x208
struct UVehicleAIUserComponent : UVehicleUserComponentBase {
	// Functions

	// Object Name: Function AI.VehicleAIUserComponent.ServerVehicleLeanOut
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ServerVehicleLeanOut(bool bLeanOut); // Offset: 0x103b2ddb8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AI.VehicleAIUserComponent.ServerExitVehicle
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ServerExitVehicle(); // Offset: 0x103b2dda4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AI.VehicleAIUserComponent.ServerEnterVehicle
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ServerEnterVehicle(struct ASTExtraVehicleBase* InVehicle, char SeatType); // Offset: 0x103b2dcec // Return & Params: Num(2) Size(0x9)

	// Object Name: Function AI.VehicleAIUserComponent.ServerChangeVehicleSeat
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ServerChangeVehicleSeat(int InSeatIndex); // Offset: 0x103b2dc70 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AI.VehicleAIUserComponent.MulticastExitVehicle
	// Flags: [Net|NetReliableNative|Event|NetMulticast|Public]
	void MulticastExitVehicle(); // Offset: 0x103b2dc54 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AI.VehicleAIUserComponent.MulticastEnterVehicle
	// Flags: [Net|NetReliableNative|Event|NetMulticast|Public]
	void MulticastEnterVehicle(struct ASTExtraVehicleBase* InVehicle, struct ASTExtraPlayerCharacter* Pawn, bool bSuccess, char SeatType, int SeatIndex); // Offset: 0x103b2dad4 // Return & Params: Num(5) Size(0x18)

	// Object Name: Function AI.VehicleAIUserComponent.MulticastChangeVehicleSeat
	// Flags: [Net|NetReliableNative|Event|NetMulticast|Public]
	void MulticastChangeVehicleSeat(int InSeatIndex); // Offset: 0x103b2da50 // Return & Params: Num(1) Size(0x4)
};

