#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum AI.EAISoundCollectType
enum class EAISoundCollectType : uint8 {
	AISoundCollectType_Step = 1,
	AISoundCollectType_Weapon = 2,
	AISoundCollectType_Vehicle = 3,
	AISoundCollectType_MAX = 4
};

