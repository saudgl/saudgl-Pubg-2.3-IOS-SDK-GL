#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass LobbyAvatarFunctionLibrary.LobbyAvatarFunctionLibrary_C
// Size: 0x98 // Inherited bytes: 0x98
struct ULobbyAvatarFunctionLibrary_C : UBlueprintFunctionOverride {
	// Functions

	// Object Name: Function LobbyAvatarFunctionLibrary.LobbyAvatarFunctionLibrary_C.OnPlayerRotate
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	void OnPlayerRotate(struct UObject* __WorldContext); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x8)
};

