#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BattleItemHandle_BP_Head_07.BattleItemHandle_BP_Head_07_C
// Size: 0xb38 // Inherited bytes: 0xb38
struct UBattleItemHandle_BP_Head_07_C : UBattleItemHandle_HeadBP_C {
};

