#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: AnimBlueprintGeneratedClass BP_Phone_Anim.BP_Phone_Anim_C
// Size: 0x488 // Inherited bytes: 0x3c0
struct UBP_Phone_Anim_C : UAnimInstance {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x3c0 // Size: 0x08
	struct FAnimNode_Root AnimGraphNode_Root_F915205347D80689471DF88D9872E184; // Offset: 0x3c8 // Size: 0x50
	struct FAnimNode_Slot AnimGraphNode_Slot_806200C547ABA7C6C9334E8EAD357C8B; // Offset: 0x418 // Size: 0x70

	// Functions

	// Object Name: Function BP_Phone_Anim.BP_Phone_Anim_C.AnimNotify_ShowPhone
	// Flags: [BlueprintCallable|BlueprintEvent]
	void AnimNotify_ShowPhone(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_Phone_Anim.BP_Phone_Anim_C.ExecuteUbergraph_BP_Phone_Anim
	// Flags: [None]
	void ExecuteUbergraph_BP_Phone_Anim(int EntryPoint); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x4)
};

