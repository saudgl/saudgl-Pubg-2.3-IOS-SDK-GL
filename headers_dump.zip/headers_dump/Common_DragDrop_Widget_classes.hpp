#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Common_DragDrop_Widget.Common_DragDrop_Widget_C
// Size: 0x270 // Inherited bytes: 0x260
struct UCommon_DragDrop_Widget_C : UUserWidget {
	// Fields
	struct UImage* DefaultTexture; // Offset: 0x260 // Size: 0x08
	struct UImage* Frame; // Offset: 0x268 // Size: 0x08
};

