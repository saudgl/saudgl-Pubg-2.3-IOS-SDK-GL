#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_Lobby_Grenade.BP_Lobby_Grenade_C
// Size: 0x3f0 // Inherited bytes: 0x3d8
struct ABP_Lobby_Grenade_C : AActor {
	// Fields
	struct UGrenadeAvatarComponent_BP_C* GrenadeAvatarComponent_BP; // Offset: 0x3d8 // Size: 0x08
	struct UStaticMeshComponent* StaticMesh; // Offset: 0x3e0 // Size: 0x08
	bool IsAvatarReady; // Offset: 0x3e8 // Size: 0x01
	char pad_0x3E9[0x3]; // Offset: 0x3e9 // Size: 0x03
	int grenadeResId; // Offset: 0x3ec // Size: 0x04

	// Functions

	// Object Name: Function BP_Lobby_Grenade.BP_Lobby_Grenade_C.SetAvatarReady
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetAvatarReady(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_Lobby_Grenade.BP_Lobby_Grenade_C.UserConstructionScript
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void UserConstructionScript(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)
};

