#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class Client.AppBaseConfig
// Size: 0x150 // Inherited bytes: 0x28
struct UAppBaseConfig : UObject {
	// Fields
	int PUBLISH_REGION_ID; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct FString PUBLISH_AREA; // Offset: 0x30 // Size: 0x10
	struct FString IMSDK_GAME_ID; // Offset: 0x40 // Size: 0x10
	struct FString GEMAppID; // Offset: 0x50 // Size: 0x10
	uint32_t TSSGameId; // Offset: 0x60 // Size: 0x04
	char pad_0x64[0x4]; // Offset: 0x64 // Size: 0x04
	uint64 GameID; // Offset: 0x68 // Size: 0x08
	struct FString GameKey; // Offset: 0x70 // Size: 0x10
	uint64 GVoiceGameId; // Offset: 0x80 // Size: 0x08
	struct FString GVoiceGameKey; // Offset: 0x88 // Size: 0x10
	struct FString APPID_FACEBOOK; // Offset: 0x98 // Size: 0x10
	struct FString APPID_APPLE; // Offset: 0xa8 // Size: 0x10
	struct FString APPID_GOOGLE; // Offset: 0xb8 // Size: 0x10
	struct FString APPID_TWITTER; // Offset: 0xc8 // Size: 0x10
	struct FString APPID_WECHAT; // Offset: 0xd8 // Size: 0x10
	struct FString APPID_VK; // Offset: 0xe8 // Size: 0x10
	struct FString APPID_LINE; // Offset: 0xf8 // Size: 0x10
	struct FString APPID_QQ; // Offset: 0x108 // Size: 0x10
	struct FString GUID_GAMEMASTER; // Offset: 0x118 // Size: 0x10
	struct FString GEMCtrlURL; // Offset: 0x128 // Size: 0x10
	struct FString TGPACtrlURL; // Offset: 0x138 // Size: 0x10
	int SubsideFeatureLevel; // Offset: 0x148 // Size: 0x04
	char pad_0x14C[0x4]; // Offset: 0x14c // Size: 0x04
};

// Object Name: Class Client.AsyncLoadHelper
// Size: 0xe0 // Inherited bytes: 0x28
struct UAsyncLoadHelper : UObject {
	// Fields
	struct TMap<struct FString, struct UObject*> PreloadObjectMap; // Offset: 0x28 // Size: 0x50
	char pad_0x78[0x68]; // Offset: 0x78 // Size: 0x68

	// Functions

	// Object Name: Function Client.AsyncLoadHelper.SetMaxTaskNum
	// Flags: [Final|Native|Public]
	void SetMaxTaskNum(int Num); // Offset: 0x10392c6f0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.AsyncLoadHelper.RunNextTask
	// Flags: [Final|Native|Public]
	void RunNextTask(); // Offset: 0x10392c6dc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.AsyncLoadHelper.OnLoadCallBack
	// Flags: [Final|Native|Public|HasDefaults]
	void OnLoadCallBack(struct FSoftObjectPath softObjPath); // Offset: 0x10392c610 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function Client.AsyncLoadHelper.ClearOneTask
	// Flags: [Final|Native|Public]
	void ClearOneTask(struct FString ObjectPath); // Offset: 0x10392c554 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.AsyncLoadHelper.ClearAllTask
	// Flags: [Final|Native|Public]
	void ClearAllTask(); // Offset: 0x10392c540 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.AsyncLoadHelper.AddTask
	// Flags: [Final|Native|Public]
	void AddTask(struct FString ObjectPath, int LoadPriority); // Offset: 0x10392c444 // Return & Params: Num(2) Size(0x14)
};

// Object Name: Class Client.AsyncLoadWidgetBlueprint
// Size: 0x80 // Inherited bytes: 0x28
struct UAsyncLoadWidgetBlueprint : UBlueprintAsyncActionBase {
	// Fields
	struct FScriptMulticastDelegate BeforeLoad; // Offset: 0x28 // Size: 0x10
	struct FScriptMulticastDelegate AfterLoad; // Offset: 0x38 // Size: 0x10
	struct FScriptMulticastDelegate OnCancelled; // Offset: 0x48 // Size: 0x10
	char pad_0x58[0x28]; // Offset: 0x58 // Size: 0x28

	// Functions

	// Object Name: Function Client.AsyncLoadWidgetBlueprint.Cancel
	// Flags: [Native|Public|BlueprintCallable]
	void Cancel(); // Offset: 0x10392cc14 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.AsyncLoadWidgetBlueprint.AsyncLoadWidgetBlueprint
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAsyncLoadWidgetBlueprint* AsyncLoadWidgetBlueprint(struct FString BlueprintPath, int Priority); // Offset: 0x10392cb18 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Client.AsyncLoadWidgetBlueprint.AfterLoadCallback
	// Flags: [Final|Native|Private|HasOutParms|HasDefaults]
	void AfterLoadCallback(struct FSoftObjectPath& SoftObjectPath); // Offset: 0x10392ca58 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function Client.AsyncLoadWidgetBlueprint.Activate
	// Flags: [Native|Public|BlueprintCallable]
	void Activate(); // Offset: 0x10392ca3c // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Client.AsyncTaskCDNDownloader
// Size: 0x98 // Inherited bytes: 0x28
struct UAsyncTaskCDNDownloader : UBlueprintAsyncActionBase {
	// Fields
	char pad_0x28[0x30]; // Offset: 0x28 // Size: 0x30
	struct FScriptMulticastDelegate onRequestHandler; // Offset: 0x58 // Size: 0x10
	char pad_0x68[0x30]; // Offset: 0x68 // Size: 0x30

	// Functions

	// Object Name: Function Client.AsyncTaskCDNDownloader.DownloadCDNContent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAsyncTaskCDNDownloader* DownloadCDNContent(struct FString URL, int loaderType, struct FString savedDir, bool breakpointContinualTransfer); // Offset: 0x10392d060 // Return & Params: Num(5) Size(0x38)
};

// Object Name: Class Client.AsyncTaskDownloader
// Size: 0x98 // Inherited bytes: 0x28
struct UAsyncTaskDownloader : UBlueprintAsyncActionBase {
	// Fields
	char pad_0x28[0x30]; // Offset: 0x28 // Size: 0x30
	struct FScriptMulticastDelegate onRequestHandler; // Offset: 0x58 // Size: 0x10
	char pad_0x68[0x30]; // Offset: 0x68 // Size: 0x30

	// Functions

	// Object Name: Function Client.AsyncTaskDownloader.DownloadContent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAsyncTaskDownloader* DownloadContent(struct FString URL, int loaderType, struct FString savedDir, bool breakpointContinualTransfer); // Offset: 0x10392d5a0 // Return & Params: Num(5) Size(0x38)
};

// Object Name: Class Client.BattleScriptHelper
// Size: 0x28 // Inherited bytes: 0x28
struct UBattleScriptHelper : UObject {
	// Functions

	// Object Name: Function Client.BattleScriptHelper.SyncNewBattlePlayer
	// Flags: [Final|Native|Static|Public|HasOutParms]
	uint32_t SyncNewBattlePlayer(struct UBattleUtils* Utils, uint64 UId, struct FPlayerInfoData& Info); // Offset: 0x10392ddbc // Return & Params: Num(4) Size(0xd4)

	// Object Name: Function Client.BattleScriptHelper.SyncGameInfo
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void SyncGameInfo(struct UBattleUtils* Utils, struct FBattleGameInfo& Info); // Offset: 0x10392dcd4 // Return & Params: Num(2) Size(0x40)

	// Object Name: Function Client.BattleScriptHelper.SyncGameExit
	// Flags: [Final|Native|Static|Public]
	void SyncGameExit(struct UBattleUtils* Utils); // Offset: 0x10392dc60 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.BattleScriptHelper.SyncBattlePlayerExit
	// Flags: [Final|Native|Static|Public]
	void SyncBattlePlayerExit(struct UBattleUtils* Utils, uint64 UId, struct FName PlayerType, struct FString Reason); // Offset: 0x10392dae8 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function Client.BattleScriptHelper.ResponPlayerWeaponDIYData
	// Flags: [Final|Native|Static|Public]
	void ResponPlayerWeaponDIYData(struct UBattleUtils* Utils, uint64 PlayerUID, struct FWeaponDIYData InWeaponDIYData); // Offset: 0x10392d9ac // Return & Params: Num(3) Size(0x60)

	// Object Name: Function Client.BattleScriptHelper.GenerateAIPlayerParams
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void GenerateAIPlayerParams(struct UBattleUtils* Utils, struct FPlayerInfoData& Info); // Offset: 0x10392d8cc // Return & Params: Num(2) Size(0xc8)
};

// Object Name: Class Client.BattlePlayer
// Size: 0x160 // Inherited bytes: 0x28
struct UBattlePlayer : UObject {
	// Fields
	uint64 UId; // Offset: 0x28 // Size: 0x08
	struct FPlayerInfoData PlayerInfoData; // Offset: 0x30 // Size: 0xc0
	struct FPlayerAvatarData PlayerAvatarData; // Offset: 0xf0 // Size: 0x18
	struct TMap<int, struct FWeaponDIYData> WeaponDIYData; // Offset: 0x108 // Size: 0x50
	struct UBattleUtils* OwningBattleUtils; // Offset: 0x158 // Size: 0x08

	// Functions

	// Object Name: Function Client.BattlePlayer.ExtractGameModePlayerParams
	// Flags: [Final|Native|Public|Const]
	struct FGameModePlayerParams ExtractGameModePlayerParams(); // Offset: 0x10392e244 // Return & Params: Num(1) Size(0x398)
};

// Object Name: Class Client.BattleAIPlayer
// Size: 0x160 // Inherited bytes: 0x160
struct UBattleAIPlayer : UBattlePlayer {
	// Functions

	// Object Name: Function Client.BattleAIPlayer.ExtractGameModeAIPlayerParams
	// Flags: [Final|Native|Public|Const]
	struct FGameModeAIPlayerParams ExtractGameModeAIPlayerParams(); // Offset: 0x10392e3f8 // Return & Params: Num(1) Size(0x3a8)
};

// Object Name: Class Client.BattleUtils
// Size: 0x4f8 // Inherited bytes: 0x28
struct UBattleUtils : UObject {
	// Fields
	char pad_0x28[0x60]; // Offset: 0x28 // Size: 0x60
	struct UGameFrontendHUD* OwningFrontendHUD; // Offset: 0x88 // Size: 0x08
	char pad_0x90[0x10]; // Offset: 0x90 // Size: 0x10
	struct AUAEGameMode* BattleGameMode; // Offset: 0xa0 // Size: 0x08
	struct TArray<struct UBattlePlayer*> BattlePlayerList; // Offset: 0xa8 // Size: 0x10
	struct FBattleGameInfo CachedBattleGameInfo; // Offset: 0xb8 // Size: 0x38
	struct FGameModeAIPlayerParams CachedAIPlayerParams; // Offset: 0xf0 // Size: 0x3a8
	struct FString LuaFilePath; // Offset: 0x498 // Size: 0x10
	char pad_0x4A8[0x50]; // Offset: 0x4a8 // Size: 0x50

	// Functions

	// Object Name: Function Client.BattleUtils.SyncNewBattlePlayer
	// Flags: [Final|Native|Public|HasOutParms]
	uint32_t SyncNewBattlePlayer(uint64 UId, struct FPlayerInfoData& Info); // Offset: 0x10392f2ac // Return & Params: Num(3) Size(0xcc)

	// Object Name: Function Client.BattleUtils.SyncGameInfo
	// Flags: [Final|Native|Public|HasOutParms]
	void SyncGameInfo(struct FBattleGameInfo& Info); // Offset: 0x10392f1f8 // Return & Params: Num(1) Size(0x38)

	// Object Name: Function Client.BattleUtils.SyncGameExit
	// Flags: [Final|Native|Public]
	void SyncGameExit(); // Offset: 0x10392f1e4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.BattleUtils.SyncBattlePlayerExit
	// Flags: [Final|Native|Public]
	void SyncBattlePlayerExit(uint64 UId, struct FName PlayerType, struct FString Reason); // Offset: 0x10392f0a4 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Client.BattleUtils.RetrievePlayerParams
	// Flags: [Final|Native|Public|Const]
	struct FGameModePlayerParams RetrievePlayerParams(struct FPlayerID PlayerID); // Offset: 0x10392efe4 // Return & Params: Num(2) Size(0x3a8)

	// Object Name: Function Client.BattleUtils.RetrieveAIPlayerParams
	// Flags: [Final|Native|Public]
	struct FGameModeAIPlayerParams RetrieveAIPlayerParams(struct FPlayerID PlayerID); // Offset: 0x10392ef24 // Return & Params: Num(2) Size(0x3b8)

	// Object Name: Function Client.BattleUtils.ResponPlayerWeaponDIYData
	// Flags: [Final|Native|Public]
	void ResponPlayerWeaponDIYData(uint64 PlayerUID, struct FWeaponDIYData InWeaponDIYData); // Offset: 0x10392ee14 // Return & Params: Num(2) Size(0x58)

	// Object Name: Function Client.BattleUtils.RequestSomePlayersBattleData
	// Flags: [Final|Native|Public]
	void RequestSomePlayersBattleData(struct TArray<uint64> PlayerUIDList, char DataType); // Offset: 0x10392ecf0 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.BattleUtils.RequestPlayerWeaponDIYData
	// Flags: [Final|Native|Public]
	void RequestPlayerWeaponDIYData(uint64 PlayerUID, int WeaponSkinID, int PlanID); // Offset: 0x10392ec00 // Return & Params: Num(3) Size(0x10)

	// Object Name: Function Client.BattleUtils.RequestOnePlayersBattleData
	// Flags: [Final|Native|Public]
	void RequestOnePlayersBattleData(uint64 PlayerUID, char DataType); // Offset: 0x10392eb48 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.BattleUtils.RequestAllPlayersBattleData
	// Flags: [Final|Native|Public]
	void RequestAllPlayersBattleData(char DataType); // Offset: 0x10392eacc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.BattleUtils.OnPostLoadMapWithWorld
	// Flags: [Final|Native|Public]
	void OnPostLoadMapWithWorld(struct UWorld* World); // Offset: 0x10392ea50 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.BattleUtils.NewBattlePlayer
	// Flags: [Final|Native|Public]
	struct UBattlePlayer* NewBattlePlayer(); // Offset: 0x10392ea1c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.BattleUtils.NewBattleAIPlayer
	// Flags: [Final|Native|Public]
	struct UBattleAIPlayer* NewBattleAIPlayer(); // Offset: 0x10392e9e8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.BattleUtils.HandleGameModeStateChanged
	// Flags: [Final|Native|Public|HasOutParms]
	void HandleGameModeStateChanged(struct FGameModeStateChangedParams& Params); // Offset: 0x10392e92c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.BattleUtils.GetBattleGameMode
	// Flags: [Final|Native|Public|Const]
	struct AUAEGameMode* GetBattleGameMode(); // Offset: 0x10392e8f8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.BattleUtils.GenerateAIPlayerParams
	// Flags: [Final|Native|Public|HasOutParms]
	void GenerateAIPlayerParams(struct FPlayerInfoData& Info); // Offset: 0x10392e84c // Return & Params: Num(1) Size(0xc0)

	// Object Name: Function Client.BattleUtils.FindPlayerByUID
	// Flags: [Final|Native|Public|Const]
	struct UBattlePlayer* FindPlayerByUID(uint64 UId, struct FName PlayerType); // Offset: 0x10392e788 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Client.BattleUtils.FindPlayerByPlayerName
	// Flags: [Final|Native|Public|Const]
	struct UBattlePlayer* FindPlayerByPlayerName(struct FString PlayerName, struct FName PlayerType); // Offset: 0x10392e67c // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Client.BattleUtils.FindPlayerByPlayerKey
	// Flags: [Final|Native|Public|Const]
	struct UBattlePlayer* FindPlayerByPlayerKey(uint32_t PlayerKey, struct FName PlayerType); // Offset: 0x10392e5b4 // Return & Params: Num(3) Size(0x18)
};

// Object Name: Class Client.BattleWindowMgr
// Size: 0x28 // Inherited bytes: 0x28
struct UBattleWindowMgr : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function Client.BattleWindowMgr.ShowUI
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ShowUI(struct UObject* WorldContextObject, struct FString WindowName, struct UObject* ObjectParam); // Offset: 0x10392fc50 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Client.BattleWindowMgr.SetInstance
	// Flags: [Final|Native|Static|Public]
	void SetInstance(struct UBattleWindowMgrLuaUtils* InInstance, struct ULuaStateWrapper* InLuaStateWrapper); // Offset: 0x10392fba4 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Client.BattleWindowMgr.HideUI
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void HideUI(struct UObject* WorldContextObject, struct FString WindowName); // Offset: 0x10392fab0 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.BattleWindowMgr.CheckWindowOpen
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool CheckWindowOpen(struct UObject* WorldContextObject, struct FString WindowName); // Offset: 0x10392f9b4 // Return & Params: Num(3) Size(0x19)
};

// Object Name: Class Client.BattleWindowMgrLuaUtils
// Size: 0x70 // Inherited bytes: 0x28
struct UBattleWindowMgrLuaUtils : UObject {
	// Fields
	struct TWeakObjectPtr<struct ULuaStateWrapper> LuaStateWrapper; // Offset: 0x28 // Size: 0x08
	struct FString LuaManagerName; // Offset: 0x30 // Size: 0x10
	struct FString ShowUI; // Offset: 0x40 // Size: 0x10
	struct FString HideUI; // Offset: 0x50 // Size: 0x10
	struct FString CheckWindowOpen; // Offset: 0x60 // Size: 0x10
};

// Object Name: Class Client.BugReporter
// Size: 0xa0 // Inherited bytes: 0x28
struct UBugReporter : UObject {
	// Fields
	char pad_0x28[0x78]; // Offset: 0x28 // Size: 0x78

	// Functions

	// Object Name: Function Client.BugReporter.SendScreenShot
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SendScreenShot(struct FString errorReason, struct FString errorDescription, struct FString ImagePath, float X, float Y, float Z); // Offset: 0x103930498 // Return & Params: Num(6) Size(0x3c)

	// Object Name: Function Client.BugReporter.SendLog
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SendLog(struct FString errorReason, struct FString errorDescription, float X, float Y, float Z, bool pullAll, bool zipLogUpload); // Offset: 0x103930210 // Return & Params: Num(7) Size(0x2e)

	// Object Name: Function Client.BugReporter.ReadZipLog
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ReadZipLog(struct FString Filename); // Offset: 0x103930154 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.BugReporter.CompressLog
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct TArray<char> CompressLog(bool pullAllLog); // Offset: 0x103930098 // Return & Params: Num(2) Size(0x18)
};

// Object Name: Class Client.BuildConfig
// Size: 0x58 // Inherited bytes: 0x28
struct UBuildConfig : UObject {
	// Fields
	struct FString branch_name; // Offset: 0x28 // Size: 0x10
	struct FString build_no; // Offset: 0x38 // Size: 0x10
	struct FString build_url; // Offset: 0x48 // Size: 0x10
};

// Object Name: Class Client.BusinessHelper
// Size: 0x28 // Inherited bytes: 0x28
struct UBusinessHelper : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function Client.BusinessHelper.UIGetResWithPath
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UObject* UIGetResWithPath(struct FString DesManagerName); // Offset: 0x10393210c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.BusinessHelper.UIGetLuaManagerByName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct ALuaClassObj* UIGetLuaManagerByName(struct UUAEUserWidget* pUIClass, struct FString InManagerName); // Offset: 0x103932010 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Client.BusinessHelper.UIGetLuaManager
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct ALuaClassObj* UIGetLuaManager(struct UUAEUserWidget* pUIClass); // Offset: 0x103931f94 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Client.BusinessHelper.StopUIStat
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void StopUIStat(struct FString UIName, bool bReport); // Offset: 0x103931e98 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.BusinessHelper.StopTimeWatch
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	float StopTimeWatch(); // Offset: 0x103931e64 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.BusinessHelper.StartUIStat
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void StartUIStat(struct FString UIName); // Offset: 0x103931db0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.BusinessHelper.StartTimeWatch
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void StartTimeWatch(); // Offset: 0x103931d9c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.BusinessHelper.SetUIStatMaxClickTimes
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetUIStatMaxClickTimes(int Times); // Offset: 0x103931d28 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.BusinessHelper.ReportUIStat
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ReportUIStat(struct FString UIName, bool bGStatTime, bool bReport, float TotalTime); // Offset: 0x103931b9c // Return & Params: Num(4) Size(0x18)

	// Object Name: Function Client.BusinessHelper.RemoveKnownMissingPackageRefObjectByObj
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void RemoveKnownMissingPackageRefObjectByObj(struct UObject* RefedObject); // Offset: 0x103931b28 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.BusinessHelper.LoadAssetFromPath
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UObject* LoadAssetFromPath(struct FString DesManagerName); // Offset: 0x103931a90 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.BusinessHelper.IsSplitMiniPakVersion
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsSplitMiniPakVersion(); // Offset: 0x103931a5c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.BusinessHelper.IsSplitMapPakVersion
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsSplitMapPakVersion(); // Offset: 0x103931a28 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.BusinessHelper.IsFit
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsFit(); // Offset: 0x1039319f4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.BusinessHelper.IsClassOf
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsClassOf(struct UObject* Object, struct UObject* Class); // Offset: 0x103931940 // Return & Params: Num(3) Size(0x11)

	// Object Name: Function Client.BusinessHelper.IsChildOf
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsChildOf(struct UObject* ChildClass, struct UObject* Class); // Offset: 0x10393188c // Return & Params: Num(3) Size(0x11)

	// Object Name: Function Client.BusinessHelper.IsCEVersion
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsCEVersion(); // Offset: 0x103931858 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.BusinessHelper.IsAppFromStore
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsAppFromStore(); // Offset: 0x103931824 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.BusinessHelper.HasDownloadedBasePak
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool HasDownloadedBasePak(); // Offset: 0x1039317f0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.BusinessHelper.GetWidgetByName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UUAEUserWidget* GetWidgetByName(struct UUAEUserWidget* pUIClass, struct FString InManagerName, struct FString InWidgtName); // Offset: 0x1039316c8 // Return & Params: Num(4) Size(0x30)

	// Object Name: Function Client.BusinessHelper.GetTSSGameId
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetTSSGameId(); // Offset: 0x103931694 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.BusinessHelper.GetTime
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	float GetTime(); // Offset: 0x103931660 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.BusinessHelper.GetSplitMapConfigInfo
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetSplitMapConfigInfo(); // Offset: 0x1039315fc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.BusinessHelper.GetPublishRegionID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetPublishRegionID(); // Offset: 0x1039315c8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.BusinessHelper.GetPublishRegion
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetPublishRegion(); // Offset: 0x103931564 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.BusinessHelper.GetPackChannel
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetPackChannel(); // Offset: 0x103931500 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.BusinessHelper.GetOpenId
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetOpenId(); // Offset: 0x10393149c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.BusinessHelper.GetMobileBasePath
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetMobileBasePath(struct FString InPath); // Offset: 0x1039313dc // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.BusinessHelper.GetLuaManagerByName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct ALuaClassObj* GetLuaManagerByName(struct UUAEUserWidget* pUIClass, struct FString InManagerName); // Offset: 0x1039312e0 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Client.BusinessHelper.GetITopGameId
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetITopGameId(); // Offset: 0x10393127c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.BusinessHelper.GetInGameLocalConnectURL
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetInGameLocalConnectURL(); // Offset: 0x103931218 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.BusinessHelper.GetIMSDKEnv
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetIMSDKEnv(); // Offset: 0x1039311e4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.BusinessHelper.GetGVoiceGameId
	// Flags: [Final|Native|Static|Public]
	uint64 GetGVoiceGameId(); // Offset: 0x1039311b0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.BusinessHelper.GetDeviceQualityLevel
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetDeviceQualityLevel(); // Offset: 0x10393117c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.BusinessHelper.GetDeviceOrientation
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetDeviceOrientation(); // Offset: 0x103931148 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.BusinessHelper.GetDataTable
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UUAEDataTable* GetDataTable(struct FString tableName); // Offset: 0x1039310b0 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.BusinessHelper.GetCurrentNetworkState
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetCurrentNetworkState(); // Offset: 0x10393107c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.BusinessHelper.GetChildByName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UWidget* GetChildByName(struct UUserWidget* pParent, struct FString Name); // Offset: 0x103930fa8 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Client.BusinessHelper.GetBuildURL
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetBuildURL(); // Offset: 0x103930f44 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.BusinessHelper.GetBuildNo
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetBuildNo(); // Offset: 0x103930ee0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.BusinessHelper.GetBranchName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetBranchName(); // Offset: 0x103930e7c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.BusinessHelper.GetBase64Key
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetBase64Key(); // Offset: 0x103930e18 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.BusinessHelper.GetAppVersion
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetAppVersion(); // Offset: 0x103930db4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.BusinessHelper.GetAOSSHOPID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetAOSSHOPID(); // Offset: 0x103930d80 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.BusinessHelper.GetAOSSHOP
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetAOSSHOP(); // Offset: 0x103930d1c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.BusinessHelper.ClearDisplayLookupTable
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ClearDisplayLookupTable(); // Offset: 0x103930d08 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.BusinessHelper.BroadCastMSG
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void BroadCastMSG(struct UFrontendHUD* FrontendHUD, struct FString DesManagerName, struct FString Msg); // Offset: 0x103930be8 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Client.BusinessHelper.AddKnownMissingPackage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void AddKnownMissingPackage(struct FString PackageName, struct UObject* BindObj, bool bReplace); // Offset: 0x103930aac // Return & Params: Num(3) Size(0x19)
};

// Object Name: Class Client.IntlHelper
// Size: 0x28 // Inherited bytes: 0x28
struct UIntlHelper : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function Client.IntlHelper.UpdateXGPushNightTag
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void UpdateXGPushNightTag(bool bInit); // Offset: 0x103934d70 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.IntlHelper.UpdateXGPushDayTag
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void UpdateXGPushDayTag(bool bInit); // Offset: 0x103934cf4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.IntlHelper.UpdateVoiceUrl
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void UpdateVoiceUrl(struct FString regionVoiceUrl); // Offset: 0x103934c40 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.IntlHelper.UnInitTweenMaker
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void UnInitTweenMaker(); // Offset: 0x103934c2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.IntlHelper.TimeFormatString
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString TimeFormatString(struct FString Format, int hours, int Mins, int secs); // Offset: 0x103934ab0 // Return & Params: Num(5) Size(0x30)

	// Object Name: Function Client.IntlHelper.SaveXGTags
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SaveXGTags(struct FString Language, struct FString timezone, struct FString Region); // Offset: 0x10393490c // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.IntlHelper.OnSwitchLanguage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void OnSwitchLanguage(); // Offset: 0x1039348f8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.IntlHelper.OnChoosingZone
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void OnChoosingZone(int ZoneID, struct FString AddrIP, struct FString regionVoiceUrl); // Offset: 0x10393478c // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Client.IntlHelper.IsRemoteNotificationsEnabled
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsRemoteNotificationsEnabled(); // Offset: 0x103934758 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.IntlHelper.IsHelpshiftEnable4CurrentChannel
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsHelpshiftEnable4CurrentChannel(); // Offset: 0x103934724 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.IntlHelper.IsHelpshiftEnable
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsHelpshiftEnable(); // Offset: 0x1039346f0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.IntlHelper.InitTweenMaker
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void InitTweenMaker(); // Offset: 0x1039346dc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.IntlHelper.HelpshiftUploadLog
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void HelpshiftUploadLog(); // Offset: 0x1039346c8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.IntlHelper.HelpshiftShowSingleFAQWithInfo
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void HelpshiftShowSingleFAQWithInfo(struct FString publishID, struct FString PlayerName, struct FString PlayerLevel, struct FString PlayerGold, int PlayerRecharge, int PlayerRegisterTime, struct FString ExtraTags); // Offset: 0x10393446c // Return & Params: Num(7) Size(0x58)

	// Object Name: Function Client.IntlHelper.HelpshiftShowFAQsWithInfo
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void HelpshiftShowFAQsWithInfo(struct FString PlayerName, struct FString PlayerLevel, struct FString PlayerGold, int PlayerRecharge, int PlayerRegisterTime, struct FString ExtraTags); // Offset: 0x103934264 // Return & Params: Num(6) Size(0x48)

	// Object Name: Function Client.IntlHelper.HelpshiftShowFAQs
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void HelpshiftShowFAQs(); // Offset: 0x103934250 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.IntlHelper.HelpshiftShowConversionWithInfo
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void HelpshiftShowConversionWithInfo(struct FString Name, struct FString Level, struct FString Gold); // Offset: 0x1039340ac // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.IntlHelper.HelpshiftShowConversion
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void HelpshiftShowConversion(); // Offset: 0x103934098 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.IntlHelper.HelpshiftRequestUnreadMessagesCount
	// Flags: [Final|Native|Static|Public]
	void HelpshiftRequestUnreadMessagesCount(); // Offset: 0x103934084 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.IntlHelper.HelpshiftGetUnreadMessgesCount
	// Flags: [Final|Native|Static|Public]
	int HelpshiftGetUnreadMessgesCount(); // Offset: 0x103934050 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.IntlHelper.HelpshiftClearUnreadMessgesCount
	// Flags: [Final|Native|Static|Public]
	void HelpshiftClearUnreadMessgesCount(); // Offset: 0x10393403c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.IntlHelper.GetSavedXGTimezoneTag
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetSavedXGTimezoneTag(); // Offset: 0x103933fd8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.IntlHelper.GetSavedXGRegionTag
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetSavedXGRegionTag(); // Offset: 0x103933f74 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.IntlHelper.GetSavedXGPushNightTag
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetSavedXGPushNightTag(); // Offset: 0x103933f10 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.IntlHelper.GetSavedXGPushDayTag
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetSavedXGPushDayTag(); // Offset: 0x103933eac // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.IntlHelper.GetSavedXGLanguageTag
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetSavedXGLanguageTag(); // Offset: 0x103933e48 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.IntlHelper.GetPlayerUCLevel
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetPlayerUCLevel(); // Offset: 0x103933de4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.IntlHelper.GetLocalTimezone
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetLocalTimezone(); // Offset: 0x103933db0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.IntlHelper.GetLocalizeStringWithString
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetLocalizeStringWithString(struct FString sourceString, int numStringIndex, struct FString string1, struct FString string2, struct FString string3, struct FString string4); // Offset: 0x103933b60 // Return & Params: Num(7) Size(0x68)

	// Object Name: Function Client.IntlHelper.GetLocalizeStringWithNum
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetLocalizeStringWithNum(int ID, int numStringIndex, struct FString string1, struct FString string2, struct FString string3, struct FString string4); // Offset: 0x103933930 // Return & Params: Num(7) Size(0x58)

	// Object Name: Function Client.IntlHelper.GetLocalizeStrByStr
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetLocalizeStrByStr(struct FString Source, struct FString string1, struct FString string2, struct FString string3, struct FString string4); // Offset: 0x103933720 // Return & Params: Num(6) Size(0x60)

	// Object Name: Function Client.IntlHelper.GetLocalizeStrByID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetLocalizeStrByID(int ID, struct FString string1, struct FString string2, struct FString string3, struct FString string4); // Offset: 0x103933528 // Return & Params: Num(6) Size(0x58)

	// Object Name: Function Client.IntlHelper.GetLocalizationStringWithID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetLocalizationStringWithID(int ID); // Offset: 0x103933484 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.IntlHelper.GetLocalizationString
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetLocalizationString(struct FString Key); // Offset: 0x1039333c4 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.IntlHelper.GetLocalizationBattleStringWithID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetLocalizationBattleStringWithID(int ID); // Offset: 0x103933320 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.IntlHelper.GetHistoryErrorCode
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetHistoryErrorCode(); // Offset: 0x1039332bc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.IntlHelper.GetGameMasterVID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetGameMasterVID(); // Offset: 0x103933258 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.IntlHelper.GetCurrentZoneID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetCurrentZoneID(); // Offset: 0x103933224 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.IntlHelper.FormatLocalizeStrByStr
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FString FormatLocalizeStrByStr(struct FString Source, struct TArray<struct FString>& stringArr); // Offset: 0x103933100 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.IntlHelper.DownloadTranslation
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void DownloadTranslation(struct FString PatchName); // Offset: 0x10393304c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.IntlHelper.DownloadServerList
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void DownloadServerList(); // Offset: 0x103933038 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.IntlHelper.DirectToNotificationSetup
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void DirectToNotificationSetup(); // Offset: 0x103933024 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.IntlHelper.ClearAdjustDeepLink
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ClearAdjustDeepLink(); // Offset: 0x103933010 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.IntlHelper.AdjustParaAnalysis
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void AdjustParaAnalysis(); // Offset: 0x103932ffc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.IntlHelper.AddErrorCodeToHistory
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void AddErrorCodeToHistory(struct FString InErrorCode); // Offset: 0x103932f48 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class Client.TestHUD
// Size: 0x3d8 // Inherited bytes: 0x3d8
struct ATestHUD : AActor {
	// Functions

	// Object Name: Function Client.TestHUD.TestFunctionNOParam
	// Flags: [Final|Native|Public|BlueprintCallable]
	void TestFunctionNOParam(); // Offset: 0x103935cd8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.TestHUD.TestFunctionBP_LUA
	// Flags: [Event|Public|BlueprintEvent]
	float TestFunctionBP_LUA(); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.TestHUD.TestFunctionBP
	// Flags: [Event|Public|BlueprintEvent]
	float TestFunctionBP(); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.TestHUD.Function_Lua
	// Flags: [Final|Native|Public|BlueprintCallable]
	float Function_Lua(); // Offset: 0x103935ca4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.TestHUD.Function_CPlus_Call
	// Flags: [Final|Native|Public|BlueprintCallable]
	float Function_CPlus_Call(); // Offset: 0x103935c70 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.TestHUD.Function_CPlus
	// Flags: [Final|Native|Public|BlueprintCallable]
	float Function_CPlus(); // Offset: 0x103935c3c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.TestHUD.Function_BP_CPP
	// Flags: [Event|Public|BlueprintEvent]
	float Function_BP_CPP(); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.TestHUD.Function_BP_Call_LUA
	// Flags: [Final|Native|Public|BlueprintCallable]
	float Function_BP_Call_LUA(); // Offset: 0x103935c08 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.TestHUD.Function_BP_Call_CPP
	// Flags: [Event|Public|BlueprintEvent]
	float Function_BP_Call_CPP(); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.TestHUD.Function_BP_Call_CPlus
	// Flags: [Final|Native|Public|BlueprintCallable]
	float Function_BP_Call_CPlus(); // Offset: 0x103935bd4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.TestHUD.Function_BP_Call
	// Flags: [Final|Native|Public|BlueprintCallable]
	float Function_BP_Call(); // Offset: 0x103935ba0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.TestHUD.Function_BP
	// Flags: [Final|Native|Public|BlueprintCallable]
	float Function_BP(); // Offset: 0x103935b6c // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class Client.CDNUpdate
// Size: 0x368 // Inherited bytes: 0x28
struct UCDNUpdate : UObject {
	// Fields
	char pad_0x28[0x90]; // Offset: 0x28 // Size: 0x90
	struct UGameFrontendHUD* GameFrontendHUD; // Offset: 0xb8 // Size: 0x08
	char pad_0xC0[0x2a8]; // Offset: 0xc0 // Size: 0x2a8

	// Functions

	// Object Name: Function Client.CDNUpdate.StartUpdateApp
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StartUpdateApp(); // Offset: 0x103938a6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.CDNUpdate.StartAppUpdate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StartAppUpdate(bool StartGrayUpdate); // Offset: 0x1039389e8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.CDNUpdate.OnRequestProgress
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void OnRequestProgress(struct FCDNDownloaderInfo& Info); // Offset: 0x103938934 // Return & Params: Num(1) Size(0x30)

	// Object Name: Function Client.CDNUpdate.OnRequestComplete
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void OnRequestComplete(struct FCDNDownloaderInfo& Info); // Offset: 0x103938880 // Return & Params: Num(1) Size(0x30)

	// Object Name: Function Client.CDNUpdate.IsUpdating
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsUpdating(); // Offset: 0x10393884c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.CDNUpdate.IsGrayUpdate
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsGrayUpdate(); // Offset: 0x103938818 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.CDNUpdate.GetCurStage
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	int GetCurStage(float& percent, int& GetCurVal, int& GetMaxVal); // Offset: 0x1039386dc // Return & Params: Num(4) Size(0x10)

	// Object Name: Function Client.CDNUpdate.FinishUpdate
	// Flags: [Final|Native|Public]
	void FinishUpdate(); // Offset: 0x1039386c8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.CDNUpdate.ContinueUpdate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ContinueUpdate(); // Offset: 0x1039386b4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.CDNUpdate.CancelUpdate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CancelUpdate(); // Offset: 0x1039386a0 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Client.ClientNetInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UClientNetInterface : UNetInterface {
};

// Object Name: Class Client.CompressTextureHelper
// Size: 0x28 // Inherited bytes: 0x28
struct UCompressTextureHelper : UObject {
	// Functions

	// Object Name: Function Client.CompressTextureHelper.TestGetTexture2DFromDisk_KTX2
	// Flags: [Final|Native|Static|Public]
	struct UTexture2D* TestGetTexture2DFromDisk_KTX2(struct FString PathName); // Offset: 0x103939d44 // Return & Params: Num(2) Size(0x18)
};

// Object Name: Class Client.DragDropTextBox
// Size: 0xca0 // Inherited bytes: 0xca0
struct UDragDropTextBox : UEditableTextBox {
};

// Object Name: Class Client.GameBackendUtils
// Size: 0x30 // Inherited bytes: 0x30
struct UGameBackendUtils : UBackendUtils {
	// Functions

	// Object Name: Function Client.GameBackendUtils.GetTableManager
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UUAETableManager* GetTableManager(); // Offset: 0x10393a108 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class Client.GameBackendHUD
// Size: 0xb0 // Inherited bytes: 0xb0
struct UGameBackendHUD : UBackendHUD {
	// Functions

	// Object Name: Function Client.GameBackendHUD.GetUtils
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UGameBackendUtils* GetUtils(); // Offset: 0x10393a3e4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameBackendHUD.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UGameBackendHUD* GetInstance(); // Offset: 0x10393a3b0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameBackendHUD.GetGameFrontendHUDByGameInstance
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UGameFrontendHUD* GetGameFrontendHUDByGameInstance(struct UGameInstance* GameInstance); // Offset: 0x10393a324 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Client.GameBackendHUD.GetFirstGameFrontendHUD
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UGameFrontendHUD* GetFirstGameFrontendHUD(struct UObject* WorldContextObject); // Offset: 0x10393a298 // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class Client.GameBusinessManager
// Size: 0x170 // Inherited bytes: 0xf8
struct UGameBusinessManager : ULogicManagerBase {
	// Fields
	struct TArray<struct FGameWidgetConfig> WidgetConfigList; // Offset: 0xf8 // Size: 0x10
	char pad_0x108[0x50]; // Offset: 0x108 // Size: 0x50
	struct AUAEPlayerController* OwningController; // Offset: 0x158 // Size: 0x08
	char pad_0x160[0x8]; // Offset: 0x160 // Size: 0x08
	struct ALuaClassObj* LuaObject; // Offset: 0x168 // Size: 0x08

	// Functions

	// Object Name: Function Client.GameBusinessManager.GetWidget
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UUAEUserWidget* GetWidget(int Index); // Offset: 0x10393a768 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Client.GameBusinessManager.GetLuaObject
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct ALuaClassObj* GetLuaObject(); // Offset: 0x10393a734 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameBusinessManager.GetGameFrontendHUD
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UGameFrontendHUD* GetGameFrontendHUD(); // Offset: 0x10393a700 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class Client.GameFrontendHUD
// Size: 0x7f8 // Inherited bytes: 0x1d0
struct UGameFrontendHUD : UFrontendHUD {
	// Fields
	struct FScriptMulticastDelegate OnHandleWebviewActionDelegate; // Offset: 0x1d0 // Size: 0x10
	struct FScriptMulticastDelegate OnGetTicketNotifyDelegate; // Offset: 0x1e0 // Size: 0x10
	struct FScriptMulticastDelegate OnHandleServerListDownload; // Offset: 0x1f0 // Size: 0x10
	struct FScriptMulticastDelegate OnUIStatReport; // Offset: 0x200 // Size: 0x10
	struct FScriptMulticastDelegate OnReportClientTool; // Offset: 0x210 // Size: 0x10
	struct FString CSVTableRelativeDir; // Offset: 0x220 // Size: 0x10
	struct TMap<struct FName, struct FString> GameStatusMap; // Offset: 0x230 // Size: 0x50
	bool EnableTickLog; // Offset: 0x280 // Size: 0x01
	char pad_0x281[0x1]; // Offset: 0x281 // Size: 0x01
	bool bEnableReportMemory; // Offset: 0x282 // Size: 0x01
	char pad_0x283[0x1d]; // Offset: 0x283 // Size: 0x1d
	struct UGVoiceInterface* GVoice; // Offset: 0x2a0 // Size: 0x08
	bool IsNewGVoiceCreated; // Offset: 0x2a8 // Size: 0x01
	bool DisableGVoice; // Offset: 0x2a9 // Size: 0x01
	char pad_0x2AA[0x6]; // Offset: 0x2aa // Size: 0x06
	struct UBugReporter* GameBugReporter; // Offset: 0x2b0 // Size: 0x08
	struct UGMLogShare* LogShare; // Offset: 0x2b8 // Size: 0x08
	int MaxUpdateRetryTimes; // Offset: 0x2c0 // Size: 0x04
	char pad_0x2C4[0xc]; // Offset: 0x2c4 // Size: 0x0c
	struct UGDolphinUpdater* GDolphin; // Offset: 0x2d0 // Size: 0x08
	struct UTranslator* Translator; // Offset: 0x2d8 // Size: 0x08
	struct UHttpWrapper* HttpWrapper; // Offset: 0x2e0 // Size: 0x08
	struct UGCPufferDownloader* GPuffer; // Offset: 0x2e8 // Size: 0x08
	struct ULaggingReporter* LaggingReporter; // Offset: 0x2f0 // Size: 0x08
	char pad_0x2F8[0x8]; // Offset: 0x2f8 // Size: 0x08
	struct UAsyncTaskDownloader* DownloadTask; // Offset: 0x300 // Size: 0x08
	char pad_0x308[0x44]; // Offset: 0x308 // Size: 0x44
	bool bUseDolphinUpdateFirst; // Offset: 0x34c // Size: 0x01
	bool bEnableUseDolphinUpdate; // Offset: 0x34d // Size: 0x01
	bool bEnableUseCDNUpdate; // Offset: 0x34e // Size: 0x01
	bool bUseDolphinUpdateAfterCDNFailed; // Offset: 0x34f // Size: 0x01
	bool bUseCDNUpdateAfterDolphinFailed; // Offset: 0x350 // Size: 0x01
	bool bEnableEditorPufferDownload; // Offset: 0x351 // Size: 0x01
	bool bIsWaitingUpdateStateData; // Offset: 0x352 // Size: 0x01
	bool IsUsingDolphinUpdate; // Offset: 0x353 // Size: 0x01
	bool IsUsingCDNUpdate; // Offset: 0x354 // Size: 0x01
	char pad_0x355[0x13]; // Offset: 0x355 // Size: 0x13
	struct UCDNUpdate* CDNUpdater; // Offset: 0x368 // Size: 0x08
	int ODPaksPoolSize; // Offset: 0x370 // Size: 0x04
	int ODPaksPoolSizeLowend; // Offset: 0x374 // Size: 0x04
	int ODPaksPoolSizeLowendThreshold; // Offset: 0x378 // Size: 0x04
	bool ODPaksEnable; // Offset: 0x37c // Size: 0x01
	char pad_0x37D[0x33]; // Offset: 0x37d // Size: 0x33
	struct FName UnrealNetworkStatus; // Offset: 0x3b0 // Size: 0x08
	char pad_0x3B8[0x18]; // Offset: 0x3b8 // Size: 0x18
	float UnrealNetworkConnectingTimer; // Offset: 0x3d0 // Size: 0x04
	char pad_0x3D4[0x1c]; // Offset: 0x3d4 // Size: 0x1c
	float UnrealNetworkConnectingTime; // Offset: 0x3f0 // Size: 0x04
	bool bUseDynamicCreateLuaManager; // Offset: 0x3f4 // Size: 0x01
	char pad_0x3F5[0x3]; // Offset: 0x3f5 // Size: 0x03
	struct TArray<struct FString> PersistentLuaManager; // Offset: 0x3f8 // Size: 0x10
	char pad_0x408[0x4]; // Offset: 0x408 // Size: 0x04
	bool bPatchReInitSequence; // Offset: 0x40c // Size: 0x01
	char pad_0x40D[0x3]; // Offset: 0x40d // Size: 0x03
	struct ULuaStateWrapper* LuaStateWrapper; // Offset: 0x410 // Size: 0x08
	struct ULuaEventBridge* LuaEventBridgeInstace; // Offset: 0x418 // Size: 0x08
	struct UBattleWindowMgrLuaUtils* LuaBattleWindowMgr; // Offset: 0x420 // Size: 0x08
	struct ULuaBlueprintMgr* LuaBlueprintSysMgr; // Offset: 0x428 // Size: 0x08
	char pad_0x430[0x8]; // Offset: 0x430 // Size: 0x08
	struct FString ScriptBPRelativeDir; // Offset: 0x438 // Size: 0x10
	struct FString ScriptRelativeDir; // Offset: 0x448 // Size: 0x10
	struct FString InGameLuaDir; // Offset: 0x458 // Size: 0x10
	struct FString PreloadLuaFileRelativePath; // Offset: 0x468 // Size: 0x10
	struct TArray<struct FString> LuaDirList; // Offset: 0x478 // Size: 0x10
	struct TArray<struct FString> NoGCPackage; // Offset: 0x488 // Size: 0x10
	float LuaTickTime; // Offset: 0x498 // Size: 0x04
	bool bCallLuaTick; // Offset: 0x49c // Size: 0x01
	bool bAutoLoginEnable; // Offset: 0x49d // Size: 0x01
	char pad_0x49E[0x1a]; // Offset: 0x49e // Size: 0x1a
	int PingFirstReportIntervalSecond; // Offset: 0x4b8 // Size: 0x04
	int PingReportIntervalSecond; // Offset: 0x4bc // Size: 0x04
	int LossSyncIntervalSecond; // Offset: 0x4c0 // Size: 0x04
	int vmInstrumentOptimization; // Offset: 0x4c4 // Size: 0x04
	struct UTssManager* TssMgr; // Offset: 0x4c8 // Size: 0x08
	char pad_0x4D0[0x1c]; // Offset: 0x4d0 // Size: 0x1c
	float PingReportInterval; // Offset: 0x4ec // Size: 0x04
	char pad_0x4F0[0xd4]; // Offset: 0x4f0 // Size: 0xd4
	uint32_t ImageDownloadClearDayCount; // Offset: 0x5c4 // Size: 0x04
	struct FScriptMulticastDelegate UIStackChangeDelegate; // Offset: 0x5c8 // Size: 0x10
	struct FScriptMulticastDelegate UIStackRecoverDelegate; // Offset: 0x5d8 // Size: 0x10
	struct FScriptMulticastDelegate OnFRefreshAdaptationUIEvent; // Offset: 0x5e8 // Size: 0x10
	struct FScriptMulticastDelegate OnFRefreshAdaptationExUIEvent; // Offset: 0x5f8 // Size: 0x10
	char pad_0x608[0x78]; // Offset: 0x608 // Size: 0x78
	struct UImageDownloader* ImageDownloaderInGame; // Offset: 0x680 // Size: 0x08
	int FpsForWindowClient; // Offset: 0x688 // Size: 0x04
	char pad_0x68C[0x4]; // Offset: 0x68c // Size: 0x04
	struct UUDPPingCollector* UDPPingCollector; // Offset: 0x690 // Size: 0x08
	bool UIElemLayoutJsonConfigSwitch; // Offset: 0x698 // Size: 0x01
	bool NationAllSwitch; // Offset: 0x699 // Size: 0x01
	bool NationBattleSwitch; // Offset: 0x69a // Size: 0x01
	bool NationRankSwitch; // Offset: 0x69b // Size: 0x01
	bool SelfieSwitch; // Offset: 0x69c // Size: 0x01
	bool ReportBugSwitch; // Offset: 0x69d // Size: 0x01
	bool FirstVoicePopupSwitch; // Offset: 0x69e // Size: 0x01
	bool GDPRForbidVoiceSwitch; // Offset: 0x69f // Size: 0x01
	bool GDPRSettingSwitch; // Offset: 0x6a0 // Size: 0x01
	char pad_0x6A1[0x3]; // Offset: 0x6a1 // Size: 0x03
	int GDPRUserType; // Offset: 0x6a4 // Size: 0x04
	bool bShouldShowAdaptTipInLobby; // Offset: 0x6a8 // Size: 0x01
	char pad_0x6A9[0x3]; // Offset: 0x6a9 // Size: 0x03
	float fLaggingFPSDiffThreshold; // Offset: 0x6ac // Size: 0x04
	float fLaggingFPSDiffThresholdMin; // Offset: 0x6b0 // Size: 0x04
	float fLaggingFPSDiffThresholdMax; // Offset: 0x6b4 // Size: 0x04
	float fLaggingFrameTimeThreshold; // Offset: 0x6b8 // Size: 0x04
	float fLaggingFrameTimeThresholdMin; // Offset: 0x6bc // Size: 0x04
	float fLaggingFrameTimeThresholdMax; // Offset: 0x6c0 // Size: 0x04
	float fFPSReportInterval; // Offset: 0x6c4 // Size: 0x04
	char pad_0x6C8[0x10]; // Offset: 0x6c8 // Size: 0x10
	bool bUnLoadNoGcPackage; // Offset: 0x6d8 // Size: 0x01
	char pad_0x6D9[0x7]; // Offset: 0x6d9 // Size: 0x07
	struct TArray<struct UPackage*> NoGcPackages; // Offset: 0x6e0 // Size: 0x10
	bool bFlushAsyncLoadingBeforeGC; // Offset: 0x6f0 // Size: 0x01
	bool bEnablePandora; // Offset: 0x6f1 // Size: 0x01
	char pad_0x6F2[0x1]; // Offset: 0x6f2 // Size: 0x01
	bool bEnableJMLog; // Offset: 0x6f3 // Size: 0x01
	char pad_0x6F4[0xb4]; // Offset: 0x6f4 // Size: 0xb4
	bool bEnableH5Cache; // Offset: 0x7a8 // Size: 0x01
	bool bCheckWorldNameForLoadConfig; // Offset: 0x7a9 // Size: 0x01
	char pad_0x7AA[0x6]; // Offset: 0x7aa // Size: 0x06
	struct UColorBlindnessMgr* ColorBlindnessMgrInstace; // Offset: 0x7b0 // Size: 0x08
	struct TArray<struct FNativeHUDTickContainer> NativeHUDTickList; // Offset: 0x7b8 // Size: 0x10
	bool IsNativeHUDTickLock; // Offset: 0x7c8 // Size: 0x01
	bool IsShutDown; // Offset: 0x7c9 // Size: 0x01
	char pad_0x7CA[0x2]; // Offset: 0x7ca // Size: 0x02
	int NativeHUDTickIndex; // Offset: 0x7cc // Size: 0x04
	struct UAsyncLoadHelper* AsyncLoadHelper; // Offset: 0x7d0 // Size: 0x08
	struct FString BattleUtilsClassName; // Offset: 0x7d8 // Size: 0x10
	struct UBattleUtils* BattleUtils; // Offset: 0x7e8 // Size: 0x08
	char pad_0x7F0[0x8]; // Offset: 0x7f0 // Size: 0x08

	// Functions

	// Object Name: Function Client.GameFrontendHUD.VNGPostPersonalInfo
	// Flags: [Final|Native|Public|BlueprintCallable]
	void VNGPostPersonalInfo(struct FString OpenID, struct FString Name, struct FString passportId, struct FString email, struct FString phone, struct FString address); // Offset: 0x10393d0ec // Return & Params: Num(6) Size(0x60)

	// Object Name: Function Client.GameFrontendHUD.UnRegisterUIShowHideEventDelegate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UnRegisterUIShowHideEventDelegate(struct FString Source); // Offset: 0x10393d030 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GameFrontendHUD.TimeStatisticStop
	// Flags: [Final|Native|Public|BlueprintCallable]
	void TimeStatisticStop(int Type, struct FString Name); // Offset: 0x10393cf34 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.GameFrontendHUD.TimeStatisticStart
	// Flags: [Final|Native|Public|BlueprintCallable]
	void TimeStatisticStart(int Type); // Offset: 0x10393ceb8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GameFrontendHUD.TickUdpCollector
	// Flags: [Final|Native|Public]
	void TickUdpCollector(float DeltaTime); // Offset: 0x10393ce3c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GameFrontendHUD.StatisVisibilityWidget
	// Flags: [Final|Native|Public]
	void StatisVisibilityWidget(struct UWidget* Widget); // Offset: 0x10393cdc0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.StatisLoadedTexture
	// Flags: [Final|Native|Public]
	void StatisLoadedTexture(struct UTexture* Texture); // Offset: 0x10393cd44 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.StartGrayUpdate
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool StartGrayUpdate(); // Offset: 0x10393cd10 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GameFrontendHUD.StartDolphinUpdateAfterCDNUpdateFailed
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StartDolphinUpdateAfterCDNUpdateFailed(); // Offset: 0x10393ccfc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GameFrontendHUD.StartCDNUpdateAfterDolphinUpdateFailed
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StartCDNUpdateAfterDolphinUpdateFailed(); // Offset: 0x10393cce8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GameFrontendHUD.ShutdownUnrealNetwork
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ShutdownUnrealNetwork(); // Offset: 0x10393cccc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GameFrontendHUD.SetShouldShowAdaptTipInLobby
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetShouldShowAdaptTipInLobby(bool bShoudShow); // Offset: 0x10393cc48 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GameFrontendHUD.SetGameSubMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetGameSubMode(struct FString SubMode); // Offset: 0x10393cbb0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GameFrontendHUD.SetGameStatusMap
	// Flags: [Final|Native|Public]
	void SetGameStatusMap(struct TMap<struct FName, struct FString> InGameStatusMap); // Offset: 0x10393caf0 // Return & Params: Num(1) Size(0x50)

	// Object Name: Function Client.GameFrontendHUD.SetClientEnterBattleStage
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetClientEnterBattleStage(struct FString InStageStr); // Offset: 0x10393ca58 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GameFrontendHUD.SetAccountByWebLogin
	// Flags: [Final|Native|Public]
	void SetAccountByWebLogin(int Channel, struct FString OpenID, struct FString userId, struct FString TokenID, int ExpireTime); // Offset: 0x10393c89c // Return & Params: Num(5) Size(0x3c)

	// Object Name: Function Client.GameFrontendHUD.RetryDownload
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RetryDownload(); // Offset: 0x10393c888 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GameFrontendHUD.RetryCDNDownload
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RetryCDNDownload(); // Offset: 0x10393c874 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GameFrontendHUD.ReleaseBattleUtils
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ReleaseBattleUtils(); // Offset: 0x10393c860 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GameFrontendHUD.RegisterUserSettingsDelegate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RegisterUserSettingsDelegate(DelegateProperty Delegate); // Offset: 0x10393c7d0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GameFrontendHUD.RegisterUIShowHideEventDelegate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RegisterUIShowHideEventDelegate(struct FString Source, DelegateProperty Delegate); // Offset: 0x10393c6c0 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.GameFrontendHUD.OnWebviewNotify
	// Flags: [Final|RequiredAPI|Native|Public|HasOutParms]
	void OnWebviewNotify(struct FWebviewInfoWrapper& webviewinfo); // Offset: 0x10393c614 // Return & Params: Num(1) Size(0x30)

	// Object Name: Function Client.GameFrontendHUD.OnWebviewActionNotify
	// Flags: [Final|RequiredAPI|Native|Public]
	void OnWebviewActionNotify(struct FString URL); // Offset: 0x10393c558 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GameFrontendHUD.OnUAAssistantEvent
	// Flags: [Final|RequiredAPI|Native|Public|HasOutParms]
	void OnUAAssistantEvent(struct FUAAssistantInfoWrapper& UAAssistentInfo); // Offset: 0x10393c4a8 // Return & Params: Num(1) Size(0x28)

	// Object Name: Function Client.GameFrontendHUD.OnSDKCallbackEvent
	// Flags: [Final|RequiredAPI|Native|Public|HasOutParms]
	void OnSDKCallbackEvent(struct FSDKCallbackInfoWrapper& sdkCallbackInfo); // Offset: 0x10393c3f8 // Return & Params: Num(1) Size(0x28)

	// Object Name: Function Client.GameFrontendHUD.OnRequestComplete
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void OnRequestComplete(struct FCDNDownloaderInfo& Info); // Offset: 0x10393c344 // Return & Params: Num(1) Size(0x30)

	// Object Name: Function Client.GameFrontendHUD.OnRefreshAccountInfo
	// Flags: [Final|RequiredAPI|Native|Public]
	void OnRefreshAccountInfo(bool Result, int InChannel, struct FString InOpenId); // Offset: 0x10393c1fc // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Client.GameFrontendHUD.OnQuickLoginNotify
	// Flags: [Final|RequiredAPI|Native|Public|HasOutParms]
	void OnQuickLoginNotify(struct FWakeupInfoWrapper& wakeupinfo); // Offset: 0x10393c150 // Return & Params: Num(1) Size(0x50)

	// Object Name: Function Client.GameFrontendHUD.OnPlatformFriendNotify
	// Flags: [Final|RequiredAPI|Native|Public|HasOutParms]
	void OnPlatformFriendNotify(struct FPlatformFriendInfoMap& PlatformFriendInfoMap); // Offset: 0x10393c094 // Return & Params: Num(1) Size(0x58)

	// Object Name: Function Client.GameFrontendHUD.OnNotUpdateFinished
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OnNotUpdateFinished(); // Offset: 0x10393c080 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GameFrontendHUD.OnLoginFlowNotify
	// Flags: [Final|RequiredAPI|Native|Public]
	void OnLoginFlowNotify(int _Flow, int _Param, struct FString ExtraData); // Offset: 0x10393bf3c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Client.GameFrontendHUD.OnHttpImgResponse
	// Flags: [Final|Native|Protected]
	void OnHttpImgResponse(struct UTexture2D* Texture, struct UImageDownloader* downloader); // Offset: 0x10393be88 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Client.GameFrontendHUD.OnGroupNotify
	// Flags: [Final|RequiredAPI|Native|Public|HasOutParms]
	void OnGroupNotify(struct FGroupInfoWrapper& groupInfo); // Offset: 0x10393bdd8 // Return & Params: Num(1) Size(0x50)

	// Object Name: Function Client.GameFrontendHUD.OnGetTicketNotify
	// Flags: [Final|RequiredAPI|Native|Public]
	void OnGetTicketNotify(struct FString Ticket); // Offset: 0x10393bd1c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GameFrontendHUD.OnGetShortUrlNotify
	// Flags: [Final|RequiredAPI|Native|Public]
	void OnGetShortUrlNotify(int Ret, struct FString ShortUrl); // Offset: 0x10393bc20 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.GameFrontendHUD.OnGetCountryNoNotify
	// Flags: [Final|RequiredAPI|Native|Public]
	void OnGetCountryNoNotify(int country); // Offset: 0x10393bba4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GameFrontendHUD.OnGenQRImgNotify
	// Flags: [Final|RequiredAPI|Native|Public]
	void OnGenQRImgNotify(int Ret, int Size, struct FString imgPath); // Offset: 0x10393ba94 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Client.GameFrontendHUD.OnGCloudNetStateChangeNotify
	// Flags: [Final|RequiredAPI|Native|Public]
	void OnGCloudNetStateChangeNotify(int State, int EventParam1, int EventParam2, int EventParam3); // Offset: 0x10393b96c // Return & Params: Num(4) Size(0x10)

	// Object Name: Function Client.GameFrontendHUD.OnGameMasterEvent
	// Flags: [Final|RequiredAPI|Native|Public]
	void OnGameMasterEvent(struct FString EventName, int Ret); // Offset: 0x10393b870 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.GameFrontendHUD.OnCheckUpdateStateFinished
	// Flags: [Final|Native|Private|HasOutParms]
	void OnCheckUpdateStateFinished(struct FDownloaderInfo& Info); // Offset: 0x10393b7c4 // Return & Params: Num(1) Size(0x40)

	// Object Name: Function Client.GameFrontendHUD.OnAreaChanged
	// Flags: [Final|Native|Public]
	void OnAreaChanged(struct FString InArea); // Offset: 0x10393b72c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GameFrontendHUD.NotifyLoadingUIOperation
	// Flags: [Final|Native|Public|BlueprintCallable]
	void NotifyLoadingUIOperation(int OperationType); // Offset: 0x10393b6b0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GameFrontendHUD.MakeToSuppotAdaptation
	// Flags: [Final|Native|Public]
	void MakeToSuppotAdaptation(struct UPanelSlot* PanelSlot); // Offset: 0x10393b634 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.LuaDoString
	// Flags: [Native|Public|BlueprintCallable|Const]
	void LuaDoString(struct FString LuaString); // Offset: 0x10393b594 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GameFrontendHUD.IsWindowOB
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsWindowOB(); // Offset: 0x10393b560 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GameFrontendHUD.IsInstallPlatform
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsInstallPlatform(struct FString PlatForm); // Offset: 0x10393b494 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.GameFrontendHUD.IsCEHideLobbyUI
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsCEHideLobbyUI(); // Offset: 0x10393b460 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GameFrontendHUD.HasAnyNetMsgToHandle
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool HasAnyNetMsgToHandle(); // Offset: 0x10393b42c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GameFrontendHUD.GetWidgetRenderCanChange
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool GetWidgetRenderCanChange(); // Offset: 0x10393b3f8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GameFrontendHUD.GetUserSettings
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct USaveGame* GetUserSettings(); // Offset: 0x10393b3bc // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.GetUpdater
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UGDolphinUpdater* GetUpdater(); // Offset: 0x10393b3a0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.GetTranslator
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UTranslator* GetTranslator(); // Offset: 0x10393b384 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.GetShouldShowAdaptTipInLobby
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool GetShouldShowAdaptTipInLobby(); // Offset: 0x10393b350 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GameFrontendHUD.GetSettingSubsystem
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct USettingSubsystem* GetSettingSubsystem(); // Offset: 0x10393b31c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.GetPufferDownloader
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UGCPufferDownloader* GetPufferDownloader(); // Offset: 0x10393b300 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.GetPingReportInfo
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetPingReportInfo(); // Offset: 0x10393b29c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GameFrontendHUD.GetPacketLossReportInfo
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetPacketLossReportInfo(); // Offset: 0x10393b238 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GameFrontendHUD.GetLuaStateWrapper
	// Flags: [Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct ULuaStateWrapper* GetLuaStateWrapper(); // Offset: 0x10393b204 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.GetLuaEventBridge
	// Flags: [Final|Native|Public]
	struct ULuaEventBridge* GetLuaEventBridge(); // Offset: 0x10393b1d0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.GetLuaBlueprintSysMgr
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct ULuaBlueprintMgr* GetLuaBlueprintSysMgr(); // Offset: 0x10393b19c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.GetHttpWrapper
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UHttpWrapper* GetHttpWrapper(); // Offset: 0x10393b180 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.GetGVoiceInterface
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UGVoiceInterface* GetGVoiceInterface(); // Offset: 0x10393b144 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.GetGameSubMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetGameSubMode(); // Offset: 0x10393b10c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GameFrontendHUD.GetGameState
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct AGameStateBase* GetGameState(); // Offset: 0x10393b0d8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.GetFPSReportInfo
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetFPSReportInfo(); // Offset: 0x10393b074 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GameFrontendHUD.GetEffectSettingMgr
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UEffectSettingMgr* GetEffectSettingMgr(); // Offset: 0x10393b038 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.GetDetailNetInfoFromGCloud
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetDetailNetInfoFromGCloud(); // Offset: 0x10393b004 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GameFrontendHUD.GetColorBlindnessMgr
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UColorBlindnessMgr* GetColorBlindnessMgr(); // Offset: 0x10393afc8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.GetClientNetObj
	// Flags: [Final|Native|Public|Const]
	struct UObject* GetClientNetObj(); // Offset: 0x10393af94 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.GetClientEnterBattleStage
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetClientEnterBattleStage(); // Offset: 0x10393af5c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GameFrontendHUD.GetBugReporter
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UBugReporter* GetBugReporter(); // Offset: 0x10393af28 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.GetBattleUtils
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UBattleUtils* GetBattleUtils(); // Offset: 0x10393aef4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.GetBattleIDHexStr
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetBattleIDHexStr(); // Offset: 0x10393ae90 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GameFrontendHUD.GetAutoRunModID
	// Flags: [Final|Native|Public]
	int GetAutoRunModID(); // Offset: 0x10393ae5c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GameFrontendHUD.GetAsyncLoadHelper
	// Flags: [Final|Native|Public]
	struct UAsyncLoadHelper* GetAsyncLoadHelper(); // Offset: 0x10393ae28 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.FinishModifyUserSettings
	// Flags: [Final|Native|Public|BlueprintCallable]
	void FinishModifyUserSettings(); // Offset: 0x10393ae14 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GameFrontendHUD.EnableFPSAndMemoryLog
	// Flags: [Final|Native|Public|BlueprintCallable]
	void EnableFPSAndMemoryLog(bool bEnable); // Offset: 0x10393ad90 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GameFrontendHUD.DispatchLongTimeNoOperation
	// Flags: [Final|Native|Public|HasOutParms]
	void DispatchLongTimeNoOperation(int& TimeOutCounter); // Offset: 0x10393ad04 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GameFrontendHUD.DispatchConfirmMisKill
	// Flags: [Final|Native|Public]
	void DispatchConfirmMisKill(struct FString KillerName); // Offset: 0x10393ac7c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GameFrontendHUD.CreateBattleUtils
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CreateBattleUtils(); // Offset: 0x10393ac68 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GameFrontendHUD.CallGlobalScriptFunction
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CallGlobalScriptFunction(struct FString InFunctionName); // Offset: 0x10393abc8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GameFrontendHUD.BeginModifyUserSettings
	// Flags: [Final|Native|Public|BlueprintCallable]
	void BeginModifyUserSettings(); // Offset: 0x10393abb4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GameFrontendHUD.BattleUtilsGameEnd
	// Flags: [Final|Native|Public|BlueprintCallable]
	void BattleUtilsGameEnd(); // Offset: 0x10393aba0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GameFrontendHUD.AfterLoadedEditorLogin
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AfterLoadedEditorLogin(); // Offset: 0x10393ab8c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GameFrontendHUD.AddAdaptationWidgetDelegateEx
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddAdaptationWidgetDelegateEx(struct UPanelSlot* PanelSlot); // Offset: 0x10393ab10 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameFrontendHUD.AddAdaptationWidgetDelegate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddAdaptationWidgetDelegate(struct UPanelSlot* PanelSlot); // Offset: 0x10393aa94 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class Client.GameFrontendUtils
// Size: 0x398 // Inherited bytes: 0x398
struct UGameFrontendUtils : UFrontendUtils {
};

// Object Name: Class Client.GameJoyInterface
// Size: 0x48 // Inherited bytes: 0x28
struct UGameJoyInterface : UObject {
	// Fields
	struct UGameFrontendHUD* GameFrontendHUD; // Offset: 0x28 // Size: 0x08
	char pad_0x30[0x18]; // Offset: 0x30 // Size: 0x18

	// Functions

	// Object Name: Function Client.GameJoyInterface.ShareVideo
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ShareVideo(int Channel); // Offset: 0x103943570 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GameJoyInterface.SetGameFrontendHUD
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetGameFrontendHUD(struct UGameFrontendHUD* InHUD); // Offset: 0x1039434f4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameJoyInterface.OnVideoShare
	// Flags: [Final|Native|Private]
	void OnVideoShare(struct FString Msg); // Offset: 0x103943438 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GameJoyInterface.OnShowVideoPlayer
	// Flags: [Final|Native|Private]
	void OnShowVideoPlayer(int IsShow); // Offset: 0x1039433bc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GameJoyInterface.OnRecordingStart
	// Flags: [Final|Native|Private]
	void OnRecordingStart(int Status); // Offset: 0x103943340 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GameJoyInterface.OnRecordingEnd
	// Flags: [Final|Native|Private]
	void OnRecordingEnd(int64_t Duration); // Offset: 0x1039432c4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GameJoyInterface.OnManualRecordingStart
	// Flags: [Final|Native|Private]
	void OnManualRecordingStart(int Status); // Offset: 0x103943248 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GameJoyInterface.OnCheckSDKPermission
	// Flags: [Final|Native|Private]
	void OnCheckSDKPermission(bool IsSuccess); // Offset: 0x1039431c4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GameJoyInterface.OnCheckSDKFeature
	// Flags: [Final|Native|Private]
	void OnCheckSDKFeature(int sdkFeatureInt); // Offset: 0x103943148 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GameJoyInterface.IsSDKFeatureSupport
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsSDKFeatureSupport(); // Offset: 0x103943114 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GameJoyInterface.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UGameJoyInterface* GetInstance(); // Offset: 0x1039430e0 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class Client.GDolphinUpdater
// Size: 0x318 // Inherited bytes: 0x28
struct UGDolphinUpdater : UObject {
	// Fields
	char pad_0x28[0x50]; // Offset: 0x28 // Size: 0x50
	struct TMap<struct FString, struct FString> pakHashList; // Offset: 0x78 // Size: 0x50
	char pad_0xC8[0xc8]; // Offset: 0xc8 // Size: 0xc8
	bool AllowIOSBGDownload; // Offset: 0x190 // Size: 0x01
	bool AllowIOSBGDownloadPush; // Offset: 0x191 // Size: 0x01
	bool DisableJPKRBGDownloadNightPush; // Offset: 0x192 // Size: 0x01
	char pad_0x193[0x1]; // Offset: 0x193 // Size: 0x01
	int DisableJPKRBGDownloadNightPushAfterHour; // Offset: 0x194 // Size: 0x04
	int DisableJPKRBGDownloadNightPushBeforeHour; // Offset: 0x198 // Size: 0x04
	int IOSBGDownloadPushDelaySeconds; // Offset: 0x19c // Size: 0x04
	bool EnableRandomBackupURL; // Offset: 0x1a0 // Size: 0x01
	bool EnablePufferUpdate; // Offset: 0x1a1 // Size: 0x01
	char pad_0x1A2[0x16]; // Offset: 0x1a2 // Size: 0x16
	struct FString UpdateInfoPath; // Offset: 0x1b8 // Size: 0x10
	bool OpenDebugLog; // Offset: 0x1c8 // Size: 0x01
	char pad_0x1C9[0x14f]; // Offset: 0x1c9 // Size: 0x14f

	// Functions

	// Object Name: Function Client.GDolphinUpdater.StartAppUpdate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StartAppUpdate(); // Offset: 0x103944050 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GDolphinUpdater.SetEnableCDNGetVersion
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetEnableCDNGetVersion(bool Enable); // Offset: 0x103943fcc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GDolphinUpdater.OnUpdateError
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OnUpdateError(int curVersionStage, int ErrorCode); // Offset: 0x103943f18 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.GDolphinUpdater.OnDolphinBGDownloadDone
	// Flags: [Final|Native|Public]
	void OnDolphinBGDownloadDone(); // Offset: 0x103943f04 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GDolphinUpdater.OnAreaChanged
	// Flags: [Final|Native|Private]
	void OnAreaChanged(struct FString InArea); // Offset: 0x103943e6c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GDolphinUpdater.IsUpdating
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsUpdating(); // Offset: 0x103943e38 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GDolphinUpdater.IsInstallInApp
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsInstallInApp(); // Offset: 0x103943e04 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GDolphinUpdater.IsGrayUpdate
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsGrayUpdate(); // Offset: 0x103943dd0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GDolphinUpdater.IsExamine
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsExamine(); // Offset: 0x103943d9c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GDolphinUpdater.Install
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Install(); // Offset: 0x103943d88 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GDolphinUpdater.GetTotalValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetTotalValue(); // Offset: 0x103943d54 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GDolphinUpdater.GetCurValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetCurValue(); // Offset: 0x103943d20 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GDolphinUpdater.GetCurStage
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	int GetCurStage(float& percent, int& GetCurVal, int& GetMaxVal); // Offset: 0x103943be4 // Return & Params: Num(4) Size(0x10)

	// Object Name: Function Client.GDolphinUpdater.GetCurPercent
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetCurPercent(); // Offset: 0x103943bb0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GDolphinUpdater.GetChannelIDWithHUD
	// Flags: [Final|Native|Private]
	uint32_t GetChannelIDWithHUD(struct UGameFrontendHUD* InGameFrontendHUD); // Offset: 0x103943b24 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.GDolphinUpdater.GetChannelID
	// Flags: [Final|Native|Private]
	uint32_t GetChannelID(); // Offset: 0x103943af0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GDolphinUpdater.FinishUpdate
	// Flags: [Final|Native|Public]
	void FinishUpdate(); // Offset: 0x103943adc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GDolphinUpdater.FinishPufferUpdate
	// Flags: [Final|Native|Public]
	void FinishPufferUpdate(); // Offset: 0x103943ac8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GDolphinUpdater.EnableIOSBGDownload4G
	// Flags: [Final|Native|Public|BlueprintCallable]
	void EnableIOSBGDownload4G(bool bEnableCellularAccess); // Offset: 0x103943a44 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GDolphinUpdater.EnableCDNGetVersion
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool EnableCDNGetVersion(); // Offset: 0x103943a10 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GDolphinUpdater.ContinueUpdate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ContinueUpdate(); // Offset: 0x1039439fc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GDolphinUpdater.CancelUpdate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CancelUpdate(); // Offset: 0x1039439e8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GDolphinUpdater.CancelAppUpdate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CancelAppUpdate(); // Offset: 0x1039439d4 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Client.IMSDKNotice
// Size: 0xa8 // Inherited bytes: 0x28
struct UIMSDKNotice : UObject {
	// Fields
	char pad_0x28[0x80]; // Offset: 0x28 // Size: 0x80

	// Functions

	// Object Name: Function Client.IMSDKNotice.GetNotice
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct TArray<struct FIMSDKNoticeInfo> GetNotice(struct FString Scene); // Offset: 0x103944fd0 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.IMSDKNotice.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UIMSDKNotice* GetInstance(); // Offset: 0x103944f9c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.IMSDKNotice.ClearNotice
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearNotice(); // Offset: 0x103944f88 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Client.AvatarItemDownloadPuffer
// Size: 0x30 // Inherited bytes: 0x30
struct UAvatarItemDownloadPuffer : UAvatarItemDownload {
	// Functions

	// Object Name: Function Client.AvatarItemDownloadPuffer.StartDownloadItem
	// Flags: [Native|Public]
	void StartDownloadItem(uint32_t ItemID, uint32_t Priority, DelegateProperty OnItemDownloadDelegate); // Offset: 0x1039457d4 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Client.AvatarItemDownloadPuffer.StartBatchDownloadItem
	// Flags: [Native|Public]
	void StartBatchDownloadItem(struct TArray<uint32_t> ItemIDs, uint32_t Priority, DelegateProperty OnBatchItemDownloadDelegate); // Offset: 0x103945654 // Return & Params: Num(3) Size(0x28)
};

// Object Name: Class Client.GCPufferDownloader
// Size: 0x440 // Inherited bytes: 0x28
struct UGCPufferDownloader : UObject {
	// Fields
	char pad_0x28[0x2c8]; // Offset: 0x28 // Size: 0x2c8
	bool Disable; // Offset: 0x2f0 // Size: 0x01
	char pad_0x2F1[0x97]; // Offset: 0x2f1 // Size: 0x97
	struct FString DownloadDir; // Offset: 0x388 // Size: 0x10
	struct FString PufferTmpDir; // Offset: 0x398 // Size: 0x10
	uint32_t CleanFlagVer; // Offset: 0x3a8 // Size: 0x04
	char pad_0x3AC[0x4]; // Offset: 0x3ac // Size: 0x04
	struct TArray<struct FString> CleanFileNamePattern; // Offset: 0x3b0 // Size: 0x10
	bool PreFetchPakEnable; // Offset: 0x3c0 // Size: 0x01
	bool PreFetchFileClearEnable; // Offset: 0x3c1 // Size: 0x01
	bool PreFetchConvertEnable; // Offset: 0x3c2 // Size: 0x01
	char pad_0x3C3[0x5]; // Offset: 0x3c3 // Size: 0x05
	struct TArray<struct FString> PreFetchPakNames; // Offset: 0x3c8 // Size: 0x10
	uint32_t PreFetchReserveredDiskSpace; // Offset: 0x3d8 // Size: 0x04
	bool PreFetchODPak_Enable; // Offset: 0x3dc // Size: 0x01
	char pad_0x3DD[0x3]; // Offset: 0x3dd // Size: 0x03
	int PreFetchODPaks_MaxNum; // Offset: 0x3e0 // Size: 0x04
	int PreFetchODPaks_BatchSize; // Offset: 0x3e4 // Size: 0x04
	int PreFetchODPaks_FetchedNum; // Offset: 0x3e8 // Size: 0x04
	int PreFetchODPaks_FetchedIndex; // Offset: 0x3ec // Size: 0x04
	struct TArray<struct FString> PreFetchODPaks_Filenames; // Offset: 0x3f0 // Size: 0x10
	bool AllowIOSBGDownload; // Offset: 0x400 // Size: 0x01
	bool AllowIOSBGDownloadPush; // Offset: 0x401 // Size: 0x01
	bool DisableJPKRBGDownloadNightPush; // Offset: 0x402 // Size: 0x01
	char pad_0x403[0x1]; // Offset: 0x403 // Size: 0x01
	int DisableJPKRBGDownloadNightPushAfterHour; // Offset: 0x404 // Size: 0x04
	int DisableJPKRBGDownloadNightPushBeforeHour; // Offset: 0x408 // Size: 0x04
	int IOSBGDownloadPushDelaySeconds; // Offset: 0x40c // Size: 0x04
	bool DisableBGDownloadNotification; // Offset: 0x410 // Size: 0x01
	char pad_0x411[0x3]; // Offset: 0x411 // Size: 0x03
	float PreFetchODPaks_StartTime; // Offset: 0x414 // Size: 0x04
	struct FString PreFetchODPaks_ConfigName; // Offset: 0x418 // Size: 0x10
	char pad_0x428[0x18]; // Offset: 0x428 // Size: 0x18

	// Functions

	// Object Name: Function Client.GCPufferDownloader.StopTask
	// Flags: [Final|Native|Public]
	bool StopTask(uint64 TaskId); // Offset: 0x103947ea4 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.GCPufferDownloader.StopMergeBinDiffPak
	// Flags: [Final|Native|Public]
	int StopMergeBinDiffPak(int outterTaskID); // Offset: 0x103947e18 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.GCPufferDownloader.StopCheckDownloadFileFraming
	// Flags: [Final|Native|Public]
	bool StopCheckDownloadFileFraming(int outterTaskID); // Offset: 0x103947d8c // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Client.GCPufferDownloader.StopBGDownloadNotification
	// Flags: [Final|Native|Public]
	void StopBGDownloadNotification(); // Offset: 0x103947d78 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GCPufferDownloader.StopAllTask
	// Flags: [Final|Native|Public]
	bool StopAllTask(); // Offset: 0x103947d44 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GCPufferDownloader.StartDownloadItem
	// Flags: [Final|Native|Public]
	void StartDownloadItem(uint32_t ItemID, uint32_t Priority, DelegateProperty downloadDelegate); // Offset: 0x103947c40 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Client.GCPufferDownloader.StartBGDownloadNotification
	// Flags: [Final|Native|Public]
	void StartBGDownloadNotification(uint64 InDownloadedSize); // Offset: 0x103947bc4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GCPufferDownloader.StartBatchDownloadItem
	// Flags: [Final|Native|Public]
	void StartBatchDownloadItem(struct TArray<uint32_t> ItemIDs, uint32_t Priority, DelegateProperty OnBatchItemDownloadDelegate); // Offset: 0x103947a4c // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Client.GCPufferDownloader.SetTempProductIdBase
	// Flags: [Final|Native|Public]
	void SetTempProductIdBase(int ProductIdRaw); // Offset: 0x1039479d0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GCPufferDownloader.SetTempProductId
	// Flags: [Final|Native|Public]
	void SetTempProductId(struct FString ProductIdRaw); // Offset: 0x103947914 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GCPufferDownloader.SetPrefetchConfig
	// Flags: [Final|Native|Public]
	void SetPrefetchConfig(bool pakEnable, bool fileClearEnable, bool convertEnable, int reserveredDiskSpace, struct FString FileList, int InPreFetchODPaksMaxNum, int InPreFetchODPaksBatchSize); // Offset: 0x1039476c0 // Return & Params: Num(7) Size(0x20)

	// Object Name: Function Client.GCPufferDownloader.SetIOSBGDownloadAttribute
	// Flags: [Final|Native|Public]
	void SetIOSBGDownloadAttribute(bool bEnableCellularAccess, bool bEnableResumeData, int nMinFileSize, int nMaxTasks); // Offset: 0x10394757c // Return & Params: Num(4) Size(0xc)

	// Object Name: Function Client.GCPufferDownloader.SetImmDLMaxSpeed
	// Flags: [Final|Native|Public]
	bool SetImmDLMaxSpeed(uint64 MaxSpeed); // Offset: 0x1039474f0 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.GCPufferDownloader.SetBattleDownloadSwitch
	// Flags: [Final|Native|Public]
	void SetBattleDownloadSwitch(bool Enable); // Offset: 0x10394746c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GCPufferDownloader.ReturnSplitMiniPakFilelist_LuaState
	// Flags: [Final|Native|Static|Public]
	int ReturnSplitMiniPakFilelist_LuaState(); // Offset: 0x103947454 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GCPufferDownloader.ReturnLocalFiles_LuaState
	// Flags: [Final|Native|Static|Public]
	int ReturnLocalFiles_LuaState(); // Offset: 0x10394743c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GCPufferDownloader.RequestFile
	// Flags: [Final|Native|Public]
	uint64 RequestFile(struct FString FilePath, bool ForceUpdate); // Offset: 0x103947328 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Client.GCPufferDownloader.RemountPakFiles
	// Flags: [Final|Native|Public]
	bool RemountPakFiles(); // Offset: 0x1039472f4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GCPufferDownloader.ReadFile
	// Flags: [Final|Native|Public]
	struct FString ReadFile(struct FString Filename); // Offset: 0x103947200 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.GCPufferDownloader.PreFetchPakFiles
	// Flags: [Final|Native|Public]
	bool PreFetchPakFiles(); // Offset: 0x1039471cc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GCPufferDownloader.PreFetchODPakFilesUpdate
	// Flags: [Final|Native|Public]
	int PreFetchODPakFilesUpdate(); // Offset: 0x103947198 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GCPufferDownloader.PreFetchODPakFilesPreProcess
	// Flags: [Final|Native|Public]
	bool PreFetchODPakFilesPreProcess(bool Start); // Offset: 0x103947104 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function Client.GCPufferDownloader.PreFetchODPakFilesPostProcess
	// Flags: [Final|Native|Public]
	bool PreFetchODPakFilesPostProcess(int ErrorCode); // Offset: 0x103947078 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Client.GCPufferDownloader.PreFetchODPakFiles
	// Flags: [Final|Native|Public]
	bool PreFetchODPakFiles(bool Start); // Offset: 0x103946fe4 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function Client.GCPufferDownloader.OnItemDownloadedInFighting
	// Flags: [Final|Native|Public]
	void OnItemDownloadedInFighting(struct FString PackHash, struct FString ErrorCode); // Offset: 0x103946eb0 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.GCPufferDownloader.OnHashGenerateFinished
	// Flags: [Final|Native|Public]
	void OnHashGenerateFinished(int outterTaskID, struct FString hashCode); // Offset: 0x103946db4 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.GCPufferDownloader.MoveFileTo
	// Flags: [Final|Native|Public]
	int MoveFileTo(struct FString Filename, struct FString from, struct FString to); // Offset: 0x103946bf8 // Return & Params: Num(4) Size(0x34)

	// Object Name: Function Client.GCPufferDownloader.MoveFile
	// Flags: [Final|Native|Public]
	int MoveFile(struct FString from, struct FString to); // Offset: 0x103946ab4 // Return & Params: Num(3) Size(0x24)

	// Object Name: Function Client.GCPufferDownloader.MergeBinDiffPak
	// Flags: [Final|Native|Public]
	int MergeBinDiffPak(int outterTaskID, struct FString PakFilenameOld, struct FString PakFilenameDiff, struct FString PakFilenameNew, bool fast); // Offset: 0x103946870 // Return & Params: Num(6) Size(0x40)

	// Object Name: Function Client.GCPufferDownloader.IsODPaks
	// Flags: [Final|Native|Public]
	bool IsODPaks(struct FString FilePath); // Offset: 0x1039467a4 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.GCPufferDownloader.IsODFileExists
	// Flags: [Final|Native|Public]
	bool IsODFileExists(struct FString Path); // Offset: 0x1039466fc // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.GCPufferDownloader.IsInitSuccess
	// Flags: [Final|Native|Public]
	bool IsInitSuccess(); // Offset: 0x1039466c8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GCPufferDownloader.IsFileReady
	// Flags: [Final|Native|Public]
	bool IsFileReady(struct FString FilePath); // Offset: 0x1039465fc // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.GCPufferDownloader.IsFileExist
	// Flags: [Final|Native|Public]
	bool IsFileExist(struct FString Filename, struct FString extension); // Offset: 0x1039464b8 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function Client.GCPufferDownloader.InitializeODPaks
	// Flags: [Final|Native|Public]
	bool InitializeODPaks(); // Offset: 0x103946484 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GCPufferDownloader.GetTempWorkPath
	// Flags: [Final|Native|Public]
	struct FString GetTempWorkPath(); // Offset: 0x103946420 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GCPufferDownloader.GetProductIDBase
	// Flags: [Final|Native|Public|HasOutParms]
	void GetProductIDBase(struct TArray<int>& ProductIDs); // Offset: 0x103946378 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GCPufferDownloader.GetProductID
	// Flags: [Final|Native|Public|HasOutParms]
	void GetProductID(struct TArray<int>& ProductIDs); // Offset: 0x1039462d0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GCPufferDownloader.GetODPakNum
	// Flags: [Final|Native|Public]
	int GetODPakNum(); // Offset: 0x10394629c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GCPufferDownloader.GetODPakName
	// Flags: [Final|Native|Public]
	struct FString GetODPakName(struct FString Path); // Offset: 0x1039461cc // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.GCPufferDownloader.GetInitErrcode
	// Flags: [Final|Native|Public]
	uint32_t GetInitErrcode(); // Offset: 0x103946198 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GCPufferDownloader.GetFileSizeCompressed
	// Flags: [Final|Native|Public]
	uint64 GetFileSizeCompressed(struct FString FilePath); // Offset: 0x1039460cc // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.GCPufferDownloader.GetFileSize
	// Flags: [Final|Native|Public]
	float GetFileSize(struct FString Filename); // Offset: 0x103946000 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.GCPufferDownloader.GetDownloadPath
	// Flags: [Final|Native|Public]
	struct FString GetDownloadPath(); // Offset: 0x103945f9c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GCPufferDownloader.GetCurrentSpeed
	// Flags: [Final|Native|Public]
	float GetCurrentSpeed(); // Offset: 0x103945f68 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GCPufferDownloader.GetBatchODPaksDownloadList_LuaState
	// Flags: [Final|Native|Public]
	int GetBatchODPaksDownloadList_LuaState(); // Offset: 0x103945f50 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GCPufferDownloader.EnableUseOldInterface
	// Flags: [Final|Native|Public]
	void EnableUseOldInterface(bool Enable); // Offset: 0x103945ecc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GCPufferDownloader.DeleteFileEvenIfUnfinished
	// Flags: [Final|Native|Public]
	bool DeleteFileEvenIfUnfinished(struct FString FilePath); // Offset: 0x103945e00 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.GCPufferDownloader.DeleteFile
	// Flags: [Final|Native|Static|Public]
	bool DeleteFile(struct FString fullPath); // Offset: 0x103945d44 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.GCPufferDownloader.ConvertPreFetchFiles
	// Flags: [Final|Native|Public]
	bool ConvertPreFetchFiles(); // Offset: 0x103945d10 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GCPufferDownloader.ConvertItemIdToPakName
	// Flags: [Final|Native|Public]
	struct FString ConvertItemIdToPakName(uint32_t ItemID); // Offset: 0x103945c5c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.GCPufferDownloader.ClearUselessODPaks
	// Flags: [Final|Native|Public]
	bool ClearUselessODPaks(); // Offset: 0x103945c28 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GCPufferDownloader.ClearPreFetchODPaksFiles
	// Flags: [Final|Native|Public]
	bool ClearPreFetchODPaksFiles(); // Offset: 0x103945bf4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GCPufferDownloader.ClearPreFetchFiles
	// Flags: [Final|Native|Public]
	bool ClearPreFetchFiles(); // Offset: 0x103945bc0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GCPufferDownloader.CheckDownloadFileFraming
	// Flags: [Final|Native|Public]
	bool CheckDownloadFileFraming(int outterTaskID, struct FString Filename, int chunkSize); // Offset: 0x103945a74 // Return & Params: Num(4) Size(0x1d)
};

// Object Name: Class Client.GMLogShare
// Size: 0x30 // Inherited bytes: 0x28
struct UGMLogShare : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08

	// Functions

	// Object Name: Function Client.GMLogShare.ShareLogFile
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ShareLogFile(); // Offset: 0x103949010 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GMLogShare.Init
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void Init(); // Offset: 0x103948ffc // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Client.GVoiceInterface
// Size: 0x348 // Inherited bytes: 0x28
struct UGVoiceInterface : UObject {
	// Fields
	char pad_0x28[0x4]; // Offset: 0x28 // Size: 0x04
	int lbsRoomMemberID; // Offset: 0x2c // Size: 0x04
	char pad_0x30[0x18]; // Offset: 0x30 // Size: 0x18
	DelegateProperty CheckTempLbsRoomOnJoinRoom; // Offset: 0x48 // Size: 0x10
	DelegateProperty CheckTempLbsRoomOnQuitRoom; // Offset: 0x58 // Size: 0x10
	DelegateProperty OnSTTReportCallback; // Offset: 0x68 // Size: 0x10
	DelegateProperty OnRSTSCallback; // Offset: 0x78 // Size: 0x10
	DelegateProperty OnRSTSSpeechToTextCallback; // Offset: 0x88 // Size: 0x10
	char pad_0x98[0x10]; // Offset: 0x98 // Size: 0x10
	DelegateProperty OpenMicFail; // Offset: 0xa8 // Size: 0x10
	DelegateProperty OpenMicSuccess; // Offset: 0xb8 // Size: 0x10
	DelegateProperty CloseMicFail; // Offset: 0xc8 // Size: 0x10
	DelegateProperty CloseMicSuccess; // Offset: 0xd8 // Size: 0x10
	DelegateProperty OpenSpeakerFail; // Offset: 0xe8 // Size: 0x10
	DelegateProperty OpenSpeakerSuccess; // Offset: 0xf8 // Size: 0x10
	DelegateProperty CloseSpeakerFail; // Offset: 0x108 // Size: 0x10
	DelegateProperty CloseSpeakerSuccess; // Offset: 0x118 // Size: 0x10
	DelegateProperty JoinRoomFail; // Offset: 0x128 // Size: 0x10
	DelegateProperty JoinRoomNotify; // Offset: 0x138 // Size: 0x10
	DelegateProperty QuitRoomNotify; // Offset: 0x148 // Size: 0x10
	DelegateProperty JoinLbsRoomNotify; // Offset: 0x158 // Size: 0x10
	DelegateProperty RoomStatusUpdatedNotify; // Offset: 0x168 // Size: 0x10
	DelegateProperty SetAppInfoSuccess; // Offset: 0x178 // Size: 0x10
	DelegateProperty SetAppInfoFail; // Offset: 0x188 // Size: 0x10
	DelegateProperty GetReconnectInfo; // Offset: 0x198 // Size: 0x10
	DelegateProperty ImSpeakingNotify; // Offset: 0x1a8 // Size: 0x10
	DelegateProperty TestMicFail; // Offset: 0x1b8 // Size: 0x10
	DelegateProperty TestMicSuccess; // Offset: 0x1c8 // Size: 0x10
	DelegateProperty QuitRoomFail; // Offset: 0x1d8 // Size: 0x10
	DelegateProperty DownLoadFileNotify; // Offset: 0x1e8 // Size: 0x10
	DelegateProperty SpeechToTextNotify; // Offset: 0x1f8 // Size: 0x10
	DelegateProperty UploadFileNotify; // Offset: 0x208 // Size: 0x10
	DelegateProperty ApplyMessageKeyNotify; // Offset: 0x218 // Size: 0x10
	DelegateProperty MemberIsSpeakingNotify; // Offset: 0x228 // Size: 0x10
	DelegateProperty LbsMemberIsSpeakingNotify; // Offset: 0x238 // Size: 0x10
	DelegateProperty OnMuteSwitchResult; // Offset: 0x248 // Size: 0x10
	DelegateProperty ReportVoiceTimeToServer; // Offset: 0x258 // Size: 0x10
	DelegateProperty RecordSuccess; // Offset: 0x268 // Size: 0x10
	DelegateProperty RecordFail; // Offset: 0x278 // Size: 0x10
	DelegateProperty UploadSuccess; // Offset: 0x288 // Size: 0x10
	DelegateProperty UploadFail; // Offset: 0x298 // Size: 0x10
	DelegateProperty SpeechToTextSuccess; // Offset: 0x2a8 // Size: 0x10
	DelegateProperty SpeechToTextFail; // Offset: 0x2b8 // Size: 0x10
	DelegateProperty DownloadFileSuccess; // Offset: 0x2c8 // Size: 0x10
	DelegateProperty DownloadFileFail; // Offset: 0x2d8 // Size: 0x10
	DelegateProperty EnableRoomMicrophone; // Offset: 0x2e8 // Size: 0x10
	DelegateProperty ExitInfectionGameMode; // Offset: 0x2f8 // Size: 0x10
	DelegateProperty JoinInfectionGameMode; // Offset: 0x308 // Size: 0x10
	DelegateProperty RequestPrivacyInSetting; // Offset: 0x318 // Size: 0x10
	DelegateProperty OnReportPlayerCallback; // Offset: 0x328 // Size: 0x10
	DelegateProperty OnGVoiceEvent; // Offset: 0x338 // Size: 0x10

	// Functions

	// Object Name: Function Client.GVoiceInterface.UploadRecordFile
	// Flags: [Native|Public|BlueprintCallable]
	void UploadRecordFile(); // Offset: 0x10394c470 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.TestMic
	// Flags: [Native|Public|BlueprintCallable]
	void TestMic(); // Offset: 0x10394c454 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.TeamSpeakerEnable
	// Flags: [Native|Public|BlueprintCallable]
	bool TeamSpeakerEnable(); // Offset: 0x10394c418 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.TeamMicphoneEnable
	// Flags: [Native|Public|BlueprintCallable]
	bool TeamMicphoneEnable(); // Offset: 0x10394c3dc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.SwitchMode
	// Flags: [Native|Public|BlueprintCallable]
	void SwitchMode(enum class ECharacterMainType CharMode); // Offset: 0x10394c358 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.SwitchMicphoneWhenCorpsMode
	// Flags: [Native|Public|BlueprintCallable]
	void SwitchMicphoneWhenCorpsMode(); // Offset: 0x10394c33c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.SwitchCampRoom
	// Flags: [Native|Public|BlueprintCallable]
	void SwitchCampRoom(enum class ECharacterMainType campMode); // Offset: 0x10394c2b8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.StopRecord
	// Flags: [Native|Public|BlueprintCallable]
	void StopRecord(); // Offset: 0x10394c29c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.StopPlayRecordFile
	// Flags: [Native|Public|BlueprintCallable]
	void StopPlayRecordFile(); // Offset: 0x10394c280 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.StopInterphone
	// Flags: [Native|Public|BlueprintCallable]
	void StopInterphone(); // Offset: 0x10394c264 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.StopCampMode
	// Flags: [Native|Public|BlueprintCallable]
	void StopCampMode(); // Offset: 0x10394c248 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.StartRecord
	// Flags: [Native|Public|BlueprintCallable]
	void StartRecord(); // Offset: 0x10394c22c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.StartInterphone
	// Flags: [Native|Public|BlueprintCallable]
	void StartInterphone(); // Offset: 0x10394c210 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.StartCampMode
	// Flags: [Native|Public|BlueprintCallable]
	void StartCampMode(struct FString ZombieCampRoomName, struct FString ManCampRoomName, struct FString userId); // Offset: 0x10394c0c8 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.GVoiceInterface.SpeechToText
	// Flags: [Native|Public|BlueprintCallable]
	void SpeechToText(); // Offset: 0x10394c0ac // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.ShowOpenSpeakerAtFirstMsg
	// Flags: [Native|Public|BlueprintCallable]
	void ShowOpenSpeakerAtFirstMsg(); // Offset: 0x10394c090 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.ShowCorpsModeCannotUseLBSVoice
	// Flags: [Native|Public|BlueprintCallable]
	void ShowCorpsModeCannotUseLBSVoice(); // Offset: 0x10394c074 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.SetVoiceServer
	// Flags: [Native|Public]
	void SetVoiceServer(struct FString ServerInfo); // Offset: 0x10394bfd4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GVoiceInterface.SetVoiceMode
	// Flags: [Native|Public|BlueprintCallable]
	void SetVoiceMode(int Type); // Offset: 0x10394bf50 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceInterface.SetSpeakerVolum
	// Flags: [Native|Public|BlueprintCallable]
	void SetSpeakerVolum(float Value); // Offset: 0x10394becc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceInterface.SetSpeakerStatus
	// Flags: [Native|Public|BlueprintCallable]
	void SetSpeakerStatus(bool Flag); // Offset: 0x10394be40 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.SetReportBufferTime
	// Flags: [Native|Public|BlueprintCallable]
	void SetReportBufferTime(int nTimeSec); // Offset: 0x10394bdbc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceInterface.SetPlayerVolume
	// Flags: [Native|Public|BlueprintCallable]
	void SetPlayerVolume(struct FString InPlayerid, int InVol); // Offset: 0x10394bcb8 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.GVoiceInterface.SetMicphoneVolum
	// Flags: [Native|Public|BlueprintCallable]
	void SetMicphoneVolum(float Value); // Offset: 0x10394bc34 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceInterface.SetMicphoneStatus
	// Flags: [Native|Public|BlueprintCallable]
	void SetMicphoneStatus(bool Flag); // Offset: 0x10394bba8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.SetLbsVoiceRadius
	// Flags: [Native|Public|BlueprintCallable]
	void SetLbsVoiceRadius(float Radius); // Offset: 0x10394bb24 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceInterface.SetLbsRoomEnableStatus
	// Flags: [Native|Public|BlueprintCallable]
	void SetLbsRoomEnableStatus(bool Flag); // Offset: 0x10394ba98 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.SetGVoiceSupportBackgroundChat
	// Flags: [Final|Native|Public]
	void SetGVoiceSupportBackgroundChat(bool isSupportBGChat); // Offset: 0x10394ba2c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.SetGVoiceChatServiceEnable
	// Flags: [Final|Native|Public]
	void SetGVoiceChatServiceEnable(bool IsEnable); // Offset: 0x10394b9c0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.SetGMServerUrl
	// Flags: [Final|Native|Public]
	void SetGMServerUrl(struct FString InServerUrl); // Offset: 0x10394b928 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GVoiceInterface.SetGameFrontendHUD
	// Flags: [Native|Public|BlueprintCallable]
	void SetGameFrontendHUD(struct UGameFrontendHUD* InHUD); // Offset: 0x10394b8a4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GVoiceInterface.SetFeature
	// Flags: [Native|Public]
	void SetFeature(uint8_t InFeature, bool Inactive); // Offset: 0x10394b7dc // Return & Params: Num(2) Size(0x2)

	// Object Name: Function Client.GVoiceInterface.SetCurrentDownloadFieldID
	// Flags: [Native|Public|BlueprintCallable]
	void SetCurrentDownloadFieldID(struct FString filedId); // Offset: 0x10394b718 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GVoiceInterface.SetAllVoiceStatus
	// Flags: [Native|Public|BlueprintCallable]
	void SetAllVoiceStatus(bool Flag); // Offset: 0x10394b68c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.RSTSStopRecording
	// Flags: [Native|Public|BlueprintCallable]
	void RSTSStopRecording(); // Offset: 0x10394b670 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.RSTSSpeechToText
	// Flags: [Native|Public|BlueprintCallable]
	int RSTSSpeechToText(int InSrcLang); // Offset: 0x10394b5dc // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.GVoiceInterface.ResetWhenLogOut
	// Flags: [Native|Public|BlueprintCallable]
	void ResetWhenLogOut(); // Offset: 0x10394b5c0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.ReportPlayers
	// Flags: [Native|Public|BlueprintCallable]
	bool ReportPlayers(struct FString InExtraInfo, struct TArray<struct FString> InOpenids); // Offset: 0x10394b454 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function Client.GVoiceInterface.ReportFileForAbroad
	// Flags: [Native|Public|BlueprintCallable]
	int ReportFileForAbroad(struct FString InFilePath, bool InTranslate, bool InChangeVoice, int InTime); // Offset: 0x10394b2cc // Return & Params: Num(5) Size(0x1c)

	// Object Name: Function Client.GVoiceInterface.ReactiveLbsStatus
	// Flags: [Native|Public|BlueprintCallable]
	void ReactiveLbsStatus(); // Offset: 0x10394b2b0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.QuitTempLbsRoom
	// Flags: [Native|Public|BlueprintCallable]
	void QuitTempLbsRoom(struct FString roomStr); // Offset: 0x10394b1ec // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GVoiceInterface.QuitRoom
	// Flags: [Native|Public|BlueprintCallable]
	void QuitRoom(); // Offset: 0x10394b1d0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.QuitCommonRoom
	// Flags: [Native|Public]
	void QuitCommonRoom(struct FString InRoomName); // Offset: 0x10394b130 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GVoiceInterface.PlayRecordFile
	// Flags: [Native|Public|BlueprintCallable]
	void PlayRecordFile(); // Offset: 0x10394b114 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.OpenVoiceSpeaker
	// Flags: [Native|Public]
	int OpenVoiceSpeaker(); // Offset: 0x10394b0d8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceInterface.OpenTeamSpeakerOnly
	// Flags: [Native|Public|BlueprintCallable]
	void OpenTeamSpeakerOnly(bool ShowTips); // Offset: 0x10394b04c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.OpenTeamMicphoneOnly
	// Flags: [Native|Public|BlueprintCallable]
	int OpenTeamMicphoneOnly(bool ShowTips); // Offset: 0x10394afb0 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.GVoiceInterface.OpenTeamInterphone
	// Flags: [Native|Public|BlueprintCallable]
	int OpenTeamInterphone(); // Offset: 0x10394af74 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceInterface.OpenSpeakerByTempLbs
	// Flags: [Native|Public|BlueprintCallable]
	void OpenSpeakerByTempLbs(bool Open); // Offset: 0x10394aee8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.OpenSpeaker
	// Flags: [Native|Public|BlueprintCallable]
	int OpenSpeaker(); // Offset: 0x10394aeac // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceInterface.OpenMicByTempLbs
	// Flags: [Native|Public|BlueprintCallable]
	void OpenMicByTempLbs(bool Open); // Offset: 0x10394ae20 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.OpenMicAndSpeakerAfterJoinLbsRoom
	// Flags: [Native|Public|BlueprintCallable]
	void OpenMicAndSpeakerAfterJoinLbsRoom(); // Offset: 0x10394ae04 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.OpenMic
	// Flags: [Native|Public|BlueprintCallable]
	int OpenMic(); // Offset: 0x10394adc8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceInterface.OpenIngameSpeaker
	// Flags: [Native|Public|BlueprintCallable]
	void OpenIngameSpeaker(); // Offset: 0x10394adac // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.OpenIngameMicphone
	// Flags: [Native|Public|BlueprintCallable]
	int OpenIngameMicphone(); // Offset: 0x10394ad70 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceInterface.OpenAllSpeaker
	// Flags: [Native|Public|BlueprintCallable]
	void OpenAllSpeaker(bool ShowTips); // Offset: 0x10394ace4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.OpenAllMicphone
	// Flags: [Native|Public|BlueprintCallable]
	int OpenAllMicphone(bool ShowTips); // Offset: 0x10394ac48 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.GVoiceInterface.OpenAllInterphone
	// Flags: [Native|Public|BlueprintCallable]
	int OpenAllInterphone(); // Offset: 0x10394ac0c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceInterface.OnRoomTypeChanged
	// Flags: [Native|Public|BlueprintCallable]
	void OnRoomTypeChanged(struct FString itemtext); // Offset: 0x10394ab48 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GVoiceInterface.OnResume
	// Flags: [Native|Public|BlueprintCallable]
	void OnResume(); // Offset: 0x10394ab2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.OnPause
	// Flags: [Native|Public|BlueprintCallable]
	void OnPause(); // Offset: 0x10394ab10 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.LbsSpeakerEnable
	// Flags: [Native|Public|BlueprintCallable]
	bool LbsSpeakerEnable(); // Offset: 0x10394aad4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.LbsMicphoneEnable
	// Flags: [Native|Public|BlueprintCallable]
	bool LbsMicphoneEnable(); // Offset: 0x10394aa98 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.JoinTempLbsRoom
	// Flags: [Native|Public|BlueprintCallable]
	void JoinTempLbsRoom(struct FString Room, struct FString userId); // Offset: 0x10394a95c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.GVoiceInterface.JoinRoom
	// Flags: [Native|Public|BlueprintCallable]
	void JoinRoom(struct FString Room, struct FString userId); // Offset: 0x10394a820 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.GVoiceInterface.JoinLbsRoom
	// Flags: [Native|Public|BlueprintCallable]
	void JoinLbsRoom(struct FString lbsRoom, struct FString userId); // Offset: 0x10394a6e4 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.GVoiceInterface.JoinCommonRoom
	// Flags: [Native|Public]
	void JoinCommonRoom(struct FString InRoomName); // Offset: 0x10394a644 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GVoiceInterface.IsTeamInterphoneOpenned
	// Flags: [Native|Public|BlueprintCallable]
	bool IsTeamInterphoneOpenned(); // Offset: 0x10394a608 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.IsNewGVoiceInterface
	// Flags: [Native|Public|BlueprintCallable]
	bool IsNewGVoiceInterface(); // Offset: 0x10394a5cc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.IsLbsInterphoneOpenned
	// Flags: [Native|Public|BlueprintCallable]
	bool IsLbsInterphoneOpenned(); // Offset: 0x10394a590 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.IsInterphoneMode
	// Flags: [Native|Public|BlueprintCallable]
	bool IsInterphoneMode(); // Offset: 0x10394a554 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.Invoke
	// Flags: [Native|Public]
	int Invoke(uint32_t InCmd, uint32_t InParam1, uint32_t InParam2); // Offset: 0x10394a44c // Return & Params: Num(4) Size(0x10)

	// Object Name: Function Client.GVoiceInterface.InitGVoiceComponent
	// Flags: [Native|Public|BlueprintCallable]
	void InitGVoiceComponent(struct FString userId); // Offset: 0x10394a388 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GVoiceInterface.Init
	// Flags: [Native|Public]
	void Init(); // Offset: 0x10394a36c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.HaveTeamRoom
	// Flags: [Native|Public|BlueprintCallable]
	bool HaveTeamRoom(); // Offset: 0x10394a330 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.HaveLbsRoom
	// Flags: [Native|Public|BlueprintCallable]
	bool HaveLbsRoom(); // Offset: 0x10394a2f4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.GetVoiceLength
	// Flags: [Native|Public|BlueprintCallable]
	float GetVoiceLength(); // Offset: 0x10394a2b8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceInterface.GetTeamRoomName
	// Flags: [Native|Public]
	struct FString GetTeamRoomName(); // Offset: 0x10394a24c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GVoiceInterface.GetRoomStatus
	// Flags: [Native|Public]
	int GetRoomStatus(struct FString InRoomName); // Offset: 0x10394a19c // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.GVoiceInterface.GetPlayerVolume
	// Flags: [Native|Public|BlueprintCallable]
	int GetPlayerVolume(struct FString InPlayerid); // Offset: 0x10394a0c8 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.GVoiceInterface.GetMicState
	// Flags: [Native|Public]
	int GetMicState(); // Offset: 0x10394a08c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceInterface.GetLbsRoomName
	// Flags: [Native|Public]
	struct FString GetLbsRoomName(); // Offset: 0x10394a020 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GVoiceInterface.GetGMServerUrl
	// Flags: [Final|Native|Public]
	struct FString GetGMServerUrl(); // Offset: 0x103949fb8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GVoiceInterface.GetAuthKey
	// Flags: [Native|Public|BlueprintCallable]
	void GetAuthKey(); // Offset: 0x103949f9c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.GetAudioDeviceConnectionState
	// Flags: [Native|Public|BlueprintCallable]
	int GetAudioDeviceConnectionState(); // Offset: 0x103949f60 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceInterface.ForbidTeammateVoiceById
	// Flags: [Native|Public|BlueprintCallable]
	void ForbidTeammateVoiceById(int memberID, bool IsEnable); // Offset: 0x103949e9c // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Client.GVoiceInterface.ForbidLbsMemberVoiceById
	// Flags: [Native|Public|BlueprintCallable]
	void ForbidLbsMemberVoiceById(int memberID, bool IsEnable); // Offset: 0x103949dd8 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Client.GVoiceInterface.EnbleMicAndSpeakerByRoomName
	// Flags: [Native|Public|BlueprintCallable]
	void EnbleMicAndSpeakerByRoomName(struct FString roomName, bool Enable); // Offset: 0x103949cc4 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.GVoiceInterface.EnableVoiceChat
	// Flags: [Native|Public]
	void EnableVoiceChat(bool InEnable); // Offset: 0x103949c38 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.EnableRoomSpeaker
	// Flags: [Native|Public]
	int EnableRoomSpeaker(struct FString InRoomName, bool InEnable); // Offset: 0x103949b40 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Client.GVoiceInterface.EnableReportForAbroad
	// Flags: [Native|Public|BlueprintCallable]
	int EnableReportForAbroad(bool InIsWholeRoundaudit); // Offset: 0x103949aa4 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.GVoiceInterface.EnableReportALLAbroad
	// Flags: [Native|Public|BlueprintCallable]
	bool EnableReportALLAbroad(bool InEnable, bool InWithEncryption, int InTimeout); // Offset: 0x103949980 // Return & Params: Num(4) Size(0x9)

	// Object Name: Function Client.GVoiceInterface.EnableGVoiceRoomMicrophone
	// Flags: [Native|Public]
	int EnableGVoiceRoomMicrophone(struct FString InRoomName, bool InEnable); // Offset: 0x103949888 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Client.GVoiceInterface.DownloadRecordFile
	// Flags: [Native|Public|BlueprintCallable]
	void DownloadRecordFile(); // Offset: 0x10394986c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.CommonTestMic
	// Flags: [Native|Public|BlueprintCallable]
	void CommonTestMic(); // Offset: 0x103949850 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.CloseVoiceSpeaker
	// Flags: [Native|Public]
	int CloseVoiceSpeaker(); // Offset: 0x103949814 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceInterface.CloseSpeaker
	// Flags: [Native|Public|BlueprintCallable]
	void CloseSpeaker(); // Offset: 0x1039497f8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.CloseMic
	// Flags: [Native|Public|BlueprintCallable]
	void CloseMic(); // Offset: 0x1039497dc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.CloseIngameSpeaker
	// Flags: [Native|Public|BlueprintCallable]
	void CloseIngameSpeaker(); // Offset: 0x1039497c0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.CloseIngameMicphone
	// Flags: [Native|Public|BlueprintCallable]
	void CloseIngameMicphone(); // Offset: 0x1039497a4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.CloseAllSpeaker
	// Flags: [Native|Public|BlueprintCallable]
	void CloseAllSpeaker(bool ShowTips); // Offset: 0x103949718 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.CloseAllMicphone
	// Flags: [Native|Public|BlueprintCallable]
	void CloseAllMicphone(bool ShowTips); // Offset: 0x10394968c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceInterface.CheckDeviceMuteState
	// Flags: [Native|Public|BlueprintCallable]
	int CheckDeviceMuteState(); // Offset: 0x103949650 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceInterface.CheckAndEnableRoomSpeaker
	// Flags: [Native|Public|BlueprintCallable]
	void CheckAndEnableRoomSpeaker(); // Offset: 0x103949634 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.ChatShowAgeRestrictionMsgInLobby
	// Flags: [Native|Public|BlueprintCallable]
	void ChatShowAgeRestrictionMsgInLobby(); // Offset: 0x103949618 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.ChatShowAgeRestrictionMsgInFighting
	// Flags: [Native|Public|BlueprintCallable]
	void ChatShowAgeRestrictionMsgInFighting(); // Offset: 0x1039495fc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.ChatShowAgeRestrictionMsgInChat
	// Flags: [Native|Public|BlueprintCallable]
	void ChatShowAgeRestrictionMsgInChat(); // Offset: 0x1039495e0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.ChatRequestPrivacyInSetting
	// Flags: [Native|Public|BlueprintCallable]
	void ChatRequestPrivacyInSetting(); // Offset: 0x1039495c4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.ChatRequestPrivacyInGame
	// Flags: [Native|Public|BlueprintCallable]
	void ChatRequestPrivacyInGame(); // Offset: 0x1039495a8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceInterface.AlwaysDisableRoomMic
	// Flags: [Native|Public|BlueprintCallable]
	void AlwaysDisableRoomMic(struct FString InRoomName, bool WithClear); // Offset: 0x1039494c0 // Return & Params: Num(2) Size(0x11)
};

// Object Name: Class Client.GVoiceNewInterface
// Size: 0x490 // Inherited bytes: 0x348
struct UGVoiceNewInterface : UGVoiceInterface {
	// Fields
	char pad_0x348[0x8]; // Offset: 0x348 // Size: 0x08
	struct FString ServerInfo; // Offset: 0x350 // Size: 0x10
	uint32_t openGvoiceLog; // Offset: 0x360 // Size: 0x04
	uint32_t MicVolumeMUFactor; // Offset: 0x364 // Size: 0x04
	uint32_t SpeekerVolumeMUFactor; // Offset: 0x368 // Size: 0x04
	char pad_0x36C[0x4]; // Offset: 0x36c // Size: 0x04
	struct UGameFrontendHUD* GameFrontendHUD; // Offset: 0x370 // Size: 0x08
	char pad_0x378[0x118]; // Offset: 0x378 // Size: 0x118

	// Functions

	// Object Name: Function Client.GVoiceNewInterface.VoiceSpeechToText
	// Flags: [Final|Native|Public]
	int VoiceSpeechToText(struct FString InFileID, int InTimeout, int InLanguage); // Offset: 0x10395515c // Return & Params: Num(4) Size(0x1c)

	// Object Name: Function Client.GVoiceNewInterface.UploadRecordFile
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UploadRecordFile(); // Offset: 0x103955140 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceNewInterface.UploadRecordedFile
	// Flags: [Final|Native|Public]
	int UploadRecordedFile(struct FString InFilePath, int InTimeout, bool InPermanent); // Offset: 0x103955014 // Return & Params: Num(4) Size(0x1c)

	// Object Name: Function Client.GVoiceNewInterface.UpdateVoiceCoordinate
	// Flags: [Final|Native|Public]
	int UpdateVoiceCoordinate(struct FString InRoomName, int64_t X, int64_t Y, int64_t Z, int64_t Radius); // Offset: 0x103954e74 // Return & Params: Num(6) Size(0x34)

	// Object Name: Function Client.GVoiceNewInterface.TestMic
	// Flags: [Final|Native|Public|BlueprintCallable]
	void TestMic(); // Offset: 0x103954e58 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceNewInterface.TeamSpeakerEnable
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool TeamSpeakerEnable(); // Offset: 0x103954e1c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceNewInterface.TeamMicphoneEnable
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool TeamMicphoneEnable(); // Offset: 0x103954de0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceNewInterface.SwitchMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SwitchMode(enum class ECharacterMainType CharMode); // Offset: 0x103954d5c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceNewInterface.SwitchMicphoneWhenCorpsMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SwitchMicphoneWhenCorpsMode(); // Offset: 0x103954d40 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceNewInterface.SwitchCampRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SwitchCampRoom(enum class ECharacterMainType campMode); // Offset: 0x103954cbc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceNewInterface.StopRecording
	// Flags: [Final|Native|Public]
	int StopRecording(); // Offset: 0x103954c88 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceNewInterface.StopRecord
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StopRecord(); // Offset: 0x103954c6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceNewInterface.StopPlayRecordFile
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StopPlayRecordFile(); // Offset: 0x103954c50 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceNewInterface.StopInterphone
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StopInterphone(); // Offset: 0x103954c34 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceNewInterface.StopCampMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StopCampMode(); // Offset: 0x103954c18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceNewInterface.StartRecording
	// Flags: [Final|Native|Public]
	int StartRecording(struct FString InFilePath, bool InNotVoip); // Offset: 0x103954b28 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Client.GVoiceNewInterface.StartRecord
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StartRecord(); // Offset: 0x103954b0c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceNewInterface.StartInterphone
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StartInterphone(); // Offset: 0x103954af0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceNewInterface.StartCampMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StartCampMode(struct FString ZombieCampRoomName, struct FString ManCampRoomName, struct FString userId); // Offset: 0x1039549a8 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.GVoiceNewInterface.SpeechToText
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SpeechToText(); // Offset: 0x10395498c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceNewInterface.SetVoiceServer
	// Flags: [Final|Native|Public]
	void SetVoiceServer(struct FString ServerInfo); // Offset: 0x1039548ec // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GVoiceNewInterface.SetVoiceMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVoiceMode(int Type); // Offset: 0x103954868 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceNewInterface.SetSpeakerVolum
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSpeakerVolum(float Value); // Offset: 0x1039547e4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceNewInterface.SetSpeakerStatus
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSpeakerStatus(bool Flag); // Offset: 0x103954758 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceNewInterface.SetServerInfo
	// Flags: [Final|Native|Public]
	int SetServerInfo(struct FString URL, struct FString InDefaultIpSvr); // Offset: 0x10395465c // Return & Params: Num(3) Size(0x24)

	// Object Name: Function Client.GVoiceNewInterface.SetReportBufferTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetReportBufferTime(int nTimeSec); // Offset: 0x1039545d8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceNewInterface.SetPlayerVolume
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPlayerVolume(struct FString InPlayerid, int InVol); // Offset: 0x1039544d4 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.GVoiceNewInterface.SetNotify
	// Flags: [Final|Native|Public]
	int SetNotify(); // Offset: 0x1039544a0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceNewInterface.SetMode
	// Flags: [Final|Native|Public]
	int SetMode(int InGVMode); // Offset: 0x103954414 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.GVoiceNewInterface.SetMicphoneVolum
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMicphoneVolum(float Value); // Offset: 0x103954390 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceNewInterface.SetMicphoneStatus
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMicphoneStatus(bool Flag); // Offset: 0x103954304 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceNewInterface.SetLbsVoiceRadius
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetLbsVoiceRadius(float Radius); // Offset: 0x103954280 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceNewInterface.SetLbsRoomEnableStatus
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetLbsRoomEnableStatus(bool Flag); // Offset: 0x1039541f4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceNewInterface.SetGVoiceSupportBackgroundChat
	// Flags: [Final|Native|Public]
	void SetGVoiceSupportBackgroundChat(bool isSupportBGChat); // Offset: 0x103954170 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceNewInterface.SetGVoiceChatServiceEnable
	// Flags: [Final|Native|Public]
	void SetGVoiceChatServiceEnable(bool IsEnable); // Offset: 0x1039540ec // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceNewInterface.SetGameFrontendHUD
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetGameFrontendHUD(struct UGameFrontendHUD* InHUD); // Offset: 0x103954068 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GVoiceNewInterface.SetFeature
	// Flags: [Final|Native|Public]
	void SetFeature(uint8_t InFeature, bool Inactive); // Offset: 0x103953fa0 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function Client.GVoiceNewInterface.SetCurrentDownloadFieldID
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetCurrentDownloadFieldID(struct FString filedId); // Offset: 0x103953edc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GVoiceNewInterface.SetAppInfo
	// Flags: [Final|Native|Public]
	int SetAppInfo(struct FString InAppId, struct FString InAppKey, struct FString InOpenId); // Offset: 0x103953d8c // Return & Params: Num(4) Size(0x34)

	// Object Name: Function Client.GVoiceNewInterface.RSTSStopRecording
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RSTSStopRecording(); // Offset: 0x103953d70 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceNewInterface.RSTSSpeechToText
	// Flags: [Final|Native|Public|BlueprintCallable]
	int RSTSSpeechToText(int InSrcLang); // Offset: 0x103953cdc // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.GVoiceNewInterface.ResetWhenLogOut
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ResetWhenLogOut(); // Offset: 0x103953cc0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceNewInterface.ReportPlayers
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool ReportPlayers(struct FString InExtraInfo, struct TArray<struct FString> InOpenids); // Offset: 0x103953b54 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function Client.GVoiceNewInterface.ReportFileForAbroad
	// Flags: [Final|Native|Public|BlueprintCallable]
	int ReportFileForAbroad(struct FString InFilePath, bool InTranslate, bool InChangeVoice, int InTime); // Offset: 0x1039539cc // Return & Params: Num(5) Size(0x1c)

	// Object Name: Function Client.GVoiceNewInterface.ReactiveLbsStatus
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ReactiveLbsStatus(); // Offset: 0x1039539b0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceNewInterface.QuitVoiceRoom
	// Flags: [Final|Native|Public]
	int QuitVoiceRoom(struct FString InRoomName); // Offset: 0x103953908 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.GVoiceNewInterface.QuitTempLbsRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	void QuitTempLbsRoom(struct FString roomStr); // Offset: 0x103953844 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GVoiceNewInterface.QuitRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	void QuitRoom(); // Offset: 0x103953828 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceNewInterface.QuitCommonRoom
	// Flags: [Final|Native|Public]
	void QuitCommonRoom(struct FString InRoomName); // Offset: 0x103953788 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GVoiceNewInterface.Poll
	// Flags: [Final|Native|Public]
	int Poll(); // Offset: 0x103953754 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceNewInterface.PlayRecordFile
	// Flags: [Final|Native|Public|BlueprintCallable]
	void PlayRecordFile(); // Offset: 0x103953738 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceNewInterface.PlayRecordedFile
	// Flags: [Final|Native|Public]
	int PlayRecordedFile(struct FString InDownloadInFilePath); // Offset: 0x103953690 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.GVoiceNewInterface.OpenVoiceSpeaker
	// Flags: [Final|Native|Public]
	int OpenVoiceSpeaker(); // Offset: 0x103953654 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceNewInterface.OpenVoiceMic
	// Flags: [Final|Native|Public]
	int OpenVoiceMic(); // Offset: 0x103953620 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceNewInterface.OpenTeamSpeakerOnly
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OpenTeamSpeakerOnly(bool ShowTips); // Offset: 0x103953594 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceNewInterface.OpenTeamMicphoneOnly
	// Flags: [Final|Native|Public|BlueprintCallable]
	int OpenTeamMicphoneOnly(bool ShowTips); // Offset: 0x1039534f8 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.GVoiceNewInterface.OpenTeamInterphone
	// Flags: [Final|Native|Public|BlueprintCallable]
	int OpenTeamInterphone(); // Offset: 0x1039534bc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceNewInterface.OpenSpeakerByTempLbs
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OpenSpeakerByTempLbs(bool Open); // Offset: 0x103953430 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceNewInterface.OpenSpeaker
	// Flags: [Final|Native|Public|BlueprintCallable]
	int OpenSpeaker(); // Offset: 0x1039533f4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceNewInterface.OpenMicByTempLbs
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OpenMicByTempLbs(bool Open); // Offset: 0x103953368 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceNewInterface.OpenMicAndSpeakerAfterJoinLbsRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OpenMicAndSpeakerAfterJoinLbsRoom(); // Offset: 0x10395334c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceNewInterface.OpenMic
	// Flags: [Final|Native|Public|BlueprintCallable]
	int OpenMic(); // Offset: 0x103953310 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceNewInterface.OpenIngameSpeaker
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OpenIngameSpeaker(); // Offset: 0x1039532f4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceNewInterface.OpenIngameMicphone
	// Flags: [Final|Native|Public|BlueprintCallable]
	int OpenIngameMicphone(); // Offset: 0x1039532b8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceNewInterface.OpenAllSpeaker
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OpenAllSpeaker(bool ShowTips); // Offset: 0x10395322c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceNewInterface.OpenAllMicphone
	// Flags: [Final|Native|Public|BlueprintCallable]
	int OpenAllMicphone(bool ShowTips); // Offset: 0x103953190 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.GVoiceNewInterface.OpenAllInterphone
	// Flags: [Final|Native|Public|BlueprintCallable]
	int OpenAllInterphone(); // Offset: 0x103953154 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceNewInterface.OnResume
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OnResume(); // Offset: 0x103953138 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceNewInterface.OnPause
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OnPause(); // Offset: 0x10395311c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceNewInterface.LbsSpeakerEnable
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool LbsSpeakerEnable(); // Offset: 0x1039530e0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceNewInterface.LbsMicphoneEnable
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool LbsMicphoneEnable(); // Offset: 0x1039530a4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceNewInterface.JoinTempLbsRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	void JoinTempLbsRoom(struct FString Room, struct FString userId); // Offset: 0x103952f68 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.GVoiceNewInterface.JoinTeamRoom
	// Flags: [Final|Native|Public]
	int JoinTeamRoom(struct FString InRoomName); // Offset: 0x103952ec0 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.GVoiceNewInterface.JoinRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	void JoinRoom(struct FString Room, struct FString userId); // Offset: 0x103952d84 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.GVoiceNewInterface.JoinRangeRoom
	// Flags: [Final|Native|Public]
	int JoinRangeRoom(struct FString InRoomName); // Offset: 0x103952cdc // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.GVoiceNewInterface.JoinLbsRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	void JoinLbsRoom(struct FString lbsRoom, struct FString userId); // Offset: 0x103952ba0 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.GVoiceNewInterface.JoinCommonRoom
	// Flags: [Final|Native|Public]
	void JoinCommonRoom(struct FString InRoomName); // Offset: 0x103952b00 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GVoiceNewInterface.IsTeamInterphoneOpenned
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsTeamInterphoneOpenned(); // Offset: 0x103952ac4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceNewInterface.IsSpeaking
	// Flags: [Final|Native|Public]
	bool IsSpeaking(); // Offset: 0x103952a90 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceNewInterface.IsNewGVoiceInterface
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsNewGVoiceInterface(); // Offset: 0x103952a54 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceNewInterface.IsLbsInterphoneOpenned
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsLbsInterphoneOpenned(); // Offset: 0x103952a18 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceNewInterface.IsInterphoneMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsInterphoneMode(); // Offset: 0x1039529dc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceNewInterface.IsGVoiceEnable
	// Flags: [Final|Native|Public]
	bool IsGVoiceEnable(); // Offset: 0x1039529a8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceNewInterface.Invoke
	// Flags: [Final|Native|Public]
	int Invoke(uint32_t InCmd, uint32_t InParam1, uint32_t InParam2); // Offset: 0x1039528a0 // Return & Params: Num(4) Size(0x10)

	// Object Name: Function Client.GVoiceNewInterface.InitGVoiceComponent
	// Flags: [Final|Native|Public|BlueprintCallable]
	void InitGVoiceComponent(struct FString userId); // Offset: 0x1039527dc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GVoiceNewInterface.InitGVoice
	// Flags: [Final|Native|Public]
	int InitGVoice(); // Offset: 0x1039527a8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceNewInterface.Init
	// Flags: [Final|Native|Public]
	void Init(); // Offset: 0x10395278c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceNewInterface.HaveTeamRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool HaveTeamRoom(); // Offset: 0x103952750 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceNewInterface.HaveLbsRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool HaveLbsRoom(); // Offset: 0x103952714 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceNewInterface.GetVoiceLength
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetVoiceLength(); // Offset: 0x1039526d8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceNewInterface.GetTeamRoomName
	// Flags: [Final|Native|Public]
	struct FString GetTeamRoomName(); // Offset: 0x10395266c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GVoiceNewInterface.GetRoomStatus
	// Flags: [Final|Native|Public]
	int GetRoomStatus(struct FString InRoomName); // Offset: 0x1039525bc // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.GVoiceNewInterface.GetPlayerVolume
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetPlayerVolume(struct FString InPlayerid); // Offset: 0x1039524e8 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.GVoiceNewInterface.GetMicState
	// Flags: [Final|Native|Public]
	int GetMicState(); // Offset: 0x1039524ac // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceNewInterface.GetLbsRoomName
	// Flags: [Final|Native|Public]
	struct FString GetLbsRoomName(); // Offset: 0x103952440 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GVoiceNewInterface.GetAuthKey
	// Flags: [Final|Native|Public|BlueprintCallable]
	void GetAuthKey(); // Offset: 0x103952424 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceNewInterface.GetAudioDeviceConnectionState
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetAudioDeviceConnectionState(); // Offset: 0x1039523e8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceNewInterface.ForbidTeammateVoiceById
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ForbidTeammateVoiceById(int memberID, bool IsEnable); // Offset: 0x103952324 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Client.GVoiceNewInterface.ForbidMemberVoice
	// Flags: [Final|Native|Public]
	int ForbidMemberVoice(int InMember, bool InEnable, struct FString InRoomName); // Offset: 0x1039521fc // Return & Params: Num(4) Size(0x1c)

	// Object Name: Function Client.GVoiceNewInterface.ForbidLbsMemberVoiceById
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ForbidLbsMemberVoiceById(int memberID, bool IsEnable); // Offset: 0x103952138 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Client.GVoiceNewInterface.EnbleMicAndSpeakerByRoomName
	// Flags: [Final|Native|Public|BlueprintCallable]
	void EnbleMicAndSpeakerByRoomName(struct FString roomName, bool Enable); // Offset: 0x103952024 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.GVoiceNewInterface.EnableVoiceChat
	// Flags: [Final|Native|Public]
	void EnableVoiceChat(bool InEnable); // Offset: 0x103951f98 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceNewInterface.EnableRoomSpeaker
	// Flags: [Final|Native|Public]
	int EnableRoomSpeaker(struct FString InRoomName, bool InEnable); // Offset: 0x103951ea0 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Client.GVoiceNewInterface.EnableReportForAbroad
	// Flags: [Final|Native|Public|BlueprintCallable]
	int EnableReportForAbroad(bool InIsWholeRoundaudit); // Offset: 0x103951e04 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.GVoiceNewInterface.EnableReportALLAbroad
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool EnableReportALLAbroad(bool InEnable, bool InWithEncryption, int InTimeout); // Offset: 0x103951ce0 // Return & Params: Num(4) Size(0x9)

	// Object Name: Function Client.GVoiceNewInterface.EnableMultiRoom
	// Flags: [Final|Native|Public]
	int EnableMultiRoom(bool InEnable); // Offset: 0x103951c4c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.GVoiceNewInterface.EnableLog
	// Flags: [Final|Native|Public]
	void EnableLog(bool InEnable); // Offset: 0x103951bc8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceNewInterface.EnableGVoiceRoomMicrophone
	// Flags: [Final|Native|Public]
	int EnableGVoiceRoomMicrophone(struct FString InRoomName, bool InEnable); // Offset: 0x103951ad0 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Client.GVoiceNewInterface.DownloadRecordFile
	// Flags: [Final|Native|Public|BlueprintCallable]
	void DownloadRecordFile(); // Offset: 0x103951ab4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceNewInterface.DownloadRecordedFile
	// Flags: [Final|Native|Public]
	int DownloadRecordedFile(struct FString InFileID, struct FString InDownloadInFilePath, int InTimeout, bool InPermanent); // Offset: 0x103951934 // Return & Params: Num(5) Size(0x2c)

	// Object Name: Function Client.GVoiceNewInterface.CommonTestMic
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CommonTestMic(); // Offset: 0x103951918 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceNewInterface.CloseVoiceSpeaker
	// Flags: [Final|Native|Public]
	int CloseVoiceSpeaker(); // Offset: 0x1039518dc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceNewInterface.CloseVoiceMic
	// Flags: [Final|Native|Public]
	int CloseVoiceMic(); // Offset: 0x1039518a8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceNewInterface.CloseSpeaker
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CloseSpeaker(); // Offset: 0x10395188c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceNewInterface.CloseMic
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CloseMic(); // Offset: 0x103951870 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceNewInterface.CloseAllSpeaker
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CloseAllSpeaker(bool ShowTips); // Offset: 0x1039517e4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceNewInterface.CloseAllMicphone
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CloseAllMicphone(bool ShowTips); // Offset: 0x103951758 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceNewInterface.CheckDeviceMuteState
	// Flags: [Final|Native|Public|BlueprintCallable]
	int CheckDeviceMuteState(); // Offset: 0x10395171c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceNewInterface.CheckAndEnableRoomSpeaker
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CheckAndEnableRoomSpeaker(); // Offset: 0x103951700 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceNewInterface.ChatRequestPrivacyInSetting
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ChatRequestPrivacyInSetting(); // Offset: 0x1039516e4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceNewInterface.ChatRequestPrivacyInGame
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ChatRequestPrivacyInGame(); // Offset: 0x1039516c8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceNewInterface.ApplyMessageKey
	// Flags: [Final|Native|Public]
	int ApplyMessageKey(); // Offset: 0x103951694 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceNewInterface.AlwaysDisableRoomMic
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AlwaysDisableRoomMic(struct FString InRoomName, bool WithClear); // Offset: 0x1039515ac // Return & Params: Num(2) Size(0x11)
};

// Object Name: Class Client.GVoiceOldInterface
// Size: 0x538 // Inherited bytes: 0x348
struct UGVoiceOldInterface : UGVoiceInterface {
	// Fields
	char pad_0x348[0xc8]; // Offset: 0x348 // Size: 0xc8
	struct FString ServerInfo; // Offset: 0x410 // Size: 0x10
	uint32_t openGvoiceLog; // Offset: 0x420 // Size: 0x04
	uint32_t MicVolumeMUFactor; // Offset: 0x424 // Size: 0x04
	uint32_t SpeekerVolumeMUFactor; // Offset: 0x428 // Size: 0x04
	char pad_0x42C[0x14]; // Offset: 0x42c // Size: 0x14
	struct UGameFrontendHUD* GameFrontendHUD; // Offset: 0x440 // Size: 0x08
	char pad_0x448[0xf0]; // Offset: 0x448 // Size: 0xf0

	// Functions

	// Object Name: Function Client.GVoiceOldInterface.UploadRecordFile
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UploadRecordFile(); // Offset: 0x103959d3c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceOldInterface.TestMic
	// Flags: [Final|Native|Public|BlueprintCallable]
	void TestMic(); // Offset: 0x103959d20 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceOldInterface.TeamSpeakerEnable
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool TeamSpeakerEnable(); // Offset: 0x103959ce4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceOldInterface.TeamMicphoneEnable
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool TeamMicphoneEnable(); // Offset: 0x103959ca8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceOldInterface.SwitchMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SwitchMode(enum class ECharacterMainType CharMode); // Offset: 0x103959c24 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceOldInterface.SwitchMicphoneWhenCorpsMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SwitchMicphoneWhenCorpsMode(); // Offset: 0x103959c08 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceOldInterface.SwitchCampRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SwitchCampRoom(enum class ECharacterMainType campMode); // Offset: 0x103959b84 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceOldInterface.StopRecord
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StopRecord(); // Offset: 0x103959b68 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceOldInterface.StopPlayRecordFile
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StopPlayRecordFile(); // Offset: 0x103959b4c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceOldInterface.StopInterphone
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StopInterphone(); // Offset: 0x103959b30 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceOldInterface.StopCampMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StopCampMode(); // Offset: 0x103959b14 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceOldInterface.StartRecord
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StartRecord(); // Offset: 0x103959af8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceOldInterface.StartInterphone
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StartInterphone(); // Offset: 0x103959adc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceOldInterface.StartCampMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StartCampMode(struct FString ZombieCampRoomName, struct FString ManCampRoomName, struct FString userId); // Offset: 0x103959994 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.GVoiceOldInterface.SpeechToText
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SpeechToText(); // Offset: 0x103959978 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceOldInterface.ShowOpenSpeakerAtFirstMsg
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ShowOpenSpeakerAtFirstMsg(); // Offset: 0x10395995c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceOldInterface.ShowCorpsModeCannotUseLBSVoice
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ShowCorpsModeCannotUseLBSVoice(); // Offset: 0x103959940 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceOldInterface.SetVoiceServer
	// Flags: [Final|Native|Public]
	void SetVoiceServer(struct FString ServerInfo); // Offset: 0x1039598a0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GVoiceOldInterface.SetVoiceMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVoiceMode(int Type); // Offset: 0x10395981c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceOldInterface.SetSpeakerVolum
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSpeakerVolum(float Value); // Offset: 0x103959798 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceOldInterface.SetSpeakerStatus
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSpeakerStatus(bool Flag); // Offset: 0x10395970c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceOldInterface.SetReportBufferTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetReportBufferTime(int nTimeSec); // Offset: 0x103959688 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceOldInterface.SetPlayerVolume
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPlayerVolume(struct FString InPlayerid, int InVol); // Offset: 0x103959584 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.GVoiceOldInterface.SetMicphoneVolum
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMicphoneVolum(float Value); // Offset: 0x103959500 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceOldInterface.SetMicphoneStatus
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMicphoneStatus(bool Flag); // Offset: 0x103959474 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceOldInterface.SetLbsVoiceRadius
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetLbsVoiceRadius(float Radius); // Offset: 0x1039593f0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceOldInterface.SetLbsRoomEnableStatus
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetLbsRoomEnableStatus(bool Flag); // Offset: 0x103959364 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceOldInterface.SetGVoiceSupportBackgroundChat
	// Flags: [Final|Native|Public]
	void SetGVoiceSupportBackgroundChat(bool isSupportBGChat); // Offset: 0x1039592e0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceOldInterface.SetGameFrontendHUD
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetGameFrontendHUD(struct UGameFrontendHUD* InHUD); // Offset: 0x10395925c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.GVoiceOldInterface.SetCurrentDownloadFieldID
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetCurrentDownloadFieldID(struct FString filedId); // Offset: 0x103959198 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GVoiceOldInterface.SetAllVoiceStatus
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAllVoiceStatus(bool Flag); // Offset: 0x10395910c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceOldInterface.ResetWhenLogOut
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ResetWhenLogOut(); // Offset: 0x1039590f0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceOldInterface.ReportPlayers
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool ReportPlayers(struct FString InExtraInfo, struct TArray<struct FString> InOpenids); // Offset: 0x103958f84 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function Client.GVoiceOldInterface.ReportFileForAbroad
	// Flags: [Final|Native|Public|BlueprintCallable]
	int ReportFileForAbroad(struct FString InFilePath, bool InTranslate, bool InChangeVoice, int InTime); // Offset: 0x103958dfc // Return & Params: Num(5) Size(0x1c)

	// Object Name: Function Client.GVoiceOldInterface.ReactiveLbsStatus
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ReactiveLbsStatus(); // Offset: 0x103958de0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceOldInterface.QuitTempLbsRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	void QuitTempLbsRoom(struct FString roomStr); // Offset: 0x103958d1c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GVoiceOldInterface.QuitRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	void QuitRoom(); // Offset: 0x103958d00 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceOldInterface.PlayRecordFile
	// Flags: [Final|Native|Public|BlueprintCallable]
	void PlayRecordFile(); // Offset: 0x103958ce4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceOldInterface.OpenTeamSpeakerOnly
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OpenTeamSpeakerOnly(bool ShowTips); // Offset: 0x103958c58 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceOldInterface.OpenTeamMicphoneOnly
	// Flags: [Final|Native|Public|BlueprintCallable]
	int OpenTeamMicphoneOnly(bool ShowTips); // Offset: 0x103958bbc // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.GVoiceOldInterface.OpenTeamInterphone
	// Flags: [Final|Native|Public|BlueprintCallable]
	int OpenTeamInterphone(); // Offset: 0x103958b80 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceOldInterface.OpenSpeakerByTempLbs
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OpenSpeakerByTempLbs(bool Open); // Offset: 0x103958af4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceOldInterface.OpenSpeaker
	// Flags: [Final|Native|Public|BlueprintCallable]
	int OpenSpeaker(); // Offset: 0x103958ab8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceOldInterface.OpenMicByTempLbs
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OpenMicByTempLbs(bool Open); // Offset: 0x103958a2c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceOldInterface.OpenMicAndSpeakerAfterJoinLbsRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OpenMicAndSpeakerAfterJoinLbsRoom(); // Offset: 0x103958a10 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceOldInterface.OpenMic
	// Flags: [Final|Native|Public|BlueprintCallable]
	int OpenMic(); // Offset: 0x1039589d4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceOldInterface.OpenIngameSpeaker
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OpenIngameSpeaker(); // Offset: 0x1039589b8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceOldInterface.OpenIngameMicphone
	// Flags: [Final|Native|Public|BlueprintCallable]
	int OpenIngameMicphone(); // Offset: 0x10395897c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceOldInterface.OpenAllSpeaker
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OpenAllSpeaker(bool ShowTips); // Offset: 0x1039588f0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceOldInterface.OpenAllMicphone
	// Flags: [Final|Native|Public|BlueprintCallable]
	int OpenAllMicphone(bool ShowTips); // Offset: 0x103958854 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.GVoiceOldInterface.OpenAllInterphone
	// Flags: [Final|Native|Public|BlueprintCallable]
	int OpenAllInterphone(); // Offset: 0x103958818 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceOldInterface.OnRoomTypeChanged
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OnRoomTypeChanged(struct FString itemtext); // Offset: 0x103958754 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GVoiceOldInterface.OnResume
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OnResume(); // Offset: 0x103958738 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceOldInterface.OnPause
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OnPause(); // Offset: 0x10395871c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceOldInterface.LbsSpeakerEnable
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool LbsSpeakerEnable(); // Offset: 0x1039586e0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceOldInterface.LbsMicphoneEnable
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool LbsMicphoneEnable(); // Offset: 0x1039586a4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceOldInterface.JoinTempLbsRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	void JoinTempLbsRoom(struct FString Room, struct FString userId); // Offset: 0x103958568 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.GVoiceOldInterface.JoinRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	void JoinRoom(struct FString Room, struct FString userId); // Offset: 0x10395842c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.GVoiceOldInterface.JoinLbsRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	void JoinLbsRoom(struct FString lbsRoom, struct FString userId); // Offset: 0x1039582f0 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.GVoiceOldInterface.IsTeamInterphoneOpenned
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsTeamInterphoneOpenned(); // Offset: 0x1039582b4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceOldInterface.IsLbsInterphoneOpenned
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsLbsInterphoneOpenned(); // Offset: 0x103958278 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceOldInterface.IsInterphoneMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsInterphoneMode(); // Offset: 0x10395823c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceOldInterface.Invoke
	// Flags: [Final|Native|Public]
	int Invoke(uint32_t InCmd, uint32_t InParam1, uint32_t InParam2); // Offset: 0x103958134 // Return & Params: Num(4) Size(0x10)

	// Object Name: Function Client.GVoiceOldInterface.InitGVoiceComponent
	// Flags: [Final|Native|Public|BlueprintCallable]
	void InitGVoiceComponent(struct FString userId); // Offset: 0x103958070 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GVoiceOldInterface.Init
	// Flags: [Final|Native|Public]
	void Init(); // Offset: 0x103958054 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceOldInterface.HaveTeamRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool HaveTeamRoom(); // Offset: 0x103958018 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceOldInterface.HaveLbsRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool HaveLbsRoom(); // Offset: 0x103957fdc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceOldInterface.GetVoiceLength
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetVoiceLength(); // Offset: 0x103957fa0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceOldInterface.GetTeamRoomName
	// Flags: [Final|Native|Public]
	struct FString GetTeamRoomName(); // Offset: 0x103957f34 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GVoiceOldInterface.GetPlayerVolume
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetPlayerVolume(struct FString InPlayerid); // Offset: 0x103957e60 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.GVoiceOldInterface.GetMicState
	// Flags: [Final|Native|Public]
	int GetMicState(); // Offset: 0x103957e24 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceOldInterface.GetLbsRoomName
	// Flags: [Final|Native|Public]
	struct FString GetLbsRoomName(); // Offset: 0x103957db8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.GVoiceOldInterface.GetAuthKey
	// Flags: [Final|Native|Public|BlueprintCallable]
	void GetAuthKey(); // Offset: 0x103957d9c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceOldInterface.GetAudioDeviceConnectionState
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetAudioDeviceConnectionState(); // Offset: 0x103957d60 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceOldInterface.ForbidTeammateVoiceById
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ForbidTeammateVoiceById(int memberID, bool IsEnable); // Offset: 0x103957c9c // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Client.GVoiceOldInterface.ForbidLbsMemberVoiceById
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ForbidLbsMemberVoiceById(int memberID, bool IsEnable); // Offset: 0x103957bd8 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Client.GVoiceOldInterface.EnbleMicAndSpeakerByRoomName
	// Flags: [Final|Native|Public|BlueprintCallable]
	void EnbleMicAndSpeakerByRoomName(struct FString roomName, bool Enable); // Offset: 0x103957ac4 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.GVoiceOldInterface.EnableReportForAbroad
	// Flags: [Final|Native|Public|BlueprintCallable]
	int EnableReportForAbroad(bool InIsWholeRoundaudit); // Offset: 0x103957a28 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.GVoiceOldInterface.EnableReportALLAbroad
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool EnableReportALLAbroad(bool InEnable, bool InWithEncryption, int InTimeout); // Offset: 0x103957904 // Return & Params: Num(4) Size(0x9)

	// Object Name: Function Client.GVoiceOldInterface.EnableGVoiceRoomMicrophone
	// Flags: [Final|Native|Public]
	int EnableGVoiceRoomMicrophone(struct FString InRoomName, bool InEnable); // Offset: 0x10395780c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Client.GVoiceOldInterface.DownloadRecordFile
	// Flags: [Final|Native|Public|BlueprintCallable]
	void DownloadRecordFile(); // Offset: 0x1039577f0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceOldInterface.CommonTestMic
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CommonTestMic(); // Offset: 0x1039577d4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceOldInterface.CloseSpeaker
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CloseSpeaker(); // Offset: 0x1039577b8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceOldInterface.CloseMic
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CloseMic(); // Offset: 0x10395779c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceOldInterface.CloseIngameSpeaker
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CloseIngameSpeaker(); // Offset: 0x103957780 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceOldInterface.CloseIngameMicphone
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CloseIngameMicphone(); // Offset: 0x103957764 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceOldInterface.CloseAllSpeaker
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CloseAllSpeaker(bool ShowTips); // Offset: 0x1039576d8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceOldInterface.CloseAllMicphone
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CloseAllMicphone(bool ShowTips); // Offset: 0x10395764c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.GVoiceOldInterface.CheckDeviceMuteState
	// Flags: [Final|Native|Public|BlueprintCallable]
	int CheckDeviceMuteState(); // Offset: 0x103957610 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.GVoiceOldInterface.CheckAndEnableRoomSpeaker
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CheckAndEnableRoomSpeaker(); // Offset: 0x1039575f4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceOldInterface.ChatShowAgeRestrictionMsgInLobby
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ChatShowAgeRestrictionMsgInLobby(); // Offset: 0x1039575d8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceOldInterface.ChatShowAgeRestrictionMsgInFighting
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ChatShowAgeRestrictionMsgInFighting(); // Offset: 0x1039575bc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceOldInterface.ChatShowAgeRestrictionMsgInChat
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ChatShowAgeRestrictionMsgInChat(); // Offset: 0x1039575a0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceOldInterface.ChatRequestPrivacyInSetting
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ChatRequestPrivacyInSetting(); // Offset: 0x103957584 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceOldInterface.ChatRequestPrivacyInGame
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ChatRequestPrivacyInGame(); // Offset: 0x103957568 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.GVoiceOldInterface.AlwaysDisableRoomMic
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AlwaysDisableRoomMic(struct FString InRoomName, bool WithClear); // Offset: 0x103957480 // Return & Params: Num(2) Size(0x11)
};

// Object Name: Class Client.HttpWrapper
// Size: 0xb0 // Inherited bytes: 0x28
struct UHttpWrapper : UObject {
	// Fields
	struct FScriptMulticastDelegate OnResponseEvent; // Offset: 0x28 // Size: 0x10
	struct FScriptMulticastDelegate OnImageDownloadResponseEvent; // Offset: 0x38 // Size: 0x10
	char pad_0x48[0x68]; // Offset: 0x48 // Size: 0x68

	// Functions

	// Object Name: Function Client.HttpWrapper.SimplePostForLua
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SimplePostForLua(struct FString URL, struct FString Content, int Priority, int QueueType); // Offset: 0x10395ca20 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function Client.HttpWrapper.SetQueueSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetQueueSize(int QueueType, int InSize); // Offset: 0x10395c96c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.HttpWrapper.SetQueueEnable
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetQueueEnable(bool InEnableQueue); // Offset: 0x10395c8ec // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.HttpWrapper.SetPoolEnable
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPoolEnable(bool InEnablePool); // Offset: 0x10395c864 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.HttpWrapper.RequestForLua
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	int RequestForLua(struct FString URL, struct FString Verb, struct TMap<struct FString, struct FString>& Headers, struct FString Content, int Priority, int QueueType); // Offset: 0x10395c628 // Return & Params: Num(7) Size(0x8c)

	// Object Name: Function Client.HttpWrapper.ImageDownloadRequestForLua
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	int ImageDownloadRequestForLua(struct FString URL, struct FString Verb, struct TMap<struct FString, struct FString>& Headers, struct FString Content, int Priority); // Offset: 0x10395c428 // Return & Params: Num(6) Size(0x88)

	// Object Name: Function Client.HttpWrapper.GetQueueEnable
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool GetQueueEnable(); // Offset: 0x10395c40c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.HttpWrapper.GetPoolEnable
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool GetPoolEnable(); // Offset: 0x10395c3e0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.HttpWrapper.GetInternalIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetInternalIndex(); // Offset: 0x10395c3c4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.HttpWrapper.CancelRequestAll
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CancelRequestAll(int QueueType); // Offset: 0x10395c348 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.HttpWrapper.CancelRequest
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CancelRequest(int QueueType, int ReqIndex); // Offset: 0x10395c294 // Return & Params: Num(2) Size(0x8)
};

// Object Name: Class Client.ImageDownloader
// Size: 0xb0 // Inherited bytes: 0x28
struct UImageDownloader : UObject {
	// Fields
	struct FScriptMulticastDelegate OnSuccess; // Offset: 0x28 // Size: 0x10
	struct FScriptMulticastDelegate OnFail; // Offset: 0x38 // Size: 0x10
	struct FString FileURL; // Offset: 0x48 // Size: 0x10
	struct FString CompreesedFileUrl; // Offset: 0x58 // Size: 0x10
	struct FString FileSavePath; // Offset: 0x68 // Size: 0x10
	struct FString CompreesedFileSavePath; // Offset: 0x78 // Size: 0x10
	struct FString UrlHash; // Offset: 0x88 // Size: 0x10
	struct FString CompreesedUrlHash; // Offset: 0x98 // Size: 0x10
	bool InvalidImageFormat; // Offset: 0xa8 // Size: 0x01
	bool SaveDiskFile; // Offset: 0xa9 // Size: 0x01
	bool ForceUpdate; // Offset: 0xaa // Size: 0x01
	char pad_0xAB[0x5]; // Offset: 0xab // Size: 0x05

	// Functions

	// Object Name: Function Client.ImageDownloader.Start
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Start(struct FString URL); // Offset: 0x10395d1d0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ImageDownloader.MakeDownloaderInGame
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UImageDownloader* MakeDownloaderInGame(); // Offset: 0x10395d19c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ImageDownloader.MakeDownloader
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UImageDownloader* MakeDownloader(); // Offset: 0x10395d168 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ImageDownloader.GetTextureFromUrlWithoutDownload
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UTexture2D* GetTextureFromUrlWithoutDownload(struct FString URL); // Offset: 0x10395d09c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ImageDownloader.CheckAndGetEncryptUrl
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FString CheckAndGetEncryptUrl(struct FString& InUrl); // Offset: 0x10395cfcc // Return & Params: Num(2) Size(0x20)
};

// Object Name: Class Client.ImageDownloadUtil
// Size: 0x28 // Inherited bytes: 0x28
struct UImageDownloadUtil : UObject {
	// Functions

	// Object Name: Function Client.ImageDownloadUtil.SaveImageDownloadDiskFile
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SaveImageDownloadDiskFile(struct TArray<char>& OutArray, struct FString SavePath); // Offset: 0x10395d914 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ImageDownloadUtil.GetTextureFromMemory
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UTexture2D* GetTextureFromMemory(struct FString PathName); // Offset: 0x10395d848 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ImageDownloadUtil.GetTexture2DFromDisk
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UTexture2D* GetTexture2DFromDisk(struct FString SavePath, bool IsCompressed); // Offset: 0x10395d734 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Client.ImageDownloadUtil.GetTexture2DFromArray
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct UTexture2D* GetTexture2DFromArray(struct TArray<char>& OutArray, bool IsCompressed); // Offset: 0x10395d630 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Client.ImageDownloadUtil.CheckDiskFile
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CheckDiskFile(struct FString ImgDir, struct FString SubDir); // Offset: 0x10395d4fc // Return & Params: Num(2) Size(0x20)
};

// Object Name: Class Client.InGameUIManager
// Size: 0x360 // Inherited bytes: 0x170
struct UInGameUIManager : UGameBusinessManager {
	// Fields
	char pad_0x170[0x8]; // Offset: 0x170 // Size: 0x08
	struct TArray<struct UObject*> InGameUIList; // Offset: 0x178 // Size: 0x10
	char pad_0x188[0x68]; // Offset: 0x188 // Size: 0x68
	struct TMap<struct FString, struct TWeakObjectPtr<struct UUAEUserWidget>> WidgetsMap; // Offset: 0x1f0 // Size: 0x50
	struct TMap<int, struct FDynamicWidgetAsyncLoadData> PendingAsyncLoadRequests; // Offset: 0x240 // Size: 0x50
	char pad_0x290[0xd0]; // Offset: 0x290 // Size: 0xd0

	// Functions

	// Object Name: Function Client.InGameUIManager.SubUIWidgetListWithMountData
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SubUIWidgetListWithMountData(struct TArray<struct FInGameWidgetData>& InGameWidgetDataList, struct TArray<struct FString>& GameStatusStrList, bool InPersistentUI, bool InUsedByControler, bool InOberverOnly, int inUIControlState); // Offset: 0x10395e830 // Return & Params: Num(6) Size(0x28)

	// Object Name: Function Client.InGameUIManager.SubUIWidgetList
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SubUIWidgetList(struct TArray<struct FGameWidgetConfig>& InWidgetConfigList, struct TArray<struct FString>& GameStatusStrList, bool InPersistentUI, bool InUsedByControler, bool InOberverOnly); // Offset: 0x10395e634 // Return & Params: Num(5) Size(0x23)

	// Object Name: Function Client.InGameUIManager.SubDynamicUIWidgetList
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SubDynamicUIWidgetList(struct TArray<struct FDynamicWidgetData>& DynamicWidgetMap); // Offset: 0x10395e58c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.InGameUIManager.OnAsyncLoadWidgetClassObj
	// Flags: [Final|Native|Public]
	void OnAsyncLoadWidgetClassObj(struct UObject* InClassObj, int RequestID); // Offset: 0x10395e4d4 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.InGameUIManager.HandleUIMessage
	// Flags: [Final|Native|Public|BlueprintCallable]
	void HandleUIMessage(struct FString UIMessage); // Offset: 0x10395e43c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.InGameUIManager.HandleMountWidget
	// Flags: [Final|Native|Public|BlueprintCallable]
	void HandleMountWidget(struct UInGameUIManager* IngameManager); // Offset: 0x10395e3c0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.InGameUIManager.HandleDynamicDestroy
	// Flags: [Final|Native|Public|BlueprintCallable]
	void HandleDynamicDestroy(); // Offset: 0x10395e3ac // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.InGameUIManager.HandleDynamicCreation
	// Flags: [Final|Native|Public|BlueprintCallable]
	void HandleDynamicCreation(bool isAsyncLoad); // Offset: 0x10395e328 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.InGameUIManager.GetWidgetHandleAsyncWithCallBack
	// Flags: [Final|Native|Public]
	void GetWidgetHandleAsyncWithCallBack(struct FString WidgetKey, DelegateProperty InCallback); // Offset: 0x10395e23c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.InGameUIManager.GetWidgetHandle
	// Flags: [Final|Native|Public]
	struct UUAEUserWidget* GetWidgetHandle(struct FString WidgetKey); // Offset: 0x10395e194 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.InGameUIManager.GetMountCanvasPanel
	// Flags: [Final|Native|Public]
	struct UCanvasPanel* GetMountCanvasPanel(struct FString MountOuterName, struct FString MountName); // Offset: 0x10395e098 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Client.InGameUIManager.ChangeSubUIWidgetList
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void ChangeSubUIWidgetList(struct TArray<struct FGameWidgetConfig>& InWidgetConfigList); // Offset: 0x10395dff0 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class Client.IntlSDKComplianceHelper
// Size: 0x70 // Inherited bytes: 0x28
struct UIntlSDKComplianceHelper : UObject {
	// Fields
	struct FString IntlGameId; // Offset: 0x28 // Size: 0x10
	struct FString IntlSdkUrl; // Offset: 0x38 // Size: 0x10
	struct FString IntlSdkUrlDebug; // Offset: 0x48 // Size: 0x10
	struct FString IntlSdkKey; // Offset: 0x58 // Size: 0x10
	bool IntlSdkEnable; // Offset: 0x68 // Size: 0x01
	bool IntlLogEnable; // Offset: 0x69 // Size: 0x01
	char pad_0x6A[0x6]; // Offset: 0x6a // Size: 0x06

	// Functions

	// Object Name: Function Client.IntlSDKComplianceHelper.SetUserProfile
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetUserProfile(struct FString InRegion); // Offset: 0x10395f538 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.IntlSDKComplianceHelper.SetParentStatus
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetParentStatus(int ParentCertificateStatus); // Offset: 0x10395f4bc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.IntlSDKComplianceHelper.SetLogConfig
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetLogConfig(bool enableConsoleLog, bool enableFileLog, int LogLevel); // Offset: 0x10395f3b0 // Return & Params: Num(3) Size(0x8)

	// Object Name: Function Client.IntlSDKComplianceHelper.SetEUAgreeStatus
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetEUAgreeStatus(int AgreeStatus); // Offset: 0x10395f334 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.IntlSDKComplianceHelper.SetAdulthood
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAdulthood(int AgeStatus); // Offset: 0x10395f2b8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.IntlSDKComplianceHelper.SendEmail
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SendEmail(struct FString InEmail, struct FString UserName); // Offset: 0x10395f1cc // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.IntlSDKComplianceHelper.QueryUserStatus
	// Flags: [Final|Native|Public|BlueprintCallable]
	void QueryUserStatus(); // Offset: 0x10395f1b8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.IntlSDKComplianceHelper.QueryIsEEA
	// Flags: [Final|Native|Public|BlueprintCallable]
	void QueryIsEEA(struct FString InRegion); // Offset: 0x10395f120 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.IntlSDKComplianceHelper.QueryConfig
	// Flags: [Final|Native|Public|BlueprintCallable]
	void QueryConfig(); // Offset: 0x10395f10c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.IntlSDKComplianceHelper.OnMSDKEvnSwitched
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OnMSDKEvnSwitched(int Env); // Offset: 0x10395f090 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.IntlSDKComplianceHelper.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UIntlSDKComplianceHelper* GetInstance(); // Offset: 0x10395f05c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.IntlSDKComplianceHelper.ComplianceInit
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ComplianceInit(); // Offset: 0x10395f048 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.IntlSDKComplianceHelper.CommitBirthday
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CommitBirthday(struct FString InBirthday); // Offset: 0x10395efb0 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class Client.LaggingReporter
// Size: 0x98 // Inherited bytes: 0x28
struct ULaggingReporter : UObject {
	// Fields
	char pad_0x28[0x20]; // Offset: 0x28 // Size: 0x20
	struct UGameFrontendHUD* GameFrontendHUD; // Offset: 0x48 // Size: 0x08
	char pad_0x50[0x48]; // Offset: 0x50 // Size: 0x48
};

// Object Name: Class Client.LiveBroadcast
// Size: 0x38 // Inherited bytes: 0x28
struct ULiveBroadcast : UObject {
	// Fields
	char pad_0x28[0x10]; // Offset: 0x28 // Size: 0x10

	// Functions

	// Object Name: Function Client.LiveBroadcast.SetFullScreen
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetFullScreen(bool FullScreen); // Offset: 0x10395fdd8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.LiveBroadcast.OpenLiveBroadcast
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OpenLiveBroadcast(struct FString URL, float Margin); // Offset: 0x10395fcdc // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.LiveBroadcast.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct ULiveBroadcast* GetInstance(); // Offset: 0x10395fca8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.LiveBroadcast.CloseWebView
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CloseWebView(); // Offset: 0x10395fc94 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.LiveBroadcast.C2JSetString
	// Flags: [Final|Native|Static|Public]
	void C2JSetString(struct FString str); // Offset: 0x10395fbe0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.LiveBroadcast.C2JSetIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	void C2JSetIndex(int Index); // Offset: 0x10395fb64 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class Client.LoadTexture
// Size: 0x28 // Inherited bytes: 0x28
struct ULoadTexture : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function Client.LoadTexture.LoadTexture2D
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UTexture2D* LoadTexture2D(struct FString ImagePath, bool& IsValid, int& OutWidth, int& OutHeight); // Offset: 0x103960190 // Return & Params: Num(5) Size(0x28)

	// Object Name: Function Client.LoadTexture.GetTexture2DFromDiskFile
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UTexture2D* GetTexture2DFromDiskFile(struct FString FilePath); // Offset: 0x1039600f8 // Return & Params: Num(2) Size(0x18)
};

// Object Name: Class Client.LuaBlueprintLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct ULuaBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function Client.LuaBlueprintLibrary.StringToLVar
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FLuaBPVar StringToLVar(struct UObject* WorldContextObject, struct FString Value); // Offset: 0x103962614 // Return & Params: Num(3) Size(0x38)

	// Object Name: Function Client.LuaBlueprintLibrary.SetMemAllocLog
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetMemAllocLog(struct UObject* WorldContextObject, bool bMemAllocLog); // Offset: 0x10396255c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.LuaBlueprintLibrary.RequireAndCallLuaWithArgs
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void RequireAndCallLuaWithArgs(struct UObject* WorldContextObject, struct FString& ModulePath, struct FString& FunctionName, struct FLuaBPVar& InA, struct FLuaBPVar& InB, struct FLuaBPVar& InC, struct FLuaBPVar& InD, struct FLuaBPVar& OutA, struct FLuaBPVar& OutB, struct FLuaBPVar& OutC, struct FLuaBPVar& OutD); // Offset: 0x103962078 // Return & Params: Num(11) Size(0x128)

	// Object Name: Function Client.LuaBlueprintLibrary.ObjectToLVar
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FLuaBPVar ObjectToLVar(struct UObject* WorldContextObject, struct UObject* O); // Offset: 0x103961f98 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.LuaBlueprintLibrary.LVarToString
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FString LVarToString(struct UObject* WorldContextObject, struct FLuaBPVar& Value); // Offset: 0x103961e88 // Return & Params: Num(3) Size(0x38)

	// Object Name: Function Client.LuaBlueprintLibrary.LVarToObject
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct UObject* LVarToObject(struct UObject* WorldContextObject, struct FLuaBPVar& Value); // Offset: 0x103961da0 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.LuaBlueprintLibrary.LVarToInt
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	int LVarToInt(struct UObject* WorldContextObject, struct FLuaBPVar& Value); // Offset: 0x103961cb8 // Return & Params: Num(3) Size(0x2c)

	// Object Name: Function Client.LuaBlueprintLibrary.LVarToFloat
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	float LVarToFloat(struct UObject* WorldContextObject, struct FLuaBPVar& Value); // Offset: 0x103961bd0 // Return & Params: Num(3) Size(0x2c)

	// Object Name: Function Client.LuaBlueprintLibrary.LVarToBool
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	bool LVarToBool(struct UObject* WorldContextObject, struct FLuaBPVar& Value); // Offset: 0x103961ae8 // Return & Params: Num(3) Size(0x29)

	// Object Name: Function Client.LuaBlueprintLibrary.IntToLVar
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FLuaBPVar IntToLVar(struct UObject* WorldContextObject, int Value); // Offset: 0x103961a08 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.LuaBlueprintLibrary.FloatToLVar
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FLuaBPVar FloatToLVar(struct UObject* WorldContextObject, float Value); // Offset: 0x103961928 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.LuaBlueprintLibrary.CallLuaWithMultiArgs
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void CallLuaWithMultiArgs(struct UObject* WorldContextObject, struct FString& Function, struct FLuaBPVar& InA, struct FLuaBPVar& InB, struct FLuaBPVar& InC, struct FLuaBPVar& InD, struct FLuaBPVar& InE, struct FLuaBPVar& InF, struct FLuaBPVar& OutA, struct FLuaBPVar& OutB, struct FLuaBPVar& OutC, struct FLuaBPVar& OutD); // Offset: 0x1039613cc // Return & Params: Num(12) Size(0x158)

	// Object Name: Function Client.LuaBlueprintLibrary.CallLuaWithHUD
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void CallLuaWithHUD(struct UObject* WorldContextObject, struct UGameFrontendHUD* GameFrontendHUD, struct FString& Function, struct FLuaBPVar& InA, struct FLuaBPVar& InB, struct FLuaBPVar& InC, struct FLuaBPVar& InD, struct FLuaBPVar& OutA, struct FLuaBPVar& OutB, struct FLuaBPVar& OutC, struct FLuaBPVar& OutD); // Offset: 0x103960f18 // Return & Params: Num(11) Size(0x120)

	// Object Name: Function Client.LuaBlueprintLibrary.CallLuaWithArgs
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void CallLuaWithArgs(struct UObject* WorldContextObject, struct FString& Function, struct FLuaBPVar& InA, struct FLuaBPVar& InB, struct FLuaBPVar& InC, struct FLuaBPVar& InD, struct FLuaBPVar& OutA, struct FLuaBPVar& OutB, struct FLuaBPVar& OutC, struct FLuaBPVar& OutD); // Offset: 0x103960a9c // Return & Params: Num(10) Size(0x118)

	// Object Name: Function Client.LuaBlueprintLibrary.CallLua
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void CallLua(struct UObject* WorldContextObject, struct FString& Function, struct FLuaBPVar& OutA, struct FLuaBPVar& OutB, struct FLuaBPVar& OutC, struct FLuaBPVar& OutD); // Offset: 0x1039607f0 // Return & Params: Num(6) Size(0x98)

	// Object Name: Function Client.LuaBlueprintLibrary.BoolToLVar
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FLuaBPVar BoolToLVar(struct UObject* WorldContextObject, bool Value); // Offset: 0x103960708 // Return & Params: Num(3) Size(0x30)
};

// Object Name: Class Client.LuaBlueprintMgr
// Size: 0x80 // Inherited bytes: 0x28
struct ULuaBlueprintMgr : UObject {
	// Fields
	struct TMap<struct FString, struct ULuaBluepirntSys*> SystemMap; // Offset: 0x28 // Size: 0x50
	char pad_0x78[0x8]; // Offset: 0x78 // Size: 0x08

	// Functions

	// Object Name: Function Client.LuaBlueprintMgr.GetSystemByName
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct ULuaBluepirntSys* GetSystemByName(struct FString SystemName); // Offset: 0x103962da4 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.LuaBlueprintMgr.AddSystem
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddSystem(struct FString SystemName, struct FString BPPath); // Offset: 0x103962c70 // Return & Params: Num(2) Size(0x20)
};

// Object Name: Class Client.LuaBluepirntSys
// Size: 0xa0 // Inherited bytes: 0x28
struct ULuaBluepirntSys : UObject {
	// Fields
	char pad_0x28[0x60]; // Offset: 0x28 // Size: 0x60
	struct FString LuaFilePath; // Offset: 0x88 // Size: 0x10
	char pad_0x98[0x8]; // Offset: 0x98 // Size: 0x08

	// Functions

	// Object Name: Function Client.LuaBluepirntSys.Init
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void Init(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Client.LuaClassObj
// Size: 0x440 // Inherited bytes: 0x3f0
struct ALuaClassObj : ALuaContext {
	// Fields
	struct UGameBusinessManager* pManager; // Offset: 0x3f0 // Size: 0x08
	char pad_0x3F8[0x2]; // Offset: 0x3f8 // Size: 0x02
	bool bClearSourceCodeAfterInitialized; // Offset: 0x3fa // Size: 0x01
	char pad_0x3FB[0x45]; // Offset: 0x3fb // Size: 0x45

	// Functions

	// Object Name: Function Client.LuaClassObj.SubUIWidgetList
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SubUIWidgetList(struct TArray<struct FGameWidgetConfig>& InWidgetConfigList, struct TArray<struct FString>& GameStatusStrList, bool bPersistentUI, bool InStatusConcern, bool bDynamicWidget, bool bKeepDynamicWidget); // Offset: 0x103963b90 // Return & Params: Num(6) Size(0x24)

	// Object Name: Function Client.LuaClassObj.SubShowHideEvent
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SubShowHideEvent(struct TArray<struct FString>& WidgetPathList); // Offset: 0x103963ae8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.LuaClassObj.SubDefaultSceneCamera
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SubDefaultSceneCamera(int sceneCameraIndex); // Offset: 0x103963a6c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.LuaClassObj.SubDefaultChildUI
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SubDefaultChildUI(struct TArray<struct FString>& childList); // Offset: 0x1039639c4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.LuaClassObj.SubDefaultBaseUI
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SubDefaultBaseUI(struct FString baseUI); // Offset: 0x10396392c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.LuaClassObj.SubCollapseWidgetList
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SubCollapseWidgetList(struct FString RootWidgetName, struct TArray<struct FString>& ChildWidgetNames); // Offset: 0x103963830 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.LuaClassObj.SetWidgetZorder
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetWidgetZorder(int Index, int ZOrder); // Offset: 0x10396377c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.LuaClassObj.RestoreWidgetZorder
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RestoreWidgetZorder(int Index); // Offset: 0x103963700 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.LuaClassObj.RestoreAllWidgetZorder
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RestoreAllWidgetZorder(); // Offset: 0x1039636ec // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.LuaClassObj.IsTopStackPanel
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsTopStackPanel(); // Offset: 0x1039636b8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.LuaClassObj.IsPushedPanel
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsPushedPanel(); // Offset: 0x103963684 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.LuaClassObj.InCombatState
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool InCombatState(); // Offset: 0x103963650 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.LuaClassObj.HandleUIMessageNoFetch
	// Flags: [Final|Native|Public|BlueprintCallable]
	void HandleUIMessageNoFetch(struct FString UIMessage); // Offset: 0x1039635b8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.LuaClassObj.HandleUIMessage
	// Flags: [Final|Native|Public|BlueprintCallable]
	void HandleUIMessage(struct FString UIMessage); // Offset: 0x103963520 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.LuaClassObj.HandleStopAsyncLoad
	// Flags: [Final|Native|Public|BlueprintCallable]
	void HandleStopAsyncLoad(); // Offset: 0x10396350c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.LuaClassObj.HandleDynamicDestroy
	// Flags: [Final|Native|Public|BlueprintCallable]
	void HandleDynamicDestroy(); // Offset: 0x1039634f8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.LuaClassObj.HandleDynamicCreationInternal
	// Flags: [Final|Native|Public|BlueprintCallable]
	void HandleDynamicCreationInternal(bool isAsyncLoad); // Offset: 0x103963474 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.LuaClassObj.HandleDynamicCreation
	// Flags: [Final|Native|Public|BlueprintCallable]
	void HandleDynamicCreation(bool isAsyncLoad); // Offset: 0x1039633f0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.LuaClassObj.HandleCollapseWidgetList
	// Flags: [Final|Native|Public|BlueprintCallable]
	void HandleCollapseWidgetList(struct FString RootWidgetName); // Offset: 0x103963358 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.LuaClassObj.GetTopStackPanelSrcTag
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetTopStackPanelSrcTag(); // Offset: 0x1039632f4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.LuaClassObj.GetTopStackPanelDstTag
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetTopStackPanelDstTag(); // Offset: 0x103963290 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.LuaClassObj.GetGameStatus
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetGameStatus(); // Offset: 0x10396322c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.LuaClassObj.ChangeSubUIWidgetList
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void ChangeSubUIWidgetList(struct TArray<struct FGameWidgetConfig>& InWidgetConfigList); // Offset: 0x103963184 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.LuaClassObj.AddToTopStackPanel
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddToTopStackPanel(); // Offset: 0x103963170 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Client.MaskBox
// Size: 0x160 // Inherited bytes: 0x118
struct UMaskBox : UContentWidget {
	// Fields
	int InvalidateFrameCount; // Offset: 0x114 // Size: 0x04
	int Phase; // Offset: 0x118 // Size: 0x04
	int PhaseCount; // Offset: 0x11c // Size: 0x04
	bool IgnoreStretch; // Offset: 0x120 // Size: 0x01
	bool UpdateRenderTarget; // Offset: 0x121 // Size: 0x01
	int MaskType; // Offset: 0x124 // Size: 0x04
	struct FVector2D MaskTransformPivot; // Offset: 0x128 // Size: 0x08
	struct FVector2D MaskTransformScale; // Offset: 0x130 // Size: 0x08
	float MaskTransformAngle; // Offset: 0x138 // Size: 0x04
	char pad_0x13E[0x2]; // Offset: 0x13e // Size: 0x02
	struct UMaterialInterface* MaskMaterial; // Offset: 0x140 // Size: 0x08
	struct UTexture2D* MaskTexture; // Offset: 0x148 // Size: 0x08
	char pad_0x150[0x10]; // Offset: 0x150 // Size: 0x10

	// Functions

	// Object Name: Function Client.MaskBox.SetMaskTransformScale
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetMaskTransformScale(struct FVector2D Scale); // Offset: 0x103964814 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.MaskBox.SetMaskTransformPivot
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetMaskTransformPivot(struct FVector2D Pivot); // Offset: 0x10396479c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.MaskBox.SetMaskTransformAngle
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMaskTransformAngle(float Angle); // Offset: 0x103964720 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.MaskBox.SetMaskMaterial
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMaskMaterial(struct UMaterialInterface* EffectMaterial); // Offset: 0x1039646a4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.MaskBox.SetBrushFromTexture
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetBrushFromTexture(struct UTexture2D* Texture); // Offset: 0x103964628 // Return & Params: Num(1) Size(0x8)

	// Object Name: DelegateFunction Client.MaskBox.GetVector2D__DelegateSignature
	// Flags: [Public|Delegate|HasDefaults]
	struct FVector2D GetVector2D__DelegateSignature(); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.MaskBox.GetMaskMaterial
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UMaterialInstanceDynamic* GetMaskMaterial(); // Offset: 0x1039645f4 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class Client.MaskImage
// Size: 0x290 // Inherited bytes: 0x250
struct UMaskImage : UImage {
	// Fields
	bool bIgnoreStretch; // Offset: 0x250 // Size: 0x01
	char pad_0x251[0x3]; // Offset: 0x251 // Size: 0x03
	int MaskType; // Offset: 0x254 // Size: 0x04
	struct FVector2D MaskTransformPivot; // Offset: 0x258 // Size: 0x08
	struct FVector2D MaskTransformScale; // Offset: 0x260 // Size: 0x08
	float MaskTransformAngle; // Offset: 0x268 // Size: 0x04
	char pad_0x26C[0x4]; // Offset: 0x26c // Size: 0x04
	struct UMaterialInterface* MaskMaterial; // Offset: 0x270 // Size: 0x08
	struct UTexture2D* MaskTexture; // Offset: 0x278 // Size: 0x08
	char pad_0x280[0x10]; // Offset: 0x280 // Size: 0x10

	// Functions

	// Object Name: Function Client.MaskImage.SetMaskTransformScale
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetMaskTransformScale(struct FVector2D Scale); // Offset: 0x1039670e0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.MaskImage.SetMaskTransformPivot
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetMaskTransformPivot(struct FVector2D Pivot); // Offset: 0x103967068 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.MaskImage.SetMaskTransformAngle
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMaskTransformAngle(float Angle); // Offset: 0x103966fec // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.MaskImage.SetMaskTexture
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMaskTexture(struct UTexture2D* Texture); // Offset: 0x103966f70 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.MaskImage.SetMaskMaterial
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMaskMaterial(struct UMaterialInterface* InEffectMaterial); // Offset: 0x103966ef4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.MaskImage.GetMaskMaterial
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UMaterialInstanceDynamic* GetMaskMaterial(); // Offset: 0x103966ec0 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class Client.MidasManager
// Size: 0x1c8 // Inherited bytes: 0x28
struct UMidasManager : UObject {
	// Fields
	char pad_0x28[0x30]; // Offset: 0x28 // Size: 0x30
	struct FString payChannel; // Offset: 0x58 // Size: 0x10
	struct FString midasIdc; // Offset: 0x68 // Size: 0x10
	struct FString ZoneID; // Offset: 0x78 // Size: 0x10
	struct FString goodsZoneID; // Offset: 0x88 // Size: 0x10
	struct FString offerID; // Offset: 0x98 // Size: 0x10
	int iAOSShop; // Offset: 0xa8 // Size: 0x04
	char pad_0xAC[0x4]; // Offset: 0xac // Size: 0x04
	struct FString offerID_H5; // Offset: 0xb0 // Size: 0x10
	struct FString payChannel_H5; // Offset: 0xc0 // Size: 0x10
	char pad_0xD0[0x70]; // Offset: 0xd0 // Size: 0x70
	struct FString PAY_TYPE_UC; // Offset: 0x140 // Size: 0x10
	struct FString PAY_TYPE_GOODS; // Offset: 0x150 // Size: 0x10
	struct FString PAY_TYPE_SUBSCRIBE; // Offset: 0x160 // Size: 0x10
	struct UGameFrontendHUD* GameFrontendHUD; // Offset: 0x170 // Size: 0x08
	char pad_0x178[0x50]; // Offset: 0x178 // Size: 0x50

	// Functions

	// Object Name: Function Client.MidasManager.TickMidasPackage
	// Flags: [Final|Native|Private]
	void TickMidasPackage(); // Offset: 0x10396900c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.MidasManager.Tick
	// Flags: [Final|Native|Public]
	void Tick(float DeltaTime); // Offset: 0x103968f90 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.MidasManager.SwitchPayChannel
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SwitchPayChannel(enum class EMidasMultiPayChannelSwitch switchChannel); // Offset: 0x103968f14 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.MidasManager.Subscribe
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Subscribe(struct FString productid, int payItem, struct FString country, struct FString currency, struct FString serviceCode, struct FString ServiceName, bool autoPay); // Offset: 0x103968be4 // Return & Params: Num(7) Size(0x59)

	// Object Name: Function Client.MidasManager.SetZoneID
	// Flags: [Final|Native|Public]
	void SetZoneID(struct FString inZoneID, struct FString inGoodsZoneID); // Offset: 0x103968ab0 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.MidasManager.SetRoleInfo
	// Flags: [Final|Native|Public]
	void SetRoleInfo(int InChannel, struct FString OpenID); // Offset: 0x1039689b4 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.MidasManager.SetMidasIDC
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMidasIDC(struct FString idc); // Offset: 0x1039688f8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.MidasManager.SetJPAge
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetJPAge(int Age); // Offset: 0x10396887c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.MidasManager.SetFrontendHUD
	// Flags: [Final|Native|Public]
	void SetFrontendHUD(struct UGameFrontendHUD* InFrontendHUD); // Offset: 0x103968800 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.MidasManager.Reprovide
	// Flags: [Final|Native|Public]
	void Reprovide(); // Offset: 0x1039687ec // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.MidasManager.Pay
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Pay(struct FString productid, int payItem, struct FString country, struct FString currency); // Offset: 0x1039685fc // Return & Params: Num(4) Size(0x38)

	// Object Name: Function Client.MidasManager.ModifySubscribe
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ModifySubscribe(struct FString oldProductId, struct FString newProductid, int payItem, struct FString country, struct FString currency, struct FString serviceCode, struct FString ServiceName, bool autoPay); // Offset: 0x103968250 // Return & Params: Num(8) Size(0x69)

	// Object Name: Function Client.MidasManager.IsH5PayEnable
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsH5PayEnable(); // Offset: 0x10396821c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.MidasManager.Initialize
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Initialize(enum class EMidasMultiPayChannelSwitch envior); // Offset: 0x1039681a0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.MidasManager.H5Pay
	// Flags: [Final|Native|Public|BlueprintCallable]
	void H5Pay(struct FString country); // Offset: 0x1039680e4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.MidasManager.GoodsPresent
	// Flags: [Final|Native|Public|BlueprintCallable]
	void GoodsPresent(struct FString productid, int payItem, struct FString price, struct FString country, struct FString currency, struct FString MetaData); // Offset: 0x103967e04 // Return & Params: Num(6) Size(0x58)

	// Object Name: Function Client.MidasManager.Goods
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Goods(struct FString productid, int payItem, struct FString price, struct FString country, struct FString currency); // Offset: 0x103967b9c // Return & Params: Num(5) Size(0x48)

	// Object Name: Function Client.MidasManager.GetProductInfo
	// Flags: [Final|Native|Public|BlueprintCallable]
	void GetProductInfo(struct TMap<struct FString, struct FString> listProductID); // Offset: 0x103967adc // Return & Params: Num(1) Size(0x50)

	// Object Name: Function Client.MidasManager.getPF
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString getPF(); // Offset: 0x103967a78 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.MidasManager.GetPayEnvironment
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetPayEnvironment(); // Offset: 0x103967a14 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.MidasManager.GetPayChannel
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetPayChannel(); // Offset: 0x1039679b0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.MidasManager.GetPackChannel
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetPackChannel(); // Offset: 0x10396794c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.MidasManager.GetOfferID
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetOfferID(); // Offset: 0x1039678e8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.MidasManager.GetNativePackageTag
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetNativePackageTag(); // Offset: 0x103967884 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.MidasManager.GetMPInfo
	// Flags: [Final|Native|Public|BlueprintCallable]
	void GetMPInfo(struct FString country, struct FString currency); // Offset: 0x103967750 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.MidasManager.GetIntroPrice
	// Flags: [Final|Native|Public|BlueprintCallable]
	void GetIntroPrice(struct TMap<struct FString, struct FString> listProductID); // Offset: 0x103967690 // Return & Params: Num(1) Size(0x50)

	// Object Name: Function Client.MidasManager.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UMidasManager* GetInstance(); // Offset: 0x10396765c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.MidasManager.GetInIDC
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetInIDC(); // Offset: 0x1039675f8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.MidasManager.GetAOSSHOP
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetAOSSHOP(); // Offset: 0x1039675c4 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class Client.NewButton
// Size: 0x520 // Inherited bytes: 0x518
struct UNewButton : UButton {
	// Fields
	enum class EButtonClickSoundTypes ClickSound; // Offset: 0x518 // Size: 0x01
	char pad_0x519[0x7]; // Offset: 0x519 // Size: 0x07

	// Functions

	// Object Name: Function Client.NewButton.SetClickSound
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetClickSound(enum class EButtonClickSoundTypes inSoundType); // Offset: 0x103969898 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class Client.PlatformAppraise
// Size: 0x28 // Inherited bytes: 0x28
struct UPlatformAppraise : UObject {
};

// Object Name: Class Client.PublishAreaMgr
// Size: 0x28 // Inherited bytes: 0x28
struct UPublishAreaMgr : UObject {
	// Functions

	// Object Name: Function Client.PublishAreaMgr.SelectArea
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SelectArea(struct FString InArea); // Offset: 0x103969f20 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.PublishAreaMgr.IsMultiAreaBuild
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsMultiAreaBuild(); // Offset: 0x103969eec // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.PublishAreaMgr.GetString
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetString(struct FString InKey, struct FString InDefaultValue); // Offset: 0x103969dd8 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.PublishAreaMgr.GetPublishAreas
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetPublishAreas(); // Offset: 0x103969d74 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.PublishAreaMgr.GetInt
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetInt(struct FString InKey, int InDefaultValue); // Offset: 0x103969c9c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Client.PublishAreaMgr.GetBool
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool GetBool(struct FString InKey, bool InDefaultValue); // Offset: 0x103969bbc // Return & Params: Num(3) Size(0x12)

	// Object Name: Function Client.PublishAreaMgr.GetArea
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetArea(); // Offset: 0x103969b58 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class Client.ScreenInput
// Size: 0x70 // Inherited bytes: 0x28
struct UScreenInput : UObject {
	// Fields
	struct FScriptMulticastDelegate OnScreenTouch; // Offset: 0x28 // Size: 0x10
	DelegateProperty OnMouseButtonUp; // Offset: 0x38 // Size: 0x10
	DelegateProperty OnMouseButtonDown; // Offset: 0x48 // Size: 0x10
	char pad_0x58[0x18]; // Offset: 0x58 // Size: 0x18

	// Functions

	// Object Name: Function Client.ScreenInput.Shutdown
	// Flags: [Final|Native|Public]
	void Shutdown(); // Offset: 0x10396a374 // Return & Params: Num(0) Size(0x0)

	// Object Name: DelegateFunction Client.ScreenInput.OnScreenTouch__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnScreenTouch__DelegateSignature(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: DelegateFunction Client.ScreenInput.OnMouseButtonDown__DelegateSignature
	// Flags: [Public|Delegate|HasOutParms|HasDefaults]
	void OnMouseButtonDown__DelegateSignature(struct FVector2D& ContainerPos); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScreenInput.Init
	// Flags: [Final|Native|Public]
	void Init(); // Offset: 0x10396a360 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Client.ScreenshotMaker
// Size: 0x28 // Inherited bytes: 0x28
struct UScreenshotMaker : UObject {
	// Functions

	// Object Name: Function Client.ScreenshotMaker.SetDefaultShowUI
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetDefaultShowUI(bool ShowUI); // Offset: 0x10396b0d0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScreenshotMaker.SaveToPhotosAlbumEx
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool SaveToPhotosAlbumEx(struct FString pathStr); // Offset: 0x10396b014 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScreenshotMaker.SaveToPhotosAlbum
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool SaveToPhotosAlbum(struct FString pathStr); // Offset: 0x10396af58 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScreenshotMaker.ResizePicture
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ResizePicture(struct FString pathStr, float Scale, struct FString savePathStr); // Offset: 0x10396ade0 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Client.ScreenshotMaker.ReMakePicture
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	void ReMakePicture(struct FString pathStr, struct FVector4 Vector4); // Offset: 0x10396ace0 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScreenshotMaker.ReMakeMomentPicture
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	struct FString ReMakeMomentPicture(struct FString srcPath, struct FVector4 Vector4); // Offset: 0x10396abb0 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.ScreenshotMaker.MakePictureWithName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString MakePictureWithName(struct FString PicName); // Offset: 0x10396aacc // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScreenshotMaker.MakePictureToLua
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString MakePictureToLua(struct UGameFrontendHUD* InFrontendHUD, struct FString tableName, struct FString FunctionName, bool isShowUI); // Offset: 0x10396a8e0 // Return & Params: Num(5) Size(0x40)

	// Object Name: Function Client.ScreenshotMaker.MakePicture
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString MakePicture(bool isShowUI); // Offset: 0x10396a834 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScreenshotMaker.MakeBugReprotPic
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString MakeBugReprotPic(bool isShowUI); // Offset: 0x10396a788 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScreenshotMaker.HasCaptured
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool HasCaptured(struct FString pathStr); // Offset: 0x10396a6cc // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScreenshotMaker.GetSaveStatus
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetSaveStatus(); // Offset: 0x10396a698 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScreenshotMaker.GetPhotoHash
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetPhotoHash(struct FString pathStr, int algorithmVersion); // Offset: 0x10396a59c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Client.ScreenshotMaker.GetMomentThumbPictureFullPathFiles
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct TArray<struct FString> GetMomentThumbPictureFullPathFiles(); // Offset: 0x10396a538 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScreenshotMaker.GetMomentPictureFullPathFiles
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct TArray<struct FString> GetMomentPictureFullPathFiles(); // Offset: 0x10396a4d4 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class Client.ScriptHelperClient
// Size: 0x28 // Inherited bytes: 0x28
struct UScriptHelperClient : UObject {
	// Functions

	// Object Name: Function Client.ScriptHelperClient.ZLIBDecompress
	// Flags: [Final|Native|Static|Public]
	struct FString ZLIBDecompress(struct FString CompressedData, int CompressedSize, int UnCompressedSize); // Offset: 0x103989954 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function Client.ScriptHelperClient.ZLIBCompress_LuaState
	// Flags: [Final|Native|Static|Public]
	int ZLIBCompress_LuaState(); // Offset: 0x10398993c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.WechatShareWithUrlInfo
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void WechatShareWithUrlInfo(struct TScriptInterface<Class>& ClientNetInterface, struct FString _descShare, struct FString _titleShare, struct FString _imgPath, struct FString _url, int _shareScene); // Offset: 0x103989720 // Return & Params: Num(6) Size(0x54)

	// Object Name: Function Client.ScriptHelperClient.WeChatShareWithMiniApp
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void WeChatShareWithMiniApp(struct TScriptInterface<Class>& ClientNetInterface, struct FString _descShare, struct FString _titleShare, struct FString _imgPath, struct FString _webpageUrl, struct FString _userName, struct FString _path, struct FString _messageExt, struct FString _messageAction, int _shareScene); // Offset: 0x1039893a8 // Return & Params: Num(10) Size(0x94)

	// Object Name: Function Client.ScriptHelperClient.WechatShareToFriend
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void WechatShareToFriend(struct TScriptInterface<Class>& ClientNetInterface, struct FString OpenID, struct FString Title, struct FString Desc, struct FString mediaId, struct FString messageExt, struct FString mediaTagName, struct FString msdkExtInfo); // Offset: 0x1039890d0 // Return & Params: Num(8) Size(0x80)

	// Object Name: Function Client.ScriptHelperClient.WechatShare
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void WechatShare(struct TScriptInterface<Class>& ClientNetInterface, struct FString _descShare, struct FString _titleShare, struct FString _imgPath, struct FString _mediaTagName, struct FString _messageExt); // Offset: 0x103988ea0 // Return & Params: Num(6) Size(0x60)

	// Object Name: Function Client.ScriptHelperClient.WechatQueryGroup
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void WechatQueryGroup(struct TScriptInterface<Class>& ClientNetInterface, struct FString unionId, struct FString OpenIdList); // Offset: 0x103988d6c // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.WechatJoinGroup
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void WechatJoinGroup(struct TScriptInterface<Class>& ClientNetInterface, struct FString unionId, struct FString chatRoomNickName); // Offset: 0x103988c38 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.WechatCreateGroup
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void WechatCreateGroup(struct TScriptInterface<Class>& ClientNetInterface, struct FString unionId, struct FString chatRoomName, struct FString chatRoomNickName); // Offset: 0x103988ab0 // Return & Params: Num(4) Size(0x40)

	// Object Name: Function Client.ScriptHelperClient.WakeupFromSuspendSound
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void WakeupFromSuspendSound(); // Offset: 0x103988a9c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.VPNTearDown
	// Flags: [Final|Native|Static|Public]
	int VPNTearDown(); // Offset: 0x103988a68 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.VPNSetUserInfo
	// Flags: [Final|Native|Static|Public]
	int VPNSetUserInfo(struct FString InUserId, struct FString InUserToken, struct FString InAppId); // Offset: 0x103988928 // Return & Params: Num(4) Size(0x34)

	// Object Name: Function Client.ScriptHelperClient.VPNSetPortRange
	// Flags: [Final|Native|Static|Public]
	int VPNSetPortRange(int Min, int Max); // Offset: 0x103988874 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.VPNSetNodelist
	// Flags: [Final|Native|Static|Public]
	int VPNSetNodelist(struct FString InNodelist); // Offset: 0x1039887dc // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.ScriptHelperClient.VPNPrepare
	// Flags: [Final|Native|Static|Public]
	int VPNPrepare(); // Offset: 0x1039887a8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.VPNHandUp
	// Flags: [Final|Native|Static|Public]
	int VPNHandUp(); // Offset: 0x103988774 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.VPNGetNodeRegionList
	// Flags: [Final|Native|Static|Public]
	struct FString VPNGetNodeRegionList(); // Offset: 0x103988710 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.VPNDialUp
	// Flags: [Final|Native|Static|Public]
	int VPNDialUp(struct FString InRegion); // Offset: 0x103988678 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.ScriptHelperClient.Vibrate
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void Vibrate(int Param); // Offset: 0x103988604 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.UserName
	// Flags: [Final|Native|Static|Public]
	struct FString UserName(); // Offset: 0x1039885a0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.UrlEncode
	// Flags: [Final|Native|Static|Public]
	struct FString UrlEncode(struct FString UnencodedString); // Offset: 0x1039884e0 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.UQMSetAppVersion
	// Flags: [Final|Native|Static|Public]
	void UQMSetAppVersion(struct FString Version); // Offset: 0x103988450 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.UQMBuglyPutUserData
	// Flags: [Final|Native|Static|Public]
	void UQMBuglyPutUserData(struct FString Key, struct FString Value); // Offset: 0x10398836c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.UQMBuglyPostExceptionFull
	// Flags: [Final|Native|Static|Public]
	void UQMBuglyPostExceptionFull(int Category, struct FString Name, struct FString Msg, struct FString stack); // Offset: 0x1039881f8 // Return & Params: Num(4) Size(0x38)

	// Object Name: Function Client.ScriptHelperClient.UQMBuglyPostException
	// Flags: [Final|Native|Static|Public]
	void UQMBuglyPostException(int Category, struct FString Reason); // Offset: 0x10398812c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.UQMBuglyLog
	// Flags: [Final|Native|Static|Public]
	void UQMBuglyLog(int Level, struct FString Tag, struct FString Log, bool needDump); // Offset: 0x103987fc4 // Return & Params: Num(4) Size(0x29)

	// Object Name: Function Client.ScriptHelperClient.UpdatePublishRegionForBattle
	// Flags: [Final|Native|Static|Public]
	void UpdatePublishRegionForBattle(); // Offset: 0x103987fb0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.UpdateMemResource
	// Flags: [Final|Native|Static|Public]
	void UpdateMemResource(struct FString ResType, struct FString KeyWord); // Offset: 0x103987e84 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.UpdateAkAudioDeviceBluetoothDelay
	// Flags: [Final|Native|Static|Public]
	void UpdateAkAudioDeviceBluetoothDelay(int InDelayTime); // Offset: 0x103987e10 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.UnsubscribeFromTopic
	// Flags: [Final|Native|Static|Public]
	void UnsubscribeFromTopic(struct FString Topic); // Offset: 0x103987d80 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.UnmountPakFile
	// Flags: [Final|Native|Static|Public]
	bool UnmountPakFile(struct FString InPakFilename); // Offset: 0x103987ce8 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.UnitTestODPaksOpen
	// Flags: [Final|Native|Static|Public]
	void UnitTestODPaksOpen(int fileCount, int Times, int threadNum); // Offset: 0x103987c00 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.TVMacroTesting
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void TVMacroTesting(); // Offset: 0x103987bec // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.TriggerTouchEvent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void TriggerTouchEvent(float X, float Y, int event_type); // Offset: 0x103987b04 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.TriggerOOMCrash
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void TriggerOOMCrash(); // Offset: 0x103987af0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.TriggerLoginCrashTest
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void TriggerLoginCrashTest(int Type); // Offset: 0x103987a7c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.TriggerLobbyCrashTest
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void TriggerLobbyCrashTest(int Type); // Offset: 0x103987a08 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.TriggerBlockAndroidANR
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void TriggerBlockAndroidANR(); // Offset: 0x1039879f4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.TGPASwitchRichTapMode
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void TGPASwitchRichTapMode(struct FString Mode); // Offset: 0x103987940 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.TGPAStopRichTap
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void TGPAStopRichTap(); // Offset: 0x10398792c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.TGPAStartRichTapWithData
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void TGPAStartRichTapWithData(struct FString InKey, struct TMap<struct FString, struct FString>& InMapData); // Offset: 0x103987830 // Return & Params: Num(2) Size(0x60)

	// Object Name: Function Client.ScriptHelperClient.TGPAStartRichTap
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void TGPAStartRichTap(struct FString Filename); // Offset: 0x10398777c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.TGPALoadHeFile
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString TGPALoadHeFile(struct FString StrFilePath); // Offset: 0x1039876bc // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.TGPAGetRichTapSupport
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString TGPAGetRichTapSupport(); // Offset: 0x103987658 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.TGPAGetRichTapAmplitudeSupport
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString TGPAGetRichTapAmplitudeSupport(); // Offset: 0x1039875f4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.Tex_UpdateMemResource
	// Flags: [Final|Native|Static|Public]
	void Tex_UpdateMemResource(struct FString KeyWord); // Offset: 0x103987540 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.Tex_DumpMemObjectInfo
	// Flags: [Final|Native|Static|Public]
	void Tex_DumpMemObjectInfo(struct FString KeyWord); // Offset: 0x10398748c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.TestSaveStringToFile
	// Flags: [Final|Native|Static|Public]
	void TestSaveStringToFile(struct FString String, struct FString TargetDir, struct FString FullPathName); // Offset: 0x103987354 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.TestLoadGameSlotMultiThread
	// Flags: [Final|Native|Static|Public]
	void TestLoadGameSlotMultiThread(); // Offset: 0x103987340 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.TestLoadGameSlot
	// Flags: [Final|Native|Static|Public]
	void TestLoadGameSlot(); // Offset: 0x10398732c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.Tea2Encrypt_LuaState
	// Flags: [Final|Native|Static|Public]
	int Tea2Encrypt_LuaState(); // Offset: 0x103987314 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.Tea2Decrypt_LuaState
	// Flags: [Final|Native|Static|Public]
	int Tea2Decrypt_LuaState(); // Offset: 0x1039872fc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.TapmReport
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void TapmReport(int Type, struct FString ExtraInfo, bool send); // Offset: 0x1039871c0 // Return & Params: Num(3) Size(0x19)

	// Object Name: Function Client.ScriptHelperClient.TapmPostLargeValueS
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void TapmPostLargeValueS(struct FString catgory, struct FString Key, struct FString Value); // Offset: 0x10398701c // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.TapmMarkTime
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void TapmMarkTime(int Type); // Offset: 0x103986fa8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.TapmMarkLevelFin
	// Flags: [Final|Native|Static|Public]
	void TapmMarkLevelFin(); // Offset: 0x103986f94 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.TApmDisconnectReport
	// Flags: [Final|Native|Static|Public]
	void TApmDisconnectReport(struct UGameFrontendHUD* GameFrontendHUD, int EventId); // Offset: 0x103986ee4 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.TApmDataReport
	// Flags: [Final|Native|Static|Public]
	void TApmDataReport(struct UGameFrontendHUD* GameFrontendHUD, int EventId, struct FString EventInfo); // Offset: 0x103986db0 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.SyncLoadPackageUpdateCurrentWorldName
	// Flags: [Final|Native|Static|Public]
	void SyncLoadPackageUpdateCurrentWorldName(struct FString WorldName); // Offset: 0x103986cfc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.SyncLoadPackageInitialize
	// Flags: [Final|Native|Static|Public]
	void SyncLoadPackageInitialize(struct FString CfgFilename); // Offset: 0x103986c48 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.SyncLoadPackageInit
	// Flags: [Final|Native|Static|Public]
	void SyncLoadPackageInit(struct FString ConfigFilename); // Offset: 0x103986b94 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.SyncLoadPackageInfoCollect
	// Flags: [Final|Native|Static|Public]
	void SyncLoadPackageInfoCollect(struct FString PackageName, struct FString WorldName); // Offset: 0x103986a68 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.SyncLoadPackageGetPackageListForWorld
	// Flags: [Final|Native|Static|Public]
	struct TArray<struct FString> SyncLoadPackageGetPackageListForWorld(struct FString WorldName); // Offset: 0x103986984 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.SyncLoadPackageDumpInfo
	// Flags: [Final|Native|Static|Public]
	void SyncLoadPackageDumpInfo(struct FString DumpFilename); // Offset: 0x1039868d0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.SwitchUser
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void SwitchUser(struct TScriptInterface<Class>& ClientNetInterface, bool useExternalAccount); // Offset: 0x103986808 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.SwitchSceneCamera
	// Flags: [Final|Native|Static|Public]
	void SwitchSceneCamera(struct UGameFrontendHUD* GameFrontendHUD, struct FString SceneCameraName, float blendTime, bool bForce); // Offset: 0x10398668c // Return & Params: Num(4) Size(0x1d)

	// Object Name: Function Client.ScriptHelperClient.SwitchCampRoom
	// Flags: [Final|Native|Static|Public]
	void SwitchCampRoom(struct UGameFrontendHUD* GameFrontendHUD, int campMode); // Offset: 0x1039865dc // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.SuspendSound
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SuspendSound(); // Offset: 0x1039865c8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.SubscribeToTopic
	// Flags: [Final|Native|Static|Public]
	void SubscribeToTopic(struct FString Topic); // Offset: 0x103986538 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.StringToJsonString
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString StringToJsonString(struct FString String); // Offset: 0x103986478 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.StringToFMargin
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FMargin StringToFMargin(struct FString MarginStr); // Offset: 0x1039863d0 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.StopUIStat
	// Flags: [Final|Native|Static|Public]
	void StopUIStat(struct FString UIName, bool bReport); // Offset: 0x1039862d4 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.StopTouchRecord
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FTouchInputRecord StopTouchRecord(); // Offset: 0x103986270 // Return & Params: Num(1) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.StopTask
	// Flags: [Final|Native|Static|Public]
	bool StopTask(struct UGameFrontendHUD* GameFrontendHUD, uint64 TaskId); // Offset: 0x1039861bc // Return & Params: Num(3) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.StopShaderPrecompile
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool StopShaderPrecompile(); // Offset: 0x103986188 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.StopPuffer
	// Flags: [Final|Native|Static|Public]
	void StopPuffer(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103986114 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.StopHapticsEngine
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void StopHapticsEngine(); // Offset: 0x103986100 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.StopH5Downloading
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void StopH5Downloading(); // Offset: 0x1039860ec // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.StopCampMode
	// Flags: [Final|Native|Static|Public]
	void StopCampMode(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103986078 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.StartUIStat
	// Flags: [Final|Native|Static|Public]
	void StartUIStat(struct FString UIName); // Offset: 0x103985fc4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.StartTrace
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void StartTrace(struct FString InHost, int InStartTTL, int InMaxTTL, int InCount); // Offset: 0x103985e78 // Return & Params: Num(4) Size(0x1c)

	// Object Name: Function Client.ScriptHelperClient.StartTouchRecord
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void StartTouchRecord(); // Offset: 0x103985e64 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.StartShaderPrecompile
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool StartShaderPrecompile(); // Offset: 0x103985e30 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.StartOpenReadCollect
	// Flags: [Final|Native|Static|Public]
	void StartOpenReadCollect(struct UGameFrontendHUD* GameFrontendHUD, bool bStart); // Offset: 0x103985d78 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.StartHapticsEngine
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void StartHapticsEngine(DelegateProperty Callback); // Offset: 0x103985cf0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.StartGrayUpdate
	// Flags: [Final|Native|Static|Public]
	bool StartGrayUpdate(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103985c74 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.StartDownloadItem
	// Flags: [Final|Native|Static|Public]
	void StartDownloadItem(uint32_t ItemID, uint32_t Priority, DelegateProperty OnItemDownloadDelegate); // Offset: 0x103985b78 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.StartDolphinResourceUpdate
	// Flags: [Final|Native|Static|Public]
	void StartDolphinResourceUpdate(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103985b04 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.StartCDNUpdateAfterDolphinUpdateFailed
	// Flags: [Final|Native|Static|Public]
	void StartCDNUpdateAfterDolphinUpdateFailed(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103985a90 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.StartCampMode
	// Flags: [Final|Native|Static|Public]
	void StartCampMode(struct UGameFrontendHUD* GameFrontendHUD, struct FString ZombieCampRoomName, struct FString ManCampRoomName, struct FString userId); // Offset: 0x10398591c // Return & Params: Num(4) Size(0x38)

	// Object Name: Function Client.ScriptHelperClient.StartBatchDownloadItem
	// Flags: [Final|Native|Static|Public]
	void StartBatchDownloadItem(struct TArray<uint32_t> ItemIDs, uint32_t Priority, DelegateProperty OnBatchItemDownloadDelegate); // Offset: 0x1039857ac // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Client.ScriptHelperClient.ShutdownUnrealNetwork
	// Flags: [Final|Native|Static|Public]
	void ShutdownUnrealNetwork(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103985738 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.ShutdownPuffer
	// Flags: [Final|Native|Static|Public]
	void ShutdownPuffer(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x1039856c4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.ShrinkUObjectHashTables
	// Flags: [Final|Native|Static|Public]
	void ShrinkUObjectHashTables(); // Offset: 0x1039856b0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.ShowWebView
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ShowWebView(bool Show); // Offset: 0x103985634 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.ShowVLink
	// Flags: [Final|Native|Static|Public]
	void ShowVLink(struct FString jsonString, struct FString signString); // Offset: 0x103985550 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.ShowVideoListDialog
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ShowVideoListDialog(); // Offset: 0x10398553c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.ShowScreenDebugMessage
	// Flags: [Final|Native|Static|Public]
	void ShowScreenDebugMessage(struct FString Message); // Offset: 0x103985488 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.ShowH5WebView
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ShowH5WebView(); // Offset: 0x103985474 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.ShorterStreamingDistanceWhenGameEnd
	// Flags: [Final|Native|Static|Public]
	void ShorterStreamingDistanceWhenGameEnd(uint32_t Distance); // Offset: 0x103985400 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.ShareWithUploadPhotoByChannel
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void ShareWithUploadPhotoByChannel(struct TScriptInterface<Class>& ClientNetInterface, struct FString _imgPath, int _channel, struct FString _url); // Offset: 0x10398528c // Return & Params: Num(4) Size(0x38)

	// Object Name: Function Client.ScriptHelperClient.ShareWithPhotoByChannel
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void ShareWithPhotoByChannel(struct TScriptInterface<Class>& ClientNetInterface, struct FString _imgPath, struct FString _mediaTagName, struct FString _messageExt, struct FString _messageAction, int _channel, struct FString _url); // Offset: 0x10398501c // Return & Params: Num(7) Size(0x68)

	// Object Name: Function Client.ScriptHelperClient.ShareLogFile
	// Flags: [Final|Native|Static|Public]
	void ShareLogFile(); // Offset: 0x103985008 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.SetWebViewCacheInfoDelegate
	// Flags: [Final|Native|Static|Public]
	void SetWebViewCacheInfoDelegate(DelegateProperty Delegate); // Offset: 0x103984f80 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.SetVpnServiceStrategy
	// Flags: [Final|Native|Static|Public]
	bool SetVpnServiceStrategy(struct FString InKey, int InValue); // Offset: 0x103984ea8 // Return & Params: Num(3) Size(0x15)

	// Object Name: Function Client.ScriptHelperClient.SetVoiceSwitch
	// Flags: [Final|Native|Static|Public]
	void SetVoiceSwitch(struct UGameFrontendHUD* GameFrontendHUD, bool FirstVoicePopupSwitch, bool GDPRForbidVoiceSwitch, bool GDPRSettingSwitch); // Offset: 0x103984d60 // Return & Params: Num(4) Size(0xb)

	// Object Name: Function Client.ScriptHelperClient.SetVoiceReEneterInfo
	// Flags: [Final|Native|Static|Public]
	void SetVoiceReEneterInfo(struct UGameFrontendHUD* GameFrontendHUD, float Duration, int MaxCount); // Offset: 0x103984c74 // Return & Params: Num(3) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.SetUserVulkanSetting
	// Flags: [Final|Native|Static|Public]
	void SetUserVulkanSetting(bool Enable); // Offset: 0x103984bf8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.SetUserTGPATapEnableFlag
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetUserTGPATapEnableFlag(int EnableFlag); // Offset: 0x103984b84 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.SetUserProperty
	// Flags: [Final|Native|Static|Public]
	void SetUserProperty(struct FString propertyKey, struct FString propertyValue); // Offset: 0x103984aa0 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.SetUpdatedSoPatchFile
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool SetUpdatedSoPatchFile(struct FString InSourceFile, int InABI); // Offset: 0x1039849c8 // Return & Params: Num(3) Size(0x15)

	// Object Name: Function Client.ScriptHelperClient.SetupAkAudioDeviceListener
	// Flags: [Final|Native|Static|Public]
	void SetupAkAudioDeviceListener(); // Offset: 0x1039849b4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.SetUIStatMaxClickTimes
	// Flags: [Final|Native|Static|Public]
	void SetUIStatMaxClickTimes(int Times); // Offset: 0x103984940 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.SetUIRectOffset
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetUIRectOffset(struct FString uirect); // Offset: 0x10398488c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.SetUIElemLayoutJsonConfigSwitch
	// Flags: [Final|Native|Static|Public]
	void SetUIElemLayoutJsonConfigSwitch(struct UGameFrontendHUD* GameFrontendHUD, bool UIElemLayoutJsonConfigSwitch); // Offset: 0x1039847d4 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.SetUIConfigTGPATapEnableFlag
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetUIConfigTGPATapEnableFlag(int uiEnable); // Offset: 0x103984760 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.SetTssNetworkStatus
	// Flags: [Final|Native|Static|Public]
	void SetTssNetworkStatus(struct UGameFrontendHUD* GameFrontendHUD, int Status); // Offset: 0x1039846b0 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.SetTickMemoryInterval
	// Flags: [Final|Native|Static|Public]
	void SetTickMemoryInterval(struct UGameFrontendHUD* GameFrontendHUD, float interval); // Offset: 0x103984600 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.SetTGPATapWhiteListFlag
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetTGPATapWhiteListFlag(int TapWhiteList); // Offset: 0x10398458c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.SetTestEditorNum
	// Flags: [Final|Native|Static|Public]
	void SetTestEditorNum(int PlayerCount, struct FString Num, struct FString SceneName, int PlatForm); // Offset: 0x1039843e0 // Return & Params: Num(4) Size(0x2c)

	// Object Name: Function Client.ScriptHelperClient.SetSoundEffectQuality
	// Flags: [Final|Native|Static|Public]
	bool SetSoundEffectQuality(int Type); // Offset: 0x103984364 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Client.ScriptHelperClient.SetShowFriendObservers
	// Flags: [Final|Native|Static|Public]
	void SetShowFriendObservers(struct UGameFrontendHUD* GameFrontendHUD, bool bShow); // Offset: 0x1039842ac // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.SetSelfieSwitch
	// Flags: [Final|Native|Static|Public]
	void SetSelfieSwitch(struct UGameFrontendHUD* GameFrontendHUD, bool SelfieSwitch); // Offset: 0x1039841f4 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.SetSdkIoctl
	// Flags: [Final|Native|Static|Public|HasOutParms]
	int SetSdkIoctl(struct UGameFrontendHUD* GameFrontendHUD, int request, struct FString& Token); // Offset: 0x1039840d4 // Return & Params: Num(4) Size(0x24)

	// Object Name: Function Client.ScriptHelperClient.SetScreenHole
	// Flags: [Final|Native|Static|Public]
	void SetScreenHole(struct FString sceenHole); // Offset: 0x103984020 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.SetReportBugSwitch
	// Flags: [Final|Native|Static|Public]
	void SetReportBugSwitch(struct UGameFrontendHUD* GameFrontendHUD, bool ReportBugSwitch); // Offset: 0x103983f68 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.SetRemoteResource
	// Flags: [Final|Native|Static|Public]
	void SetRemoteResource(struct FString AssetId, struct UObject* DescObj); // Offset: 0x103983e74 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.SetRegionNoByLua
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void SetRegionNoByLua(struct TScriptInterface<Class>& ClientNetInterface, int regionNo); // Offset: 0x103983db4 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.ScriptHelperClient.SetRedBloodSwitch
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetRedBloodSwitch(bool redBloodSwitch); // Offset: 0x103983d38 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.SetPufferBuildInfo
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetPufferBuildInfo(struct FString PipeLineID, struct FString BuildNo); // Offset: 0x103983c0c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.SetPublishRegion
	// Flags: [Final|Native|Static|Public]
	void SetPublishRegion(struct FString Region); // Offset: 0x103983b58 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.SetPlayerBaseInfo
	// Flags: [Final|Native|Static|Public]
	void SetPlayerBaseInfo(struct UGameFrontendHUD* GameFrontendHUD, struct FString OpenID, uint64 RoleID, struct FString PlayerName, struct FString HeadIconUrl); // Offset: 0x103983930 // Return & Params: Num(5) Size(0x40)

	// Object Name: Function Client.ScriptHelperClient.SetOnGetItemBigIcon
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetOnGetItemBigIcon(DelegateProperty onShow); // Offset: 0x1039838a8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.SetNationSwitch
	// Flags: [Final|Native|Static|Public]
	void SetNationSwitch(struct UGameFrontendHUD* GameFrontendHUD, bool NationAllSwitch, bool NationBattleSwitch, bool NationRankSwitch); // Offset: 0x103983760 // Return & Params: Num(4) Size(0xb)

	// Object Name: Function Client.ScriptHelperClient.SetMyFriendObserversDetail
	// Flags: [Final|Native|Static|Public]
	void SetMyFriendObserversDetail(struct UGameFrontendHUD* GameFrontendHUD, struct TArray<struct FFriendObserver> FriendObserversDetails); // Offset: 0x103983644 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.SetMiniGameFinalAwardResId
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetMiniGameFinalAwardResId(struct UGameFrontendHUD* GameFrontendHUD, int AwardResId); // Offset: 0x103983594 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.SetMidasZoneID_LuaState
	// Flags: [Final|Native|Static|Public]
	int SetMidasZoneID_LuaState(); // Offset: 0x10398357c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.SetMidasIDC
	// Flags: [Final|Native|Static|Public]
	void SetMidasIDC(struct FString midasIdc); // Offset: 0x1039834c8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.SetLinkStyle
	// Flags: [Final|Native|Static|Public]
	bool SetLinkStyle(struct FString StyleName, int FontSize, struct FString FontPath, struct FString FontColor, bool ShowUnderline, struct FString PathHyperLinkNormalBrush, struct FString PathHyperLinkHoveredrBrush); // Offset: 0x103983198 // Return & Params: Num(8) Size(0x61)

	// Object Name: Function Client.ScriptHelperClient.SetLevelStreamingUnloadTimeslice
	// Flags: [Final|Native|Static|Public]
	void SetLevelStreamingUnloadTimeslice(bool Enabled); // Offset: 0x10398311c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.SetiTOPLbsDelay
	// Flags: [Final|Native|Static|Public]
	void SetiTOPLbsDelay(int Delay); // Offset: 0x1039830a8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.SetIPRegion
	// Flags: [Final|Native|Static|Public]
	void SetIPRegion(int region_no); // Offset: 0x103983034 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.SetIosStuckEnableByServerConfig
	// Flags: [Final|Native|Static|Public]
	void SetIosStuckEnableByServerConfig(int bEnable); // Offset: 0x103982fc0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.SetIOSBGDownloadAttribute
	// Flags: [Final|Native|Static|Public]
	void SetIOSBGDownloadAttribute(struct UGameFrontendHUD* GameFrontendHUD, bool bEnableCellularAccess, bool bEnableResumeData, int nMinFileSize, int nMaxTasks); // Offset: 0x103982e48 // Return & Params: Num(5) Size(0x14)

	// Object Name: Function Client.ScriptHelperClient.SetIntDefaultConfig
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetIntDefaultConfig(int Value); // Offset: 0x103982dd4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.SetImageVersionString
	// Flags: [Final|Native|Static|Public]
	void SetImageVersionString(struct FString oldVersion, struct FString newVersion); // Offset: 0x103982cf0 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.SetImageStyle
	// Flags: [Final|Native|Static|Public]
	bool SetImageStyle(struct FString StyleName, int ImageSize, struct FString ImagePath, struct FString ImageColor, bool bPreLoad); // Offset: 0x103982ab0 // Return & Params: Num(6) Size(0x3a)

	// Object Name: Function Client.ScriptHelperClient.SetHapticsEngineEnable
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetHapticsEngineEnable(bool bEnable); // Offset: 0x103982a34 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.SetGlobalRedBloodSwitch
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetGlobalRedBloodSwitch(bool redBloodSwitch); // Offset: 0x1039829b8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.SetGDPRUserType
	// Flags: [Final|Native|Static|Public]
	void SetGDPRUserType(struct UGameFrontendHUD* GameFrontendHUD, int GDPRUserType); // Offset: 0x103982908 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.SetGameStatusMap
	// Flags: [Final|Native|Static|Public]
	void SetGameStatusMap(struct UGameFrontendHUD* GameFrontendHUD, struct TMap<struct FName, struct FString> GameStatusMap); // Offset: 0x103982810 // Return & Params: Num(2) Size(0x58)

	// Object Name: Function Client.ScriptHelperClient.SetGameSrvID
	// Flags: [Final|Native|Static|Public]
	void SetGameSrvID(struct UGameFrontendHUD* GameFrontendHUD, int GameSrvID); // Offset: 0x103982760 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.SetFontStyle
	// Flags: [Final|Native|Static|Public]
	bool SetFontStyle(struct FString StyleName, int FontSize, struct FString FontPath, struct FString FontColor, bool UseShadow, bool IsBold); // Offset: 0x1039824d8 // Return & Params: Num(7) Size(0x3b)

	// Object Name: Function Client.ScriptHelperClient.SetExtraLocalizationMap
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SetExtraLocalizationMap(struct TMap<struct FString, struct FString>& translationMap); // Offset: 0x103982434 // Return & Params: Num(1) Size(0x50)

	// Object Name: Function Client.ScriptHelperClient.SetExtraItemTableMappingByFix
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void SetExtraItemTableMappingByFix(struct TMap<int, struct FItemFixTableItem>& ItemFixMap); // Offset: 0x103982390 // Return & Params: Num(1) Size(0x50)

	// Object Name: Function Client.ScriptHelperClient.SetDynamicLevels
	// Flags: [Final|Native|Static|Public]
	void SetDynamicLevels(struct UGameFrontendHUD* GameFrontendHUD, struct TArray<struct FString> DynamicLevels); // Offset: 0x103982274 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.SetDumpShaderCompile
	// Flags: [Final|Native|Static|Public]
	void SetDumpShaderCompile(int iDumpVal); // Offset: 0x103982200 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.SetDownLoadLanguageName
	// Flags: [Final|Native|Static|Public]
	void SetDownLoadLanguageName(struct FString Language); // Offset: 0x103982170 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.SetCrashContextReportLevel
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetCrashContextReportLevel(int Level); // Offset: 0x1039820fc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.SetCanWatchEnemy
	// Flags: [Final|Native|Static|Public]
	void SetCanWatchEnemy(struct UGameFrontendHUD* GameFrontendHUD, bool bCan); // Offset: 0x103982044 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.SetBtnClickInCdFunc
	// Flags: [Final|Native|Static|Public]
	void SetBtnClickInCdFunc(); // Offset: 0x103982030 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.SetAppDetailInfo
	// Flags: [Final|Native|Static|Public]
	void SetAppDetailInfo(struct FString appInfo); // Offset: 0x103981fa0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.SetAccountRegion
	// Flags: [Final|Native|Static|Public]
	void SetAccountRegion(struct FString Region); // Offset: 0x103981eec // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.SendRetriveBeginnerFinisheGuideReq
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SendRetriveBeginnerFinisheGuideReq(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103981e78 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.SendRecordFinishedGuideReq
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SendRecordFinishedGuideReq(struct UGameFrontendHUD* GameFrontendHUD, struct FString TipsID); // Offset: 0x103981d84 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.SendPlayEmote
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SendPlayEmote(struct UGameFrontendHUD* GameFrontendHUD, int EmoteIndex); // Offset: 0x103981cd4 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.SendLobbyChat
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SendLobbyChat(struct UGameFrontendHUD* GameFrontendHUD, struct FString gid, struct FString Content); // Offset: 0x103981b68 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Client.ScriptHelperClient.SendDirtyToFilter
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SendDirtyToFilter(struct UGameFrontendHUD* GameFrontendHUD, struct FString dirtyString, struct FString prefixString, int UId); // Offset: 0x1039819bc // Return & Params: Num(4) Size(0x2c)

	// Object Name: Function Client.ScriptHelperClient.SendClientLog
	// Flags: [Final|Native|Static|Public]
	void SendClientLog(struct UGameFrontendHUD* GameFrontendHUD, struct FString errorReason, struct FString errorDescription, bool pullAll); // Offset: 0x103981854 // Return & Params: Num(4) Size(0x29)

	// Object Name: Function Client.ScriptHelperClient.ScheduleLocalNotificationAtTime
	// Flags: [Final|Native|Static|Public]
	void ScheduleLocalNotificationAtTime(int Year, int Month, int Day, int Hour, int Minute, int Second, bool LocalTime, struct FString Title, struct FString Body, struct FString Action, int NotificationID); // Offset: 0x103981498 // Return & Params: Num(11) Size(0x54)

	// Object Name: Function Client.ScriptHelperClient.SaveStringToIntermediateFile
	// Flags: [Final|Native|Static|Public]
	void SaveStringToIntermediateFile(struct FString String, struct FString Filename); // Offset: 0x1039813b4 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.SaveStringToFile
	// Flags: [Final|Native|Static|Public]
	void SaveStringToFile(struct FString String, struct FString Filename); // Offset: 0x1039812d0 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.SaveStringArrayToFile
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void SaveStringArrayToFile(struct TArray<struct FString>& Lines, struct FString Filename); // Offset: 0x1039811d8 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.SaveSavFile
	// Flags: [Final|Native|Static|Public]
	bool SaveSavFile(struct FString CompressedData, struct FString Filename, int CompressedSize, int UnCompressedSize); // Offset: 0x103981028 // Return & Params: Num(5) Size(0x29)

	// Object Name: Function Client.ScriptHelperClient.SaveLuaMemoryFile
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SaveLuaMemoryFile(struct FString Filename, struct FString InputContent, bool RmExistFile); // Offset: 0x103980efc // Return & Params: Num(3) Size(0x21)

	// Object Name: Function Client.ScriptHelperClient.SaveLoadGameSlotCrashFlag
	// Flags: [Final|Native|Static|Public]
	void SaveLoadGameSlotCrashFlag(); // Offset: 0x103980ee8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.SaveGameSlotMultiThread
	// Flags: [Final|Native|Static|Public]
	void SaveGameSlotMultiThread(); // Offset: 0x103980ed4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.SaveArrayToFile
	// Flags: [Final|Native|Static|Public|HasOutParms]
	bool SaveArrayToFile(struct TArray<char>& Content, struct FString Filename); // Offset: 0x103980dcc // Return & Params: Num(3) Size(0x21)

	// Object Name: Function Client.ScriptHelperClient.RunConsoleCommondAndGetString
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString RunConsoleCommondAndGetString(struct FString commond); // Offset: 0x103980d0c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.RunConsoleCommond
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void RunConsoleCommond(struct FString commond); // Offset: 0x103980c7c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.RoomOwnerInterruptGame
	// Flags: [Final|Native|Static|Public]
	void RoomOwnerInterruptGame(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103980c08 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.ReturnToLobby
	// Flags: [Final|Native|Static|Public]
	void ReturnToLobby(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103980b94 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.RestartShaderPrecompile
	// Flags: [Final|Native|Static|Public]
	void RestartShaderPrecompile(); // Offset: 0x103980b80 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.RestartPuffer
	// Flags: [Final|Native|Static|Public]
	void RestartPuffer(struct UGameFrontendHUD* GameFrontendHUD, bool needCheck, int maxDownloadsPerTask, int maxDownTask, int maxDownloadSpeed, bool useOldInterface, bool removeOldWhenUpdate, int versionType); // Offset: 0x10398094c // Return & Params: Num(8) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.RestartGame
	// Flags: [Final|Native|Static|Public]
	void RestartGame(); // Offset: 0x103980938 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.RequestFile
	// Flags: [Final|Native|Static|Public]
	uint64 RequestFile(struct UGameFrontendHUD* GameFrontendHUD, struct FString FilePath, bool ForceUpdate); // Offset: 0x1039807ec // Return & Params: Num(4) Size(0x28)

	// Object Name: Function Client.ScriptHelperClient.ReportFirebaseEventWithString
	// Flags: [Final|Native|Static|Public]
	void ReportFirebaseEventWithString(struct FString eventTypeString, struct FString bundleExtraKey, struct FString bundleExtraValue, bool isUnique); // Offset: 0x10398066c // Return & Params: Num(4) Size(0x31)

	// Object Name: Function Client.ScriptHelperClient.ReportFirebaseEventWithParam
	// Flags: [Final|Native|Static|Public]
	void ReportFirebaseEventWithParam(struct FString eventTypeString, struct TMap<struct FString, struct FString> _params, bool isUnique); // Offset: 0x103980514 // Return & Params: Num(3) Size(0x61)

	// Object Name: Function Client.ScriptHelperClient.ReportEventRegisterCompleted
	// Flags: [Final|Native|Static|Public]
	void ReportEventRegisterCompleted(); // Offset: 0x103980500 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.ReportEventPurchaseConsider
	// Flags: [Final|Native|Static|Public]
	void ReportEventPurchaseConsider(); // Offset: 0x1039804ec // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.ReportEventLoadingCompleted
	// Flags: [Final|Native|Static|Public]
	void ReportEventLoadingCompleted(); // Offset: 0x1039804d8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.ReportContextValuesOnCrash
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void ReportContextValuesOnCrash(struct FString& Json); // Offset: 0x103980438 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.ReportBuglyLogWithFDNum
	// Flags: [Final|Native|Static|Public]
	void ReportBuglyLogWithFDNum(struct FString baseLogInfo); // Offset: 0x103980384 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.ReportBattleChat
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ReportBattleChat(struct UGameFrontendHUD* GameFrontendHUD, struct FString Msg, int MsgExtraParam); // Offset: 0x103980250 // Return & Params: Num(3) Size(0x1c)

	// Object Name: Function Client.ScriptHelperClient.ReplyInvite
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ReplyInvite(struct UGameFrontendHUD* GameFrontendHUD, struct FString gid, bool bReply); // Offset: 0x103980114 // Return & Params: Num(3) Size(0x19)

	// Object Name: Function Client.ScriptHelperClient.RemoveKnownMissingPackage
	// Flags: [Final|Native|Static|Public]
	void RemoveKnownMissingPackage(struct FString PackageName); // Offset: 0x103980060 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.RemountPakFiles
	// Flags: [Final|Native|Static|Public]
	bool RemountPakFiles(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x10397ffe4 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.ReInitializePuffer
	// Flags: [Final|Native|Static|Public]
	void ReInitializePuffer(struct UGameFrontendHUD* GameFrontendHUD, bool needCheck, int maxDownloadsPerTask, int maxDownTask, int maxDownloadSpeed, bool useOldInterface, bool removeOldWhenUpdate, int versionType); // Offset: 0x10397fdb0 // Return & Params: Num(8) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.RecordLuaExceptionInfo
	// Flags: [Final|Native|Static|Public]
	void RecordLuaExceptionInfo(struct FString exception); // Offset: 0x10397fcfc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.RebuildHISM
	// Flags: [Final|Native|Static|Public]
	void RebuildHISM(struct UHierarchicalInstancedStaticMeshComponent* Comp, bool Async, bool ForceUpdate); // Offset: 0x10397fc00 // Return & Params: Num(3) Size(0xa)

	// Object Name: Function Client.ScriptHelperClient.QuitVoiceRoom
	// Flags: [Final|Native|Static|Public]
	void QuitVoiceRoom(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x10397fb8c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.QuitLbsVoiceRoom
	// Flags: [Final|Native|Static|Public]
	void QuitLbsVoiceRoom(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x10397fb18 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.QuitFightChat
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void QuitFightChat(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x10397faa4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.QuickLogin
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void QuickLogin(struct TScriptInterface<Class>& ClientNetInterface, int refreshTokenBeforeExpDays); // Offset: 0x10397f9e4 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.ScriptHelperClient.QQShareToFriend
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void QQShareToFriend(struct TScriptInterface<Class>& ClientNetInterface, int act, struct FString OpenID, struct FString Title, struct FString Desc, struct FString targetUrl, struct FString imgUrl, struct FString previewText, struct FString gameTag, struct FString msdkExtInfo); // Offset: 0x10397f678 // Return & Params: Num(10) Size(0x98)

	// Object Name: Function Client.ScriptHelperClient.QQShareH5WithPhoto
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void QQShareH5WithPhoto(struct TScriptInterface<Class>& ClientNetInterface, struct FString _title, struct FString _fullURL, int Channel); // Offset: 0x10397f504 // Return & Params: Num(4) Size(0x34)

	// Object Name: Function Client.ScriptHelperClient.QQShare
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void QQShare(struct TScriptInterface<Class>& ClientNetInterface, struct FString _descShare, struct FString _titleShare, struct FString _imgPath, struct FString _imgUrl, struct FString _url, int _shareScene); // Offset: 0x10397f294 // Return & Params: Num(7) Size(0x64)

	// Object Name: Function Client.ScriptHelperClient.QQAddFriend
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void QQAddFriend(struct TScriptInterface<Class>& ClientNetInterface, struct FString OpenID, struct FString Desc, struct FString Message); // Offset: 0x10397f10c // Return & Params: Num(4) Size(0x40)

	// Object Name: Function Client.ScriptHelperClient.PVEAutoTestGetEnermyLocation
	// Flags: [Final|Native|Static|Public|HasDefaults]
	struct FVector PVEAutoTestGetEnermyLocation(); // Offset: 0x10397f0d4 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.PubgmSimulateActionClientEx
	// Flags: [Final|Native|Static|Public]
	void PubgmSimulateActionClientEx(struct UGameFrontendHUD* GameFrontendHUD, int SimulateType); // Offset: 0x10397f024 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.ProjectSavedDir
	// Flags: [Final|Native|Static|Public]
	struct FString ProjectSavedDir(); // Offset: 0x10397efc0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.ProjectDir
	// Flags: [Final|Native|Static|Public]
	struct FString ProjectDir(); // Offset: 0x10397ef5c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.ProjectContentDir
	// Flags: [Final|Native|Static|Public]
	struct FString ProjectContentDir(); // Offset: 0x10397eef8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.ProcessSoPatch
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool ProcessSoPatch(struct FString InAppVerStr); // Offset: 0x10397ee60 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.ProcessServerRelationChainError
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void ProcessServerRelationChainError(struct TScriptInterface<Class>& ClientNetInterface, struct FString ErrorMsg, int iForceLoginInterval); // Offset: 0x10397ed1c // Return & Params: Num(3) Size(0x24)

	// Object Name: Function Client.ScriptHelperClient.PostGameStatusToTGPASMap
	// Flags: [Final|Native|Static|Public]
	void PostGameStatusToTGPASMap(struct UGameFrontendHUD* GameFrontendHUD, struct FString Key, struct TMap<struct FString, struct FString> mapData); // Offset: 0x10397eba8 // Return & Params: Num(3) Size(0x68)

	// Object Name: Function Client.ScriptHelperClient.PlayHapticsFile
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void PlayHapticsFile(struct FString FilePath, int Duration, DelegateProperty Callback); // Offset: 0x10397ea60 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Client.ScriptHelperClient.PandoraSendCmd
	// Flags: [Final|Native|Static|Public]
	void PandoraSendCmd(struct FString jsonStr); // Offset: 0x10397e9ac // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.PandoraInit
	// Flags: [Final|Native|Static|Public]
	void PandoraInit(struct FString InOpenId, struct FString InRoleId, struct FString InAppId, struct FString InPlatId, struct FString InAccType, struct FString InArea, struct FString InPartion, struct FString InCloudTest, struct FString InAccessToken, struct FString InSdkVersion, struct FString InGameVersion, struct FString InRoleName, struct FString InPayToken, struct FString InHeadUrl, struct FString InChanelId, struct FString InBelongingId, struct FString InLanguage, struct FString InTicket, struct FString InIp, struct FString InNation, struct FString InNetType); // Offset: 0x10397df64 // Return & Params: Num(21) Size(0x150)

	// Object Name: Function Client.ScriptHelperClient.PandoraErrorReport
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void PandoraErrorReport(int iType, int iActId, int errCode, struct FString errMsg, struct FString extraMsg, struct TMap<struct FString, struct FString>& extendDict); // Offset: 0x10397dd64 // Return & Params: Num(6) Size(0x80)

	// Object Name: Function Client.ScriptHelperClient.PandoraEnable
	// Flags: [Final|Native|Static|Public]
	void PandoraEnable(bool Enable); // Offset: 0x10397dce8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.PandoraClose
	// Flags: [Final|Native|Static|Public]
	void PandoraClose(); // Offset: 0x10397dcd4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.OpenWebviewInGameProcess
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void OpenWebviewInGameProcess(struct FString URL, int Left, int Top, int Right, int Bottom); // Offset: 0x10397db4c // Return & Params: Num(5) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.OpenURLWithExtra
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void OpenURLWithExtra(struct FString URL, struct TMap<struct FString, struct FString> ExtraMap); // Offset: 0x10397da18 // Return & Params: Num(2) Size(0x60)

	// Object Name: Function Client.ScriptHelperClient.OpenURL
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void OpenURL(struct FString URL, bool isGetTicket, bool withNeverAdjust, bool bKeepCache); // Offset: 0x10397d884 // Return & Params: Num(4) Size(0x13)

	// Object Name: Function Client.ScriptHelperClient.OpenShaderCodeLibrary
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool OpenShaderCodeLibrary(struct FString Path, struct FString VersionNum); // Offset: 0x10397d750 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function Client.ScriptHelperClient.OpenH5FromCache
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void OpenH5FromCache(struct UGameFrontendHUD* GameFrontendHUD, struct FString ModuleName, struct FString Language, int netType, int Top, int Left, int Right, struct FString ViewParam); // Offset: 0x10397d478 // Return & Params: Num(8) Size(0x48)

	// Object Name: DelegateFunction Client.ScriptHelperClient.OnWebViewCacheInfoDelegate__DelegateSignature
	// Flags: [Public|Delegate]
	void OnWebViewCacheInfoDelegate__DelegateSignature(int code); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.OnWebViewCache
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void OnWebViewCache(int code); // Offset: 0x10397d404 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.OnNotifyFightFriendChat
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void OnNotifyFightFriendChat(struct UGameFrontendHUD* GameFrontendHUD, struct FFightFriendChat& Data); // Offset: 0x10397d320 // Return & Params: Num(2) Size(0x40)

	// Object Name: Function Client.ScriptHelperClient.OnMiniGameEnded
	// Flags: [Final|Native|Static|Public]
	void OnMiniGameEnded(struct UGameFrontendHUD* GameFrontendHUD, int Score, int Duration, bool bGameClosed); // Offset: 0x10397d1f4 // Return & Params: Num(4) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.OnIslandPlayerInfoNotify
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void OnIslandPlayerInfoNotify(struct UGameFrontendHUD* GameFrontendHUD, int LandId); // Offset: 0x10397d144 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.OnInviteNextBattle
	// Flags: [Final|Native|Static|Public]
	bool OnInviteNextBattle(struct UGameFrontendHUD* GameFrontendHUD, struct FString gid, struct FString Name); // Offset: 0x10397d01c // Return & Params: Num(4) Size(0x29)

	// Object Name: Function Client.ScriptHelperClient.OnGetUpdateStateCDNConfigUrl
	// Flags: [Final|Native|Static|Public]
	void OnGetUpdateStateCDNConfigUrl(struct UGameFrontendHUD* GameFrontendHUD, struct FString URL); // Offset: 0x10397cf50 // Return & Params: Num(2) Size(0x18)

	// Object Name: DelegateFunction Client.ScriptHelperClient.OnGetItemBigIcon__DelegateSignature
	// Flags: [Public|Delegate]
	struct FString OnGetItemBigIcon__DelegateSignature(struct FString strPath); // Offset: 0x103df3e6c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.OnFilterFinish
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void OnFilterFinish(struct UGameFrontendHUD* GameFrontendHUD, struct FString filterText); // Offset: 0x10397ce84 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.OnEnterLobbyReloadLocalizationResource
	// Flags: [Final|Native|Static|Public]
	void OnEnterLobbyReloadLocalizationResource(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x10397ce10 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.OnEnterGameReleaseLocalizationResource
	// Flags: [Final|Native|Static|Public]
	void OnEnterGameReleaseLocalizationResource(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x10397cd9c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.OnDolphinAppUpdateFinished
	// Flags: [Final|Native|Static|Public]
	void OnDolphinAppUpdateFinished(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x10397cd28 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.OnCombatHitFeedback
	// Flags: [Final|Native|Static|Public]
	void OnCombatHitFeedback(struct UGameFrontendHUD* GameFrontendHUD, bool bCombatHitFeedbackEnable); // Offset: 0x10397cc70 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.OnBattleResultCallBack
	// Flags: [Final|Native|Static|Public]
	void OnBattleResultCallBack(struct UGameFrontendHUD* GameFrontendHUD, struct FBattleResultData BattleResultData); // Offset: 0x10397cb70 // Return & Params: Num(2) Size(0x90)

	// Object Name: Function Client.ScriptHelperClient.OnBattleResult
	// Flags: [Final|Native|Static|Public]
	void OnBattleResult(struct UGameFrontendHUD* GameFrontendHUD, struct FBattleResultData BattleResultData); // Offset: 0x10397ca70 // Return & Params: Num(2) Size(0x90)

	// Object Name: Function Client.ScriptHelperClient.ObjectPoolServerSwitch
	// Flags: [Final|Native|Static|Public]
	void ObjectPoolServerSwitch(bool bSwitchOn); // Offset: 0x10397c9f4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.NotifyBeginnerFinishedGuideUpdated
	// Flags: [Final|Native|Static|Public]
	void NotifyBeginnerFinishedGuideUpdated(struct UGameFrontendHUD* GameFrontendHUD, bool GuideSwitch, struct TArray<struct FPlayerFinishedGuide> finished_guide, int player_level, int player_exp_type); // Offset: 0x10397c818 // Return & Params: Num(5) Size(0x28)

	// Object Name: Function Client.ScriptHelperClient.MSDKWebViewCallJS
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void MSDKWebViewCallJS(struct FString strJS); // Offset: 0x10397c764 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.MoveFollowTarget
	// Flags: [Final|Native|Static|Public]
	void MoveFollowTarget(struct UGameFrontendHUD* GameFrontendHUD, int FollowType, uint64 UId); // Offset: 0x10397c678 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.MoveFile
	// Flags: [Final|Native|Static|Public]
	bool MoveFile(struct FString SrcFullPath, struct FString DesFullPath); // Offset: 0x10397c58c // Return & Params: Num(3) Size(0x21)

	// Object Name: Function Client.ScriptHelperClient.MountPakFile
	// Flags: [Final|Native|Static|Public]
	bool MountPakFile(struct FString InPakFilename, struct FString Key); // Offset: 0x10397c4a0 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function Client.ScriptHelperClient.MidasSDKInit_LuaState
	// Flags: [Final|Native|Static|Public]
	int MidasSDKInit_LuaState(); // Offset: 0x10397c488 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.MidasReprovide_LuaState
	// Flags: [Final|Native|Static|Public]
	int MidasReprovide_LuaState(); // Offset: 0x10397c470 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.MidasPay
	// Flags: [Final|Native|Static|Public]
	void MidasPay(struct FString productid, int payItem, struct FString country, struct FString currency); // Offset: 0x10397c2f8 // Return & Params: Num(4) Size(0x38)

	// Object Name: Function Client.ScriptHelperClient.MidasH5Pay
	// Flags: [Final|Native|Static|Public]
	void MidasH5Pay(struct FString country); // Offset: 0x10397c268 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.MidasGoodsPresent
	// Flags: [Final|Native|Static|Public]
	void MidasGoodsPresent(struct FString productid, int payItem, struct FString price, struct FString country, struct FString currency, struct FString MetaData); // Offset: 0x10397c048 // Return & Params: Num(6) Size(0x58)

	// Object Name: Function Client.ScriptHelperClient.MidasGoods
	// Flags: [Final|Native|Static|Public]
	void MidasGoods(struct FString productid, int payItem, struct FString price, struct FString country, struct FString currency); // Offset: 0x10397be7c // Return & Params: Num(5) Size(0x48)

	// Object Name: Function Client.ScriptHelperClient.MessageBoxExt
	// Flags: [Final|Native|Static|Public]
	void MessageBoxExt(struct FString Caption, struct FString Text); // Offset: 0x10397bd98 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.MediaCopyFromPakToLocal
	// Flags: [Final|Native|Static|Public]
	bool MediaCopyFromPakToLocal(struct FString from, bool bForce); // Offset: 0x10397bc8c // Return & Params: Num(3) Size(0x12)

	// Object Name: Function Client.ScriptHelperClient.MD5LuaString_LuaState
	// Flags: [Final|Native|Static|Public]
	int MD5LuaString_LuaState(); // Offset: 0x10397bc74 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.MD5HashAnsiString
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString MD5HashAnsiString(struct FString str); // Offset: 0x10397bb90 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.ManualSleep
	// Flags: [Final|Native|Static|Public]
	void ManualSleep(float Seconds); // Offset: 0x10397bb1c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.LuaLoadFileToString
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString LuaLoadFileToString(struct FString InFileName); // Offset: 0x10397ba5c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.LogoutAllDevices
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void LogoutAllDevices(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x10397b9d8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.Logout
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void Logout(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x10397b954 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.LoginWithExtraInfo
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void LoginWithExtraInfo(struct TScriptInterface<Class>& ClientNetInterface, uint32_t Channel, struct FString InExtraJson); // Offset: 0x10397b838 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Client.ScriptHelperClient.Login
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void Login(struct TScriptInterface<Class>& ClientNetInterface, uint32_t Channel); // Offset: 0x10397b778 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.ScriptHelperClient.LobbySetUserRegion
	// Flags: [Final|Native|Static|Public]
	void LobbySetUserRegion(int InRegion); // Offset: 0x10397b704 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.LobbySetProxyPortlist
	// Flags: [Final|Native|Static|Public]
	void LobbySetProxyPortlist(struct FString InNodePortList); // Offset: 0x10397b674 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.LobbySetProxyNodelist
	// Flags: [Final|Native|Static|Public]
	void LobbySetProxyNodelist(struct FString InNodeIpList); // Offset: 0x10397b5e4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.LobbySetEchoPortlist
	// Flags: [Final|Native|Static|Public]
	void LobbySetEchoPortlist(struct FString InEchoPortList); // Offset: 0x10397b554 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.LobbyIsLinkProxy
	// Flags: [Final|Native|Static|Public]
	bool LobbyIsLinkProxy(struct FString InIp, int InPort); // Offset: 0x10397b47c // Return & Params: Num(3) Size(0x15)

	// Object Name: Function Client.ScriptHelperClient.LobbyAddAddress
	// Flags: [Final|Native|Static|Public]
	void LobbyAddAddress(struct FString InProtocol, struct FString InIp, int InPort); // Offset: 0x10397b358 // Return & Params: Num(3) Size(0x24)

	// Object Name: Function Client.ScriptHelperClient.LoadSavFile_LuaState
	// Flags: [Final|Native|Static|Public]
	int LoadSavFile_LuaState(); // Offset: 0x10397b340 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.LoadMidasMP_LuaState
	// Flags: [Final|Native|Static|Public]
	int LoadMidasMP_LuaState(); // Offset: 0x10397b328 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.LoadIntermediateFileToString
	// Flags: [Final|Native|Static|Public]
	struct FString LoadIntermediateFileToString(struct FString Filename); // Offset: 0x10397b268 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.LoadH5FromCache
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void LoadH5FromCache(struct UGameFrontendHUD* GameFrontendHUD, struct FString ModuleName, struct FString Language, int netType, int Top, int Left, int Right, struct FString ViewParam); // Offset: 0x10397af90 // Return & Params: Num(8) Size(0x48)

	// Object Name: Function Client.ScriptHelperClient.LoadFileToStringByFullPath
	// Flags: [Final|Native|Static|Public]
	struct FString LoadFileToStringByFullPath(struct FString FullPathName); // Offset: 0x10397aed0 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.LoadFileToString
	// Flags: [Final|Native|Static|Public]
	struct FString LoadFileToString(struct FString Filename); // Offset: 0x10397ae10 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.LoadFileToArray
	// Flags: [Final|Native|Static|Public]
	struct TArray<char> LoadFileToArray(struct FString Filename); // Offset: 0x10397ad50 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.LoadAmendODs
	// Flags: [Final|Native|Static|Public]
	bool LoadAmendODs(struct TMap<uint32_t, struct FString> Keys); // Offset: 0x10397ac90 // Return & Params: Num(2) Size(0x51)

	// Object Name: Function Client.ScriptHelperClient.LoadAFDTranslation
	// Flags: [Final|Native|Static|Public]
	void LoadAFDTranslation(); // Offset: 0x10397ac7c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.LaunchUrl
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void LaunchUrl(struct FString& URL); // Offset: 0x10397abdc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.JoinVoiceRoom
	// Flags: [Final|Native|Static|Public]
	void JoinVoiceRoom(struct UGameFrontendHUD* GameFrontendHUD, struct FString roomName, struct FString userId); // Offset: 0x10397aa70 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Client.ScriptHelperClient.JoinLbsVoiceRoom
	// Flags: [Final|Native|Static|Public]
	void JoinLbsVoiceRoom(struct UGameFrontendHUD* GameFrontendHUD, struct FString lbsRoomName, struct FString userId); // Offset: 0x10397a904 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Client.ScriptHelperClient.IsWindowsClientReplay
	// Flags: [Final|Native|Static|Public]
	bool IsWindowsClientReplay(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x10397a888 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.IsWindowOB
	// Flags: [Final|Native|Static|Public]
	bool IsWindowOB(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x10397a80c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.IsUsingBluetooth
	// Flags: [Final|Native|Static|Public]
	bool IsUsingBluetooth(); // Offset: 0x10397a7d8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsUseTypicalResultFlowMode
	// Flags: [Final|Native|Static|Public]
	bool IsUseTypicalResultFlowMode(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x10397a75c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.IsUpdateSkip
	// Flags: [Final|Native|Static|Public]
	bool IsUpdateSkip(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x10397a6e0 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.IsUIAutoTest
	// Flags: [Final|Native|Static|Public]
	bool IsUIAutoTest(); // Offset: 0x10397a6ac // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsTypicalMode
	// Flags: [Final|Native|Static|Public]
	bool IsTypicalMode(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x10397a630 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.IsTest
	// Flags: [Final|Native|Static|Public]
	bool IsTest(); // Offset: 0x10397a5fc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsSystemVPNOpened
	// Flags: [Final|Native|Static|Public]
	bool IsSystemVPNOpened(); // Offset: 0x10397a5c8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsSupportVulkan
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsSupportVulkan(); // Offset: 0x10397a594 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsSplitMiniPakVersion
	// Flags: [Final|Native|Static|Public]
	bool IsSplitMiniPakVersion(); // Offset: 0x10397a560 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsSplitMapPakVersion
	// Flags: [Final|Native|Static|Public]
	bool IsSplitMapPakVersion(); // Offset: 0x10397a52c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.isSkipUpdateByRepair
	// Flags: [Final|Native|Static|Public]
	bool isSkipUpdateByRepair(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x10397a4b0 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.IsShipping
	// Flags: [Final|Native|Static|Public]
	bool IsShipping(); // Offset: 0x10397a47c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsSavFileData
	// Flags: [Final|Native|Static|Public]
	bool IsSavFileData(struct FString CompressedData, int CompressedSize, int UnCompressedSize, int ToCheckEndWithCDLenght); // Offset: 0x10397a304 // Return & Params: Num(5) Size(0x1d)

	// Object Name: Function Client.ScriptHelperClient.IsRuningOnVulkan
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsRuningOnVulkan(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x10397a288 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.IsReleaseVersion
	// Flags: [Final|Native|Static|Public|HasOutParms]
	bool IsReleaseVersion(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x10397a1fc // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsPVEMode
	// Flags: [Final|Native|Static|Public]
	bool IsPVEMode(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x10397a180 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.IsOpenAOS90FPSConfig
	// Flags: [Final|Native|Static|Public]
	bool IsOpenAOS90FPSConfig(); // Offset: 0x10397a14c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsODPakMonted
	// Flags: [Final|Native|Static|Public]
	bool IsODPakMonted(struct FString Filename); // Offset: 0x10397a0b4 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsNotificationEnabled
	// Flags: [Final|Native|Static|Public]
	bool IsNotificationEnabled(); // Offset: 0x10397a080 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsNoAuthMode
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsNoAuthMode(); // Offset: 0x10397a04c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsNetworkReachable
	// Flags: [Final|Native|Static|Public]
	bool IsNetworkReachable(); // Offset: 0x10397a018 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsNeedClearHiddenUI
	// Flags: [Final|Native|Static|Public]
	bool IsNeedClearHiddenUI(struct UFrontendHUD* GameFrontendHUD); // Offset: 0x103979f9c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.IsMounted
	// Flags: [Final|Native|Static|Public]
	bool IsMounted(struct FString Filename); // Offset: 0x103979f04 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsMlAIDebug
	// Flags: [Final|Native|Static|Public]
	bool IsMlAIDebug(); // Offset: 0x103979ed0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsLaunchedByLocalNotification
	// Flags: [Final|Native|Static|Public]
	bool IsLaunchedByLocalNotification(); // Offset: 0x103979e9c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsJaguar
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsJaguar(); // Offset: 0x103979e68 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsIPhoneFiveSOriginal
	// Flags: [Final|Native|Static|Public]
	bool IsIPhoneFiveSOriginal(); // Offset: 0x103979e34 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsIPhoneFiveS
	// Flags: [Final|Native|Static|Public]
	bool IsIPhoneFiveS(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103979db8 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.IsIOSVersionAbove13
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsIOSVersionAbove13(); // Offset: 0x103979d84 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsInstallWX
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool IsInstallWX(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x103979cf8 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsInstallWhatsapp
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool IsInstallWhatsapp(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x103979c6c // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsInstallVK
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool IsInstallVK(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x103979be0 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsInstallTwitter
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool IsInstallTwitter(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x103979b54 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsInstallQQByiTOP
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool IsInstallQQByiTOP(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x103979ac8 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsInstallOpenRec
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool IsInstallOpenRec(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x103979a3c // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsInstallMirrativ
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool IsInstallMirrativ(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x1039799b0 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsInstallMessenger
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool IsInstallMessenger(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x103979924 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsInstallLite
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool IsInstallLite(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x103979898 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsInstallLine
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool IsInstallLine(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x10397980c // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsInstallFaceBook
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool IsInstallFaceBook(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x103979780 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsInstallDiscord
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool IsInstallDiscord(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x1039796f4 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsHarmonyOS
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsHarmonyOS(); // Offset: 0x1039796c0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsHapticsEngineEnable
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsHapticsEngineEnable(); // Offset: 0x10397968c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsForCE
	// Flags: [Final|Native|Static|Public]
	bool IsForCE(); // Offset: 0x103979658 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsFileReady
	// Flags: [Final|Native|Static|Public]
	bool IsFileReady(struct UGameFrontendHUD* GameFrontendHUD, struct FString FilePath); // Offset: 0x10397955c // Return & Params: Num(3) Size(0x19)

	// Object Name: Function Client.ScriptHelperClient.IsFileExistsWithPakCheckMatchExt
	// Flags: [Final|Native|Static|Public]
	bool IsFileExistsWithPakCheckMatchExt(struct FString Filename); // Offset: 0x1039794c4 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsFileExistsWithPakCheck
	// Flags: [Final|Native|Static|Public]
	bool IsFileExistsWithPakCheck(struct FString Filename); // Offset: 0x10397942c // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsFileExistsWithOutPakCheck
	// Flags: [Final|Native|Static|Public]
	bool IsFileExistsWithOutPakCheck(struct FString Path); // Offset: 0x103979394 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsFileExistByFileName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsFileExistByFileName(struct FString Filename); // Offset: 0x1039792fc // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsFileExistByExtension
	// Flags: [Final|Native|Static|Public]
	bool IsFileExistByExtension(struct UGameFrontendHUD* GameFrontendHUD, struct FString Filename, struct FString fileExtension); // Offset: 0x103979188 // Return & Params: Num(4) Size(0x29)

	// Object Name: Function Client.ScriptHelperClient.IsFileExist
	// Flags: [Final|Native|Static|Public]
	bool IsFileExist(struct UGameFrontendHUD* GameFrontendHUD, struct FString Filename); // Offset: 0x10397908c // Return & Params: Num(3) Size(0x19)

	// Object Name: Function Client.ScriptHelperClient.IsEnableDSGrayPublishFlag
	// Flags: [Final|Native|Static|Public]
	bool IsEnableDSGrayPublishFlag(uint64 nGrayPublishFlag); // Offset: 0x103979010 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.IsEmulatorWhenInit
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsEmulatorWhenInit(); // Offset: 0x103978fdc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsEmulator
	// Flags: [Final|Native|Static|Public]
	bool IsEmulator(); // Offset: 0x103978fa8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsEditorDedicatedServer
	// Flags: [Final|Native|Static|Public]
	bool IsEditorDedicatedServer(); // Offset: 0x103978f74 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsEditor
	// Flags: [Final|Native|Static|Public]
	bool IsEditor(); // Offset: 0x103978f40 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsDolbyAtmosSupported
	// Flags: [Final|Native|Static|Public]
	bool IsDolbyAtmosSupported(); // Offset: 0x103978f0c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsDeviceSupportsViberation
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsDeviceSupportsViberation(); // Offset: 0x103978ed8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsDeviceSupportsHapticsEngine
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsDeviceSupportsHapticsEngine(); // Offset: 0x103978ea4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsDeviceHWSupportVulkan
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsDeviceHWSupportVulkan(); // Offset: 0x103978e70 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsDevelopment
	// Flags: [Final|Native|Static|Public]
	bool IsDevelopment(); // Offset: 0x103978e3c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsConnected
	// Flags: [Final|Native|Static|Public|HasOutParms]
	bool IsConnected(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x103978db0 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.IsCEVersion
	// Flags: [Final|Native|Static|Public]
	bool IsCEVersion(); // Offset: 0x103978d7c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsCEHideLobbyUI
	// Flags: [Final|Native|Static|Public]
	bool IsCEHideLobbyUI(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103978d00 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.IsBasePrefecthOpen
	// Flags: [Final|Native|Static|Public]
	bool IsBasePrefecthOpen(); // Offset: 0x103978ccc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsAwakedByNotification
	// Flags: [Final|Native|Static|Public]
	bool IsAwakedByNotification(); // Offset: 0x103978c98 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.IsAndroidHasGyr
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsAndroidHasGyr(); // Offset: 0x103978c64 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.InviteWhatsappOfflineFriends
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void InviteWhatsappOfflineFriends(struct TScriptInterface<Class>& ClientNetInterface, struct FString Title, struct FString Content); // Offset: 0x103978b30 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.InviteSystemOfflineFriends
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void InviteSystemOfflineFriends(struct TScriptInterface<Class>& ClientNetInterface, struct FString Title, struct FString Content); // Offset: 0x1039789fc // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.InviteSMSOfflineFriends
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void InviteSMSOfflineFriends(struct TScriptInterface<Class>& ClientNetInterface, struct FString Content); // Offset: 0x10397891c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.InviteLineOfflineFriends
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void InviteLineOfflineFriends(struct TScriptInterface<Class>& ClientNetInterface, struct FString Title, struct FString Content); // Offset: 0x1039787e8 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.InviteFBOfflineFriends
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void InviteFBOfflineFriends(struct TScriptInterface<Class>& ClientNetInterface, struct FString Title, struct FString Content, struct FString link); // Offset: 0x103978660 // Return & Params: Num(4) Size(0x40)

	// Object Name: Function Client.ScriptHelperClient.InstallNewApp
	// Flags: [Final|Native|Static|Public]
	void InstallNewApp(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x1039785ec // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.InitVPN
	// Flags: [Final|Native|Static|Public]
	int InitVPN(struct FString InVPNGUID, struct FString InClientVersion); // Offset: 0x103978500 // Return & Params: Num(3) Size(0x24)

	// Object Name: Function Client.ScriptHelperClient.InitVlink
	// Flags: [Final|Native|Static|Public]
	void InitVlink(); // Offset: 0x1039784ec // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.InitQuantumPlatformMisc
	// Flags: [Final|Native|Static|Public]
	void InitQuantumPlatformMisc(); // Offset: 0x1039784d8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.InitLoginAccount
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void InitLoginAccount(struct TScriptInterface<Class>& ClientNetInterface, uint64 AccUin, struct FString AccPswd); // Offset: 0x103978394 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Client.ScriptHelperClient.InitJavaFunctions
	// Flags: [Final|Native|Static|Public]
	void InitJavaFunctions(); // Offset: 0x103978380 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.InitIMSDKEnv
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void InitIMSDKEnv(struct TScriptInterface<Class>& ClientNetInterface, uint32_t iEnv); // Offset: 0x1039782c0 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.ScriptHelperClient.InitializePuffer
	// Flags: [Final|Native|Static|Public]
	void InitializePuffer(struct UGameFrontendHUD* GameFrontendHUD, bool needCheck, int maxDownloadsPerTask, int maxDownTask, int maxDownloadSpeed, bool useOldInterface, bool removeOldWhenUpdate, int versionType); // Offset: 0x10397808c // Return & Params: Num(8) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.InitializeLaggingReporter
	// Flags: [Final|Native|Static|Public]
	void InitializeLaggingReporter(struct UGameFrontendHUD* GameFrontendHUD, bool Enable); // Offset: 0x103977fd4 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.InitHF
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void InitHF(); // Offset: 0x103977fc0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.InitGCloudRemoteConfig
	// Flags: [Final|Native|Static|Public]
	void InitGCloudRemoteConfig(); // Offset: 0x103977fac // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.InitDH
	// Flags: [Final|Native|Static|Public]
	int InitDH(struct FString gen, struct FString prime, int v_srand); // Offset: 0x103977e38 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function Client.ScriptHelperClient.Ini_UpdateMemResource
	// Flags: [Final|Native|Static|Public]
	void Ini_UpdateMemResource(struct FString KeyWord, struct FString CMDvalue); // Offset: 0x103977d0c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.HtmlEncode
	// Flags: [Final|Native|Static|Public]
	struct FString HtmlEncode(struct FString UnencodedString); // Offset: 0x103977c4c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.HideH5WebView
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void HideH5WebView(); // Offset: 0x103977c38 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.HaveReceivedNoticeCallback
	// Flags: [Final|Native|Static|Public]
	bool HaveReceivedNoticeCallback(); // Offset: 0x103977c04 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.HasRemoteConfigReady
	// Flags: [Final|Native|Static|Public]
	bool HasRemoteConfigReady(); // Offset: 0x103977bd0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.HasNotice
	// Flags: [Final|Native|Static|Public]
	bool HasNotice(int Type, struct FString Scene); // Offset: 0x103977afc // Return & Params: Num(3) Size(0x19)

	// Object Name: Function Client.ScriptHelperClient.HasNotchInScreen
	// Flags: [Final|Native|Static|Public]
	bool HasNotchInScreen(); // Offset: 0x103977ac8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.HasLoadGameSlotCrashFlag
	// Flags: [Final|Native|Static|Public]
	bool HasLoadGameSlotCrashFlag(); // Offset: 0x103977a94 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.HasDownloadedBasePak
	// Flags: [Final|Native|Static|Public]
	bool HasDownloadedBasePak(); // Offset: 0x103977a60 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.HasDefinePermission
	// Flags: [Final|Native|Static|Public]
	bool HasDefinePermission(struct FString InPermissionName); // Offset: 0x1039779c8 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.HasActiveWifi
	// Flags: [Final|Native|Static|Public]
	bool HasActiveWifi(); // Offset: 0x103977994 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.GuestLogin
	// Flags: [Final|Native|Static|Public]
	void GuestLogin(); // Offset: 0x103977980 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.GotoPlatformAppraise
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void GotoPlatformAppraise(); // Offset: 0x10397796c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.GMTestAllocUObjs
	// Flags: [Final|Native|Static|Public]
	void GMTestAllocUObjs(struct UGameFrontendHUD* GameFrontendHUD, int Num); // Offset: 0x1039778bc // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.GMH5Enable
	// Flags: [Final|Native|Static|Public]
	void GMH5Enable(bool Flag); // Offset: 0x103977840 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.GetWidgetsByClass
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetWidgetsByClass(struct UWidget* Parent, struct UObject* Type, struct TArray<struct UWidget*>& Children); // Offset: 0x10397772c // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.GetWebViewTicket
	// Flags: [Final|Native|Static|Public|HasOutParms]
	struct FString GetWebViewTicket(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x103977678 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.GetWeaponDIYIconPath
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetWeaponDIYIconPath(struct FString PlayerUID, int WeaponID, struct FString PlanID, bool relativePath, int Width, int Height); // Offset: 0x10397740c // Return & Params: Num(7) Size(0x48)

	// Object Name: Function Client.ScriptHelperClient.GetVolume
	// Flags: [Final|Native|Static|Public]
	int GetVolume(int InStreamType); // Offset: 0x103977390 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.GetUserVulkanSetting
	// Flags: [Final|Native|Static|Public]
	bool GetUserVulkanSetting(); // Offset: 0x10397735c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.GetUserTGPATapEnableFlag
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetUserTGPATapEnableFlag(); // Offset: 0x103977328 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetUObjectName
	// Flags: [Final|Native|Static|Public]
	struct FString GetUObjectName(struct UObject* uObj); // Offset: 0x103977284 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.GetUnrealNetworkStatus
	// Flags: [Final|Native|Static|Public]
	struct FString GetUnrealNetworkStatus(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x1039771e0 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.GetUIRectOffset
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetUIRectOffset(); // Offset: 0x10397717c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetToken
	// Flags: [Final|Native|Static|Public|HasOutParms]
	struct FString GetToken(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x1039770c8 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.GetTimeInMiliSeconds
	// Flags: [Final|Native|Static|Public]
	float GetTimeInMiliSeconds(); // Offset: 0x103977094 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetTGPATapDeviceSupportFlag
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetTGPATapDeviceSupportFlag(); // Offset: 0x103977060 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetTelecomSvr
	// Flags: [Final|Native|Static|Public]
	struct FString GetTelecomSvr(); // Offset: 0x103976ffc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetTCDeviceLevel
	// Flags: [Final|Native|Static|Public]
	int GetTCDeviceLevel(); // Offset: 0x103976fc8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetTableCount
	// Flags: [Final|Native|Static|Public]
	int GetTableCount(struct FString tableName); // Offset: 0x103976f30 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.ScriptHelperClient.GetSystemLanguage_LuaState
	// Flags: [Final|Native|Static|Public]
	int GetSystemLanguage_LuaState(); // Offset: 0x103976f18 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetSubsideFeatureLevel
	// Flags: [Final|Native|Static|Public]
	uint32_t GetSubsideFeatureLevel(); // Offset: 0x103976ee4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetSrcVersion
	// Flags: [Final|Native|Static|Public]
	struct FString GetSrcVersion(); // Offset: 0x103976e80 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetSplitMapConfigInfo
	// Flags: [Final|Native|Static|Public]
	struct FString GetSplitMapConfigInfo(); // Offset: 0x103976e1c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetSpecialData
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetSpecialData(); // Offset: 0x103976db8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetSoundEffectQuality
	// Flags: [Final|Native|Static|Public]
	int GetSoundEffectQuality(); // Offset: 0x103976d84 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetShaderPrecompileProgress
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetShaderPrecompileProgress(); // Offset: 0x103976d50 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetServerDelay
	// Flags: [Final|Native|Static|Public]
	int GetServerDelay(struct FString ServerAddress); // Offset: 0x103976cb8 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.ScriptHelperClient.GetScreenWidthForWebview
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetScreenWidthForWebview(); // Offset: 0x103976c84 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetScreenWidth
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetScreenWidth(); // Offset: 0x103976c50 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetScreenHole
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetScreenHole(); // Offset: 0x103976bec // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetScreenHight
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetScreenHight(); // Offset: 0x103976bb8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetScreenHeightForWebview
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetScreenHeightForWebview(); // Offset: 0x103976b84 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetScreenDensity
	// Flags: [Final|Native|Static|Public]
	int GetScreenDensity(); // Offset: 0x103976b50 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetRuntimeProfileData
	// Flags: [Final|Native|Static|Public]
	struct FString GetRuntimeProfileData(); // Offset: 0x103976aec // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetRingMode
	// Flags: [Final|Native|Static|Public]
	int GetRingMode(); // Offset: 0x103976ab8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetRemarkNameByGIDWithObj
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetRemarkNameByGIDWithObj(struct UObject* Obj, struct FString gid, struct FString PlayerName); // Offset: 0x10397691c // Return & Params: Num(4) Size(0x38)

	// Object Name: Function Client.ScriptHelperClient.GetRemarkNameByGID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetRemarkNameByGID(struct UGameFrontendHUD* GameFrontendHUD, struct FString gid, struct FString PlayerName); // Offset: 0x103976780 // Return & Params: Num(4) Size(0x38)

	// Object Name: Function Client.ScriptHelperClient.GetRegisterChannelID
	// Flags: [Final|Native|Static|Public|HasOutParms]
	struct FString GetRegisterChannelID(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x1039766cc // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.GetRedFlameSwitch
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool GetRedFlameSwitch(); // Offset: 0x103976698 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.GetRedBloodSwitch
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool GetRedBloodSwitch(); // Offset: 0x103976664 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.GetPufferInitResult
	// Flags: [Final|Native|Static|Public]
	bool GetPufferInitResult(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x1039765e8 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.GetPufferInitErrCode
	// Flags: [Final|Native|Static|Public]
	uint32_t GetPufferInitErrCode(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x10397656c // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.GetPublishRegion
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetPublishRegion(); // Offset: 0x103976508 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetPublicKey
	// Flags: [Final|Native|Static|Public]
	struct FString GetPublicKey(struct FString cli_pri_key); // Offset: 0x103976424 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.GetPUBGModuleBaseAddr
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetPUBGModuleBaseAddr(struct FString ParamModuleName); // Offset: 0x103976340 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.GetPrivateKey
	// Flags: [Final|Native|Static|Public]
	struct FString GetPrivateKey(); // Offset: 0x1039762dc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetPingReportInfo
	// Flags: [Final|Native|Static|Public]
	struct FString GetPingReportInfo(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103976238 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.GetPingReportData
	// Flags: [Final|Native|Static|Public]
	struct FString GetPingReportData(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103976194 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.GetPhysicalFileTime
	// Flags: [Final|Native|Static|Public]
	int64_t GetPhysicalFileTime(struct FString InPath); // Offset: 0x1039760d8 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.GetPhoneType
	// Flags: [Final|Native|Static|Public]
	struct FString GetPhoneType(); // Offset: 0x103976074 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetPhoneDeviceID
	// Flags: [Final|Native|Static|Public]
	struct FString GetPhoneDeviceID(); // Offset: 0x103976010 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetPhoneAdvertisingID
	// Flags: [Final|Native|Static|Public]
	struct FString GetPhoneAdvertisingID(); // Offset: 0x103975fac // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetPackChannel
	// Flags: [Final|Native|Static|Public]
	struct FString GetPackChannel(); // Offset: 0x103975f48 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetOSVersion
	// Flags: [Final|Native|Static|Public]
	struct FString GetOSVersion(); // Offset: 0x103975ee4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetODPaksFileUseTime
	// Flags: [Final|Native|Static|Public]
	struct TArray<struct FString> GetODPaksFileUseTime(struct FString DumpFilename); // Offset: 0x103975e00 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.GetNotificationExtraDataString
	// Flags: [Final|Native|Static|Public]
	struct FString GetNotificationExtraDataString(struct FString Key); // Offset: 0x103975d40 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.GetNotchSize
	// Flags: [Final|Native|Static|Public]
	struct TArray<int> GetNotchSize(); // Offset: 0x103975cdc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetNetWorkType
	// Flags: [Final|Native|Static|Public]
	struct FString GetNetWorkType(); // Offset: 0x103975c78 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetNativeVersion
	// Flags: [Final|Native|Static|Public]
	struct FString GetNativeVersion(); // Offset: 0x103975c14 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetNativePackageTag
	// Flags: [Final|Native|Static|Public]
	struct FString GetNativePackageTag(); // Offset: 0x103975bb0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetMyFriendObservers
	// Flags: [Final|Native|Static|Public]
	struct TArray<struct FString> GetMyFriendObservers(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103975b0c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.GetMidasPF_LuaState
	// Flags: [Final|Native|Static|Public]
	int GetMidasPF_LuaState(); // Offset: 0x103975af4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetMidasPayChannel_LuaState
	// Flags: [Final|Native|Static|Public]
	int GetMidasPayChannel_LuaState(); // Offset: 0x103975adc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetMemoryStats_LuaState
	// Flags: [Final|Native|Static|Public]
	int GetMemoryStats_LuaState(); // Offset: 0x103975ac4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetMemorySize
	// Flags: [Final|Native|Static|Public]
	int GetMemorySize(); // Offset: 0x103975a90 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetLuaRootDir
	// Flags: [Final|Native|Static|Public]
	struct FString GetLuaRootDir(); // Offset: 0x103975a2c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetLoginChannel
	// Flags: [Final|Native|Static|Public|HasOutParms]
	int GetLoginChannel(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x1039759a0 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.ScriptHelperClient.GetLoadGameSlotCrashInfo
	// Flags: [Final|Native|Static|Public]
	struct FString GetLoadGameSlotCrashInfo(); // Offset: 0x10397593c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetLaunchLocalNotificationID
	// Flags: [Final|Native|Static|Public]
	struct FString GetLaunchLocalNotificationID(); // Offset: 0x1039758d8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetKnownMissingPackage
	// Flags: [Final|Native|Static|Public]
	struct TArray<struct FString> GetKnownMissingPackage(struct FString PackageName, struct FString DumpFilename); // Offset: 0x10397577c // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.GetiTOPLbsDelay
	// Flags: [Final|Native|Static|Public]
	int GetiTOPLbsDelay(); // Offset: 0x103975748 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetITopGameId
	// Flags: [Final|Native|Static|Public|HasOutParms]
	struct FString GetITopGameId(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x103975694 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.GetIsSecretVersion
	// Flags: [Final|Native|Static|Public]
	int GetIsSecretVersion(); // Offset: 0x103975660 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetIsPlayerUsingVPN
	// Flags: [Final|Native|Static|Public]
	bool GetIsPlayerUsingVPN(); // Offset: 0x10397562c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.GetIsOpenBattlePlayback
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool GetIsOpenBattlePlayback(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x1039755b0 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.GetIPRegion
	// Flags: [Final|Native|Static|Public]
	int GetIPRegion(); // Offset: 0x10397557c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetIpAddrByHost
	// Flags: [Final|Native|Static|Public]
	struct FString GetIpAddrByHost(struct FString Host); // Offset: 0x1039754bc // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.GetIpAddr
	// Flags: [Final|Native|Static|Public]
	struct FString GetIpAddr(); // Offset: 0x103975458 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetIntDefaultOffset
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int GetIntDefaultOffset(); // Offset: 0x103975424 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetInstallChannelID
	// Flags: [Final|Native|Static|Public|HasOutParms]
	struct FString GetInstallChannelID(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x103975370 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.GetIMSDKEnv
	// Flags: [Final|Native|Static|Public]
	int GetIMSDKEnv(); // Offset: 0x10397533c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetH5CacheStatus
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool GetH5CacheStatus(struct FString ModuleName); // Offset: 0x1039752a4 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.GetGvoiceReconnectInfo
	// Flags: [Final|Native|Static|Public]
	void GetGvoiceReconnectInfo(struct UGameFrontendHUD* GameFrontendHUD, struct TMap<struct FString, struct FString> Data); // Offset: 0x1039751ac // Return & Params: Num(2) Size(0x58)

	// Object Name: Function Client.ScriptHelperClient.GetGroupInfo
	// Flags: [Final|Native|Static|Public|HasOutParms]
	struct FGroupInfoWrapper GetGroupInfo(struct TScriptInterface<Class>& ClientNetInterface, int SnsAction); // Offset: 0x1039750b0 // Return & Params: Num(3) Size(0x68)

	// Object Name: Function Client.ScriptHelperClient.GetGoogleServiceVersionCode
	// Flags: [Final|Native|Static|Public]
	int GetGoogleServiceVersionCode(); // Offset: 0x10397507c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetGLVersion
	// Flags: [Final|Native|Static|Public]
	struct FString GetGLVersion(); // Offset: 0x103975018 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetGLType
	// Flags: [Final|Native|Static|Public]
	struct FString GetGLType(); // Offset: 0x103974fb4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetGameStatus
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetGameStatus(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103974f10 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.GetGameModeID
	// Flags: [Final|Native|Static|Public]
	struct FString GetGameModeID(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103974e6c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.GetGameMasterGUID
	// Flags: [Final|Native|Static|Public]
	struct FString GetGameMasterGUID(); // Offset: 0x103974e08 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetFrameCounter
	// Flags: [Final|Native|Static|Public]
	int64_t GetFrameCounter(); // Offset: 0x103974dd4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.GetFPS
	// Flags: [Final|Native|Static|Public]
	float GetFPS(); // Offset: 0x103974da0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetFireBaseFCMToken
	// Flags: [Final|Native|Static|Public]
	struct FString GetFireBaseFCMToken(); // Offset: 0x103974d3c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetFileSizeOnDiskBytes
	// Flags: [Final|Native|Static|Public]
	int64_t GetFileSizeOnDiskBytes(struct FString FilePath); // Offset: 0x103974c80 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.GetFileSizeOnDisk
	// Flags: [Final|Native|Static|Public]
	uint32_t GetFileSizeOnDisk(struct FString FilePath); // Offset: 0x103974bc4 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.ScriptHelperClient.GetFileSizeCompressed
	// Flags: [Final|Native|Static|Public]
	uint64 GetFileSizeCompressed(struct UGameFrontendHUD* GameFrontendHUD, struct FString FilePath); // Offset: 0x103974ac8 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.GetFileDirPath
	// Flags: [Final|Native|Static|Public]
	struct FString GetFileDirPath(struct FString FilePath); // Offset: 0x1039749e4 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.GetFBFriendsUnregistered
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void GetFBFriendsUnregistered(struct TScriptInterface<Class>& ClientNetInterface, uint32_t page, uint32_t Count, uint32_t Type, struct FString extend); // Offset: 0x103974854 // Return & Params: Num(5) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.GetExactDeviceLevel
	// Flags: [Final|Native|Static|Public]
	int GetExactDeviceLevel(); // Offset: 0x103974820 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetEncodeUrl
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetEncodeUrl(struct FString URL); // Offset: 0x10397473c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.GetEmulatorName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetEmulatorName(); // Offset: 0x1039746d8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetDSVersion
	// Flags: [Final|Native|Static|Public]
	struct FString GetDSVersion(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103974634 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.GetDownLoadLanguageName
	// Flags: [Final|Native|Static|Public]
	struct FString GetDownLoadLanguageName(); // Offset: 0x1039745d0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetDeviceQualityLevel
	// Flags: [Final|Native|Static|Public]
	int GetDeviceQualityLevel(); // Offset: 0x10397459c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetDevicePlatformName
	// Flags: [Final|Native|Static|Public]
	struct FString GetDevicePlatformName(); // Offset: 0x103974538 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetDeviceName
	// Flags: [Final|Native|Static|Public]
	struct FString GetDeviceName(); // Offset: 0x1039744d4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetDeviceModel
	// Flags: [Final|Native|Static|Public]
	struct FString GetDeviceModel(); // Offset: 0x103974470 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetDeviceMaxSupportSoundEffect
	// Flags: [Final|Native|Static|Public]
	int GetDeviceMaxSupportSoundEffect(); // Offset: 0x10397443c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetDeviceMake
	// Flags: [Final|Native|Static|Public]
	struct FString GetDeviceMake(); // Offset: 0x1039743d8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetDeviceInfo
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetDeviceInfo(); // Offset: 0x103974374 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetDeviceFreeSpace
	// Flags: [Final|Native|Static|Public]
	uint64 GetDeviceFreeSpace(); // Offset: 0x103974340 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.GetCurrentRHILevel
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetCurrentRHILevel(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x10397429c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.GetCurrentLanguage_LuaState
	// Flags: [Final|Native|Static|Public]
	int GetCurrentLanguage_LuaState(); // Offset: 0x103974284 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetCurrentChannel
	// Flags: [Final|Native|Static|Public]
	int GetCurrentChannel(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103974208 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.GetCpuType
	// Flags: [Final|Native|Static|Public]
	struct FString GetCpuType(); // Offset: 0x1039741a4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetCDNUpdateInfo
	// Flags: [Final|Native|Static|Public]
	void GetCDNUpdateInfo(struct UGameFrontendHUD* GameFrontendHUD, struct TMap<struct FString, struct FString> Data); // Offset: 0x1039740ac // Return & Params: Num(2) Size(0x58)

	// Object Name: Function Client.ScriptHelperClient.GetBuildVersion
	// Flags: [Final|Native|Static|Public]
	struct FString GetBuildVersion(); // Offset: 0x103974048 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetBattleKey
	// Flags: [Final|Native|Static|Public]
	struct FString GetBattleKey(struct FString svr_pub_key, struct FString cli_pri_key); // Offset: 0x103973eec // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.GetAreaIPNo
	// Flags: [Final|Native|Static|Public]
	struct FString GetAreaIPNo(); // Offset: 0x103973e88 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetAppVersion
	// Flags: [Final|Native|Static|Public]
	struct FString GetAppVersion(); // Offset: 0x103973e24 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetApplicationVersion
	// Flags: [Final|Native|Static|Public]
	struct FString GetApplicationVersion(); // Offset: 0x103973dc0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetAOSSHOP
	// Flags: [Final|Native|Static|Public]
	struct FString GetAOSSHOP(); // Offset: 0x103973d5c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetAndroidVersion
	// Flags: [Final|Native|Static|Public]
	struct FString GetAndroidVersion(); // Offset: 0x103973cf8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetAndroidSysInfo
	// Flags: [Final|Native|Static|Public]
	struct FString GetAndroidSysInfo(); // Offset: 0x103973c94 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetAndroidSOVersion
	// Flags: [Final|Native|Static|Public]
	int GetAndroidSOVersion(); // Offset: 0x103973c60 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetAndroidMaxStackSize
	// Flags: [Final|Native|Static|Public]
	uint32_t GetAndroidMaxStackSize(); // Offset: 0x103973c2c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetAndroidMaxFDNum
	// Flags: [Final|Native|Static|Public]
	uint32_t GetAndroidMaxFDNum(); // Offset: 0x103973bf8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetAndroidCurrentFDNum
	// Flags: [Final|Native|Static|Public]
	uint32_t GetAndroidCurrentFDNum(); // Offset: 0x103973bc4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetAndroidBuildForArm
	// Flags: [Final|Native|Static|Public]
	int GetAndroidBuildForArm(); // Offset: 0x103973b90 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GetAllLocalNotificationIDs
	// Flags: [Final|Native|Static|Public]
	struct TArray<int> GetAllLocalNotificationIDs(); // Offset: 0x103973b2c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetAllFilesInDir
	// Flags: [Final|Native|Static|Public]
	struct TArray<struct FString> GetAllFilesInDir(struct FString Dir, struct FString Pattern); // Offset: 0x103973a18 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.GetAccountRegion
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetAccountRegion(); // Offset: 0x1039739b4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GetAccessToken
	// Flags: [Final|Native|Static|Public|HasOutParms]
	struct FString GetAccessToken(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x103973900 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.GenerateQRImage
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void GenerateQRImage(struct TScriptInterface<Class>& ClientNetInterface, int Tag, int Size, struct FString Content, struct FString logoPath); // Offset: 0x103973754 // Return & Params: Num(5) Size(0x38)

	// Object Name: Function Client.ScriptHelperClient.GEMReportSubEvent
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void GEMReportSubEvent(struct UGameFrontendHUD* GameFrontendHUD, struct FString EventName, struct FString SubEventName, struct TArray<struct FString>& eventParams); // Offset: 0x1039735d0 // Return & Params: Num(4) Size(0x38)

	// Object Name: Function Client.ScriptHelperClient.GEMReportShaderPrecompileEvent
	// Flags: [Final|Native|Static|Public]
	void GEMReportShaderPrecompileEvent(struct UGameFrontendHUD* GameFrontendHUD, bool IsSuccess, struct FString strDesc); // Offset: 0x103973498 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.GEMReportEvent
	// Flags: [Final|Native|Static|Public]
	void GEMReportEvent(struct UGameFrontendHUD* GameFrontendHUD, struct FString EventName, struct TMap<struct FString, struct FString> eventParams); // Offset: 0x103973324 // Return & Params: Num(3) Size(0x68)

	// Object Name: Function Client.ScriptHelperClient.GEMReportEnterLobbyEvent
	// Flags: [Final|Native|Static|Public]
	void GEMReportEnterLobbyEvent(struct UGameFrontendHUD* GameFrontendHUD, bool IsSuccess, struct FString strDesc); // Offset: 0x1039731ec // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.GCloudRemoteConfigStartOnce
	// Flags: [Final|Native|Static|Public]
	void GCloudRemoteConfigStartOnce(); // Offset: 0x1039731d8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.GCloudRemoteConfigSetUrl
	// Flags: [Final|Native|Static|Public]
	void GCloudRemoteConfigSetUrl(struct FString InRemoteConfigUrl); // Offset: 0x103973148 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GCloudRemoteConfigGetString
	// Flags: [Final|Native|Static|Public]
	struct FString GCloudRemoteConfigGetString(struct FString InKey, struct FString InDefaultValue); // Offset: 0x103973034 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.GCloudRemoteConfigGetInt
	// Flags: [Final|Native|Static|Public]
	int GCloudRemoteConfigGetInt(struct FString InKey, int InDefaultValue); // Offset: 0x103972f5c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.GCloudRemoteConfigGetBool
	// Flags: [Final|Native|Static|Public]
	bool GCloudRemoteConfigGetBool(struct FString InKey, bool InDefaultValue); // Offset: 0x103972e7c // Return & Params: Num(3) Size(0x12)

	// Object Name: Function Client.ScriptHelperClient.GCloudRemoteConfigClear
	// Flags: [Final|Native|Static|Public]
	void GCloudRemoteConfigClear(); // Offset: 0x103972e68 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.GameMasterSetUserInfo
	// Flags: [Final|Native|Static|Public]
	void GameMasterSetUserInfo(struct FString InPaidInfo, struct FString InUserToken, struct FString InAppId); // Offset: 0x103972d30 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.GameMasterSetUsableRegion
	// Flags: [Final|Native|Static|Public]
	void GameMasterSetUsableRegion(struct FString InRegion); // Offset: 0x103972ca0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GameMasterSetUdpEchoPort
	// Flags: [Final|Native|Static|Public]
	void GameMasterSetUdpEchoPort(int InPort); // Offset: 0x103972c2c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GameMasterSetOnlyWifiAccel
	// Flags: [Final|Native|Static|Public]
	void GameMasterSetOnlyWifiAccel(bool InOn); // Offset: 0x103972bb0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.GameMasterSetFreeFlowUser
	// Flags: [Final|Native|Static|Public]
	void GameMasterSetFreeFlowUser(int InType); // Offset: 0x103972b3c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GameMasterOnNetDelay
	// Flags: [Final|Native|Static|Public]
	void GameMasterOnNetDelay(int InMillis); // Offset: 0x103972ac8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GameMasterIsAccelOpened
	// Flags: [Final|Native|Static|Public]
	bool GameMasterIsAccelOpened(); // Offset: 0x103972a94 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.GameMasterInit
	// Flags: [Final|Native|Static|Public]
	int GameMasterInit(int InHookType, struct FString InGuid, struct FString InLibs, int InEchoPort); // Offset: 0x10397292c // Return & Params: Num(5) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.GameMasterGetWebUIUrl
	// Flags: [Final|Native|Static|Public]
	struct FString GameMasterGetWebUIUrl(int InType); // Offset: 0x103972888 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.GameMasterGetVIPValidTime
	// Flags: [Final|Native|Static|Public]
	struct FString GameMasterGetVIPValidTime(); // Offset: 0x103972824 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GameMasterGetUserID
	// Flags: [Final|Native|Static|Public]
	struct FString GameMasterGetUserID(); // Offset: 0x1039727c0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.GameMasterGetAccelerationStatus
	// Flags: [Final|Native|Static|Public]
	int GameMasterGetAccelerationStatus(); // Offset: 0x10397278c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GameMasterClearAccelAddr
	// Flags: [Final|Native|Static|Public]
	void GameMasterClearAccelAddr(); // Offset: 0x103972778 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.GameMasterBeginRound
	// Flags: [Final|Native|Static|Public]
	void GameMasterBeginRound(struct FString InOpenId, struct FString InPvpId); // Offset: 0x103972694 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.GameMasterAddNewArenaAddress
	// Flags: [Final|Native|Static|Public]
	void GameMasterAddNewArenaAddress(struct FString InProtocol, struct FString InIp, int InPort); // Offset: 0x103972570 // Return & Params: Num(3) Size(0x24)

	// Object Name: Function Client.ScriptHelperClient.GameMasterAddAccelAddr
	// Flags: [Final|Native|Static|Public]
	void GameMasterAddAccelAddr(struct FString InProtocol, struct FString InIp, int InPort); // Offset: 0x10397244c // Return & Params: Num(3) Size(0x24)

	// Object Name: Function Client.ScriptHelperClient.GameJoySwitchOn
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void GameJoySwitchOn(int isOn); // Offset: 0x1039723d8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GameJoyStopManualRecord
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void GameJoyStopManualRecord(); // Offset: 0x1039723c4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.GameJoyStartMomentsRecord
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void GameJoyStartMomentsRecord(); // Offset: 0x1039723b0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.GameJoyStartManualRecord
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void GameJoyStartManualRecord(); // Offset: 0x10397239c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.GameJoySetVideoQuality
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void GameJoySetVideoQuality(int Quality); // Offset: 0x103972328 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GameJoySetMomentRecordSwitchOn
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void GameJoySetMomentRecordSwitchOn(int isOn); // Offset: 0x1039722b4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.GameJoySetLuaguage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void GameJoySetLuaguage(); // Offset: 0x1039722a0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.GameJoySetCurrentRecorderPosition
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void GameJoySetCurrentRecorderPosition(float X, float Y); // Offset: 0x1039721f4 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.GameJoyIsSDKFeatureSupport
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool GameJoyIsSDKFeatureSupport(); // Offset: 0x1039721c0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.GameJoyGenerateMomentsVideo
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void GameJoyGenerateMomentsVideo(struct TArray<struct FTimeStamp> shortVideosTimeStampList, struct TArray<struct FTimeStamp> largeVideosTimeStampList, struct FString Title, struct TMap<struct FString, struct FString> ExtraInfo); // Offset: 0x103971f54 // Return & Params: Num(4) Size(0x80)

	// Object Name: Function Client.ScriptHelperClient.GameJoyEndMomentsRecord
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void GameJoyEndMomentsRecord(); // Offset: 0x103971f40 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.GameJoyClearMomentsVideo
	// Flags: [Final|Native|Static|Public]
	void GameJoyClearMomentsVideo(); // Offset: 0x103971f2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.FullPathFileExist
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool FullPathFileExist(struct FString Filename); // Offset: 0x103971e94 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.FlushKnownMissingPackageRefObject
	// Flags: [Final|Native|Static|Public]
	void FlushKnownMissingPackageRefObject(); // Offset: 0x103971e80 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.FinishPufferUpdateInDolphin
	// Flags: [Final|Native|Static|Public]
	void FinishPufferUpdateInDolphin(struct UGameFrontendHUD* GameFrontendHUD, bool IsFinished); // Offset: 0x103971dc8 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.FindFilesRecursiveSkipPakPlatform
	// Flags: [Final|Native|Static|Public]
	struct TArray<struct FString> FindFilesRecursiveSkipPakPlatform(struct FString Dir, struct FString Pattern); // Offset: 0x103971cb4 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.FindFiles_LuaState
	// Flags: [Final|Native|Static|Public]
	int FindFiles_LuaState(); // Offset: 0x103971c9c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.FileSystemTesting
	// Flags: [Final|Native|Static|Public]
	void FileSystemTesting(uint32_t Count); // Offset: 0x103971c28 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.ExitGameForSafety
	// Flags: [Final|Native|Static|Public]
	void ExitGameForSafety(); // Offset: 0x103971c14 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.ExitGame
	// Flags: [Final|Native|Static|Public]
	void ExitGame(); // Offset: 0x103971c00 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.EnterLoading
	// Flags: [Final|Native|Static|Public]
	void EnterLoading(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103971b8c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.EnterFightChat
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void EnterFightChat(struct UGameFrontendHUD* GameFrontendHUD, struct FString gid); // Offset: 0x103971a98 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.EnterBattleStandAlone
	// Flags: [Final|Native|Static|Public]
	void EnterBattleStandAlone(struct UGameFrontendHUD* GameFrontendHUD, struct FString MapPath, uint32_t PlayerKey, struct FString PlayerName); // Offset: 0x1039718e8 // Return & Params: Num(4) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.EnterBattle
	// Flags: [Final|Native|Static|Public]
	void EnterBattle(struct UGameFrontendHUD* GameFrontendHUD, struct FString HostnameOrIP, uint32_t Port, uint32_t PlayerKey, struct FString PlayerName, struct FString PacketKey, uint64 GameID, bool IsObserver, struct TMap<int, struct FString> AdvConfig, int WaterType, uint32_t WaterUserID, uint32_t ModeID, uint32_t ModeType); // Offset: 0x103971458 // Return & Params: Num(13) Size(0xb0)

	// Object Name: Function Client.ScriptHelperClient.EncryptUID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString EncryptUID(struct FString sUid, struct FString sKey); // Offset: 0x1039712fc // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.EncryptItemData
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void EncryptItemData(struct TArray<int>& EncryptionItemList); // Offset: 0x10397125c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.EnableUseOldInterface
	// Flags: [Final|Native|Static|Public]
	void EnableUseOldInterface(struct UGameFrontendHUD* GameFrontendHUD, bool Enable); // Offset: 0x1039711a4 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.EnableTxtCheck
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void EnableTxtCheck(); // Offset: 0x103971190 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.EnableShaderGroup
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool EnableShaderGroup(struct FString GroupName); // Offset: 0x1039710f8 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.EnableReportGVoiceEvent
	// Flags: [Final|Native|Static|Public]
	void EnableReportGVoiceEvent(struct UGameFrontendHUD* GameFrontendHUD, bool GVoiceInitGVoiceComponentReportEnable, bool GVoiceJoinRoomReportEnable, bool GVoiceQuitRoomReportEnable, bool GVoiceJoinLbsRoomReportEnable, bool GVoiceQuitLbsRoomReportEnable, bool GVoiceOnJoinTeamRoomReportEnable, bool GVoiceOnJoinLbsRoomReportEnable); // Offset: 0x103970e90 // Return & Params: Num(8) Size(0xf)

	// Object Name: Function Client.ScriptHelperClient.EnableLocalizationStatus
	// Flags: [Final|Native|Static|Public]
	void EnableLocalizationStatus(struct UGameFrontendHUD* GameFrontendHUD, bool Status); // Offset: 0x103970dd8 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.EnableIosStuckWork
	// Flags: [Final|Native|Static|Public]
	void EnableIosStuckWork(struct UGameFrontendHUD* GameFrontendHUD, bool bEnable); // Offset: 0x103970d20 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.EnableGvoiceGemReport
	// Flags: [Final|Native|Static|Public]
	void EnableGvoiceGemReport(struct UGameFrontendHUD* GameFrontendHUD, bool Enable); // Offset: 0x103970c68 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.EnableGvoice
	// Flags: [Final|Native|Static|Public]
	void EnableGvoice(struct UGameFrontendHUD* GameFrontendHUD, bool Enable); // Offset: 0x103970bb0 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.EnableCampGvoice
	// Flags: [Final|Native|Static|Public]
	void EnableCampGvoice(struct UGameFrontendHUD* GameFrontendHUD, bool Enable); // Offset: 0x103970af8 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.EnableAutoObjectRefreshStage
	// Flags: [Final|Native|Static|Public]
	void EnableAutoObjectRefreshStage(bool bEnable); // Offset: 0x103970a7c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.EnableAudioRouteChangedNotify
	// Flags: [Final|Native|Static|Public]
	void EnableAudioRouteChangedNotify(bool Enable); // Offset: 0x103970a00 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.DumpPackageMemInfo
	// Flags: [Final|Native|Static|Public]
	struct FString DumpPackageMemInfo(struct TArray<struct FString> AssetList); // Offset: 0x1039708f8 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.DumpOpenReadCollect
	// Flags: [Final|Native|Static|Public]
	void DumpOpenReadCollect(struct UGameFrontendHUD* GameFrontendHUD, struct FString DumpFilename); // Offset: 0x103970804 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.DumpLogFile
	// Flags: [Final|Native|Static|Public]
	void DumpLogFile(bool backup); // Offset: 0x103970788 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.Disconnect
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void Disconnect(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x103970704 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.DisableRepairResource
	// Flags: [Final|Native|Static|Public]
	void DisableRepairResource(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x103970690 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.DirectToSetting
	// Flags: [Final|Native|Static|Public]
	void DirectToSetting(); // Offset: 0x10397067c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.DestroyConnector
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void DestroyConnector(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x1039705f8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.DeleteFile
	// Flags: [Final|Native|Static|Public]
	bool DeleteFile(struct FString fullPath); // Offset: 0x103970560 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ScriptHelperClient.DeleteDirectory
	// Flags: [Final|Native|Static|Public]
	void DeleteDirectory(struct FString FilePath); // Offset: 0x1039704ac // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.DelayToSetAutoInitFacebookLog
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void DelayToSetAutoInitFacebookLog(bool IsAutoInit); // Offset: 0x103970430 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.DelayToInitFacebookSDK
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void DelayToInitFacebookSDK(bool IsAutoInit, bool WithLaunchOption); // Offset: 0x103970370 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function Client.ScriptHelperClient.DelayInitThirdPartSDK
	// Flags: [Final|Native|Static|Public]
	void DelayInitThirdPartSDK(); // Offset: 0x10397035c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.CreateHapticsEngine
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void CreateHapticsEngine(DelegateProperty Callback); // Offset: 0x1039702d4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.ConvertToAbsolutePathForExternalAppForWrite
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString ConvertToAbsolutePathForExternalAppForWrite(struct FString FilePath); // Offset: 0x103970214 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.ConvertToAbsolutePathForExternalAppForRead
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString ConvertToAbsolutePathForExternalAppForRead(struct FString FilePath); // Offset: 0x103970154 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.ConvertTMap2JsonStr
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FString ConvertTMap2JsonStr(struct TMap<struct FString, struct FString>& mapData); // Offset: 0x103970080 // Return & Params: Num(2) Size(0x60)

	// Object Name: Function Client.ScriptHelperClient.ConvertRelativePathToFull
	// Flags: [Final|Native|Static|Public]
	struct FString ConvertRelativePathToFull(struct FString InPath); // Offset: 0x10396ff9c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.ConvertGamePathToRelativeFilePath
	// Flags: [Final|Native|Static|Public]
	struct FString ConvertGamePathToRelativeFilePath(struct FString Path); // Offset: 0x10396fedc // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.ConsoleCommand
	// Flags: [Final|Native|Static|Public]
	struct FString ConsoleCommand(struct UGameFrontendHUD* GameFrontendHUD, struct FString Command); // Offset: 0x10396fde0 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Client.ScriptHelperClient.ConnectToURL
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void ConnectToURL(struct TScriptInterface<Class>& ClientNetInterface, struct FString URL, int ConnectTimeOutSeconds); // Offset: 0x10396fc9c // Return & Params: Num(3) Size(0x24)

	// Object Name: Function Client.ScriptHelperClient.ComputerName
	// Flags: [Final|Native|Static|Public]
	struct FString ComputerName(); // Offset: 0x10396fc38 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.CloseWebView
	// Flags: [Final|Native|Static|Public]
	void CloseWebView(); // Offset: 0x10396fc24 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.CloseVLink
	// Flags: [Final|Native|Static|Public]
	void CloseVLink(); // Offset: 0x10396fc10 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.CloseVideoListDialog
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void CloseVideoListDialog(); // Offset: 0x10396fbfc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.CloseH5WebView
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void CloseH5WebView(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x10396fb88 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.ClipBoardCopy
	// Flags: [Final|Native|Static|Public]
	void ClipBoardCopy(struct FString Text); // Offset: 0x10396fad4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.ClientKickPlayerFromGame
	// Flags: [Final|Native|Static|Public]
	void ClientKickPlayerFromGame(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x10396fa60 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.ClientEnterWarMode
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ClientEnterWarMode(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x10396f9ec // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.ClientConfirmReturnToGame
	// Flags: [Final|Native|Static|Public]
	void ClientConfirmReturnToGame(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x10396f978 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.ClientConfirmMisKill
	// Flags: [Final|Native|Static|Public]
	void ClientConfirmMisKill(struct UGameFrontendHUD* GameFrontendHUD, int bConfirm); // Offset: 0x10396f8c8 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.ClearUpdatedSoPatch
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ClearUpdatedSoPatch(); // Offset: 0x10396f8b4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.ClearNotifications
	// Flags: [Final|Native|Static|Public]
	void ClearNotifications(); // Offset: 0x10396f8a0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.ClearNotice
	// Flags: [Final|Native|Static|Public]
	void ClearNotice(); // Offset: 0x10396f88c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.ClearHasLoadGameSlotCrashFlag
	// Flags: [Final|Native|Static|Public]
	void ClearHasLoadGameSlotCrashFlag(); // Offset: 0x10396f878 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.ClearChannelID
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void ClearChannelID(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x10396f7f4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.ClearAllLocalNotifications
	// Flags: [Final|Native|Static|Public]
	void ClearAllLocalNotifications(); // Offset: 0x10396f7e0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.CheckRegisterGestureConflictWithZoom
	// Flags: [Final|Native|Static|Public]
	void CheckRegisterGestureConflictWithZoom(); // Offset: 0x10396f7cc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.CheckLocalizationExist
	// Flags: [Final|Native|Static|Public]
	bool CheckLocalizationExist(); // Offset: 0x10396f798 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.CheckFilesInPak
	// Flags: [Final|Native|Static|Public|HasOutParms]
	struct TArray<struct FString> CheckFilesInPak(struct TArray<struct FString>& Files); // Offset: 0x10396f6c8 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.CheckBeforeInitPuffer
	// Flags: [Final|Native|Static|Public]
	void CheckBeforeInitPuffer(); // Offset: 0x10396f6b4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.ChangeLocalizationReleaseTestStatus
	// Flags: [Final|Native|Static|Public]
	void ChangeLocalizationReleaseTestStatus(struct UGameFrontendHUD* GameFrontendHUD, bool Status); // Offset: 0x10396f5fc // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.CanUseHapticsEngine
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool CanUseHapticsEngine(); // Offset: 0x10396f5c8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.CancelLocalNotification
	// Flags: [Final|Native|Static|Public]
	void CancelLocalNotification(int NotificationID); // Offset: 0x10396f554 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.CallIngameFirstTimeTips
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void CallIngameFirstTimeTips(struct UGameFrontendHUD* GameFrontendHUD, struct FString tableName, struct FString FunctionName); // Offset: 0x10396f434 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Client.ScriptHelperClient.CallEngineGC
	// Flags: [Final|Native|Static|Public]
	void CallEngineGC(); // Offset: 0x10396f420 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.CacheH5WebView
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void CacheH5WebView(struct FString ModuleName); // Offset: 0x10396f390 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.BuglySetAppVersion
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void BuglySetAppVersion(struct TScriptInterface<Class>& ClientNetInterface, struct FString Version); // Offset: 0x10396f28c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.BuglyPutUserData
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void BuglyPutUserData(struct TScriptInterface<Class>& ClientNetInterface, struct FString Key, struct FString Value); // Offset: 0x10396f110 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function Client.ScriptHelperClient.BuglyPostExceptionFull
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void BuglyPostExceptionFull(struct TScriptInterface<Class>& ClientNetInterface, int Category, struct FString Name, struct FString Msg, struct FString stack); // Offset: 0x10396eedc // Return & Params: Num(5) Size(0x48)

	// Object Name: Function Client.ScriptHelperClient.BuglyPostException
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void BuglyPostException(struct TScriptInterface<Class>& ClientNetInterface, int Category, struct FString Reason); // Offset: 0x10396ed98 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Client.ScriptHelperClient.BuglyLog
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void BuglyLog(struct TScriptInterface<Class>& ClientNetInterface, int Level, struct FString Tag, struct FString Log, bool needDump); // Offset: 0x10396eb8c // Return & Params: Num(5) Size(0x39)

	// Object Name: Function Client.ScriptHelperClient.AutoTestWaitForUIWithName
	// Flags: [Final|Native|Static|Public]
	void AutoTestWaitForUIWithName(struct FString UIName); // Offset: 0x10396eafc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.AutoTestWaitForSecond
	// Flags: [Final|Native|Static|Public]
	void AutoTestWaitForSecond(int sec); // Offset: 0x10396ea88 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.AutoTestWaitForJumpPlane
	// Flags: [Final|Native|Static|Public]
	bool AutoTestWaitForJumpPlane(); // Offset: 0x10396ea54 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.AutoTestVehicleDriverShoot
	// Flags: [Final|Native|Static|Public]
	void AutoTestVehicleDriverShoot(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x10396e9e0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.AutoTestVaultWall
	// Flags: [Final|Native|Static|Public]
	void AutoTestVaultWall(); // Offset: 0x10396e9cc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.AutoTestUsePropSkillClientEx
	// Flags: [Final|Native|Static|Public]
	void AutoTestUsePropSkillClientEx(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x10396e958 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.AutoTestUseItemClientEx
	// Flags: [Final|Native|Static|Public]
	void AutoTestUseItemClientEx(struct UGameFrontendHUD* GameFrontendHUD, int ItemID); // Offset: 0x10396e8a8 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.AutoTestUseItem
	// Flags: [Final|Native|Static|Public]
	void AutoTestUseItem(int ItemID); // Offset: 0x10396e834 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.AutoTestUpgradePropSkillClientEx
	// Flags: [Final|Native|Static|Public]
	void AutoTestUpgradePropSkillClientEx(struct UGameFrontendHUD* GameFrontendHUD, int ItemID); // Offset: 0x10396e784 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.AutoTestToggleVehicleSync
	// Flags: [Final|Native|Static|Public]
	void AutoTestToggleVehicleSync(struct UGameFrontendHUD* GameFrontendHUD, bool Val); // Offset: 0x10396e6cc // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.AutoTestThrowBoomOnlyClientEx
	// Flags: [Final|Native|Static|Public]
	void AutoTestThrowBoomOnlyClientEx(struct UGameFrontendHUD* GameFrontendHUD, int SkillID); // Offset: 0x10396e61c // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.AutoTestThrowBoom
	// Flags: [Final|Native|Static|Public]
	void AutoTestThrowBoom(int SkillID); // Offset: 0x10396e5a8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.AutoTestSwitchWeapon
	// Flags: [Final|Native|Static|Public]
	void AutoTestSwitchWeapon(int WeaponType); // Offset: 0x10396e534 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.AutoTestSwitchMode
	// Flags: [Final|Native|Static|Public]
	void AutoTestSwitchMode(struct FString FunName); // Offset: 0x10396e4a4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.AutoTestSwitchGameStatus
	// Flags: [Final|Native|Static|Public]
	void AutoTestSwitchGameStatus(struct UGameFrontendHUD* GameFrontendHUD, struct FName GameStatus, struct FString Options); // Offset: 0x10396e370 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.AutoTestStopRecordStats
	// Flags: [Final|Native|Static|Public]
	void AutoTestStopRecordStats(); // Offset: 0x10396e35c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.AutoTestStartRecordStats
	// Flags: [Final|Native|Static|Public]
	void AutoTestStartRecordStats(struct FString FileStr); // Offset: 0x10396e2cc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.AutoTestStartFireOnlyClientEx
	// Flags: [Final|Native|Static|Public]
	void AutoTestStartFireOnlyClientEx(struct UGameFrontendHUD* GameFrontendHUD, int X, int Y, int Z, int sec); // Offset: 0x10396e170 // Return & Params: Num(5) Size(0x18)

	// Object Name: Function Client.ScriptHelperClient.AutoTestStartFire
	// Flags: [Final|Native|Static|Public]
	void AutoTestStartFire(int X, int Y, int Z, int sec); // Offset: 0x10396e050 // Return & Params: Num(4) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.AutoTestSpecating
	// Flags: [Final|Native|Static|Public]
	void AutoTestSpecating(struct UGameFrontendHUD* GameFrontendHUD, int leftTeamCnt); // Offset: 0x10396dfa0 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.AutoTestSpawnVehicle
	// Flags: [Final|Native|Static|Public]
	void AutoTestSpawnVehicle(struct FString ResPath); // Offset: 0x10396deec // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.AutoTestSpawnAI
	// Flags: [Final|Native|Static|Public]
	void AutoTestSpawnAI(int ID, float PosiX, float PosiY, float PosiZ); // Offset: 0x10396ddc8 // Return & Params: Num(4) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.AutoTestSetVehicleRotation
	// Flags: [Final|Native|Static|Public]
	void AutoTestSetVehicleRotation(int X, int Y, int Z); // Offset: 0x10396dce0 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.AutoTestSetRecordFrequency
	// Flags: [Final|Native|Static|Public]
	void AutoTestSetRecordFrequency(uint32_t Frequency); // Offset: 0x10396dc6c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.AutoTestSetActorRotation
	// Flags: [Final|Native|Static|Public]
	void AutoTestSetActorRotation(float Rate, float Speed); // Offset: 0x10396dbc0 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.AutoTestSetActorPitch
	// Flags: [Final|Native|Static|Public]
	void AutoTestSetActorPitch(float Rate); // Offset: 0x10396db4c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.AutoTestSetActorFacePoint
	// Flags: [Final|Native|Static|Public]
	void AutoTestSetActorFacePoint(int X, int Y, int Z); // Offset: 0x10396da64 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.AutoTestSendBuffertoSvr
	// Flags: [Final|Native|Static|Public|HasOutParms]
	void AutoTestSendBuffertoSvr(struct TScriptInterface<Class>& ClientNetInterface); // Offset: 0x10396d9e0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.AutoTestReloadOnlyClientEx
	// Flags: [Final|Native|Static|Public]
	void AutoTestReloadOnlyClientEx(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x10396d96c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.AutoTestPickupItemOnlyClientEx
	// Flags: [Final|Native|Static|Public|HasDefaults]
	struct FVector2D AutoTestPickupItemOnlyClientEx(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x10396d8ec // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.AutoTestPickupItem
	// Flags: [Final|Native|Static|Public|HasDefaults]
	struct FVector2D AutoTestPickupItem(int ItemID); // Offset: 0x10396d86c // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.AutoTestOpenTraceRPC
	// Flags: [Final|Native|Static|Public]
	void AutoTestOpenTraceRPC(); // Offset: 0x10396d858 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.AutoTestOpenScope
	// Flags: [Final|Native|Static|Public]
	void AutoTestOpenScope(bool bOpenScope); // Offset: 0x10396d7dc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.AutoTestOpenDoorOnlyClientEx
	// Flags: [Final|Native|Static|Public]
	void AutoTestOpenDoorOnlyClientEx(struct UGameFrontendHUD* GameFrontendHUD, int bOpen); // Offset: 0x10396d72c // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.AutoTestMustDie
	// Flags: [Final|Native|Static|Public]
	void AutoTestMustDie(struct UGameFrontendHUD* GameFrontendHUD, int leftTeamCnt); // Offset: 0x10396d67c // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.AutoTestMoveVehicleForward
	// Flags: [Final|Native|Static|Public]
	void AutoTestMoveVehicleForward(float Speed, float Rate, float sec); // Offset: 0x10396d594 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.AutoTestMoveToPoint
	// Flags: [Final|Native|Static|Public]
	void AutoTestMoveToPoint(int X, int Y, int Z); // Offset: 0x10396d4ac // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.AutoTestJumpPlane
	// Flags: [Final|Native|Static|Public]
	void AutoTestJumpPlane(int sec); // Offset: 0x10396d438 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.AutoTestJump
	// Flags: [Final|Native|Static|Public]
	void AutoTestJump(); // Offset: 0x10396d424 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.AutoTestIsOnVehicle
	// Flags: [Final|Native|Static|Public]
	bool AutoTestIsOnVehicle(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x10396d3a8 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.AutoTestIsDriver
	// Flags: [Final|Native|Static|Public]
	bool AutoTestIsDriver(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x10396d32c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.ScriptHelperClient.AutoTestIsCurrentCommandFinished
	// Flags: [Final|Native|Static|Public]
	bool AutoTestIsCurrentCommandFinished(); // Offset: 0x10396d2f8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.AutoTestInputMovement
	// Flags: [Final|Native|Static|Public]
	void AutoTestInputMovement(float Rate); // Offset: 0x10396d284 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGMVehicleMoveAndTowardClientEx
	// Flags: [Final|Native|Static|Public]
	void AutoTestGMVehicleMoveAndTowardClientEx(struct UGameFrontendHUD* GameFrontendHUD, float X, float Y, float Z, float X1, float Y1, float Z1); // Offset: 0x10396d0b4 // Return & Params: Num(7) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGMGotoClientEx
	// Flags: [Final|Native|Static|Public]
	void AutoTestGMGotoClientEx(struct UGameFrontendHUD* GameFrontendHUD, int X, int Y, int Z); // Offset: 0x10396cf90 // Return & Params: Num(4) Size(0x14)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGMGoto
	// Flags: [Final|Native|Static|Public]
	void AutoTestGMGoto(int X, int Y, int Z); // Offset: 0x10396cea8 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGMCommand
	// Flags: [Final|Native|Static|Public]
	void AutoTestGMCommand(struct FString Command); // Offset: 0x10396ce18 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetVehicleLocationClientEx
	// Flags: [Final|Native|Static|Public|HasDefaults]
	struct FVector AutoTestGetVehicleLocationClientEx(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x10396cd98 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetVehicleLocation
	// Flags: [Final|Native|Static|Public|HasDefaults]
	struct FVector AutoTestGetVehicleLocation(); // Offset: 0x10396cd60 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetRuntimeStats
	// Flags: [Final|Native|Static|Public]
	void AutoTestGetRuntimeStats(); // Offset: 0x10396cd4c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetRenderTimeDetail
	// Flags: [Final|Native|Static|Public]
	void AutoTestGetRenderTimeDetail(); // Offset: 0x10396cd38 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetPrimitivesDetail
	// Flags: [Final|Native|Static|Public]
	void AutoTestGetPrimitivesDetail(); // Offset: 0x10396cd24 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetOnVehicle
	// Flags: [Final|Native|Static|Public]
	void AutoTestGetOnVehicle(int SeatType); // Offset: 0x10396ccb0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetOffVehicle
	// Flags: [Final|Native|Static|Public]
	void AutoTestGetOffVehicle(); // Offset: 0x10396cc9c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetNearVehiclePos
	// Flags: [Final|Native|Static|Public|HasDefaults]
	struct FVector AutoTestGetNearVehiclePos(); // Offset: 0x10396cc64 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetMemoryDetail
	// Flags: [Final|Native|Static|Public]
	void AutoTestGetMemoryDetail(); // Offset: 0x10396cc50 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetMapName
	// Flags: [Final|Native|Static|Public]
	struct FString AutoTestGetMapName(); // Offset: 0x10396cbec // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetGameModeState
	// Flags: [Final|Native|Static|Public]
	struct FString AutoTestGetGameModeState(); // Offset: 0x10396cb88 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetFrameInfo
	// Flags: [Final|Native|Static|Public|HasDefaults]
	struct FVector AutoTestGetFrameInfo(); // Offset: 0x10396cb50 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetDrawCallDetail
	// Flags: [Final|Native|Static|Public]
	void AutoTestGetDrawCallDetail(); // Offset: 0x10396cb3c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetDis2D
	// Flags: [Final|Native|Static|Public]
	int AutoTestGetDis2D(int X, int Y, int Z, int x2, int y2, int z2); // Offset: 0x10396c99c // Return & Params: Num(7) Size(0x1c)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetCircleLocationClientEx
	// Flags: [Final|Native|Static|Public|HasDefaults]
	struct FVector AutoTestGetCircleLocationClientEx(struct UGameFrontendHUD* GameFrontendHUD); // Offset: 0x10396c91c // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetAvailableDeadBoxItem
	// Flags: [Final|Native|Static|Public]
	struct TArray<int> AutoTestGetAvailableDeadBoxItem(); // Offset: 0x10396c8b8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetActorName
	// Flags: [Final|Native|Static|Public]
	struct FString AutoTestGetActorName(); // Offset: 0x10396c854 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetActorLocationListClientEx
	// Flags: [Final|Native|Static|Public]
	struct TArray<struct FVector> AutoTestGetActorLocationListClientEx(struct UGameFrontendHUD* GameFrontendHUD, int ActorType, float RangeRadius); // Offset: 0x10396c738 // Return & Params: Num(4) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.AutoTestGetActorLocation
	// Flags: [Final|Native|Static|Public|HasDefaults]
	struct FVector AutoTestGetActorLocation(struct FString PlayerName); // Offset: 0x10396c698 // Return & Params: Num(2) Size(0x1c)

	// Object Name: Function Client.ScriptHelperClient.AutoTestForceVehiclePosPullClientEx
	// Flags: [Final|Native|Static|Public]
	float AutoTestForceVehiclePosPullClientEx(struct UGameFrontendHUD* GameFrontendHUD, bool bNext); // Offset: 0x10396c5d8 // Return & Params: Num(3) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.AutoTestForceDeleteCmdAnim
	// Flags: [Final|Native|Static|Public]
	void AutoTestForceDeleteCmdAnim(); // Offset: 0x10396c5c4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.AutoTestEnableUITest
	// Flags: [Final|Native|Static|Public]
	void AutoTestEnableUITest(); // Offset: 0x10396c5b0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.AutoTestDropItemClientEx
	// Flags: [Final|Native|Static|Public]
	void AutoTestDropItemClientEx(struct UGameFrontendHUD* GameFrontendHUD, int ItemID, int nCount); // Offset: 0x10396c4c8 // Return & Params: Num(3) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.AutoTestContinuousMoveTo
	// Flags: [Final|Native|Static|Public]
	void AutoTestContinuousMoveTo(float X, float Y, float Z); // Offset: 0x10396c3e0 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Client.ScriptHelperClient.AutoTestConsoleCommand
	// Flags: [Final|Native|Static|Public]
	void AutoTestConsoleCommand(struct FString Command); // Offset: 0x10396c350 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.AutoTestCloseTraceRPC
	// Flags: [Final|Native|Static|Public]
	void AutoTestCloseTraceRPC(); // Offset: 0x10396c33c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.AutoTestClickButton
	// Flags: [Final|Native|Static|Public]
	void AutoTestClickButton(struct FString ButtonName); // Offset: 0x10396c2ac // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.AutoTestAddItemClientEx
	// Flags: [Final|Native|Static|Public]
	void AutoTestAddItemClientEx(struct UGameFrontendHUD* GameFrontendHUD, int ItemID, int nCount); // Offset: 0x10396c1c4 // Return & Params: Num(3) Size(0x10)

	// Object Name: Function Client.ScriptHelperClient.AutoTestAddItem
	// Flags: [Final|Native|Static|Public]
	void AutoTestAddItem(int ItemID, int nCount); // Offset: 0x10396c118 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.AutoMoveToTargetPosClientEx
	// Flags: [Final|Native|Static|Public|HasDefaults]
	void AutoMoveToTargetPosClientEx(struct UGameFrontendHUD* GameFrontendHUD, struct FVector targetPos); // Offset: 0x10396c068 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.ScriptHelperClient.AskForNotificationPermission
	// Flags: [Final|Native|Static|Public]
	void AskForNotificationPermission(); // Offset: 0x10396c054 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.AndroidShouldShowPermissionRationale
	// Flags: [Final|Native|Static|Public]
	bool AndroidShouldShowPermissionRationale(); // Offset: 0x10396c020 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.AndroidCheckPermission
	// Flags: [Final|Native|Static|Public]
	bool AndroidCheckPermission(); // Offset: 0x10396bfec // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.AkAudio_UnloadInitBank
	// Flags: [Final|Native|Static|Public]
	void AkAudio_UnloadInitBank(); // Offset: 0x10396bfd8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.AkAudio_UnloadAllFilePackages
	// Flags: [Final|Native|Static|Public]
	void AkAudio_UnloadAllFilePackages(); // Offset: 0x10396bfc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.AkAudio_StopAllSounds
	// Flags: [Final|Native|Static|Public]
	void AkAudio_StopAllSounds(bool bShouldStopUISounds); // Offset: 0x10396bf48 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperClient.AkAudio_LoadInitBank
	// Flags: [Final|Native|Static|Public]
	void AkAudio_LoadInitBank(); // Offset: 0x10396bf34 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.AkAudio_Flush
	// Flags: [Final|Native|Static|Public]
	void AkAudio_Flush(struct UWorld* WorldToFlush); // Offset: 0x10396bec0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.AkAudio_ClearBanks
	// Flags: [Final|Native|Static|Public]
	void AkAudio_ClearBanks(); // Offset: 0x10396beac // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ScriptHelperClient.AddMemoryLogSize
	// Flags: [Final|Native|Static|Public]
	int AddMemoryLogSize(int b_size); // Offset: 0x10396be30 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.ScriptHelperClient.AddKnownMissingPackage
	// Flags: [Final|Native|Static|Public]
	void AddKnownMissingPackage(struct FString PackageName, struct UObject* BindObj, bool bReplace); // Offset: 0x10396bcf4 // Return & Params: Num(3) Size(0x19)

	// Object Name: Function Client.ScriptHelperClient.AddCrashContextData
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void AddCrashContextData(int Key, struct FString Val, bool bAppendTimeStamp, int reportLevel); // Offset: 0x10396bba0 // Return & Params: Num(4) Size(0x20)

	// Object Name: Function Client.ScriptHelperClient.AddAttachFileString
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void AddAttachFileString(struct FString Type, bool bClear, struct FString& strinfo); // Offset: 0x10396ba38 // Return & Params: Num(3) Size(0x28)
};

// Object Name: Class Client.ScriptHelperEngine
// Size: 0x28 // Inherited bytes: 0x28
struct UScriptHelperEngine : UObject {
	// Functions

	// Object Name: Function Client.ScriptHelperEngine.TestLz4Decompress
	// Flags: [Final|Native|Static|Public|HasOutParms]
	struct TArray<char> TestLz4Decompress(struct TArray<char>& Source, bool bEnable); // Offset: 0x103997ae0 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Client.ScriptHelperEngine.TestLz4Compress
	// Flags: [Final|Native|Static|Public|HasOutParms]
	struct TArray<char> TestLz4Compress(struct TArray<char>& Source); // Offset: 0x103997a10 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.ScriptHelperEngine.ReplaceEmoji
	// Flags: [Final|Native|Static|Public]
	struct FString ReplaceEmoji(struct FString Content, int MaxEmojiNum, struct FString SpecialCharacter); // Offset: 0x1039978bc // Return & Params: Num(4) Size(0x38)

	// Object Name: Function Client.ScriptHelperEngine.IsLowMemoryDevice
	// Flags: [Final|Native|Static|Public]
	bool IsLowMemoryDevice(); // Offset: 0x103997888 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ScriptHelperEngine.GetMemoryUsedVirtualInKB
	// Flags: [Final|Native|Static|Public]
	float GetMemoryUsedVirtualInKB(); // Offset: 0x103997854 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ScriptHelperEngine.GetMemoryUsedPhysicalInKB
	// Flags: [Final|Native|Static|Public]
	float GetMemoryUsedPhysicalInKB(); // Offset: 0x103997820 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class Client.SDKCallbackHelper
// Size: 0x88 // Inherited bytes: 0x28
struct USDKCallbackHelper : UObject {
	// Fields
	struct FScriptMulticastDelegate SDKCallbackDelegate; // Offset: 0x28 // Size: 0x10
	char pad_0x38[0x50]; // Offset: 0x38 // Size: 0x50

	// Functions

	// Object Name: Function Client.SDKCallbackHelper.Init
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Init(); // Offset: 0x103998060 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.SDKCallbackHelper.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct USDKCallbackHelper* GetInstance(); // Offset: 0x10399802c // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class Client.SettingSubsystem
// Size: 0x270 // Inherited bytes: 0x30
struct USettingSubsystem : UGameInstanceSubsystem {
	// Fields
	bool bUseRegisterDelegateOptimize; // Offset: 0x30 // Size: 0x01
	char pad_0x31[0x7]; // Offset: 0x31 // Size: 0x07
	struct TMap<struct FString, bool> CacheRegisterProperties_Bool; // Offset: 0x38 // Size: 0x50
	struct TMap<struct FString, int> CacheRegisterProperties_Int; // Offset: 0x88 // Size: 0x50
	struct TMap<struct FString, float> CacheRegisterProperties_Float; // Offset: 0xd8 // Size: 0x50
	struct FString CachedSaveGameName; // Offset: 0x128 // Size: 0x10
	struct TArray<struct FCustomSettingSaveGame> CustomSettingSaveGames; // Offset: 0x138 // Size: 0x10
	DelegateProperty GetUserSettingsDelegate; // Offset: 0x148 // Size: 0x10
	struct UEffectSettingMgr* EffectSettingMgrInstace; // Offset: 0x158 // Size: 0x08
	struct USaveGame* UserSettings; // Offset: 0x160 // Size: 0x08
	struct UObject* UserSettingsClass; // Offset: 0x168 // Size: 0x08
	struct FString UserSettingsClassName; // Offset: 0x170 // Size: 0x10
	struct FString ActiveSaveGameName; // Offset: 0x180 // Size: 0x10
	char pad_0x190[0x8]; // Offset: 0x190 // Size: 0x08
	struct FString LanguageSettingsClassName; // Offset: 0x198 // Size: 0x10
	struct FString LanguageSaveGameName; // Offset: 0x1a8 // Size: 0x10
	char pad_0x1B8[0x60]; // Offset: 0x1b8 // Size: 0x60
	struct TMap<struct FString, bool> LanguageMap; // Offset: 0x218 // Size: 0x50
	char pad_0x268[0x8]; // Offset: 0x268 // Size: 0x08

	// Functions

	// Object Name: Function Client.SettingSubsystem.SetUserSettings_String
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetUserSettings_String(struct FString PropertyName, struct FString Val); // Offset: 0x10399941c // Return & Params: Num(3) Size(0x21)

	// Object Name: Function Client.SettingSubsystem.SetUserSettings_Int
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetUserSettings_Int(struct FString PropertyName, int Value); // Offset: 0x103999334 // Return & Params: Num(3) Size(0x15)

	// Object Name: Function Client.SettingSubsystem.SetUserSettings_Float
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetUserSettings_Float(struct FString PropertyName, float Value); // Offset: 0x10399924c // Return & Params: Num(3) Size(0x15)

	// Object Name: Function Client.SettingSubsystem.SetUserSettings_Bool
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetUserSettings_Bool(struct FString PropertyName, bool Value, bool IngoreSave); // Offset: 0x103999114 // Return & Params: Num(4) Size(0x13)

	// Object Name: Function Client.SettingSubsystem.RegisterUserSettingsDelegate_Int
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RegisterUserSettingsDelegate_Int(struct FString PropertyName, DelegateProperty Delegate); // Offset: 0x103999028 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.SettingSubsystem.RegisterUserSettingsDelegate_Float
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RegisterUserSettingsDelegate_Float(struct FString PropertyName, DelegateProperty Delegate); // Offset: 0x103998f3c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.SettingSubsystem.RegisterUserSettingsDelegate_Bool
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RegisterUserSettingsDelegate_Bool(struct FString PropertyName, DelegateProperty Delegate); // Offset: 0x103998e50 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.SettingSubsystem.RegisterUserSettingsDelegate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RegisterUserSettingsDelegate(DelegateProperty Delegate); // Offset: 0x103998dc0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.SettingSubsystem.GetUserSettingsByDelegate
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct USaveGame* GetUserSettingsByDelegate(struct FString LayoutName); // Offset: 0x103998d18 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.SettingSubsystem.GetUserSettings_String
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetUserSettings_String(struct FString PropertyName); // Offset: 0x103998c48 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.SettingSubsystem.GetUserSettings_Int
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetUserSettings_Int(struct FString PropertyName); // Offset: 0x103998ba0 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.SettingSubsystem.GetUserSettings_Float
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetUserSettings_Float(struct FString PropertyName); // Offset: 0x103998af8 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.SettingSubsystem.GetUserSettings_Bool
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool GetUserSettings_Bool(struct FString PropertyName); // Offset: 0x103998a50 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.SettingSubsystem.GetUserSettings
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct USaveGame* GetUserSettings(); // Offset: 0x103998a1c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.SettingSubsystem.GetUserLanguageSettingsProperty_String
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GetUserLanguageSettingsProperty_String(struct FString PropertyName); // Offset: 0x10399894c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.SettingSubsystem.GetEffectSettingMgr
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UEffectSettingMgr* GetEffectSettingMgr(); // Offset: 0x103998918 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.SettingSubsystem.GetCustomSetting
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct USaveGame* GetCustomSetting(struct FString InSlotName); // Offset: 0x103998870 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.SettingSubsystem.FinishModifyUserSettings
	// Flags: [Final|Native|Public|BlueprintCallable]
	void FinishModifyUserSettings(); // Offset: 0x10399885c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.SettingSubsystem.CheckLocalizationLanguage
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CheckLocalizationLanguage(); // Offset: 0x103998848 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.SettingSubsystem.CheckChangeWithCache
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool CheckChangeWithCache(struct UObject* Source, struct UProperty* Property, struct FString PropertyName); // Offset: 0x103998700 // Return & Params: Num(4) Size(0x21)

	// Object Name: Function Client.SettingSubsystem.CacheRegisterValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CacheRegisterValue(struct UObject* Source, struct UProperty* Property, struct FString PropertyName); // Offset: 0x1039985c0 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function Client.SettingSubsystem.BeginModifyUserSettings
	// Flags: [Final|Native|Public|BlueprintCallable]
	void BeginModifyUserSettings(); // Offset: 0x1039985ac // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.SettingSubsystem.AddCustomSetting
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddCustomSetting(struct FString InSlotName, struct USaveGame* InSaveGame); // Offset: 0x1039984d4 // Return & Params: Num(2) Size(0x18)
};

// Object Name: Class Client.STExtraClientUtils
// Size: 0x28 // Inherited bytes: 0x28
struct USTExtraClientUtils : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function Client.STExtraClientUtils.GetWidgetHandleAsyncWithCallBack
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void GetWidgetHandleAsyncWithCallBack(struct UObject* WorldContext, struct FString ModuleName, struct FString WidgetKey, DelegateProperty Callback); // Offset: 0x103999fdc // Return & Params: Num(4) Size(0x38)

	// Object Name: Function Client.STExtraClientUtils.GetDynamicWidgetHandle
	// Flags: [Final|Exec|Native|Public|BlueprintCallable]
	struct UUAEUserWidget* GetDynamicWidgetHandle(struct UObject* WorldContext, struct FString ModuleName, struct FString WidetKey); // Offset: 0x103999ea4 // Return & Params: Num(4) Size(0x30)

	// Object Name: Function Client.STExtraClientUtils.GetBPUtils
	// Flags: [Final|Native|Static|Public]
	struct USTExtraClientUIBPUtils* GetBPUtils(); // Offset: 0x103999e70 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.STExtraClientUtils.AsyncLoadAssetInstWithCallback
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int AsyncLoadAssetInstWithCallback(struct FString InPath, DelegateProperty Callback); // Offset: 0x103999d84 // Return & Params: Num(3) Size(0x24)
};

// Object Name: Class Client.STExtraClientUIBPUtils
// Size: 0x148 // Inherited bytes: 0x28
struct USTExtraClientUIBPUtils : UObject {
	// Fields
	char pad_0x28[0xd0]; // Offset: 0x28 // Size: 0xd0
	struct TMap<int, struct FAssetAsyncRequest> PendingAsyncAssetRequests; // Offset: 0xf8 // Size: 0x50

	// Functions

	// Object Name: Function Client.STExtraClientUIBPUtils.OnAsyncAssetLoaded
	// Flags: [Final|Native|Public|HasDefaults]
	void OnAsyncAssetLoaded(struct FSoftObjectPath InSoftPath, int RequestIdx); // Offset: 0x10399a464 // Return & Params: Num(2) Size(0x1c)

	// Object Name: Function Client.STExtraClientUIBPUtils.AsyncLoadAssetInstWithCallback
	// Flags: [Final|Native|Public]
	int AsyncLoadAssetInstWithCallback(struct FString InPath, DelegateProperty Callback); // Offset: 0x10399a368 // Return & Params: Num(3) Size(0x24)
};

// Object Name: Class Client.Translator
// Size: 0x138 // Inherited bytes: 0x28
struct UTranslator : UObject {
	// Fields
	struct FString SubscriptionKey; // Offset: 0x28 // Size: 0x10
	struct FString StoredAccessToken; // Offset: 0x38 // Size: 0x10
	DelegateProperty OnGetAccessTokenDelegate; // Offset: 0x48 // Size: 0x10
	DelegateProperty OnDetectDelegate; // Offset: 0x58 // Size: 0x10
	DelegateProperty OnTranslateDelegate; // Offset: 0x68 // Size: 0x10
	char pad_0x78[0x98]; // Offset: 0x78 // Size: 0x98
	struct UGameFrontendHUD* GameFrontendHUD; // Offset: 0x110 // Size: 0x08
	char pad_0x118[0x20]; // Offset: 0x118 // Size: 0x20

	// Functions

	// Object Name: Function Client.Translator.TranslateV2
	// Flags: [Final|Native|Public|BlueprintCallable]
	void TranslateV2(int Channel, int ID, struct FString Text); // Offset: 0x10399b4bc // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Client.Translator.Translate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Translate(struct FString URL, struct FString Verb, struct TMap<struct FString, struct FString> Headers, struct FString Content); // Offset: 0x10399b2fc // Return & Params: Num(4) Size(0x80)

	// Object Name: Function Client.Translator.PostMsg
	// Flags: [Final|Native|Public|BlueprintCallable]
	void PostMsg(struct FString URL, struct FString Content); // Offset: 0x10399b210 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Client.Translator.OnTranslateV2
	// Flags: [Final|Native|Private]
	void OnTranslateV2(bool Success, struct FString Data); // Offset: 0x10399b12c // Return & Params: Num(2) Size(0x18)

	// Object Name: DelegateFunction Client.Translator.OnTranslate__DelegateSignature
	// Flags: [Public|Delegate]
	void OnTranslate__DelegateSignature(bool IsSuccess, struct FString LanguageFrom, struct FString Translation); // Offset: 0x103df3e6c // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Client.Translator.OnTranslate
	// Flags: [Final|Native|Private]
	void OnTranslate(bool Success, struct FString Data); // Offset: 0x10399b048 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.Translator.OnGetAccessTokenV2
	// Flags: [Final|Native|Private]
	void OnGetAccessTokenV2(bool Success, struct FString Data); // Offset: 0x10399af64 // Return & Params: Num(2) Size(0x18)

	// Object Name: DelegateFunction Client.Translator.OnGetAccessToken__DelegateSignature
	// Flags: [Public|Delegate]
	void OnGetAccessToken__DelegateSignature(bool IsSuccess, struct FString Token); // Offset: 0x103df3e6c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.Translator.OnGetAccessToken
	// Flags: [Final|Native|Private]
	void OnGetAccessToken(bool Success, struct FString Data); // Offset: 0x10399ae80 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.Translator.OnDetectV2
	// Flags: [Final|Native|Private]
	void OnDetectV2(bool Success, struct FString Data); // Offset: 0x10399ad9c // Return & Params: Num(2) Size(0x18)

	// Object Name: DelegateFunction Client.Translator.OnDetect__DelegateSignature
	// Flags: [Public|Delegate]
	void OnDetect__DelegateSignature(bool IsSuccess, struct FString from, struct FString to); // Offset: 0x103df3e6c // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Client.Translator.OnDetect
	// Flags: [Final|Native|Private]
	void OnDetect(bool Success, struct FString Data); // Offset: 0x10399acb8 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.Translator.HasTranslating
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool HasTranslating(); // Offset: 0x10399ac84 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.Translator.GetAccessToken
	// Flags: [Final|Native|Public|BlueprintCallable]
	void GetAccessToken(bool bForceGet, struct FString URL, struct FString Verb, struct TMap<struct FString, struct FString> Headers, struct FString Content); // Offset: 0x10399aa78 // Return & Params: Num(5) Size(0x88)

	// Object Name: Function Client.Translator.Detect
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Detect(struct FString URL, struct FString Verb, struct TMap<struct FString, struct FString> Headers, struct FString Content); // Offset: 0x10399a8b8 // Return & Params: Num(4) Size(0x80)
};

// Object Name: Class Client.TssManager
// Size: 0x60 // Inherited bytes: 0x28
struct UTssManager : UObject {
	// Fields
	struct FString TssHostInfo; // Offset: 0x28 // Size: 0x10
	struct FString TssCDNHostInfo; // Offset: 0x38 // Size: 0x10
	struct FString TssBuildInIpInfo; // Offset: 0x48 // Size: 0x10
	int TssLocal; // Offset: 0x58 // Size: 0x04
	char pad_0x5C[0x4]; // Offset: 0x5c // Size: 0x04

	// Functions

	// Object Name: Function Client.TssManager.SendSkdData_LuaState
	// Flags: [Final|Native|Static|Public]
	int SendSkdData_LuaState(); // Offset: 0x10399bb64 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.TssManager.SendEigeninfoData_LuaState
	// Flags: [Final|Native|Static|Public]
	int SendEigeninfoData_LuaState(); // Offset: 0x10399bb4c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.TssManager.SaveSendEigeninfoCode_LuaState
	// Flags: [Final|Native|Static|Public]
	uint32_t SaveSendEigeninfoCode_LuaState(); // Offset: 0x10399bb34 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.TssManager.OnRecvData_LuaState
	// Flags: [Final|Native|Static|Public]
	int OnRecvData_LuaState(); // Offset: 0x10399bb1c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.TssManager.InvokeSDKIoctl
	// Flags: [Final|Native|Static|Public]
	uint32_t InvokeSDKIoctl(int Command, struct FString InCmdData); // Offset: 0x10399ba48 // Return & Params: Num(3) Size(0x1c)

	// Object Name: Function Client.TssManager.GetUserTag4Lua_LuaState
	// Flags: [Final|Native|Static|Public]
	int GetUserTag4Lua_LuaState(); // Offset: 0x10399ba30 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.TssManager.GetDeviceFeature_LuaState
	// Flags: [Final|Native|Static|Public]
	int GetDeviceFeature_LuaState(); // Offset: 0x10399ba18 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.TssManager.EigenArrayObfuscationVerify_LuaState
	// Flags: [Final|Native|Static|Public]
	int EigenArrayObfuscationVerify_LuaState(); // Offset: 0x10399ba00 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class Client.UAEClientGameMode
// Size: 0x4a8 // Inherited bytes: 0x4a8
struct AUAEClientGameMode : AGameMode {
};

// Object Name: Class Client.UAELobbyGameMode
// Size: 0x4a8 // Inherited bytes: 0x4a8
struct AUAELobbyGameMode : AUAEClientGameMode {
};

// Object Name: Class Client.UAELobbyPlayerController
// Size: 0x740 // Inherited bytes: 0x740
struct AUAELobbyPlayerController : APlayerController {
};

// Object Name: Class Client.UTRichTextBlock
// Size: 0xb08 // Inherited bytes: 0x100
struct UUTRichTextBlock : UWidget {
	// Fields
	char pad_0x100[0x8]; // Offset: 0x100 // Size: 0x08
	struct FScriptMulticastDelegate OnHyperlinkClicked; // Offset: 0x108 // Size: 0x10
	struct FString ContentText; // Offset: 0x118 // Size: 0x10
	char pad_0x128[0x10]; // Offset: 0x128 // Size: 0x10
	struct FSlateFontInfo Font; // Offset: 0x138 // Size: 0x58
	bool bSupportHyLink; // Offset: 0x190 // Size: 0x01
	bool bSupportImage; // Offset: 0x191 // Size: 0x01
	char pad_0x192[0x2]; // Offset: 0x192 // Size: 0x02
	struct FLinearColor TextColor; // Offset: 0x194 // Size: 0x10
	enum class ETextJustify Justification; // Offset: 0x1a4 // Size: 0x01
	enum class ETextVerticalJustify TextVerticalJustification; // Offset: 0x1a5 // Size: 0x01
	bool AutoWrapText; // Offset: 0x1a6 // Size: 0x01
	char pad_0x1A7[0x1]; // Offset: 0x1a7 // Size: 0x01
	struct FScrollBarStyle ScrollBarStyle; // Offset: 0x1a8 // Size: 0x680
	struct FMargin HScrollBarPadding; // Offset: 0x828 // Size: 0x10
	struct FMargin VScrollBarPadding; // Offset: 0x838 // Size: 0x10
	float WrapTextAt; // Offset: 0x848 // Size: 0x04
	struct FMargin Margin; // Offset: 0x84c // Size: 0x10
	float LineHeightPercentage; // Offset: 0x85c // Size: 0x04
	struct FString HyperlinkDecoratorTag; // Offset: 0x860 // Size: 0x10
	struct FString HyperlinkCallBackFunctionName; // Offset: 0x870 // Size: 0x10
	struct FString HyperlinkCallBackTableName; // Offset: 0x880 // Size: 0x10
	char pad_0x890[0x270]; // Offset: 0x890 // Size: 0x270
	struct UGameFrontendHUD* GameFrontendHUD; // Offset: 0xb00 // Size: 0x08

	// Functions

	// Object Name: Function Client.UTRichTextBlock.SetText
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetText(struct FText InText); // Offset: 0x10399c3ac // Return & Params: Num(1) Size(0x18)

	// Object Name: Function Client.UTRichTextBlock.SetGameFrontendHUD
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetGameFrontendHUD(struct UGameFrontendHUD* InHUD); // Offset: 0x10399c330 // Return & Params: Num(1) Size(0x8)

	// Object Name: DelegateFunction Client.UTRichTextBlock.OnHyperlinkClickedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void OnHyperlinkClickedEvent__DelegateSignature(struct FMetaDataHolder& MetaDataHolder); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x50)

	// Object Name: Function Client.UTRichTextBlock.GetText
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FText GetText(); // Offset: 0x10399c2cc // Return & Params: Num(1) Size(0x18)
};

// Object Name: Class Client.AEVarButton
// Size: 0x550 // Inherited bytes: 0x118
struct UAEVarButton : UContentWidget {
	// Fields
	struct USlateWidgetStyleAsset* Style; // Offset: 0x118 // Size: 0x08
	struct FButtonStyle WidgetStyle; // Offset: 0x120 // Size: 0x338
	struct FLinearColor ColorAndOpacity; // Offset: 0x458 // Size: 0x10
	struct FLinearColor BackgroundColor; // Offset: 0x468 // Size: 0x10
	enum class EButtonClickMethod ClickMethod; // Offset: 0x478 // Size: 0x01
	enum class EButtonTouchMethod TouchMethod; // Offset: 0x479 // Size: 0x01
	bool IsFocusable; // Offset: 0x47a // Size: 0x01
	bool IsPassMouseEvent; // Offset: 0x47b // Size: 0x01
	char pad_0x47C[0x4]; // Offset: 0x47c // Size: 0x04
	struct FString ButtonVar; // Offset: 0x480 // Size: 0x10
	struct FScriptMulticastDelegate OnButtonClicked; // Offset: 0x490 // Size: 0x10
	struct FScriptMulticastDelegate OnButtonPressed; // Offset: 0x4a0 // Size: 0x10
	struct FScriptMulticastDelegate OnButtonReleased; // Offset: 0x4b0 // Size: 0x10
	struct FScriptMulticastDelegate OnButtonHovered; // Offset: 0x4c0 // Size: 0x10
	struct FScriptMulticastDelegate OnButtonUnhovered; // Offset: 0x4d0 // Size: 0x10
	DelegateProperty OnMouseButtonDownEvent; // Offset: 0x4e0 // Size: 0x10
	char pad_0x4F0[0x10]; // Offset: 0x4f0 // Size: 0x10
	struct FScriptMulticastDelegate OnClicked; // Offset: 0x500 // Size: 0x10
	struct FScriptMulticastDelegate OnPressed; // Offset: 0x510 // Size: 0x10
	struct FScriptMulticastDelegate OnReleased; // Offset: 0x520 // Size: 0x10
	struct FScriptMulticastDelegate OnHovered; // Offset: 0x530 // Size: 0x10
	struct FScriptMulticastDelegate OnUnhovered; // Offset: 0x540 // Size: 0x10

	// Functions

	// Object Name: Function Client.AEVarButton.SetTouchMethod
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTouchMethod(enum class EButtonTouchMethod InTouchMethod); // Offset: 0x10399c984 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.AEVarButton.SetStyle
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetStyle(struct FButtonStyle& InStyle); // Offset: 0x10399c8d0 // Return & Params: Num(1) Size(0x338)

	// Object Name: Function Client.AEVarButton.SetColorAndOpacity
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetColorAndOpacity(struct FLinearColor InColorAndOpacity); // Offset: 0x10399c854 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.AEVarButton.SetClickMethod
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetClickMethod(enum class EButtonClickMethod InClickMethod); // Offset: 0x10399c7d8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.AEVarButton.SetBackgroundColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetBackgroundColor(struct FLinearColor InBackgroundColor); // Offset: 0x10399c75c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.AEVarButton.IsPressed
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsPressed(); // Offset: 0x10399c728 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class Client.ReuseFallC
// Size: 0xf08 // Inherited bytes: 0x260
struct UReuseFallC : UUserWidget {
	// Fields
	struct FScriptMulticastDelegate OnBeforeNewItem; // Offset: 0x260 // Size: 0x10
	struct FScriptMulticastDelegate OnAfterNewItem; // Offset: 0x270 // Size: 0x10
	struct FScriptMulticastDelegate OnRefreshItem; // Offset: 0x280 // Size: 0x10
	struct FScriptMulticastDelegate OnItemCreated; // Offset: 0x290 // Size: 0x10
	struct FScriptMulticastDelegate OnTouchFinish; // Offset: 0x2a0 // Size: 0x10
	struct FScriptMulticastDelegate OnOverscrollState; // Offset: 0x2b0 // Size: 0x10
	struct FScrollBoxStyle ScrollBoxStyle; // Offset: 0x2c0 // Size: 0x2e8
	enum class EWidgetClipping ScrollBoxClipping; // Offset: 0x5a8 // Size: 0x01
	char pad_0x5A9[0x7]; // Offset: 0x5a9 // Size: 0x07
	struct FScrollBarStyle ScrollBarStyle; // Offset: 0x5b0 // Size: 0x680
	enum class ESlateVisibility ScrollBarVisibility; // Offset: 0xc30 // Size: 0x01
	char pad_0xC31[0x3]; // Offset: 0xc31 // Size: 0x03
	struct FVector2D ScrollbarThickness; // Offset: 0xc34 // Size: 0x08
	int ColumnNum; // Offset: 0xc3c // Size: 0x04
	int ItemHeight; // Offset: 0xc40 // Size: 0x04
	int ItemPaddingX; // Offset: 0xc44 // Size: 0x04
	int ItemPaddingY; // Offset: 0xc48 // Size: 0x04
	float OverscrollLength; // Offset: 0xc4c // Size: 0x04
	struct UUserWidget* ItemClass; // Offset: 0xc50 // Size: 0x08
	struct TMap<struct FString, struct UUserWidget*> OtherItemClass; // Offset: 0xc58 // Size: 0x50
	int PreviewCount; // Offset: 0xca8 // Size: 0x04
	int ItemPoolMaxNum; // Offset: 0xcac // Size: 0x04
	int TopSpaceReserved; // Offset: 0xcb0 // Size: 0x04
	int BottomSpaceReserved; // Offset: 0xcb4 // Size: 0x04
	char pad_0xCB8[0x38]; // Offset: 0xcb8 // Size: 0x38
	struct UUserWidget* CurItemClass; // Offset: 0xcf0 // Size: 0x08
	char pad_0xCF8[0x210]; // Offset: 0xcf8 // Size: 0x210

	// Functions

	// Object Name: Function Client.ReuseFallC.SetScrollOffset
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetScrollOffset(float NewScrollOffset); // Offset: 0x10399d3a0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReuseFallC.SetItemSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetItemSize(int __Idx, float __Size); // Offset: 0x10399d2e8 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.ReuseFallC.SetItemFullStyle
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetItemFullStyle(int idx); // Offset: 0x10399d26c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReuseFallC.SetCurItemClass
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetCurItemClass(struct FString StrName); // Offset: 0x10399d1c4 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ReuseFallC.ScrollToStart
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ScrollToStart(); // Offset: 0x10399d1b0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ReuseFallC.ScrollToEnd
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ScrollToEnd(); // Offset: 0x10399d19c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ReuseFallC.ResetCurItemClassToDefault
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ResetCurItemClassToDefault(); // Offset: 0x10399d188 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ReuseFallC.Reload
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Reload(int __ItemCount); // Offset: 0x10399d10c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReuseFallC.RefreshOne
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RefreshOne(int __Idx); // Offset: 0x10399d090 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReuseFallC.Refresh
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Refresh(); // Offset: 0x10399d07c // Return & Params: Num(0) Size(0x0)

	// Object Name: DelegateFunction Client.ReuseFallC.OnUpdateItemDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnUpdateItemDelegate__DelegateSignature(struct UUserWidget* Widget, int idx); // Offset: 0x103df3e6c // Return & Params: Num(2) Size(0xc)

	// Object Name: DelegateFunction Client.ReuseFallC.OnTouchFinishDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnTouchFinishDelegate__DelegateSignature(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ReuseFallC.OnTouchFinishCallback
	// Flags: [Final|Native|Protected]
	void OnTouchFinishCallback(); // Offset: 0x10399d068 // Return & Params: Num(0) Size(0x0)

	// Object Name: DelegateFunction Client.ReuseFallC.OnOverscrollStateDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnOverscrollStateDelegate__DelegateSignature(enum class EReuseFallOverscrollState State); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x1)

	// Object Name: DelegateFunction Client.ReuseFallC.OnCreateItemDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnCreateItemDelegate__DelegateSignature(struct UUserWidget* Widget, int idx); // Offset: 0x103df3e6c // Return & Params: Num(2) Size(0xc)

	// Object Name: DelegateFunction Client.ReuseFallC.OnBeforeNewItemDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnBeforeNewItemDelegate__DelegateSignature(int idx); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x4)

	// Object Name: DelegateFunction Client.ReuseFallC.OnAfterNewItemDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnAfterNewItemDelegate__DelegateSignature(struct UUserWidget* Widget, int idx); // Offset: 0x103df3e6c // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Client.ReuseFallC.JumpByIdx
	// Flags: [Final|Native|Public|BlueprintCallable]
	void JumpByIdx(int __Idx, bool bImmedia); // Offset: 0x10399cfac // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Client.ReuseFallC.GetViewSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector2D GetViewSize(); // Offset: 0x10399cf90 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ReuseFallC.GetScrollOffset
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetScrollOffset(); // Offset: 0x10399cf5c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReuseFallC.GetOverscrollState
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class EReuseFallOverscrollState GetOverscrollState(); // Offset: 0x10399cf40 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ReuseFallC.GetContentSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector2D GetContentSize(); // Offset: 0x10399cf24 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ReuseFallC.ClearItemFullStyle
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearItemFullStyle(); // Offset: 0x10399cf10 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ReuseFallC.Clear
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Clear(); // Offset: 0x10399cefc // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Client.ReuseListC
// Size: 0xd30 // Inherited bytes: 0x260
struct UReuseListC : UUserWidget {
	// Fields
	struct FScriptMulticastDelegate OnUpdateItemParam; // Offset: 0x260 // Size: 0x10
	struct FScriptMulticastDelegate OnUpdateItem; // Offset: 0x270 // Size: 0x10
	struct FScriptMulticastDelegate OnScrollItem; // Offset: 0x280 // Size: 0x10
	struct FScriptMulticastDelegate OnCreateItem; // Offset: 0x290 // Size: 0x10
	struct FScrollBoxStyle ScrollBoxStyle; // Offset: 0x2a0 // Size: 0x2e8
	enum class EWidgetClipping ScrollBoxClipping; // Offset: 0x588 // Size: 0x01
	enum class ESlateVisibility ScrollBoxVisibility; // Offset: 0x589 // Size: 0x01
	char pad_0x58A[0x6]; // Offset: 0x58a // Size: 0x06
	struct FScrollBarStyle ScrollBarStyle; // Offset: 0x590 // Size: 0x680
	enum class ESlateVisibility ScrollBarVisibility; // Offset: 0xc10 // Size: 0x01
	char pad_0xC11[0x3]; // Offset: 0xc11 // Size: 0x03
	struct FVector2D ScrollbarThickness; // Offset: 0xc14 // Size: 0x08
	int ItemWidth; // Offset: 0xc1c // Size: 0x04
	int ItemHeight; // Offset: 0xc20 // Size: 0x04
	int PaddingX; // Offset: 0xc24 // Size: 0x04
	int PaddingY; // Offset: 0xc28 // Size: 0x04
	int TitleSize; // Offset: 0xc2c // Size: 0x04
	int TitlePadding; // Offset: 0xc30 // Size: 0x04
	bool AutoTitleSize; // Offset: 0xc34 // Size: 0x01
	enum class EReuseListStyle Style; // Offset: 0xc35 // Size: 0x01
	char pad_0xC36[0x2]; // Offset: 0xc36 // Size: 0x02
	struct UUserWidget* ItemClass; // Offset: 0xc38 // Size: 0x08
	int PreviewCount; // Offset: 0xc40 // Size: 0x04
	enum class EReuseListNotFullAlignStyle NotFullAlignStyle; // Offset: 0xc44 // Size: 0x01
	bool NotFullScrollBoxHitTestInvisible; // Offset: 0xc45 // Size: 0x01
	bool UpdateForceLayoutPrepass; // Offset: 0xc46 // Size: 0x01
	char pad_0xC47[0x1]; // Offset: 0xc47 // Size: 0x01
	int ItemCacheNum; // Offset: 0xc48 // Size: 0x04
	int DelayUpdateTimeLimitMS; // Offset: 0xc4c // Size: 0x04
	char pad_0xC50[0xe0]; // Offset: 0xc50 // Size: 0xe0

	// Functions

	// Object Name: Function Client.ReuseListC.SetTitleSlotAutoSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTitleSlotAutoSize(bool as); // Offset: 0x10399e544 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ReuseListC.SetTitleSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTitleSize(int SZ); // Offset: 0x10399e4c8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReuseListC.SetScrollOffset
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetScrollOffset(float NewScrollOffset); // Offset: 0x10399e44c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReuseListC.ScrollToStart
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ScrollToStart(); // Offset: 0x10399e438 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ReuseListC.ScrollToEnd
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ScrollToEnd(); // Offset: 0x10399e424 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ReuseListC.Reset
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Reset(struct UUserWidget* __ItemClass, enum class EReuseListStyle __Style, int __ItemWidth, int __ItemHeight, int __PaddingX, int __PaddingY); // Offset: 0x10399e284 // Return & Params: Num(6) Size(0x1c)

	// Object Name: Function Client.ReuseListC.Reload
	// Flags: [Native|Public|BlueprintCallable]
	void Reload(int __ItemCount); // Offset: 0x10399e200 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReuseListC.RefreshParam
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RefreshParam(struct FString _Param); // Offset: 0x10399e168 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ReuseListC.RefreshOneParam
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RefreshOneParam(int __Idx, struct FString _Param); // Offset: 0x10399e094 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Client.ReuseListC.RefreshOne
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RefreshOne(int __Idx); // Offset: 0x10399e018 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReuseListC.Refresh
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Refresh(); // Offset: 0x10399e004 // Return & Params: Num(0) Size(0x0)

	// Object Name: DelegateFunction Client.ReuseListC.OnUpdateItemParamDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnUpdateItemParamDelegate__DelegateSignature(struct UUserWidget* Widget, int idx, struct FString Param); // Offset: 0x103df3e6c // Return & Params: Num(3) Size(0x20)

	// Object Name: DelegateFunction Client.ReuseListC.OnUpdateItemDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnUpdateItemDelegate__DelegateSignature(struct UUserWidget* Widget, int idx); // Offset: 0x103df3e6c // Return & Params: Num(2) Size(0xc)

	// Object Name: DelegateFunction Client.ReuseListC.OnScrollItemDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnScrollItemDelegate__DelegateSignature(int BeginIdx, int EndIdx); // Offset: 0x103df3e6c // Return & Params: Num(2) Size(0x8)

	// Object Name: DelegateFunction Client.ReuseListC.OnCreateItemDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnCreateItemDelegate__DelegateSignature(struct UUserWidget* Widget); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ReuseListC.JumpByIdxStyle
	// Flags: [Final|Native|Public|BlueprintCallable]
	void JumpByIdxStyle(int __Idx, enum class EReuseListJumpStyle __Style); // Offset: 0x10399df4c // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Client.ReuseListC.JumpByIdx
	// Flags: [Final|Native|Public|BlueprintCallable]
	void JumpByIdx(int __Idx); // Offset: 0x10399ded0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReuseListC.GetViewSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector2D GetViewSize(); // Offset: 0x10399deb4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ReuseListC.GetScrollOffset
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetScrollOffset(); // Offset: 0x10399de80 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReuseListC.GetPaddingY
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetPaddingY(); // Offset: 0x10399de64 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReuseListC.GetPaddingX
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetPaddingX(); // Offset: 0x10399de48 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReuseListC.GetItemWidthAndPaddingX
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetItemWidthAndPaddingX(); // Offset: 0x10399de24 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReuseListC.GetItemWidth
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetItemWidth(); // Offset: 0x10399de08 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReuseListC.GetItemHeightAndPaddingY
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetItemHeightAndPaddingY(); // Offset: 0x10399dde4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReuseListC.GetItemHeight
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetItemHeight(); // Offset: 0x10399ddc8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReuseListC.GetContentSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector2D GetContentSize(); // Offset: 0x10399ddac // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.ReuseListC.GetAllWidgetItems
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void GetAllWidgetItems(struct TArray<struct UUserWidget*>& ResultItemList); // Offset: 0x10399dd04 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.ReuseListC.FindItem
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UUserWidget* FindItem(int idx); // Offset: 0x10399dc78 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Client.ReuseListC.Clear
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Clear(); // Offset: 0x10399dc58 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Client.ReusePageC
// Size: 0x398 // Inherited bytes: 0x260
struct UReusePageC : UUserWidget {
	// Fields
	struct FScriptMulticastDelegate OnUpdateItem; // Offset: 0x260 // Size: 0x10
	struct FScriptMulticastDelegate OnPageChanged; // Offset: 0x270 // Size: 0x10
	struct FScriptMulticastDelegate OnCreateItem; // Offset: 0x280 // Size: 0x10
	struct FScriptMulticastDelegate OnBeginDrag; // Offset: 0x290 // Size: 0x10
	struct FScriptMulticastDelegate OnEndDrag; // Offset: 0x2a0 // Size: 0x10
	struct FScriptMulticastDelegate OnEndScroll; // Offset: 0x2b0 // Size: 0x10
	struct UUserWidget* ItemClass; // Offset: 0x2c0 // Size: 0x08
	char IsLoopPage : 1; // Offset: 0x2c8 // Size: 0x01
	char IsVertical : 1; // Offset: 0x2c8 // Size: 0x01
	char CanDrag : 1; // Offset: 0x2c8 // Size: 0x01
	char pad_0x2C8_3 : 5; // Offset: 0x2c8 // Size: 0x01
	char pad_0x2C9[0x3]; // Offset: 0x2c9 // Size: 0x03
	int CanDragLimit; // Offset: 0x2cc // Size: 0x04
	float AutoPlayRate; // Offset: 0x2d0 // Size: 0x04
	int ShowPageNum; // Offset: 0x2d4 // Size: 0x04
	int DragPageNum; // Offset: 0x2d8 // Size: 0x04
	float DChgPageParam; // Offset: 0x2dc // Size: 0x04
	float ScrollInertial; // Offset: 0x2e0 // Size: 0x04
	float ScrollRate; // Offset: 0x2e4 // Size: 0x04
	char pad_0x2E8[0xb0]; // Offset: 0x2e8 // Size: 0xb0

	// Functions

	// Object Name: Function Client.ReusePageC.SetAutoPlayRate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAutoPlayRate(float Rate); // Offset: 0x1039a1188 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReusePageC.SelectPage
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SelectPage(int __Idx); // Offset: 0x1039a110c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReusePageC.Reload
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Reload(int __Count); // Offset: 0x1039a1090 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReusePageC.Play
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Play(bool bPlay); // Offset: 0x1039a100c // Return & Params: Num(1) Size(0x1)

	// Object Name: DelegateFunction Client.ReusePageC.OnUpdateItemDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnUpdateItemDelegate__DelegateSignature(struct UUserWidget* Widget, int idx); // Offset: 0x103df3e6c // Return & Params: Num(2) Size(0xc)

	// Object Name: DelegateFunction Client.ReusePageC.OnPageChangedDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnPageChangedDelegate__DelegateSignature(int PageIdx); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x4)

	// Object Name: DelegateFunction Client.ReusePageC.OnEndScrollDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnEndScrollDelegate__DelegateSignature(int PageIdx); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x4)

	// Object Name: DelegateFunction Client.ReusePageC.OnEndDragDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnEndDragDelegate__DelegateSignature(int PageIdx); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x4)

	// Object Name: DelegateFunction Client.ReusePageC.OnCreateItemDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnCreateItemDelegate__DelegateSignature(struct UUserWidget* Widget); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x8)

	// Object Name: DelegateFunction Client.ReusePageC.OnBeginDragDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnBeginDragDelegate__DelegateSignature(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ReusePageC.MovePrePage
	// Flags: [Final|Native|Public|BlueprintCallable]
	void MovePrePage(); // Offset: 0x1039a0ff8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ReusePageC.MoveNextPage
	// Flags: [Final|Native|Public|BlueprintCallable]
	void MoveNextPage(); // Offset: 0x1039a0fe4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.ReusePageC.IsDraging
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsDraging(); // Offset: 0x1039a0fc4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.ReusePageC.GetPageCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetPageCount(); // Offset: 0x1039a0fa8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReusePageC.GetPage
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int GetPage(); // Offset: 0x1039a0f8c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReusePageC.GetOffset
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetOffset(); // Offset: 0x1039a0f70 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReusePageC.GetAutoPlayRate
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetAutoPlayRate(); // Offset: 0x1039a0f54 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.ReusePageC.GetAllItems
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void GetAllItems(struct TArray<struct UUserWidget*>& ResultItemList, bool OnlyVisible); // Offset: 0x1039a0e58 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function Client.ReusePageC.ClearCache
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearCache(); // Offset: 0x1039a0e44 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class Client.UDPPingCollector
// Size: 0x138 // Inherited bytes: 0x28
struct UUDPPingCollector : UObject {
	// Fields
	char pad_0x28[0x30]; // Offset: 0x28 // Size: 0x30
	struct TMap<struct FString, struct FPingServerInfo> mUDPPingInfoMap; // Offset: 0x58 // Size: 0x50
	char pad_0xA8[0x20]; // Offset: 0xa8 // Size: 0x20
	struct FScriptMulticastDelegate UDPPingShadowResultToLuaDelegate; // Offset: 0xc8 // Size: 0x10
	char pad_0xD8[0x60]; // Offset: 0xd8 // Size: 0x60

	// Functions

	// Object Name: Function Client.UDPPingCollector.TickUDPPing
	// Flags: [Final|Native|Public|BlueprintCallable]
	void TickUDPPing(float DeltaTime); // Offset: 0x1039a1e5c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.UDPPingCollector.setUDPPingServerAddress
	// Flags: [Final|Native|Public|BlueprintCallable]
	void setUDPPingServerAddress(struct FString ServerIP, struct FString ServerPort, int ZoneID, int WaterMarkType); // Offset: 0x1039a1cac // Return & Params: Num(4) Size(0x28)

	// Object Name: Function Client.UDPPingCollector.PingServer
	// Flags: [Final|Native|Public|BlueprintCallable]
	void PingServer(struct FString address, float Timeout, int WaterMarkType); // Offset: 0x1039a1b70 // Return & Params: Num(3) Size(0x18)

	// Object Name: DelegateFunction Client.UDPPingCollector.OnPingServerResultDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnPingServerResultDelegate__DelegateSignature(struct FString address, int IsSuccess, float Time); // Offset: 0x103df3e6c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Client.UDPPingCollector.IsChooingZoneAccess
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsChooingZoneAccess(); // Offset: 0x1039a1b3c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.UDPPingCollector.isAllZoneHasPingValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool isAllZoneHasPingValue(); // Offset: 0x1039a1b08 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.UDPPingCollector.Init
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Init(float MinPingintervalTime, float pingintervalTime, float pingTimeoutSecond, float normalDelayMilliSecond, float maxAutoChooseZoneDelayMilliSecond); // Offset: 0x1039a19a4 // Return & Params: Num(5) Size(0x14)

	// Object Name: Function Client.UDPPingCollector.GetZoneServerDelay
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetZoneServerDelay(struct FString ServerAddress); // Offset: 0x1039a18d8 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function Client.UDPPingCollector.GetMinDealyAddress
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetMinDealyAddress(); // Offset: 0x1039a18a4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.UDPPingCollector.ChoosingZone
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ChoosingZone(int ZoneID, struct FString AddrIP); // Offset: 0x1039a17a8 // Return & Params: Num(2) Size(0x18)
};

// Object Name: Class Client.ViberateEngine
// Size: 0x28 // Inherited bytes: 0x28
struct UViberateEngine : UObject {
};

// Object Name: Class Client.VibrateSystemManager
// Size: 0x498 // Inherited bytes: 0x30
struct UVibrateSystemManager : UGameInstanceSubsystem {
	// Fields
	char pad_0x30[0x10]; // Offset: 0x30 // Size: 0x10
	struct FString ClassPath; // Offset: 0x40 // Size: 0x10
	struct FString VibrateAssetTablePath; // Offset: 0x50 // Size: 0x10
	int MaxAmplitude; // Offset: 0x60 // Size: 0x04
	int GroundSpesificMatVibrationMinGrear; // Offset: 0x64 // Size: 0x04
	float VehicleBreakingMinSpeedThreshold; // Offset: 0x68 // Size: 0x04
	float VehicleGearMinSpeedThreshold; // Offset: 0x6c // Size: 0x04
	struct TArray<int> TriggerVehicleVibrateGroundPhysicMatList; // Offset: 0x70 // Size: 0x10
	float TriggerVehicleVibrateMinSlip; // Offset: 0x80 // Size: 0x04
	float TriggerVehicleVibrateMinSuspensionRaisePercent; // Offset: 0x84 // Size: 0x04
	float VehicleRaiseSuspensionVibrateInerval; // Offset: 0x88 // Size: 0x04
	int InitAssetProccessNumFrames; // Offset: 0x8c // Size: 0x04
	struct FString LoopTime; // Offset: 0x90 // Size: 0x10
	char pad_0xA0[0x50]; // Offset: 0xa0 // Size: 0x50
	struct TMap<int, enum class EVibrateTriggerEventType> LoadedVibrateAssetIDAndEventTypeMap; // Offset: 0xf0 // Size: 0x50
	struct TMap<enum class EVibrateStrengthLevel, float> VibrateStrengthLevelModifireMap; // Offset: 0x140 // Size: 0x50
	struct TMap<enum class EVibrateTriggerEventType, float> VibrateEventMinIntervalMap; // Offset: 0x190 // Size: 0x50
	struct TArray<enum class EVibrateTriggerEventType> CharacterVibrateEventList; // Offset: 0x1e0 // Size: 0x10
	struct TArray<enum class EVibrateTriggerEventType> WeaponVibrateEventList; // Offset: 0x1f0 // Size: 0x10
	struct TArray<enum class EVibrateTriggerEventType> VehicleVibrateEventList; // Offset: 0x200 // Size: 0x10
	struct TArray<enum class EVibrateTriggerEventType> SoundUIVibrateEventList; // Offset: 0x210 // Size: 0x10
	struct TArray<enum class EVibrateTriggerEventType> CharacterBeHitVibrateEventList; // Offset: 0x220 // Size: 0x10
	struct TArray<enum class EVibrateTriggerEventType> VehicleEngineVibrateEventList; // Offset: 0x230 // Size: 0x10
	struct TArray<enum class EVibrateTriggerEventType> VehicleBeHitVibrateEventList; // Offset: 0x240 // Size: 0x10
	bool bEntireVibrationSwitch; // Offset: 0x250 // Size: 0x01
	bool bCharacterVibrationSwitch; // Offset: 0x251 // Size: 0x01
	bool bWeaponVibrationSwitch; // Offset: 0x252 // Size: 0x01
	bool bVehicleVibrationSwitch; // Offset: 0x253 // Size: 0x01
	bool bSoundUIVibrationSwitch; // Offset: 0x254 // Size: 0x01
	char pad_0x255[0x3]; // Offset: 0x255 // Size: 0x03
	int CharacterVibrationLevel; // Offset: 0x258 // Size: 0x04
	int WeaponVibrationLevel; // Offset: 0x25c // Size: 0x04
	int VehicleVibrationLevel; // Offset: 0x260 // Size: 0x04
	int SoundUIVibrationLevel; // Offset: 0x264 // Size: 0x04
	int EntireVibrationLevel; // Offset: 0x268 // Size: 0x04
	bool bCharacterVibrate; // Offset: 0x26c // Size: 0x01
	bool bWeaponVibrate; // Offset: 0x26d // Size: 0x01
	bool bVehicleVibrate; // Offset: 0x26e // Size: 0x01
	bool bSoundUIVibrate; // Offset: 0x26f // Size: 0x01
	bool bCharacterBeHitVibrate; // Offset: 0x270 // Size: 0x01
	bool bCharacterClimbVibrate; // Offset: 0x271 // Size: 0x01
	bool bCharacterFallVibrate; // Offset: 0x272 // Size: 0x01
	bool bCharacterSwimVibrate; // Offset: 0x273 // Size: 0x01
	bool bAutoWeaponVibrate; // Offset: 0x274 // Size: 0x01
	bool bSemiAutoWeaponVibrate; // Offset: 0x275 // Size: 0x01
	bool bBoltWeaponVibrate; // Offset: 0x276 // Size: 0x01
	bool bOtherWeaponVibrate; // Offset: 0x277 // Size: 0x01
	bool bVehicleEngineVibrate; // Offset: 0x278 // Size: 0x01
	bool bVehicleBeHitVibrate; // Offset: 0x279 // Size: 0x01
	bool bVehicleCrashVibrate; // Offset: 0x27a // Size: 0x01
	bool bFootstepSoundUIVibrate; // Offset: 0x27b // Size: 0x01
	bool bFireShotSoundUIVibrate; // Offset: 0x27c // Size: 0x01
	bool bGlassBrokenSoundUIVibrate; // Offset: 0x27d // Size: 0x01
	bool bVehicleSoundUIVibrate; // Offset: 0x27e // Size: 0x01
	char pad_0x27F[0x1]; // Offset: 0x27f // Size: 0x01
	struct FTimerHandle StopVibrateHandle; // Offset: 0x280 // Size: 0x08
	int CurPlayingVibrateAssetIndex; // Offset: 0x288 // Size: 0x04
	int CurLoopPlayingVibrateAssetIndex; // Offset: 0x28c // Size: 0x04
	int DeviceSupportVibrateType; // Offset: 0x290 // Size: 0x04
	bool bInGameVibration; // Offset: 0x294 // Size: 0x01
	bool bIsHandBreaking; // Offset: 0x295 // Size: 0x01
	char pad_0x296[0x52]; // Offset: 0x296 // Size: 0x52
	bool bHasLastVehicle; // Offset: 0x2e8 // Size: 0x01
	char pad_0x2E9[0x3]; // Offset: 0x2e9 // Size: 0x03
	int LastVehicleGear; // Offset: 0x2ec // Size: 0x04
	bool bIsLastVehicleBreaking; // Offset: 0x2f0 // Size: 0x01
	bool bIsLastVehicleSlipping; // Offset: 0x2f1 // Size: 0x01
	char pad_0x2F2[0x2]; // Offset: 0x2f2 // Size: 0x02
	int LastVehicleGroundContactMaterialSurfaceType; // Offset: 0x2f4 // Size: 0x04
	struct TMap<int, bool> LastVehicleGearVibrateCache; // Offset: 0x2f8 // Size: 0x50
	struct TMap<enum class EVibrateTriggerEventType, float> LastVibrateEventTimeMap; // Offset: 0x348 // Size: 0x50
	float CurVehicleRaiseSuspensionVibrateCD; // Offset: 0x398 // Size: 0x04
	char pad_0x39C[0x7c]; // Offset: 0x39c // Size: 0x7c
	struct TArray<struct FVibrateEntity> CacheVibrateEntityList; // Offset: 0x418 // Size: 0x10
	struct TMap<struct FString, struct FString> VibratePath2Json; // Offset: 0x428 // Size: 0x50
	char pad_0x478[0x20]; // Offset: 0x478 // Size: 0x20

	// Functions

	// Object Name: Function Client.VibrateSystemManager.StopVibrate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StopVibrate(); // Offset: 0x1039a42b4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.VibrateSystemManager.SetVibrationLoopTime
	// Flags: [Native|Event|Protected|BlueprintEvent]
	void SetVibrationLoopTime(struct FString InLoopTime); // Offset: 0x1039a4214 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.VibrateSystemManager.PostVibrateTriggerActionDirectly
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void PostVibrateTriggerActionDirectly(int SpesifyID, int Amplitude); // Offset: 0x1039a4158 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.VibrateSystemManager.PostVibrateTriggerAction
	// Flags: [Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void PostVibrateTriggerAction(struct FVibrateTriggerAction& Action, bool bCheckGate, bool bCheckInterval, int SpesifyID); // Offset: 0x1039a3fac // Return & Params: Num(4) Size(0x40)

	// Object Name: Function Client.VibrateSystemManager.PlayVibrateEntity
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void PlayVibrateEntity(struct FVibrateEntity& Entity); // Offset: 0x1039a3ee4 // Return & Params: Num(1) Size(0x48)

	// Object Name: Function Client.VibrateSystemManager.ModifyWeaponVibrationSwitch
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyWeaponVibrationSwitch(bool Val); // Offset: 0x1039a3e58 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifyWeaponVibrationLevel
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyWeaponVibrationLevel(int InVal); // Offset: 0x1039a3dd4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.VibrateSystemManager.ModifyVehicleVibrationSwitch
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyVehicleVibrationSwitch(bool Val); // Offset: 0x1039a3d48 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifyVehicleVibrationLevel
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyVehicleVibrationLevel(int InVal); // Offset: 0x1039a3cc4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.VibrateSystemManager.ModifyVehicleSoundUIVibrateSetting
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyVehicleSoundUIVibrateSetting(bool Val); // Offset: 0x1039a3c38 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifyVehicleEngineVibrationSetting
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyVehicleEngineVibrationSetting(bool Val); // Offset: 0x1039a3bac // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifyVehicleCrashVibrateSetting
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyVehicleCrashVibrateSetting(bool Val); // Offset: 0x1039a3b20 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifyVehicleBeHitVibrateSetting
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyVehicleBeHitVibrateSetting(bool Val); // Offset: 0x1039a3a94 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifySoundUIVibrationSwitch
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifySoundUIVibrationSwitch(bool Val); // Offset: 0x1039a3a08 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifySoundUIVibrationLevel
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifySoundUIVibrationLevel(int InVal); // Offset: 0x1039a3984 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.VibrateSystemManager.ModifySemiAutoWeaponVibrateSetting
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifySemiAutoWeaponVibrateSetting(bool Val); // Offset: 0x1039a38f8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifyOtherWeaponVibrateSetting
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyOtherWeaponVibrateSetting(bool Val); // Offset: 0x1039a386c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifyGlassBrokenSoundUIVibrateSetting
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyGlassBrokenSoundUIVibrateSetting(bool Val); // Offset: 0x1039a37e0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifyFootstepSoundUIVibrateSetting
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyFootstepSoundUIVibrateSetting(bool Val); // Offset: 0x1039a3754 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifyFireShotSoundUIVibrateSetting
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyFireShotSoundUIVibrateSetting(bool Val); // Offset: 0x1039a36c8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifyEntireVibrationSwitch
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyEntireVibrationSwitch(bool Val); // Offset: 0x1039a363c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifyEntireVibrationLevel
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ModifyEntireVibrationLevel(int InValue); // Offset: 0x1039a35c0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.VibrateSystemManager.ModifyCharacterVibrationSwitch
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyCharacterVibrationSwitch(bool Val); // Offset: 0x1039a3534 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifyCharacterVibrationLevel
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyCharacterVibrationLevel(int InVal); // Offset: 0x1039a34b0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.VibrateSystemManager.ModifyCharacterSwimVibrateSetting
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyCharacterSwimVibrateSetting(bool Val); // Offset: 0x1039a3424 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifyCharacterFallVibrateSetting
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyCharacterFallVibrateSetting(bool Val); // Offset: 0x1039a3398 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifyCharacterClimbVibrateSetting
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyCharacterClimbVibrateSetting(bool Val); // Offset: 0x1039a330c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifyCharacterBeHitVibrateSetting
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyCharacterBeHitVibrateSetting(bool Val); // Offset: 0x1039a3280 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifyBoltWeaponVibrateSetting
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyBoltWeaponVibrateSetting(bool Val); // Offset: 0x1039a31f4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.ModifyAutoWeaponVibrateSetting
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void ModifyAutoWeaponVibrateSetting(bool Val); // Offset: 0x1039a3168 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.LoadUserSettingData
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	void LoadUserSettingData(int inCharacterVibrationLevel, int inWeaponVibrationLevel, int inVehicleVibrationLevel, int inSoundUIVibrationLevel, bool binCharacterBeHitVibrate, bool binCharacterClimbVibrate, bool binCharacterFallVibrate, bool binCharacterSwimVibrate, bool binVehicleEngineVibrate, bool binVehicleBeHitVibrate, bool binVehicleCrashVibrate, bool binFootstepSoundUIVibrate, bool binFireShotSoundUIVibrate, bool binGlassBrokenSoundUIVibrate, bool binVehicleSoundUIVibrate, int inEntireVibrationLevel, bool binAutoWeaponVibrate, bool binSemiAutoWeaponVibrate, bool binBoltWeaponVibrate, bool binOtherWeaponVibrate); // Offset: 0x1039a2b7c // Return & Params: Num(20) Size(0x24)

	// Object Name: Function Client.VibrateSystemManager.InvalidateVibrateEntityByEventType
	// Flags: [Final|Native|Public|BlueprintCallable]
	void InvalidateVibrateEntityByEventType(enum class EVibrateTriggerEventType EventType); // Offset: 0x1039a2b00 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Client.VibrateSystemManager.InitUserSetting
	// Flags: [Native|Event|Protected|BlueprintEvent]
	void InitUserSetting(); // Offset: 0x1039a2ae4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.VibrateSystemManager.InitSystem
	// Flags: [Native|Event|Protected|BlueprintEvent]
	void InitSystem(); // Offset: 0x1039a2ac8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.VibrateSystemManager.HandleApplicationWillTerminate
	// Flags: [Native|Event|Protected|BlueprintEvent]
	void HandleApplicationWillTerminate(); // Offset: 0x1039a2aac // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.VibrateSystemManager.HandleApplicationWillEnterBackground
	// Flags: [Native|Event|Protected|BlueprintEvent]
	void HandleApplicationWillEnterBackground(); // Offset: 0x1039a2a90 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.VibrateSystemManager.HandleApplicationWillDeactivate
	// Flags: [Native|Event|Protected|BlueprintEvent]
	void HandleApplicationWillDeactivate(); // Offset: 0x1039a2a74 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.VibrateSystemManager.HandleApplicationHasReactivated
	// Flags: [Native|Event|Protected|BlueprintEvent]
	void HandleApplicationHasReactivated(); // Offset: 0x1039a2a58 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.VibrateSystemManager.HandleApplicationHasEnteredForeground
	// Flags: [Native|Event|Protected|BlueprintEvent]
	void HandleApplicationHasEnteredForeground(); // Offset: 0x1039a2a3c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.VibrateSystemManager.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UVibrateSystemManager* GetInstance(struct UObject* WorldContext, bool bAutoCreate); // Offset: 0x1039a297c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Client.VibrateSystemManager.GetEntireVibrationLevel
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetEntireVibrationLevel(); // Offset: 0x1039a2948 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Client.VibrateSystemManager.GetCurrentPlayingVibrationDebugInfo
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetCurrentPlayingVibrationDebugInfo(); // Offset: 0x1039a28e4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.VibrateSystemManager.GetAmplitudeByAlpha
	// Flags: [Final|Native|Public|BlueprintCallable]
	int GetAmplitudeByAlpha(float Alpha); // Offset: 0x1039a2850 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Client.VibrateSystemManager.ClearVibratePath2Json
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void ClearVibratePath2Json(); // Offset: 0x1039a283c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.VibrateSystemManager.ClearAllVibration
	// Flags: [Native|Event|Protected|BlueprintEvent]
	void ClearAllVibration(); // Offset: 0x1039a2820 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Client.VibrateSystemManager.CheckShootWeaponTypeVibrateGate
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	bool CheckShootWeaponTypeVibrateGate(struct ASTExtraWeapon* Weapon); // Offset: 0x1039a278c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function Client.VibrateSystemManager.CheckAndCopyFilesToSavedDir
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void CheckAndCopyFilesToSavedDir(struct UVibrateSystemManager* Mgr); // Offset: 0x1039a2718 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Client.VibrateSystemManager.ActiveInGameVibration
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ActiveInGameVibration(bool Inactive); // Offset: 0x1039a2694 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class Client.WINSDKFBWebLogin
// Size: 0x130 // Inherited bytes: 0x100
struct UWINSDKFBWebLogin : UWidget {
	// Fields
	struct FScriptMulticastDelegate OnUrlChanged; // Offset: 0x100 // Size: 0x10
	struct FScriptMulticastDelegate OnHttpResponed; // Offset: 0x110 // Size: 0x10
	struct FString InitialURL; // Offset: 0x120 // Size: 0x10

	// Functions

	// Object Name: DelegateFunction Client.WINSDKFBWebLogin.OnWINSDKHttpResponed__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnWINSDKHttpResponed__DelegateSignature(bool requestSucc, struct FString txtContent); // Offset: 0x103df3e6c // Return & Params: Num(2) Size(0x18)

	// Object Name: DelegateFunction Client.WINSDKFBWebLogin.OnUrlChanged__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void OnUrlChanged__DelegateSignature(struct FText& Text); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x18)

	// Object Name: Function Client.WINSDKFBWebLogin.LoadURL
	// Flags: [Final|Native|Public|BlueprintCallable]
	void LoadURL(struct FString NewURL); // Offset: 0x1039a5cc4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Client.WINSDKFBWebLogin.DoHttpRequest
	// Flags: [Final|Native|Public|BlueprintCallable]
	void DoHttpRequest(struct FString URL); // Offset: 0x1039a5c2c // Return & Params: Num(1) Size(0x10)
};

