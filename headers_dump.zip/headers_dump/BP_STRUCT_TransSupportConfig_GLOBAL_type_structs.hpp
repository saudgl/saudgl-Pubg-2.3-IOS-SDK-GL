#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_TransSupportConfig_GLOBAL_type.BP_STRUCT_TransSupportConfig_GLOBAL_type
// Size: 0x40 // Inherited bytes: 0x00
struct FBP_STRUCT_TransSupportConfig_GLOBAL_type {
	// Fields
	int languageID_0_1D9BF4801A0CAF180454007A0E59BFB4; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString displayName_1_7B233E0045C681C6393652C80C537045; // Offset: 0x08 // Size: 0x10
	struct FString abbreviation_2_7270DDC045E369B7531E4D2001C2187E; // Offset: 0x18 // Size: 0x10
	bool isSupported_3_297FC8C037F3503F7D952DE609923274; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x7]; // Offset: 0x29 // Size: 0x07
	struct FString languageCode_4_0C60B000517E13D413D2E28809C00BF5; // Offset: 0x30 // Size: 0x10
};

