#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_TeamUpPopFrame_type.BP_STRUCT_TeamUpPopFrame_type
// Size: 0x88 // Inherited bytes: 0x00
struct FBP_STRUCT_TeamUpPopFrame_type {
	// Fields
	int DefaultDisplay_0_220585C053DEBE9568440FB70B6BF029; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString DescGet_1_57FE06C07AEC5845715F23AD0273E1D4; // Offset: 0x08 // Size: 0x10
	struct FString DescTime_2_53A0C28040C211483960564307316F15; // Offset: 0x18 // Size: 0x10
	struct FString Icon_3_04BF61401D70FEBB200A5A1D09C173FE; // Offset: 0x28 // Size: 0x10
	int ID_4_235F024032F89E951FE43C360BA9C154; // Offset: 0x38 // Size: 0x04
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
	struct FString JumpUrl_5_6B7892C04A7323BB3250C999091EC0AC; // Offset: 0x40 // Size: 0x10
	struct FString Name_6_50AA3F4021957D0319CFE66409C2CD95; // Offset: 0x50 // Size: 0x10
	struct FString Skin_7_77C6644067975ED319CE0DDF09C02A5E; // Offset: 0x60 // Size: 0x10
	int Sort_8_075B490036B06E9C19CE1E4809C02D34; // Offset: 0x70 // Size: 0x04
	char pad_0x74[0x4]; // Offset: 0x74 // Size: 0x04
	struct FString BeginShowTime_9_570524406235C45B4B58D2440F6BD1B5; // Offset: 0x78 // Size: 0x10
};

