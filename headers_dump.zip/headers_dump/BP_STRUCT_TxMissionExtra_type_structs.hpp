#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_TxMissionExtra_type.BP_STRUCT_TxMissionExtra_type
// Size: 0x14 // Inherited bytes: 0x00
struct FBP_STRUCT_TxMissionExtra_type {
	// Fields
	struct FString key_0_1CBF844014E51DD93070B91D0B8C8B69; // Offset: 0x00 // Size: 0x10
	int value_1_101419401426BFC562F3B33D0C66E835; // Offset: 0x10 // Size: 0x04
};

