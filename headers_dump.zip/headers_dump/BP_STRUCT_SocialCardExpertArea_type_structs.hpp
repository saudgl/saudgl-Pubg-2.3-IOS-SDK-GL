#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_SocialCardExpertArea_type.BP_STRUCT_SocialCardExpertArea_type
// Size: 0x18 // Inherited bytes: 0x00
struct FBP_STRUCT_SocialCardExpertArea_type {
	// Fields
	int ID_0_7B639A406F1ECB456A314E5F0BEDC1D4; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString ExpertArea_1_655F73403FAAB0C5355298C501594C31; // Offset: 0x08 // Size: 0x10
};

