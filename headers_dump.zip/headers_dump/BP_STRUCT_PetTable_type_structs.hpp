#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_PetTable_type.BP_STRUCT_PetTable_type
// Size: 0x140 // Inherited bytes: 0x00
struct FBP_STRUCT_PetTable_type {
	// Fields
	int FoodID2_0_74453B802213AE080C1CFB2A0F6CB952; // Offset: 0x00 // Size: 0x04
	int PetID_1_161F774025C4024D0658398C0434C1E4; // Offset: 0x04 // Size: 0x04
	int FoodID3_3_74463BC02213AE090C1CFB2B0F6CB953; // Offset: 0x08 // Size: 0x04
	int FoodID1_4_74443B402213AE070C1CFB290F6CB951; // Offset: 0x0c // Size: 0x04
	struct FString PetName_5_0AD5B4406AF7C19B19AAA3EC04C27405; // Offset: 0x10 // Size: 0x10
	int FoodCnt_6_0EBF950029CC741A0C1F016A0F6CBE74; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
	struct FString JumpUrl_7_78DA5D80770D0FB87D2AB07103CD68BC; // Offset: 0x28 // Size: 0x10
	int JumpType_8_706CD94059C155B119B58A850CD70355; // Offset: 0x38 // Size: 0x04
	int PetMaxLevel_12_15E11B803EA972342741D3080D060EBC; // Offset: 0x3c // Size: 0x04
	struct FString PetImage_14_70AA6CC00734D40B21647D340C1D7495; // Offset: 0x40 // Size: 0x10
	struct FString ShareBgUrl_15_37E69D80203CAAA43B82F3630BDB729C; // Offset: 0x50 // Size: 0x10
	int EatAction_16_62B7C7C01B6BC7AD350D95BE014E87DE; // Offset: 0x60 // Size: 0x04
	char pad_0x64[0x4]; // Offset: 0x64 // Size: 0x04
	struct FString ClickAction_17_15DDFAC05B4516070D98AC880B568AFE; // Offset: 0x68 // Size: 0x10
	int DefaultAction_18_336C92801D9FE2845525FDE600CF704E; // Offset: 0x78 // Size: 0x04
	int OnlyPetCamera_22_7FA44EC046AEEDF36970978D00CEEE71; // Offset: 0x7c // Size: 0x04
	int PetAndAvatarCamera_23_070842C07D6093575B47E8000D58A301; // Offset: 0x80 // Size: 0x04
	char pad_0x84[0x4]; // Offset: 0x84 // Size: 0x04
	struct FString BigIconForStore_26_19C65D801F69D0F214C8888304B43EC5; // Offset: 0x88 // Size: 0x10
	struct FString IconForStore_27_59F359001081BBCE1F89EEFB04A08715; // Offset: 0x98 // Size: 0x10
	struct FString PetMoodIds_28_69A63FC05650597524C5E6360126C393; // Offset: 0xa8 // Size: 0x10
	struct FString PetActionPath_29_6581EEC061F1369711F2C3050CA22638; // Offset: 0xb8 // Size: 0x10
	struct FString PetClothPath_30_675355C07747DC3F23E0C98805E173D8; // Offset: 0xc8 // Size: 0x10
	struct FString PetPath_31_4674174057A3B9CB1992038B04C05C98; // Offset: 0xd8 // Size: 0x10
	struct FString PortraitImage_32_418517C028D44DEF7496DBBD05F0BB85; // Offset: 0xe8 // Size: 0x10
	struct FString IndiaShareBgUrl_33_7C3196C0049B6CBF4668FB770B5A7C4C; // Offset: 0xf8 // Size: 0x10
	struct FString PetLevelUpImage_34_2AF55C0015DCFB987645CA990E573705; // Offset: 0x108 // Size: 0x10
	struct FString BrandLogo_35_2AC407C02A97A7655B4107090F7D1E5F; // Offset: 0x118 // Size: 0x10
	int IgnoreUnlock_36_53D7FDC038CA15975236FDA9087BD05B; // Offset: 0x128 // Size: 0x04
	char pad_0x12C[0x4]; // Offset: 0x12c // Size: 0x04
	struct FString PetResHandlePath_37_1E7414C03C0BE9C3655D8C4B02AEC4E8; // Offset: 0x130 // Size: 0x10
};

