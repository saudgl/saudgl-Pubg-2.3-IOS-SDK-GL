#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Lobby_Main_Pet_UIBP.Lobby_Main_Pet_UIBP_C
// Size: 0x458 // Inherited bytes: 0x418
struct ULobby_Main_Pet_UIBP_C : UUAEUserWidget {
	// Fields
	struct UWidgetAnimation* DX_Transitions_Enter; // Offset: 0x418 // Size: 0x08
	struct UWidgetAnimation* DX_Transitions_StartEnter; // Offset: 0x420 // Size: 0x08
	struct UButton* BtnClose; // Offset: 0x428 // Size: 0x08
	struct UButton* BtnPetAction; // Offset: 0x430 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_Root; // Offset: 0x438 // Size: 0x08
	struct UOverlay* Overlay_1; // Offset: 0x440 // Size: 0x08
	struct UOverlay* Overlay_2; // Offset: 0x448 // Size: 0x08
	struct UWidgetSwitcher* WS_PetAction; // Offset: 0x450 // Size: 0x08
};

