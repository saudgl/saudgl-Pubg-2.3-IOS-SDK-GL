#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass AvatarDIYUtilsImp_BP.AvatarDIYUtilsImp_BP_C
// Size: 0x28 // Inherited bytes: 0x28
struct UAvatarDIYUtilsImp_BP_C : UAvatarDIYBPUtils {
	// Functions

	// Object Name: Function AvatarDIYUtilsImp_BP.AvatarDIYUtilsImp_BP_C.IsWeaponAttachmentDIYAvatarItem
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	bool IsWeaponAttachmentDIYAvatarItem(int InWeaponAttachmentID); // Offset: 0x103df3e6c // Return & Params: Num(2) Size(0x5)

	// Object Name: Function AvatarDIYUtilsImp_BP.AvatarDIYUtilsImp_BP_C.IsWeaponDIYAvatarItem
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	bool IsWeaponDIYAvatarItem(int InWeaponID); // Offset: 0x103df3e6c // Return & Params: Num(2) Size(0x5)

	// Object Name: Function AvatarDIYUtilsImp_BP.AvatarDIYUtilsImp_BP_C.GetDIYMatParam
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	struct FDIYMatParam GetDIYMatParam(int TextureID); // Offset: 0x103df3e6c // Return & Params: Num(2) Size(0x28)

	// Object Name: Function AvatarDIYUtilsImp_BP.AvatarDIYUtilsImp_BP_C.GetDIYBaseColorString
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	struct FString GetDIYBaseColorString(int ColorID); // Offset: 0x103df3e6c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function AvatarDIYUtilsImp_BP.AvatarDIYUtilsImp_BP_C.GetDIYBasePatternPath
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	struct FString GetDIYBasePatternPath(int PatternID); // Offset: 0x103df3e6c // Return & Params: Num(2) Size(0x18)
};

