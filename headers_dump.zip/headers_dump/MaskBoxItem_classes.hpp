#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass MaskBoxItem.MaskBoxItem_C
// Size: 0x278 // Inherited bytes: 0x260
struct UMaskBoxItem_C : UUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x260 // Size: 0x08
	struct UImage* Image_1; // Offset: 0x268 // Size: 0x08
	struct UMaskBox* MaskBox; // Offset: 0x270 // Size: 0x08

	// Functions

	// Object Name: Function MaskBoxItem.MaskBoxItem_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function MaskBoxItem.MaskBoxItem_C.ExecuteUbergraph_MaskBoxItem
	// Flags: [None]
	void ExecuteUbergraph_MaskBoxItem(int EntryPoint); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x4)
};

