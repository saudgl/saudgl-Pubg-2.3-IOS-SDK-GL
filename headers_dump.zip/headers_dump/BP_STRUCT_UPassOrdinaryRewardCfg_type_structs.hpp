#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_UPassOrdinaryRewardCfg_type.BP_STRUCT_UPassOrdinaryRewardCfg_type
// Size: 0x54 // Inherited bytes: 0x00
struct FBP_STRUCT_UPassOrdinaryRewardCfg_type {
	// Fields
	int item_num_3_0_58140BC0141A9A29093476690B708A53; // Offset: 0x00 // Size: 0x04
	int show_buy_1_288B0BC079CF19E12D3C417100B56CA9; // Offset: 0x04 // Size: 0x04
	int item_num_2_2_58130B80141A9A28093476680B708A52; // Offset: 0x08 // Size: 0x04
	int item_show_type_1_3_7DADAFC075BA33E71E3AA8B90DFC58E1; // Offset: 0x0c // Size: 0x04
	int level_4_396695C018C2A43F7EB9FBA0035ED13C; // Offset: 0x10 // Size: 0x04
	int item_expire_time_3_5_2C299E802F31320C7CD1A2170F924AF3; // Offset: 0x14 // Size: 0x04
	int ID_6_1A2FB300601D596668884C4901D83614; // Offset: 0x18 // Size: 0x04
	int item_id_1_7_79EA4A8028C1774C14C1003A07B6A691; // Offset: 0x1c // Size: 0x04
	int item_id_2_8_79EB4AC028C1774D14C1003D07B6A692; // Offset: 0x20 // Size: 0x04
	int item_expire_time_4_9_2C2A9EC02F31320D7CD1A2160F924AF4; // Offset: 0x24 // Size: 0x04
	int item_show_type_3_10_7DAFB04075BA33E91E3AA8BB0DFC58E3; // Offset: 0x28 // Size: 0x04
	int item_id_3_11_79EC4B0028C1774E14C1003C07B6A693; // Offset: 0x2c // Size: 0x04
	int season_index_12_40DF4FC04030662D72C9BB68070618B8; // Offset: 0x30 // Size: 0x04
	int item_expire_time_1_13_2C279E002F31320A7CD1A2290F924AF1; // Offset: 0x34 // Size: 0x04
	int item_show_type_4_14_7DB0B08075BA33EA1E3AA8BA0DFC58E4; // Offset: 0x38 // Size: 0x04
	int item_num_4_15_58150C00141A9A2A0934766A0B708A54; // Offset: 0x3c // Size: 0x04
	int item_id_4_16_79ED4B4028C1774F14C1003F07B6A694; // Offset: 0x40 // Size: 0x04
	int item_expire_time_2_17_2C289E402F31320B7CD1A2280F924AF2; // Offset: 0x44 // Size: 0x04
	int spec_show_18_7343628039FCCB48034FE4F90615C917; // Offset: 0x48 // Size: 0x04
	int item_show_type_2_19_7DAEB00075BA33E81E3AA8B80DFC58E2; // Offset: 0x4c // Size: 0x04
	int item_num_1_20_58120B40141A9A27093476770B708A51; // Offset: 0x50 // Size: 0x04
};

