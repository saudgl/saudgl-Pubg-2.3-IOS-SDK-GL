#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: AnimBlueprintGeneratedClass wingmanAnimationBP_DT.wingmanAnimationBP_DT_C
// Size: 0x4f8 // Inherited bytes: 0x3c0
struct UwingmanAnimationBP_DT_C : UAnimInstance {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x3c0 // Size: 0x08
	struct FAnimNode_Root AnimGraphNode_Root_2C92ABEF44108DF4306768A9A8900956; // Offset: 0x3c8 // Size: 0x50
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_94AB669544B9B14331BD1DBCC1F1B588; // Offset: 0x418 // Size: 0x70
	struct FAnimNode_Slot AnimGraphNode_Slot_8CFE89D84A15090307F81DAECC426213; // Offset: 0x488 // Size: 0x70

	// Functions

	// Object Name: Function wingmanAnimationBP_DT.wingmanAnimationBP_DT_C.OnNotifyEnd_4D0DB2A34960896103FFF0A80C92D902
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnNotifyEnd_4D0DB2A34960896103FFF0A80C92D902(struct FName NotifyName); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function wingmanAnimationBP_DT.wingmanAnimationBP_DT_C.OnNotifyBegin_4D0DB2A34960896103FFF0A80C92D902
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnNotifyBegin_4D0DB2A34960896103FFF0A80C92D902(struct FName NotifyName); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function wingmanAnimationBP_DT.wingmanAnimationBP_DT_C.OnInterrupted_4D0DB2A34960896103FFF0A80C92D902
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnInterrupted_4D0DB2A34960896103FFF0A80C92D902(struct FName NotifyName); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function wingmanAnimationBP_DT.wingmanAnimationBP_DT_C.OnBlendOut_4D0DB2A34960896103FFF0A80C92D902
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnBlendOut_4D0DB2A34960896103FFF0A80C92D902(struct FName NotifyName); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function wingmanAnimationBP_DT.wingmanAnimationBP_DT_C.OnCompleted_4D0DB2A34960896103FFF0A80C92D902
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnCompleted_4D0DB2A34960896103FFF0A80C92D902(struct FName NotifyName); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function wingmanAnimationBP_DT.wingmanAnimationBP_DT_C.BlueprintBeginPlay
	// Flags: [Event|Public|BlueprintEvent]
	void BlueprintBeginPlay(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function wingmanAnimationBP_DT.wingmanAnimationBP_DT_C.OnHallWingmanAnimPlay_Event_1
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnHallWingmanAnimPlay_Event_1(); // Offset: 0x103df3e6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function wingmanAnimationBP_DT.wingmanAnimationBP_DT_C.ExecuteUbergraph_wingmanAnimationBP_DT
	// Flags: [None]
	void ExecuteUbergraph_wingmanAnimationBP_DT(int EntryPoint); // Offset: 0x103df3e6c // Return & Params: Num(1) Size(0x4)
};

