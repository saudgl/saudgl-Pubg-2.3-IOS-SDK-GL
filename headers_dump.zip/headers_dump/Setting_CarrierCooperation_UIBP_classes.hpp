#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Setting_CarrierCooperation_UIBP.Setting_CarrierCooperation_UIBP_C
// Size: 0x2b8 // Inherited bytes: 0x260
struct USetting_CarrierCooperation_UIBP_C : UUserWidget {
	// Fields
	struct UButton* Button_Hide_Tips; // Offset: 0x260 // Size: 0x08
	struct UButton* Button_Tips; // Offset: 0x268 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_4; // Offset: 0x270 // Size: 0x08
	struct UImage* Image_2; // Offset: 0x278 // Size: 0x08
	struct UImage* Image_6; // Offset: 0x280 // Size: 0x08
	struct UCanvasPanel* Panel; // Offset: 0x288 // Size: 0x08
	struct UCanvasPanel* Panel_Tips; // Offset: 0x290 // Size: 0x08
	struct UCanvasPanel* Panel_Tips2; // Offset: 0x298 // Size: 0x08
	struct UTextBlock* Text_Tips; // Offset: 0x2a0 // Size: 0x08
	struct UTextBlock* TextBlock_2; // Offset: 0x2a8 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_1; // Offset: 0x2b0 // Size: 0x08
};

