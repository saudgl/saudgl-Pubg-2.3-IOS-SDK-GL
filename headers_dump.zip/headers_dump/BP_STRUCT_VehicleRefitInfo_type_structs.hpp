#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: UserDefinedStruct BP_STRUCT_VehicleRefitInfo_type.BP_STRUCT_VehicleRefitInfo_type
// Size: 0xa0 // Inherited bytes: 0x00
struct FBP_STRUCT_VehicleRefitInfo_type {
	// Fields
	int cost_num1_0_206D9D404A460C770DD906380BC58481; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString unlock_part_list_1_154E4640205F8CA9261052710E193D64; // Offset: 0x08 // Size: 0x10
	int cost_num2_5_206E9D804A460C780DD9063F0BC58482; // Offset: 0x18 // Size: 0x04
	int cost_id2_6_69AB5CC07C73718975D5265F08BC42F2; // Offset: 0x1c // Size: 0x04
	int vehicle_group_id_8_28A4BD0014BDAA3A35B5E24106F2D5E4; // Offset: 0x20 // Size: 0x04
	int level_9_406ABD00274B124A3D84959D01EC2D9C; // Offset: 0x24 // Size: 0x04
	int cost_id1_11_69AA5C807C73718875D5265808BC42F1; // Offset: 0x28 // Size: 0x04
	int vehicle_id_14_12DD9A006C12A260363420170D9E9004; // Offset: 0x2c // Size: 0x04
	int VehicleShapeID_15_1C46A68016CA3E7862FCD8770C15F554; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
	struct FString DefaultStyleList_16_42E513804A54486A3C87203A06970FC4; // Offset: 0x38 // Size: 0x10
	int CameraMapID_17_008BD40017FB573E1D5C69DF09B42634; // Offset: 0x48 // Size: 0x04
	char pad_0x4C[0x4]; // Offset: 0x4c // Size: 0x04
	struct FString des_18_2CE9E60030AFF29C7BC43AC30121D423; // Offset: 0x50 // Size: 0x10
	int levelShowedInStore_19_0F3E688048D05E406085DB75090EB705; // Offset: 0x60 // Size: 0x04
	char pad_0x64[0x4]; // Offset: 0x64 // Size: 0x04
	struct FString levelIcon_20_3B181F40595EF03B0759382D0DA1167E; // Offset: 0x68 // Size: 0x10
	int levelShowRefit_21_62A703C06E7AA2A73D47FB960412BC34; // Offset: 0x78 // Size: 0x04
	char pad_0x7C[0x4]; // Offset: 0x7c // Size: 0x04
	struct FString big_icon_22_6C9A25804E63836E6E62E43101E7E53E; // Offset: 0x80 // Size: 0x10
	struct FString StaticMeshPath_23_08D3F7804FBB3CE866105B0D080582D8; // Offset: 0x90 // Size: 0x10
};

